"""Model-free consistency checks inside a single venue's event.

These need no forecast: a violation is a Dutch book against quoted prices.
  - sum_bid:  mutually exclusive outcomes whose YES bids sum above 1 (buy every NO)
  - sum_ask:  exhaustive outcomes whose YES asks sum below 1 (buy every YES)
  - ladder:   "at least k" / "above k" markets where a stricter threshold bids above
              a looser one's ask
  - deadline: "by <date>" markets where an earlier deadline bids above a later one's ask
"""

from __future__ import annotations

import re

from pmpol.models import Event, Market, Signal
from pmpol.venues import info

MODULE = "constraints"


def _live(e: Event) -> list[Market]:
    return [m for m in e.markets if m.active and m.bid is not None and m.ask is not None and m.ask > 0]


def _is_exhaustive(e: Event, live: list[Market]) -> bool:
    """Whether the live outcomes cover every possibility, so that buying all YES pays 1.

    Only trusted when a catch-all bucket is itself tradeable; placeholder "Other" or
    "Person A" markets that are not open mean some outcomes cannot be bought.
    """
    labels = [m.outcome.lower() for m in live]
    if info(e.venue).exhaustive_rule == "other":
        return any(re.fullmatch(r"(any )?other( result| party| candidate)?", lab.strip()) for lab in labels)
    joined = " ".join(labels)
    return bool(re.search(r"\b(below|above|other|less than|more than)\b", joined))


def check_sums(e: Event, min_edge: float = 0.005) -> list[Signal]:
    if not e.mutually_exclusive:
        return []
    ms = _live(e)
    if len(ms) < 2:
        return []
    out = []
    # Buying NO on all n outcomes costs sum(1 - bid); at most one YES, so payoff >= n - 1.
    margin = sum(m.bid for m in ms) - 1 - sum(m.taker_fee(m.bid) for m in ms)
    if margin >= min_edge:
        out.append(Signal(MODULE, "sum_bid", e.key, round(margin, 4), {
            "title": e.title, "legs": [(m.market_id, m.outcome, m.bid, m.bid_size) for m in ms]}))
    if _is_exhaustive(e, ms):
        margin = 1 - sum(m.ask for m in ms) - sum(m.taker_fee(m.ask) for m in ms)
        if margin >= min_edge:
            out.append(Signal(MODULE, "sum_ask", e.key, round(margin, 4), {
                "title": e.title, "legs": [(m.market_id, m.outcome, m.ask, m.ask_size) for m in ms]}))
    return out


_THRESHOLD = re.compile(
    r"^(?:at least|above|more than|over)\s+\$?([\d,.]+)\s*(k|m|b|thousand|million|billion|trillion)?\b", re.I)
_UNITS = {"k": 1e3, "thousand": 1e3, "m": 1e6, "million": 1e6, "b": 1e9, "billion": 1e9, "trillion": 1e12}


def threshold(m: Market) -> float | None:
    """Lower bound of an "X above k" market, from structured strikes when available."""
    if m.strike_type in ("greater", "greater_or_equal") and m.floor_strike is not None:
        return m.floor_strike
    if m.strike_type:
        return None
    hit = _THRESHOLD.match(m.outcome.strip())
    if not hit:
        return None
    unit = (hit.group(2) or "").lower()
    return float(hit.group(1).replace(",", "")) * _UNITS.get(unit, 1.0)


def _underlying(m: Market) -> str:
    """Rule text with numbers masked: rungs of one ladder differ only in their threshold."""
    first = (m.rules or m.question).split("\n", 1)[0]
    return re.sub(r"\$?[\d][\d,.]*\s*(?:k|m|b|thousand|million|billion|trillion)?\b", "#", first, flags=re.I)


def check_ladder(e: Event, min_edge: float = 0.005) -> list[Signal]:
    """P(X >= k) must not increase with k, for markets on the same underlying X."""
    groups: dict[str, list[tuple[float, Market]]] = {}
    for m in _live(e):
        k = threshold(m)
        if k is not None:
            groups.setdefault(_underlying(m), []).append((k, m))
    out = []
    for rungs in groups.values():
        if len(rungs) > 1:
            out += _monotone(e, sorted(rungs, key=lambda t: t[0]), "ladder", min_edge)
    return out


def check_deadlines(e: Event, min_edge: float = 0.005) -> list[Signal]:
    """For "... by <date>?" events, an earlier deadline cannot be likelier than a later one."""
    if e.mutually_exclusive or not re.search(r"\bby\b", e.title, re.I):
        return []
    rungs = [(m.close_time, m) for m in _live(e) if m.close_time]
    if len({t for t, _ in rungs}) != len(rungs):
        return []
    # Sorted latest-first, so probabilities should be non-increasing along the list.
    return _monotone(e, sorted(rungs, key=lambda t: t[0], reverse=True), "deadline", min_edge)


def _monotone(e: Event, rungs: list[tuple], kind: str, min_edge: float) -> list[Signal]:
    """`rungs` are ordered so that each event implies the earlier ones (prob non-increasing).

    Checks every pair and reports the widest violation per event.
    """
    best = None
    for i, (_, looser) in enumerate(rungs):
        for _, stricter in rungs[i + 1:]:
            # Sell the stricter YES at its bid, buy the looser YES at its ask.
            margin = stricter.bid - looser.ask - stricter.taker_fee(stricter.bid) - looser.taker_fee(looser.ask)
            if margin >= min_edge and (best is None or margin > best[0]):
                best = (margin, looser, stricter)
    if best is None:
        return []
    margin, looser, stricter = best
    return [Signal(MODULE, kind, e.key, round(margin, 4), {
        "title": e.title,
        "buy": (looser.market_id, looser.outcome, looser.ask, looser.ask_size),
        "sell": (stricter.market_id, stricter.outcome, stricter.bid, stricter.bid_size),
    })]


def scan(events, min_edge: float = 0.005) -> list[Signal]:
    out = []
    for e in events:
        out += check_sums(e, min_edge) + check_ladder(e, min_edge) + check_deadlines(e, min_edge)
    return sorted(out, key=lambda s: -s.edge)
