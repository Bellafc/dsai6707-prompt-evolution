"""Key assumptions: judgements the system relies on, registered with why, how solid, what would
overturn them and when to review them (Heuer & Pherson's Key Assumptions Check).

Proofs cite the assumptions they rely on as L3 steps with ref "assumption:<id>"; `impact` counts how
many exported proofs cite each, so when an assumption falls we know which signals to revisit.
"""

from __future__ import annotations

import json
import tomllib
from dataclasses import dataclass, field
from datetime import date
from functools import lru_cache
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[2] / "config" / "assumptions.toml"
STATUS_ZH = {"solid": "穩固", "caveated": "有保留", "unsupported": "沒有根據"}


@dataclass
class Assumption:
    id: str
    statement: str
    basis: str
    status: str
    falsified_if: str
    check: str
    review_by: str
    used_in: list[str] = field(default_factory=list)

    def overdue(self, today: date) -> bool:
        return date.fromisoformat(self.review_by) < today


@lru_cache(maxsize=1)
def load(path: Path = CONFIG) -> dict[str, Assumption]:
    with open(path, "rb") as f:
        return {a["id"]: Assumption(**a) for a in tomllib.load(f)["assumption"]}


def cite(proof, *ids: str) -> list[str]:
    """Add one L3 step per assumption the proof relies on; returns the step ids for `inputs`.
    Assumptions that are not solid also become caveats."""
    reg = load()
    out = []
    for aid in ids:
        a = reg[aid]  # an unknown id is a programming error
        sid = f"assumption:{aid}"
        if any(s.id == sid for s in proof.steps):
            out.append(sid)
            continue
        proof.add("L3", f"關鍵假設（{STATUS_ZH[a.status]}）：{a.statement}", f"config/assumptions.toml#{aid}",
                  kind="rule", id=sid)
        proof.result.setdefault("assumptions", []).append(aid)
        if a.status != "solid":
            proof.caveats.append(f"依賴{STATUS_ZH[a.status]}的假設「{aid}」：{a.falsified_if}時要重新檢查。")
        out.append(sid)
    return out


def impact(proof_rows: list[dict]) -> dict[str, int]:
    """How many exported proofs cite each assumption."""
    counts = {aid: 0 for aid in load()}
    for row in proof_rows:
        p = row.get("proof", row)
        for aid in (p.get("result") or {}).get("assumptions", []):
            counts[aid] = counts.get(aid, 0) + 1
    return counts


def render(proof_rows: list[dict], today: date) -> str:
    n = impact(proof_rows)
    L = [f"# 關鍵假設 — {today.isoformat()}", "",
         "系統依賴、但每次執行不會檢查的判斷（方法：Heuer & Pherson 的關鍵假設檢查）。"
         "「引用數」是目前的推理證明中有幾份依賴它：假設一旦被推翻，就是這些訊號要重新看。", "",
         "| 假設 | 狀態 | 引用數 | 什麼情況會推翻 | 怎麼檢查 | 下次檢查 |", "|---|---|---|---|---|---|"]
    for a in sorted(load().values(), key=lambda a: (-n.get(a.id, 0), a.id)):
        due = f"⚠️ {a.review_by}（已過期）" if a.overdue(today) else a.review_by
        L.append(f"| `{a.id}`：{a.statement} | {STATUS_ZH[a.status]} | {n.get(a.id, 0):,} | {a.falsified_if} | "
                 f"{a.check} | {due} |")
    return "\n".join(L) + "\n"


def load_proof_rows(paths: list[Path]) -> list[dict]:
    rows = []
    for p in paths:
        if p.exists():
            data = json.loads(p.read_text())
            rows += data if isinstance(data, list) else data.get("signals", [])
    return rows
