"""Proof objects: the visible reasoning chain behind every L5 inference.

Each step names its knowledge layer (L0-L5), what it says, where it comes from (a fact id, a data
series, or a URL) and the time it refers to. The plain-language explanation is generated from the
steps, never written separately, so the text cannot claim more than the chain supports.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

GROUNDING_LAYERS = ("L0", "L1", "L2", "L3", "L4")

# ICD 203 (US Intelligence Community analytic standards) likelihood bands; confidence is a separate axis.
ICD203_BANDS = ((0.05, "幾乎不可能 almost no chance"), (0.20, "非常不可能 very unlikely"), (0.45, "不太可能 unlikely"),
                (0.55, "差不多一半 roughly even chance"), (0.80, "可能 likely"), (0.95, "非常可能 very likely"),
                (1.01, "幾乎確定 almost certain"))


def likelihood(p: float) -> str:
    """ICD 203 wording for a probability, e.g. 0.14 -> "非常不可能 very unlikely"."""
    return next(label for top, label in ICD203_BANDS if p < top)


STEP_KINDS = ("data", "rule", "match", "logic", "caveat")


@dataclass(frozen=True)
class Step:
    layer: str  # "L0".."L5"
    text: str
    ref: str = ""  # knowledge-base fact id, data series ("fred:UNRATE"), or URL
    as_of: str = ""  # period or date the step refers to
    kind: str = "data"  # data (an observation), rule (a definition or law), match (an identification), logic
    id: str = ""  # unique within the proof; steps without one feed the conclusion directly
    inputs: tuple[str, ...] = ()  # ids of the steps this one is derived from (PROV wasDerivedFrom)


@dataclass
class Proof:
    title: str
    conclusion: str
    steps: list[Step] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)
    result: dict[str, Any] = field(default_factory=dict)  # machine-readable outcome
    layer: str = "L5"
    # Analysis of competing hypotheses (Heuer), lite: other explanations of the same observation and
    # whether the data supports them. Each: {"hypothesis", "verdict": supports|against|unchecked, "evidence"}.
    alternatives: list[dict[str, str]] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)  # PROV-style: generated_at, generator (module, git sha)

    @property
    def grounded(self) -> bool:
        """True when the conclusion traces back to at least one L0-L4 step through the step graph.
        A conclusion resting only on system inferences is an ungrounded claim and is labelled as such."""
        g = self.graph()
        parents: dict[str, list[str]] = {}
        for e in g["edges"]:
            parents.setdefault(e["target"], []).append(e["source"])
        layer = {n["id"]: n["layer"] for n in g["nodes"]}
        seen, stack = set(), ["conclusion"]
        while stack:
            for p in parents.get(stack.pop(), []):
                if p not in seen:
                    seen.add(p)
                    stack.append(p)
        return any(layer.get(i) in GROUNDING_LAYERS for i in seen)

    def alt(self, hypothesis: str, verdict: str, evidence: str) -> "Proof":
        self.alternatives.append({"hypothesis": hypothesis, "verdict": verdict, "evidence": evidence})
        return self

    def add(self, layer: str, text: str, ref: str = "", as_of: str = "", kind: str | None = None, id: str = "",
            inputs: tuple[str, ...] = ()) -> "Proof":
        """Append a step. Without an explicit kind, L0/L3 steps are rules, L5 steps logic, the rest data."""
        kind = kind or ("rule" if layer in ("L0", "L3") else "logic" if layer == "L5" else "data")
        self.steps.append(Step(layer, text, ref, str(as_of), kind, id, tuple(inputs)))
        return self

    def check(self) -> list[str]:
        """Structural problems: unknown layers or kinds, duplicate ids, inputs that point nowhere."""
        out, ids = [], [s.id for s in self.steps if s.id]
        if len(ids) != len(set(ids)):
            out.append("duplicate step id")
        for s in self.steps:
            if s.layer not in ("L0", "L1", "L2", "L3", "L4", "L5"):
                out.append(f"bad layer {s.layer}")
            if s.kind not in STEP_KINDS:
                out.append(f"bad kind {s.kind}")
            out += [f"{s.id or s.text[:20]}: unknown input {i}" for i in s.inputs if i not in ids]
            if s.layer == "L4" and not (s.ref and s.as_of):  # team rule: a market observation names source and time
                out.append(f"{s.id or s.text[:20]}: L4 step without a source or time")
        return out

    def graph(self) -> dict[str, Any]:
        """Nodes and edges for the viewer. Steps nobody else uses feed the conclusion."""
        nodes = [{"id": s.id or f"s{i}", "layer": s.layer, "kind": s.kind, "text": s.text, "ref": s.ref,
                  "as_of": s.as_of} for i, s in enumerate(self.steps)]
        used = {i for s in self.steps for i in s.inputs}
        edges = [{"source": i, "target": s.id or f"s{k}"} for k, s in enumerate(self.steps) for i in s.inputs]
        edges += [{"source": n["id"], "target": "conclusion"} for n in nodes if n["id"] not in used]
        nodes.append({"id": "conclusion", "layer": self.layer, "kind": "conclusion", "text": self.conclusion,
                      "ref": "", "as_of": ""})
        return {"nodes": nodes, "edges": edges}

    def confidence(self) -> tuple[str, list[str]]:
        """Analytic confidence, apart from likelihood (pmpol.confidence): (high|moderate|low, reasons)."""
        from pmpol.confidence import assess

        return assess(self)

    def markdown(self) -> list[str]:
        from pmpol.confidence import describe

        head = f"**{self.title}**：{self.conclusion}" + ("" if self.grounded else "（⚠️ 無根推論）")
        lines = [head, "", describe(*self.confidence()), "", "| 層 | 推理步驟 | 來源 | 時間 |", "|---|---|---|---|"]
        for s in self.steps:
            lines.append(f"| {s.layer} | {s.text} | {s.ref} | {s.as_of} |")
        lines.append(f"| {self.layer} | **結論**：{self.conclusion} | 本系統 | |")
        if self.caveats:
            lines += [""] + [f"- 注意：{c}" for c in self.caveats]
        if self.alternatives:
            zh = {"supports": "資料支持", "against": "資料不支持", "unchecked": "未檢查"}
            lines += ["", "| 其他可能的解釋 | 判斷 | 依據 |", "|---|---|---|"]
            lines += [f"| {a['hypothesis']} | {zh.get(a['verdict'], a['verdict'])} | {a['evidence']} |"
                      for a in self.alternatives]
        return lines + [""]

    def to_dict(self) -> dict[str, Any]:
        level, reasons = self.confidence()
        return {**asdict(self), "grounded": self.grounded, "analytic_confidence": level,
                "confidence_reasons": reasons}
