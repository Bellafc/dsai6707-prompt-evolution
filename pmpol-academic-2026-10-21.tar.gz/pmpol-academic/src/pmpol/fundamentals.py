"""Fundamentals: the midterm reference class conditioned on the economy (2026-10-05).

The outside view (pmpol.reference) treats every midterm since 1946 alike. Political science conditions it on the
economy (Tufte 1975, "Determinants of the Outcomes of Midterm Congressional Elections"): the president's party loses
fewer seats when real incomes grow. The model is fixed before looking at the fit, to keep 16 data points from
choosing their own story:

  change in the president's party's House seats = a + b * x
  x = growth of real disposable personal income per capita (BEA via FRED, A229RX0), January-August of the election
      year over the same months a year earlier (the months known before a November election)

Sample: the midterms the income series covers (1962-2022). Presidential approval, Tufte's other variable, has no
source we can use, so it is left out and its absence is a stated limitation. The prediction for the coming midterm
comes with a t predictive interval, and the probability that the president's party keeps the majority is
P(change >= majority - seats now). An L5 inference from L2 history, never a fact; shown next to the market and the
unconditioned outside view.
"""

from __future__ import annotations

import csv
import io
import math
import statistics
from dataclasses import dataclass
from datetime import date
from pathlib import Path

SERIES = "A229RX0"
URL = f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={SERIES}"
UA = "pmpol/0.1 (https://github.com/bellafc/polymarket_politics; research, read-only)"
DATA = Path("data/fundamentals")
MONTHS = 8  # January to August
FACT = "us.house.midterm_fundamentals_model"


def fetch(cache: Path = DATA, get=None, today: date | None = None) -> dict[str, float]:
    """Monthly values (YYYY-MM -> value), cached per day."""
    path = cache / f"{SERIES}_{(today or date.today()).isoformat()}.csv"
    if path.exists():
        text = path.read_text(encoding="utf-8")
    else:
        if get is None:
            import httpx

            def get(url):
                r = httpx.get(url, timeout=60, headers={"User-Agent": UA}, follow_redirects=True)
                r.raise_for_status()
                return r.text
        text = get(URL)
        cache.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    out = {}
    for row in csv.DictReader(io.StringIO(text)):
        v = row.get(SERIES)
        if v and v != ".":
            out[row["observation_date"][:7]] = float(v)
    return out


def income_growth(monthly: dict[str, float], year: int, months: int = MONTHS) -> float | None:
    """Percent growth of the January..`months` average of `year` over the same months of the year before."""
    cur = [monthly.get(f"{year}-{m:02d}") for m in range(1, months + 1)]
    prev = [monthly.get(f"{year - 1}-{m:02d}") for m in range(1, months + 1)]
    if None in cur or None in prev:
        return None
    return 100 * (statistics.mean(cur) / statistics.mean(prev) - 1)


def _t_quantile(p: float, df: int) -> float:
    """Student t quantile (scipy when available; a Cornish-Fisher approximation otherwise)."""
    try:
        from scipy.stats import t

        return float(t.ppf(p, df))
    except ImportError:  # pragma: no cover
        z = statistics.NormalDist().inv_cdf(p)
        return z + (z ** 3 + z) / (4 * df)


def _t_cdf(x: float, df: int) -> float:
    try:
        from scipy.stats import t

        return float(t.cdf(x, df))
    except ImportError:  # pragma: no cover
        return statistics.NormalDist().cdf(x * (1 - 1 / (4 * df)))


@dataclass
class Model:
    years: list[int]
    x: list[float]
    y: list[float]
    a: float
    b: float
    se_b: float
    sigma: float  # residual standard deviation
    r2: float

    @property
    def n(self) -> int:
        return len(self.x)

    def predict(self, x0: float) -> tuple[float, float]:
        """(mean, predictive standard error) at x0."""
        mx = statistics.mean(self.x)
        sxx = sum((xi - mx) ** 2 for xi in self.x)
        return self.a + self.b * x0, self.sigma * math.sqrt(1 + 1 / self.n + (x0 - mx) ** 2 / sxx)

    def p_at_least(self, x0: float, needed: float) -> float:
        """P(change >= needed) under the t predictive distribution."""
        m, se = self.predict(x0)
        if se == 0:  # a perfect fit: the prediction is certain
            return 1.0 if m >= needed else 0.0
        return 1 - _t_cdf((needed - m) / se, self.n - 2)

    def interval(self, x0: float, level: float = 0.95) -> tuple[float, float]:
        m, se = self.predict(x0)
        q = _t_quantile(0.5 + level / 2, self.n - 2)
        return m - q * se, m + q * se


def fit(rows: list[dict], monthly: dict[str, float]) -> Model:
    """rows: the midterm reference class (us.house.midterm_presidents_party_change value["rows"])."""
    pts = [(r["year"], g, r["change"]) for r in rows if (g := income_growth(monthly, r["year"])) is not None]
    years, x, y = [p[0] for p in pts], [p[1] for p in pts], [float(p[2]) for p in pts]
    mx, my = statistics.mean(x), statistics.mean(y)
    sxx = sum((xi - mx) ** 2 for xi in x)
    b = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y)) / sxx
    a = my - b * mx
    resid = [yi - (a + b * xi) for xi, yi in zip(x, y)]
    sigma = math.sqrt(sum(e * e for e in resid) / (len(x) - 2))
    sst = sum((yi - my) ** 2 for yi in y)
    return Model(years, x, y, a, b, sigma / math.sqrt(sxx), sigma, 1 - sum(e * e for e in resid) / sst)


def kb_yaml(m: Model, year: int, x0: float, needed: int, recorded: date, last_month: str) -> str:
    import yaml

    lo, hi = m.interval(x0)
    mean, _ = m.predict(x0)
    t_b = m.b / m.se_b
    fact = {
        "id": FACT, "layer": "L2", "subject": "U.S. midterm elections", "predicate": "seat_change_given_income_growth",
        "value": {"model": "change = a + b * income growth (Tufte 1975, without approval)",
                  "sample": f"{m.years[0]}-{m.years[-1]}, {m.n} midterms", "a": round(m.a, 2), "b": round(m.b, 2),
                  "b_se": round(m.se_b, 2), "b_t": round(t_b, 2), "residual_sd": round(m.sigma, 1),
                  "r2": round(m.r2, 3), f"x_{year}": round(x0, 2), f"predicted_{year}": round(mean, 1),
                  f"interval95_{year}": [round(lo, 1), round(hi, 1)],
                  f"p_change_at_least_{needed}": round(m.p_at_least(x0, needed), 3),
                  "points": [{"year": yr, "income_growth": round(xi, 2), "change": int(yi)}
                             for yr, xi, yi in zip(m.years, m.x, m.y)]},
        "source": {"title": "BEA real disposable personal income per capita (FRED A229RX0), with the midterm "
                            "reference class", "url": URL, "license": "public domain (U.S. government data via FRED)"},
        "admiralty": "B2", "status": "proposed", "recorded_at": recorded,
        "derived_from": ["us.house.midterm_presidents_party_change"],
        "note": f"Income growth is January-{MONTHS:02d} over the same months a year earlier (data through "
                f"{last_month}). Model fixed before fitting; presidential approval left out (no usable source). "
                "Generated by `pmpol fundamentals --write-kb`."}
    return ("# Generated by `pmpol fundamentals --write-kb`; review before marking the facts reviewed.\n"
            + yaml.safe_dump({"facts": [fact]}, allow_unicode=True, sort_keys=False, width=120,
                             default_flow_style=None))
