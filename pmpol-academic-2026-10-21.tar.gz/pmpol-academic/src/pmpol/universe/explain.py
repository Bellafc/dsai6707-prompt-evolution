"""Proofs for universe signals: why the system says two quotes are inconsistent.

Chain for a relation signal:

  L1 contract terms (each leg's settlement rules) ─┐
  L0/L1 knowledge-base context (election date…)  ──┼─► L5 match (same contest?) ─► L5 template logic ─┐
  L4 quotes (bid/ask/size/fee, snapshot time)  ───────────────────────────────────────────────────────┴─► conclusion

The text of every step is generated from data; caveats list everything that would make the
signal not tradeable or not certain (text matches, different customer regions, assumed fees, depth).
"""

from __future__ import annotations

import hashlib

from pmpol.assumptions import cite
from pmpol.kb import KnowledgeBase
from pmpol.models import Market, Relation, Signal
from pmpol.proof import Proof
from pmpol.propositions.relations import label as onto_label
from pmpol.propositions.resolution import STATUS_ZH
from pmpol.propositions.relations import logic as onto_logic
from pmpol.universe.index import Universe
from pmpol.venues import ASSUMED_FEES, info, source_url

TEMPLATE_LOGIC = {
    "cross_venue_winner": "同一場選舉、同一個政黨或候選人：兩邊的 YES 都在「這個政黨／候選人勝選」時付 1，所以兩邊價格應該相等。",
    "cross_venue_nomination": "同一場初選、同一位候選人：兩邊的 YES 都在「這位候選人獲得提名」時付 1，所以價格應該相等。",
    "cross_venue_control": "同一個議院、同一個政黨：兩邊的 YES 都在「這個政黨取得控制權」時付 1，所以價格應該相等。",
    "cross_venue_seat_count": "一邊的一個席次區間，等於另一邊幾個相鄰區間的聯集；付款條件相同，所以價格總和應該相等。",
    "cross_venue_margin": "「贏 k 分以上」等於從 k 分開始所有勝差區間的總和；兩邊同一個區間則直接相等。",
    "cross_venue_combo": "州長＋參議員組合的同一格，在兩個平台上付款條件相同，所以價格應該相等。",
    "margin_implies_winner": "贏 k 分以上 ⇒ 一定勝選，所以「贏 k 分以上」的價格不能高於「勝選」。",
    "margin_sum_winner": "勝選 ⇔ 勝差落在其中一個區間（區間互不重疊，而且涵蓋所有勝選情況），所以各區間價格的總和應該等於勝選價格。",
    "combo_marginal": "某黨贏得這一席 ⇔ 組合裡含這個結果的兩格之一發生，所以這兩格的價格總和應該等於單場勝選價格。",
    "cross_venue_text": "兩個市場標題高度相似、截止時間接近，視為同一件事。這是文字配對，必須人工核對兩邊的結算規則。",
    "cross_venue_deadline": "較早的截止日之前發生 ⇒ 較晚的截止日之前也一定發生，所以較早那個的價格不能高於較晚那個。",
}
EVENT_LOGIC = {
    "sum_bid": "這些選項互斥（最多一個成真）。買進每一個選項的 NO，最少拿回 n−1；成本是 Σ(1−bid)。所以 YES 的 bid 總和超過 1 就是穩賺。",
    "sum_ask": "這些選項互斥而且涵蓋所有可能（恰好一個成真）。買進每一個選項的 YES 一定拿回 1，所以 ask 總和低於 1 就是穩賺。",
    "ladder": "門檻較嚴的（例如「至少 10」）成真 ⇒ 門檻較寬的（「至少 5」）也成真，所以嚴的價格不能高於寬的。",
    "deadline": "較早截止日之前發生 ⇒ 較晚截止日之前也發生，所以較早的價格不能高於較晚的。",
}
MATCH_ZH = {"rule": "結構規則", "surname": "候選人姓氏", "text": "標題相似度（待人工確認）",
            "entity": "人物的 Wikidata 身分", "name": "同一場選舉裡相同的候選人姓名", "label": "選項標籤相同（政黨名單或單名）",
            "descriptor": "事件描述詞（動作＋論元）", "title": "整理後的標題相同"}


def _leg_keys(legs) -> str:
    """Market ids of a side, without prices or sizes: a side is one leg [id, label, price, size] or a list of them."""
    if not legs:
        return ""
    if isinstance(legs[0], (list, tuple)):
        return ",".join(sorted(str(x[0]) for x in legs))
    return str(legs[0])


def signal_id(s: Signal) -> str:
    """Stable across snapshots: the same violation (same legs, same direction) keeps its id when prices move,
    so a signal can be followed over time (new, persisting, gone)."""
    p = s.payload
    raw = (f"{s.module}|{s.kind}|{s.subject}|{p.get('trade', '')}|{_leg_keys(p.get('sell'))}|{_leg_keys(p.get('buy'))}"
           f"|{_leg_keys(p.get('legs'))}")
    return f"{s.kind}:{hashlib.sha1(raw.encode()).hexdigest()[:10]}"


def _pct(x: float | None) -> str:
    return "—" if x is None else f"{100 * x:.1f}%"


def _rules_step(p: Proof, m: Market, u: Universe) -> str:
    sid = f"rules:{m.key}"
    e = u.events.get(u.market_event.get(m.key, ""))
    rules = " ".join((m.rules or "").split())
    text = f"{info(m.venue).label}「{e.title if e else m.question}」選項「{m.outcome or 'Yes'}」"
    text += f"結算規則：{rules[:280]}{'…' if len(rules) > 280 else ''}" if rules else "（平台資料沒有提供規則文字）"
    if m.close_time:
        text += f"；截止 {m.close_time[:10]}"
    p.add("L1", text, source_url(m), m.close_time[:10] if m.close_time else "", kind="rule", id=sid)
    return sid


def _quote_step(p: Proof, m: Market, side: str, price: float, size, observed_at: str) -> str:
    qid = f"quote:{side}:{m.key}"
    fee = m.taker_fee(price)
    action = "在 bid 賣出 YES（等於買進 NO）" if side == "sell" else "在 ask 買進 YES"
    size_txt = "" if size is None else f"，這個價位可成交約 {size:,.0f} 份"
    p.add("L4", f"{info(m.venue).code} {m.outcome or 'Yes'}：bid {_pct(m.bid)} / ask {_pct(m.ask)}；"
                f"{action} {_pct(price)}{size_txt}；taker 費 {_pct(fee)}"
                + ("（假設值）" if m.venue in ASSUMED_FEES else ""),
          source_url(m), observed_at, kind="data", id=qid)
    return qid


def kb_context(kb: KnowledgeBase | None, tags) -> list:
    """Knowledge-base facts that pin down which contest a race key refers to."""
    if kb is None or tags is None or tags.topic not in ("elections_us", "elections_intl"):
        return []  # election facts only for election questions (a 2026 inflation market is not about the vote)
    ids = []
    if tags.country == "United States" and tags.year == 2026 and tags.stage.startswith("general"):
        ids.append("us.election.2026_general")
        if tags.measure == "control" and tags.office == "senate":
            ids += ["us.senate.seats", "us.senate.vp_tiebreak", "us.vice_president"]
        if tags.measure == "control" and tags.office == "house":
            ids.append("us.house.majority")
    if tags.country == "Brazil" and tags.year == 2026:
        ids.append("br.election.2026_runoff" if tags.stage.startswith("runoff") else "br.election.2026_first_round")
    if tags.country == "Israel" and tags.year == 2026:
        ids.append("il.election.2026_date")
    return [kb.facts[i] for i in ids if i in kb.facts]


def _fact_step(p: Proof, f, kb: KnowledgeBase | None = None) -> str:
    sid = f"kb:{f.id}"
    status = {"reviewed": "", "proposed": "（提議中，尚未審核）", "disputed": "（有爭議）"}[f.status]
    p.add(f.layer, f"{f.subject}：{f.predicate} = {f.value}{status}", f.id, str(f.valid_from or f.recorded_at),
          kind="rule" if f.layer in ("L0", "L3") else "data", id=sid)
    for r in (kb.rivals(f.id) if kb is not None else []):  # conflicting sources side by side, not resolved
        p.caveats.append(f"「{f.id}」有不同來源的說法並列：{r.value}（{r.id}，{r.source.title}）。")
        p.result.setdefault("conflicting_facts", []).append(r.id)
    return sid


def _caveats(p: Proof, legs: list[Market], s: Signal, confidence: str = "rule") -> None:
    venues = {m.venue for m in legs}
    regions = {info(v).region for v in venues}
    if confidence != "rule":
        p.caveats.append(f"配對方式是「{MATCH_ZH.get(confidence, confidence)}」，必須人工核對兩邊的結算規則才算數。")
    if {"US", "non-US"} <= regions:
        p.caveats.append("兩邊平台的主要開放地區不同（美國／非美國），通常無法由同一個人兩邊交易；這是兩群交易者的看法差異，不是套利。")
    if venues & ASSUMED_FEES:
        p.caveats.append("有平台沒有公布手續費，這裡用每口 2 美分的保守假設。")
    near_half = [m for m in legs if m.bid is not None and m.ask is not None and 0.45 <= m.bid <= 0.5 <= m.ask <= 0.55]
    if len(legs) >= 3 and len(near_half) * 2 > len(legs):
        p.caveats.append("多數選項同時掛在 50% 上下，看起來是新市場的預設報價，還沒有真正的交易。")
    size = s.payload.get("min_size")
    if size is not None and size < 50:
        p.caveats.append(f"報價上可成交的量很小（約 {size:,.0f} 份），實際能吃到的邊際有限。")
    if any(m.spread is not None and m.spread > 0.10 for m in legs):
        p.caveats.append("至少一腿的買賣價差超過 10 個百分點，報價可能是零星掛單。")


def _legs(u: Universe, side: list) -> list[tuple[Market, float, float | None]]:
    """Payload legs are (market key, outcome, price[, size at that price])."""
    return [(u.markets[leg[0]], leg[2], leg[3] if len(leg) > 3 else None) for leg in side]


def _days_apart(a: str | None, b: str | None) -> float | None:
    from datetime import datetime, timezone

    def parse(t):
        d = datetime.fromisoformat(t.replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    if not a or not b:
        return None
    try:
        return abs((parse(a) - parse(b)).total_seconds()) / 86400
    except ValueError:
        return None


def _alternatives(p: Proof, legs: list[Market], s: Signal, confidence: str = "rule", cross_venue: bool = True) -> None:
    """Competing explanations of the same price gap, each checked against the data where possible."""
    regions = {info(m.venue).region for m in legs}
    size = s.payload.get("min_size")
    wide = [m for m in legs if m.spread is not None and m.spread > 0.10]
    thin = size is not None and size < 50
    p.alt("報價過時或太薄（不是真的能成交）", "supports" if thin or wide else ("against" if size is not None else "unchecked"),
          (f"最小可成交量 {size:,.0f} 份；" if size is not None else "沒有查訂單簿深度；")
          + (f"{len(wide)} 腿買賣價差超過 10 個百分點" if wide else "各腿價差都在 10 個百分點以內"))
    assumed = sorted({info(m.venue).label for m in legs if m.venue in ASSUMED_FEES})
    p.alt("手續費比假設的高", "supports" if assumed else "against",
          f"{'、'.join(assumed)} 的費率是假設值" if assumed else "各平台都用公布的費率計算")
    if cross_venue:
        p.alt("兩群交易者看法不同（平台開放地區不同）", "supports" if {"US", "non-US"} <= regions else "against",
              "、".join(sorted({f"{info(m.venue).code}={info(m.venue).region}" for m in legs})))
        p.alt("兩邊結算規則其實不同", "supports" if confidence == "text" else "unchecked",
              {"text": "只靠標題相似度配對", "surname": "靠候選人姓氏配對，規則文字未逐字比對"}.get(
                  confidence, "依結構規則配對；規則文字未逐字比對，見各腿 L1 步驟"))
        closes = [m.close_time for m in legs if m.close_time and m.venue != "kalshi"]  # Kalshi close is a far backstop
        spread_days = max((_days_apart(a, b) or 0 for a in closes for b in closes), default=0)
        p.alt("截止或結算時間不同", "supports" if spread_days > 45 else "against" if len(closes) >= 2 else "unchecked",
              f"非 Kalshi 各腿的截止日最多相差 {spread_days:.0f} 天" if len(closes) >= 2 else "可比較的截止日不足")
        p.alt("其中一個平台把標籤弄反", "against", "已通過疑似標籤顛倒檢查（有問題的事件會先被排除）")
    p.alt("真的定價不一致", "supports" if not (thin or wide or assumed) else "unchecked",
          "其他解釋都被資料排除時才成立；目前" + ("沒有發現其他解釋" if not (thin or wide or assumed) else "仍有其他可能"))


def _base_rate_steps(p: Proof, legs: list[Market], kb: KnowledgeBase | None) -> None:
    """Cite the L2 favourite-longshot base rate for legs priced in the tails, when we have one for that venue."""
    tails = [m for m in legs if m.mid is not None and (m.mid < 0.10 or m.mid > 0.90)]
    if not tails:
        return
    cited = []
    for venue in sorted({m.venue for m in tails}):
        f = kb.facts.get(f"calibration.{venue}.politics.h7") if kb else None
        if f is None:
            continue
        v = f.value
        parts = []
        if v.get("longshot_return") is not None:
            parts.append(f"價格 <10% 時買 YES 平均每份 {100 * v['longshot_return']:+.1f} 點")
        if v.get("favourite_return") is not None:
            parts.append(f"價格 >90% 時 {100 * v['favourite_return']:+.1f} 點")
        p.add("L2", f"歷史基準（{info(venue).label} 政治市場、截止前 7 天、{v['n']:,} 個已結算市場）："
                    + "；".join(parts) + f"；校準斜率 b = {v['slope_b']:.2f}", f.id, str(f.recorded_at), kind="data",
              id=f"base:{venue}")
        cited.append(info(venue).label)
    p.alt("已知的冷門／熱門偏差（不是新的錯價）", "supports" if cited else "unchecked",
          (f"{len(tails)} 腿落在 <10% 或 >90%；已引用 {'、'.join(cited)} 的歷史基準" if cited
           else f"{len(tails)} 腿落在 <10% 或 >90%，但這個平台還沒有校準資料"))


def _candidates() -> dict:
    """L1 candidate lists (pmpol.entities.candidates), read once per process."""
    global _CANDIDATES
    if _CANDIDATES is None:
        from pmpol.entities.candidates import load

        _CANDIDATES = load()
    return _CANDIDATES


_CANDIDATES: dict | None = None


def rule_grounds(p: Proof, r: Relation, kb: KnowledgeBase | None) -> list[str]:
    """One step per ground of the relation's inference rule (config/inference_rules.toml) and of the relation
    itself: axioms as L0 rules, knowledge-base facts in their own layer, key assumptions as L3 citations.
    A ground the knowledge base does not hold becomes a caveat. Returns the step ids."""
    if not r.template.startswith("onto:"):
        return []
    from pmpol.propositions.rules import load

    book = load()
    ids: list[str] = []
    for g in book.grounds(r.template.rsplit(":", 1)[-1], r.grounds):
        kind, _, ref = g.partition(":")
        if kind == "axiom" and ref in book.axioms:
            sid = f"axiom:{ref}"
            if not any(st.id == sid for st in p.steps):
                ax = book.axioms[ref]
                p.add("L0", f"推理規則的依據（機率公理）：{ax.statement}", f"config/inference_rules.toml#{ref}",
                      kind="rule", id=sid)
            ids.append(sid)
        elif kind == "kb" and kb is not None and ref in kb.facts:
            sid = f"kb:{ref}"
            ids.append(sid if any(st.id == sid for st in p.steps) else _fact_step(p, kb.facts[ref], kb))
        elif kind == "assumption":
            ids += cite(p, ref)
        elif kind == "data" and ref.startswith("candidates:") and (listed := _candidates().get(ref[len("candidates:"):])):
            sid = f"data:{ref}"
            if not any(st.id == sid for st in p.steps):
                c0 = listed[0]
                p.add("L1", f"大選候選人名單（提議中，次級來源）：{'、'.join(f'{c.name}（{c.party}）' for c in listed)}"
                            f"——維基百科「{c0.page.replace('_', ' ')}」{c0.section}", c0.url, c0.fetched_at,
                      kind="data", id=sid)
            ids.append(sid)
        elif kind == "data" and ref.startswith("rules:"):
            sid = f"data:{ref}"
            if not any(st.id == sid for st in p.steps):
                rules_step = next((st for st in p.steps if st.id == ref), None)
                listed = next((n for n in r.note.split("; ") if n.startswith("defined set")), "") if r.note else ""
                p.add("L1", f"規則用列舉成員定義的集合（{listed or ref}）", rules_step.ref if rules_step else "",
                      rules_step.as_of if rules_step else "", kind="data", id=sid)
            ids.append(sid)
        else:
            p.caveats.append(f"推理規則依據的「{g}」不在知識庫裡，這條關係少了一個依據。")
    return ids


def explain_relation(u: Universe, r: Relation, s: Signal, kb: KnowledgeBase | None, observed_at: str) -> Proof:
    sell, buy = _legs(u, s.payload["sell"]), _legs(u, s.payload["buy"])
    legs = [m for m, _, _ in sell + buy]
    p = Proof(f"{onto_label(r.template) or r.template}｜{r.group}", f"賣出一邊、買進另一邊，扣除手續費後每份邊際 {100 * s.edge:+.1f} 個百分點",
              result={"edge": s.edge, "template": r.template, "relation": r.kind, "confidence": r.confidence,
                      "rules": r.rules})
    rule_ids = [_rules_step(p, m, u) for m in legs]
    tags = u.tags.get(u.market_event.get(legs[0].key, ""))
    fact_ids = [_fact_step(p, f, kb) for f in kb_context(kb, tags)]
    events = sorted({u.market_event[m.key] for m in legs})
    how = MATCH_ZH.get(r.confidence, r.confidence)
    same = []
    if r.cross_venue and r.rules:
        p.add("L5", f"結算條件比對（{STATUS_ZH.get(r.rules, r.rules)}）：{r.rules_detail or '兩邊的規則沒有讀得出的共同屬性'}",
              "src/pmpol/propositions/resolution.py", kind="logic", id="rules", inputs=tuple(rule_ids))
        same = ["rules"]
    if r.cross_venue and r.rules in ("", "unverified"):  # what could not be compared still rests on the assumption
        same += cite(p, "cross_venue_rules_equivalent")
    if tags and tags.office in ("mayor", "local") and tags.topic == "elections_us" and not tags.place:
        same += cite(p, "unplaced_local_race_is_us")
    p.add("L5", f"判定是同一件事：{len(events)} 個事件都被歸到「{r.group}」"
                f"{f'（指標：{tags.measure}）' if tags else ''}；配對方式：{how}；{r.note}".rstrip("；"),
          "docs/ARCHITECTURE.md#4-全景層pmpol-universe大樓的骨架", kind="match", id="match",
          inputs=tuple(rule_ids + fact_ids + same))
    grounds = rule_grounds(p, r, kb)
    p.add("L5", f"關係（{'等價' if r.kind == 'equivalent' else '蘊含'}）：{onto_logic(r.template) or TEMPLATE_LOGIC.get(r.template, r.template)}",
          (f"config/inference_rules.toml#{r.template.rsplit(':', 1)[-1]}" if r.template.startswith("onto:")
           else f"template:{r.template}"), kind="logic", id="logic", inputs=("match", *grounds))
    quote_ids = [_quote_step(p, m, "sell", price, size, observed_at) for m, price, size in sell]
    quote_ids += [_quote_step(p, m, "buy", price, size, observed_at) for m, price, size in buy]
    total_sell, total_buy = sum(pr for _, pr, _ in sell), sum(pr for _, pr, _ in buy)
    fees = sum(m.taker_fee(pr) for m, pr, _ in sell + buy)
    fee_a = cite(p, "assumed_fees") if {m.venue for m in legs} & ASSUMED_FEES else []
    p.add("L5", f"計算：賣出那一邊的 bid 合計 {_pct(total_sell)} − 買進那一邊的 ask 合計 {_pct(total_buy)} − 手續費 {_pct(fees)}"
                f" = {100 * s.edge:+.1f} 個百分點（{s.payload.get('trade', '')}）",
          kind="logic", id="arith", inputs=tuple(["logic"] + quote_ids + fee_a))
    _caveats(p, legs, s, r.confidence)
    if r.rules == "material":
        p.caveats.insert(0, f"兩邊的結算條件有實質差異（{r.rules_detail}）：在某些情況下兩邊不會同時成立，這不一定是違反。")
    elif r.rules == "minor":
        p.caveats.append(f"兩邊的結算條件有細節差異（{r.rules_detail}），通常不影響結果。")
    _alternatives(p, legs, s, r.confidence)
    _base_rate_steps(p, legs, kb)
    return p


def explain_event_signal(u: Universe, s: Signal, observed_at: str) -> Proof:
    e = u.events[s.subject]
    pay = s.payload
    if "legs" in pay:
        side = "sell" if s.kind == "sum_bid" else "buy"
        legs = [(u.markets[f"{e.venue}:{mid}"], price, size, side) for mid, _, price, size in pay["legs"]]
    else:
        legs = [(u.markets[f"{e.venue}:{pay['sell'][0]}"], pay["sell"][2], pay["sell"][3], "sell"),
                (u.markets[f"{e.venue}:{pay['buy'][0]}"], pay["buy"][2], pay["buy"][3], "buy")]
    markets = [m for m, *_ in legs]
    p = Proof(f"{s.kind}｜{e.title}", f"單一事件內部的價格互相矛盾，扣除手續費後每組邊際 {100 * s.edge:+.1f} 個百分點",
              result={"edge": s.edge, "kind": s.kind})
    rid = _rules_step(p, markets[0], u)
    flagged = e.venue in ("polymarket", "kalshi", "limitless", "smarkets")
    basis = "平台標示為互斥" if flagged else "依標題規則判定為互斥（只有一個名額）"
    excl = [] if flagged else cite(p, "title_exclusivity")
    p.add("L5", f"結構：{basis}；{EVENT_LOGIC.get(s.kind, s.kind)}", f"constraints:{s.kind}", kind="logic", id="logic",
          inputs=(rid, *excl))
    qids = [_quote_step(p, m, side, price, size, observed_at) for m, price, size, side in legs]
    fee_a = cite(p, "assumed_fees") if e.venue in ASSUMED_FEES else []
    p.add("L5", f"計算結果：邊際 {100 * s.edge:+.1f} 個百分點（已扣手續費）", kind="logic", id="arith",
          inputs=tuple(["logic"] + qids + fee_a))
    _caveats(p, markets, s)
    _alternatives(p, markets, s, cross_venue=False)
    p.alt("這些選項其實不互斥（例如門檻階梯被誤判成分組）", "unchecked",
          "互斥判斷來自" + ("平台旗標" if e.venue in ("polymarket", "kalshi", "limitless", "smarkets") else "標題規則，請核對選項文字"))
    return p


def explain_suspect(u: Universe, event_key: str, note: str, observed_at: str) -> Proof:
    e = u.events[event_key]
    p = Proof(f"疑似標籤顛倒｜{e.title}", "這個事件的關係已排除，等人工到平台頁面確認", result={"event": event_key})
    for m in e.markets:
        if m.active:
            p.add("L4", f"{info(m.venue).code} {m.outcome}：bid {_pct(m.bid)} / ask {_pct(m.ask)}", source_url(m),
                  observed_at, kind="data", id=f"quote:{m.key}")
    p.add("L5", f"和其他平台比較：{note}", "universe/quality.py", kind="logic", id="compare",
          inputs=tuple(f"quote:{m.key}" for m in e.markets if m.active))
    p.add("L5", "判斷規則：兩黨價格都和至少兩個其他平台的中位數相差 30 個百分點以上，而且方向相反", "universe/quality.py",
          kind="rule", id="rule")
    p.caveats.append("價格只用來判斷「標籤可不可信」，不會被當成事實。")
    return p
