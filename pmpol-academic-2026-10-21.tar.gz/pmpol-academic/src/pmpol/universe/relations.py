"""Relation templates: structural rules that link markets across events and venues.

Each template scans the universe and emits `Relation`s; `check` turns a relation and the
current quotes into an executable-consistency signal. Templates are deliberately
generic (party, interval, margin, combo cell), so one rule covers hundreds of races.
"""

from __future__ import annotations

import re
from collections import defaultdict
from collections.abc import Callable, Iterable
from itertools import combinations
from pathlib import Path

from pmpol.models import Event, Market, Relation, Signal
from pmpol.universe.index import Universe, live
from pmpol.universe.outcomes import (INF, Interval, combo_cell, count_interval, kalshi_margin_rung, margin_bucket,
                                     name_key, party_of, surname)
from pmpol.venues import info, venue_order

MODULE = "relations"
Template = Callable[[Universe], Iterable[Relation]]


def _unique_by(markets: Iterable[Market], key: Callable[[Market], object]) -> dict:
    """Map key -> market, dropping keys that occur more than once (ambiguous)."""
    seen: dict = {}
    dup = set()
    for m in markets:
        k = key(m)
        if k is None:
            continue
        if k in seen:
            dup.add(k)
        seen[k] = m
    return {k: v for k, v in seen.items() if k not in dup}


def _active(e: Event) -> list[Market]:
    return [m for m in e.markets if m.active]


def _pairs(u: Universe):
    """(race, venue a, venue b) for every pair of venues that both list the race."""
    for race_key, by_venue in u.races.items():
        for a, b in combinations(sorted(by_venue, key=venue_order), 2):
            yield race_key, a, b


# --- cross-venue templates ---------------------------------------------------------

def cross_venue_winner(u: Universe) -> Iterable[Relation]:
    """Same contest, same party (or same named candidate) on two venues."""
    for race, va, vb in _pairs(u):
        for measure in ("winner", "control", "nomination"):
            for ke in u.race_events(race, va, measure):
                for pe in u.race_events(race, vb, measure):
                    kp = _unique_by(_active(ke), party_of)
                    pp = _unique_by(_active(pe), party_of)
                    matched = set()
                    for p in kp.keys() & pp.keys():
                        matched |= {kp[p].key, pp[p].key}
                        yield Relation("equivalent", [kp[p].key], [pp[p].key], f"cross_venue_{measure}", race,
                                       note=f"party {p}")
                    yield from _person_matches(ke, pe, race, measure, matched)
    # "Winner (Individual)" events list people only; a person there is the same proposition as that person in
    # the race's main event on another venue (whose other options may be parties).
    for race, by_venue in u.races.items():
        base = race.rsplit("/", 1)[0] if race.endswith("/individual") else None
        if base not in u.races:
            continue
        for va in by_venue:
            for vb in u.races[base]:
                if va == vb:
                    continue
                for ke in u.race_events(race, va, "winner"):
                    for pe in u.race_events(base, vb, "winner"):
                        yield from _person_matches(ke, pe, base, "winner", set(), note="individual-event",
                                                   people_only=True)


def _person_matches(ke: Event, pe: Event, race: str, measure: str, matched: set, note: str = "",
                    people_only: bool = False) -> Iterable[Relation]:
    def people(e):  # people_only: leave out party and "Other" options (labels that are not a person's name)
        return (m for m in _active(e) if m.key not in matched and (not people_only or name_key(m.outcome)))

    ks = _unique_by(people(ke), lambda m: surname(m.outcome))
    ps = _unique_by(people(pe), lambda m: surname(m.outcome))
    for s in ks.keys() & ps.keys():
        if not _same_first_initial(ks[s].outcome, ps[s].outcome):
            continue  # one surname, two people (John Kennedy vs Robert F. Kennedy Jr.)
        yield Relation("equivalent", [ks[s].key], [ps[s].key], f"cross_venue_{measure}", race,
                       confidence="surname", note=f"candidate {s}" + (f" ({note})" if note else ""))


def _same_first_initial(a: str, b: str) -> bool:
    """Precision guard for surname matches: first initials must agree when both labels give a first name.
    Drops nickname pairs too (Bobby/Robert): losing a true match is preferred to inventing one."""
    ka, kb = name_key(a), name_key(b)
    return ka is None or kb is None or ka[0] == kb[0]


def _exact_cover(target: Interval, parts: dict[str, Interval]) -> list[str] | None:
    """Keys of disjoint intervals that tile `target` exactly, or None."""
    inside = sorted(((iv, k) for k, iv in parts.items() if target.contains(iv)), key=lambda t: t[0].lo)
    cursor, keys = target.lo, []
    for iv, k in inside:
        if iv.lo != cursor:
            return None
        keys.append(k)
        cursor = iv.hi + 1 if iv.hi != INF else INF
    end = INF if target.hi == INF else target.hi + 1
    return keys if keys and cursor == end else None


def cross_venue_counts(u: Universe) -> Iterable[Relation]:
    """Seat-count buckets: a bucket on one venue equals a union of buckets on the other."""
    for race, va, vb in _pairs(u):
        for ke in u.race_events(race, va, "seat_count"):
            for pe in u.race_events(race, vb, "seat_count"):
                if _count_basis(ke) is None or _count_basis(ke) != _count_basis(pe):
                    continue
                ki = {m.key: iv for m in _active(ke) if (iv := count_interval(m.outcome))}
                pi = {m.key: iv for m in _active(pe) if (iv := count_interval(m.outcome))}
                for key, iv in pi.items():
                    if cover := _exact_cover(iv, ki):
                        yield Relation("equivalent", cover, [key], "cross_venue_seat_count", race)
                for key, iv in ki.items():
                    if (cover := _exact_cover(iv, pi)) and len(cover) > 1:
                        yield Relation("equivalent", [key], cover, "cross_venue_seat_count", race)


def _count_basis(e: Event) -> tuple[str, str] | None:
    """(party counted, "won" or "held"); counts on different bases are different variables."""
    t = (e.title + " " + next((m.question for m in e.markets), "")).lower()
    d, r = "democrat" in t, "republican" in t
    party = "D" if d and not r else "R" if r and not d else None
    basis = "held" if re.search(r"\bhold|\bheld|\bhave\b|\bhas\b|after the", t) else \
        "won" if re.search(r"\bwin\b|\bwon\b", t) else None
    return (party, basis) if party and basis else None


def _buckets(u: Universe, race: str, venue: str) -> dict[str, list[tuple[Market, float, float]]]:
    """Margin buckets of one venue's race, by party: (market, lo, hi)."""
    cands = u.candidate_parties(race)
    buckets: dict[str, list[tuple[Market, float, float]]] = defaultdict(list)
    for pe in u.race_events(race, venue, "margin"):
        for m in _active(pe):
            b = margin_bucket(m)
            if b is None or (b.lo == 0 and b.hi == INF):
                continue
            party = b.party or cands.get(b.who or "")
            if party:
                buckets[party].append((m, b.lo, b.hi))
    return buckets


def cross_venue_margin(u: Universe) -> Iterable[Relation]:
    """Ladder venue: "party wins by at least k" == sum of the other venue's buckets for that party from k up.
    Two bucket venues: identical buckets are the same contract."""
    for race, va, vb in _pairs(u):
        styles = {info(va).margin_style, info(vb).margin_style}
        if styles == {"bucket"}:
            ba, bb = _buckets(u, race, va), _buckets(u, race, vb)
            for party in ba.keys() & bb.keys():
                other = _unique_by(bb[party], lambda b: (b[1], b[2]))
                for m, lo, hi in _unique_by(ba[party], lambda b: (b[1], b[2])).values():
                    if (lo, hi) in other:
                        yield Relation("equivalent", [m.key], [other[(lo, hi)][0].key], "cross_venue_margin", race,
                                       note=f"{party} margin {lo:g}-{hi:g}")
            continue
        if styles != {"bucket", "ladder"}:
            continue
        ladder, bucket = (va, vb) if info(va).margin_style == "ladder" else (vb, va)
        buckets = _buckets(u, race, bucket)
        for ke in u.race_events(race, ladder, "margin"):
            for m in _active(ke):
                rung = kalshi_margin_rung(m)
                if not rung:
                    continue
                party, k = rung
                legs = sorted((b for b in buckets.get(party, []) if b[1] >= k), key=lambda b: b[1])
                if legs and legs[0][1] == k and legs[-1][2] == INF and \
                        all(a[2] == b[1] for a, b in zip(legs, legs[1:])):
                    yield Relation("equivalent", [m.key], [b[0].key for b in legs], "cross_venue_margin", race,
                                   note=f"{party} margin >= {k:g}")


def cross_venue_combo(u: Universe) -> Iterable[Relation]:
    for race, va, vb in _pairs(u):
        for ke in u.race_events(race, va, "combo"):
            for pe in u.race_events(race, vb, "combo"):
                kc = _unique_by(_active(ke), combo_cell)
                pc = _unique_by(_active(pe), combo_cell)
                for cell in kc.keys() & pc.keys():
                    yield Relation("equivalent", [kc[cell].key], [pc[cell].key], "cross_venue_combo", race,
                                   note=f"gov {cell[0]} / sen {cell[1]}")


# --- same-venue, cross-event templates -----------------------------------------------

def margin_vs_winner(u: Universe) -> Iterable[Relation]:
    """Margin markets against the winner market of the same race and venue.

    Kalshi:     "party wins by >= k"  implies  "party wins"
    Polymarket: sum of the party's margin buckets  ==  "party wins"
    """
    for race, by_venue in u.races.items():
        cands = u.candidate_parties(race)
        for venue in by_venue:
            winners = {}
            for we in u.race_events(race, venue, "winner"):
                winners.update(_unique_by(_active(we), party_of))
            if not winners:
                continue
            for me in u.race_events(race, venue, "margin"):
                by_party: dict[str, list[tuple[Market, float, float]]] = defaultdict(list)
                for m in _active(me):
                    rung = kalshi_margin_rung(m)
                    if rung and rung[0] in winners:
                        yield Relation("implies", [m.key], [winners[rung[0]].key], "margin_implies_winner", race,
                                       note=f"{rung[0]} margin >= {rung[1]:g}")
                        continue
                    b = margin_bucket(m)
                    if b:
                        party = b.party or cands.get(b.who or "")
                        if party:
                            by_party[party].append((m, b.lo, b.hi))
                for party, legs in by_party.items():
                    legs.sort(key=lambda b: b[1])
                    tiled = legs[0][1] == 0 and legs[-1][2] == INF and \
                        all(a[2] == b[1] for a, b in zip(legs, legs[1:]))
                    if tiled and party in winners:
                        yield Relation("equivalent", [b[0].key for b in legs], [winners[party].key],
                                       "margin_sum_winner", race, note=f"{party} buckets")


def combo_marginals(u: Universe) -> Iterable[Relation]:
    """Governor/Senate combo cells add up to each single-race winner market on the same venue."""
    for race, by_venue in u.races.items():
        for venue in by_venue:
            for ce in u.race_events(race, venue, "combo"):
                cells = _unique_by(_active(ce), combo_cell)
                if len(cells) != 4:
                    continue
                for pos, office in ((0, "governor"), (1, "senate")):
                    other = u.sibling_race(race, office)
                    winners = {}
                    for we in u.race_events(other, venue, "winner"):
                        winners.update(_unique_by(_active(we), party_of))
                    for party in ("D", "R"):
                        if party in winners:
                            legs = [m.key for cell, m in cells.items() if cell[pos] == party]
                            yield Relation("equivalent", legs, [winners[party].key], "combo_marginal", other,
                                           note=f"{office} {party}")


TEMPLATES: dict[str, Template] = {
    "cross_venue_winner": cross_venue_winner,
    "cross_venue_seat_count": cross_venue_counts,
    "cross_venue_margin": cross_venue_margin,
    "cross_venue_combo": cross_venue_combo,
    "margin_vs_winner": margin_vs_winner,
    "combo_marginals": combo_marginals,
}


def build_relations(u: Universe, extra: Iterable[Relation] = ()) -> list[Relation]:
    out, seen = [], set()
    for template in TEMPLATES.values():
        for r in template(u):
            if r.key not in seen:
                seen.add(r.key)
                out.append(r)
    for r in extra:
        if r.key not in seen:
            seen.add(r.key)
            out.append(r)
    return out


# --- checking ------------------------------------------------------------------------

def _side(u: Universe, keys: list[str]) -> list[Market] | None:
    ms = [u.markets.get(k) for k in keys]
    return ms if all(m is not None and live(m) for m in ms) else None


def mid_gap(u: Universe, r: Relation, max_spread: float = 0.10) -> float | None:
    """Soft inconsistency in mids; only meaningful when every leg has a reasonably tight book."""
    lhs, rhs = _side(u, r.lhs), _side(u, r.rhs)
    if lhs is None or rhs is None or any(m.spread > max_spread for m in lhs + rhs):
        return None
    gap = sum(m.mid for m in lhs) - sum(m.mid for m in rhs)
    return max(gap, 0.0) if r.kind == "implies" else gap


def check(u: Universe, r: Relation, min_edge: float = 0.005) -> Signal | None:
    """Executable violation, net of taker fees.

    Selling a side means buying NO on each of its legs; for mutually exclusive legs that
    pays (n - 1) + 1{side false}, so selling side S and buying side B nets
    sum(bid S) - sum(ask B) whenever S implies B.
    """
    lhs, rhs = _side(u, r.lhs), _side(u, r.rhs)
    if lhs is None or rhs is None:
        return None

    def margin(sell: list[Market], buy: list[Market]) -> float:
        return (sum(m.bid for m in sell) - sum(m.ask for m in buy)
                - sum(m.taker_fee(m.bid) for m in sell) - sum(m.taker_fee(m.ask) for m in buy))

    options = [("sell lhs / buy rhs", margin(lhs, rhs), lhs, rhs)]
    if r.kind == "equivalent":
        options.append(("sell rhs / buy lhs", margin(rhs, lhs), rhs, lhs))
    label, edge, sell, buy = max(options, key=lambda o: o[1])
    if edge < min_edge:
        return None
    sizes = [m.bid_size for m in sell] + [m.ask_size for m in buy]
    known = [s for s in sizes if s is not None]
    return Signal(MODULE, r.template, r.group, round(edge, 4), {
        "relation": r.kind, "trade": label, "confidence": r.confidence, "note": r.note,
        "sell": [(m.key, m.outcome, m.bid) for m in sell],
        "buy": [(m.key, m.outcome, m.ask) for m in buy],
        "min_size": min(known) if known else None,
    })


class VenueBooks:
    """Order-book depth for venues whose listings carry no sizes (dispatch by venue)."""

    def __init__(self):
        self._clients: dict[str, object] = {}

    def _client(self, venue: str):
        if venue not in self._clients:
            if venue == "polymarket":
                from pmpol.venues.polymarket import ClobBooks
                self._clients[venue] = ClobBooks()
            elif venue == "polymarket_us":
                from pmpol.venues.polymarket_us import PolymarketUSClient
                self._clients[venue] = PolymarketUSClient()
            elif venue == "gemini":
                from pmpol.venues.gemini import GeminiClient
                self._clients[venue] = GeminiClient()
            elif venue == "opinion":
                from pmpol.venues.opinion import OpinionClient
                self._clients[venue] = OpinionClient()
            elif venue == "limitless":
                from pmpol.venues.limitless import LimitlessClient
                self._clients[venue] = LimitlessClient()
            else:
                self._clients[venue] = None
        return self._clients[venue]

    def size_at(self, m: Market, side: str, price: float) -> float | None:
        client = self._client(m.venue)
        if client is None:
            return None
        book_id = m.token_id if m.venue in ("polymarket", "opinion") else m.market_id
        return client.size_at(book_id, side, price) if book_id else None


class RecordedBooks:
    """Order-book sizes seen during a crawl, kept next to the snapshot (data/snapshots/depth_<stamp>.json.gz) so a
    replay of that snapshot gives the same depths. With `live`, sizes not yet recorded are read from the venues
    and recorded; without it (a replay), an unrecorded size is unknown (None), never read live."""

    def __init__(self, live=None, recorded: dict | None = None):
        self.live = live
        self.recorded: dict[str, float | None] = dict(recorded or {})
        self.misses = 0

    @staticmethod
    def key(m: Market, side: str, price: float) -> str:
        return f"{m.key}|{side}|{price:.4f}"

    def size_at(self, m: Market, side: str, price: float) -> float | None:
        k = self.key(m, side, price)
        if k in self.recorded:
            return self.recorded[k]
        if self.live is None:
            self.misses += 1
            return None
        size = self.live.size_at(m, side, price)
        self.recorded[k] = size
        return size

    def save(self, path) -> None:
        import gzip
        import json

        with gzip.open(path, "wt", encoding="utf-8") as f:
            json.dump(self.recorded, f)

    @classmethod
    def load(cls, path) -> "RecordedBooks":
        import gzip
        import json

        with gzip.open(path, "rt", encoding="utf-8") as f:
            return cls(None, json.load(f))


def depth_path(snapshot: Path | str) -> Path:
    """data/snapshots/universe_<stamp>.json.gz -> data/snapshots/depth_<stamp>.json.gz"""
    snapshot = Path(snapshot)
    return snapshot.with_name(snapshot.name.replace("universe_", "depth_", 1))


def enrich_depth(u: Universe, signals: list[Signal], books=None, limit: int = 60) -> None:
    """Fill leg sizes from venue order books for the top signals, then recompute min_size.

    Payload legs gain a fourth element, the size available at the quoted price.
    """
    if books is None:
        books = VenueBooks()
    for s in signals[:limit]:
        sizes = []
        for side, book_side in (("sell", "bid"), ("buy", "ask")):
            legs = []
            for key, outcome, price, *_ in s.payload[side]:
                m = u.markets.get(key)
                size = m.bid_size if (m and book_side == "bid") else (m.ask_size if m else None)
                if m and size is None:
                    try:
                        size = books.size_at(m, book_side, price)
                    except Exception:
                        size = None
                legs.append((key, outcome, price, size))
                sizes.append(size)
            s.payload[side] = legs
        known = [x for x in sizes if x is not None]
        s.payload["min_size"] = min(known) if len(known) == len(sizes) and known else None
        s.payload["depth_checked"] = True


def enrich_event_depth(u: Universe, signals: list[Signal], books=None, limit: int = 40) -> None:
    """Same as enrich_depth for single-event signals (pmpol.constraints payloads)."""
    if books is None:
        books = VenueBooks()
    for s in signals[:limit]:
        e = u.events.get(s.subject)
        if e is None:
            continue
        sizes = []

        def size_of(mid, side, price, size):
            m = u.markets.get(f"{e.venue}:{mid}")
            if m is not None and size is None:
                try:
                    size = books.size_at(m, side, price)
                except Exception:
                    size = None
            sizes.append(size)
            return size

        if "legs" in s.payload:
            side = "bid" if s.kind == "sum_bid" else "ask"
            s.payload["legs"] = [(mid, o, price, size_of(mid, side, price, size))
                                 for mid, o, price, size in s.payload["legs"]]
        else:
            for key, side in (("sell", "bid"), ("buy", "ask")):
                mid, o, price, size = s.payload[key]
                s.payload[key] = (mid, o, price, size_of(mid, side, price, size))
        known = [x for x in sizes if x is not None]
        s.payload["min_size"] = min(known) if known and len(known) == len(sizes) else None
        s.payload["depth_checked"] = True
