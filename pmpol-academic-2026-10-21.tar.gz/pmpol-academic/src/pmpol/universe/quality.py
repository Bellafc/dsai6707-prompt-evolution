"""Data-quality guards on venue feeds, applied before relations are trusted.

These use market prices (L4) only to decide whether a venue's *labels* can be trusted;
they never turn a price into a fact. Flagged events keep their data but their relations
are dropped and listed in the report, so a human can check the venue's page.
"""

from __future__ import annotations

import statistics
from collections import defaultdict

from pmpol.universe.index import Universe
from pmpol.universe.outcomes import party_of


def suspect_label_swaps(u: Universe, min_dev: float = 0.3, max_spread: float = 0.15,
                        min_others: int = 2) -> dict[str, str]:
    """Events whose D and R prices both sit far from the other venues' consensus, in opposite
    directions, as if the two labels were swapped. Returns event key -> note."""
    out = {}
    for race, by_venue in u.races.items():
        for measure in ("winner", "control"):
            mids: dict[str, dict[str, tuple[float, str]]] = defaultdict(dict)
            for venue, by_measure in by_venue.items():
                for key in by_measure.get(measure, []):
                    for m in u.events[key].markets:
                        p = party_of(m)
                        if m.active and p in ("D", "R") and m.mid is not None and m.spread is not None \
                                and m.spread <= max_spread:
                            mids[venue][p] = (m.mid, key)
            for venue, own in mids.items():
                if set(own) != {"D", "R"}:
                    continue
                devs = {}
                for p, (x, _) in own.items():
                    others = [mids[o][p][0] for o in mids if o != venue and p in mids[o]]
                    if len(others) < min_others:
                        break
                    devs[p] = x - statistics.median(others)
                if len(devs) == 2 and devs["D"] * devs["R"] < 0 and min(abs(d) for d in devs.values()) >= min_dev:
                    key = own["D"][1]
                    out[key] = (f"{venue} {race}: D {own['D'][0]:.2f} vs others {own['D'][0] - devs['D']:.2f}, "
                                f"R {own['R'][0]:.2f} vs others {own['R'][0] - devs['R']:.2f}")
    return out
