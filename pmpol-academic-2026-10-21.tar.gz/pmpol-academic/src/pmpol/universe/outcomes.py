"""Outcome normalisation: party, candidate surname, numeric interval, margin bucket."""

from __future__ import annotations

import math
import re
import unicodedata
from dataclasses import dataclass

from pmpol.models import Market

INF = math.inf


def _norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", text).strip().lower()


_PARTY_LABEL = {
    "D": re.compile(r"^(democrat|democrats|democratic|democratic party|dems?|democratic party \(d\))$"),
    "R": re.compile(r"^(republican|republicans|republican party|gop|reps?)$"),
    "I": re.compile(r"^(independent|an independent|independents)$"),
}
_PARTY_QUESTION = {
    "D": re.compile(r"\bwill (?:the )?democrat(?:s|ic)?(?: party)?(?: candidate)? win\b"),
    "R": re.compile(r"\bwill (?:the )?republicans?(?: party)?(?: candidate)? win\b"),
    "I": re.compile(r"\bwill an? independent(?: candidate)? win\b"),
}


def party_of(m: Market) -> str | None:
    """Party class of a winner-style outcome, or None when it names no party."""
    if m.venue == "kalshi":
        suffix = m.market_id.rsplit("-", 1)[-1]
        if suffix in ("D", "R"):
            return suffix
    label = _norm(m.outcome)
    tag = re.search(r"\((d|r|i)\)\s*$", label)
    if tag:
        return tag.group(1).upper()
    for p, rx in _PARTY_LABEL.items():
        if rx.match(label):
            return p
    q = _norm(m.question)
    for p, rx in _PARTY_QUESTION.items():
        if rx.search(q):
            return p
    return None


# Labels that mention a person without being that person, e.g. "a party founded by Elon Musk".
_NOT_A_PERSON = re.compile(r"\b(party|founded|by|any|other|someone|nobody|none|field)\b")
_HONORIFIC = re.compile(r"^(sen|rep|gov|dr|mr|mrs|ms|president|pm)\.?\s+")
_SUFFIX = re.compile(r"\s+(jr|sr|ii|iii|iv)\.?$")


def surname(label: str) -> str | None:
    """Lower-case surname of a person-like label, e.g. "Sen. Dan Sullivan (R)" -> "sullivan"."""
    t = _norm(re.sub(r"\(.*?\)", "", label))
    t = _HONORIFIC.sub("", t)
    t = _SUFFIX.sub("", t).strip(" ,")
    words = re.findall(r"[a-z][a-z'\-]+", t)
    if not words or len(words) > 5 or _NOT_A_PERSON.search(t):
        return None
    return words[-1]


_SUFFIXES = {"jr", "sr", "ii", "iii", "iv"}


def name_key(label: str) -> str | None:
    """Interim person key until entities carry Wikidata ids: first initial + surname + suffix.
    "Alexandria Ocasio-Cortez" and "A. Ocasio-Cortez" -> "a ocasio-cortez"; "Donald J. Trump" -> "d trump";
    "Donald Trump Jr." -> "d trump jr"; "John Kennedy" and "Robert F. Kennedy Jr." stay apart.
    Quoted nicknames are dropped ("Dwayne 'The Rock' Johnson" -> "d johnson"). None if not a person."""
    label = re.sub(r"(^|\s)[\"“‘'][^\"”’']+[\"”’'](?=\s|$)", " ", label)
    if surname(label) is None:
        return None
    t = _norm(re.sub(r"\(.*?\)", "", label))
    t = re.sub(r"^(sen|rep|gov|dr|mr|mrs|ms|president|pm)\.?\s+", "", t.strip())
    toks = re.findall(r"[a-z][a-z'\-]*", t.replace(".", " "))
    suffix = toks.pop() if len(toks) > 1 and toks[-1] in _SUFFIXES else ""
    if len(toks) < 2:
        return None
    return f"{toks[0][0]} {toks[-1]}" + (f" {suffix}" if suffix else "")


@dataclass(frozen=True)
class Interval:
    lo: float  # inclusive
    hi: float  # inclusive

    def contains(self, other: "Interval") -> bool:
        return self.lo <= other.lo and other.hi <= self.hi


_NUM = r"(\d[\d,]*(?:\.\d+)?)"


def _n(x: str) -> float:
    return float(x.replace(",", ""))


def count_interval(label: str) -> Interval | None:
    """Integer-count intervals from labels such as "Below 45", "8-10", "57+", "≤47", "At least 17"."""
    # Replace unicode dashes and comparison signs first; ASCII folding would drop them.
    t = _norm(label.replace("–", "-").replace("—", "-").replace("≤", "<=").replace("≥", ">="))
    pats = [
        (rf"^(?:below|less than|fewer than|under)\s+{_NUM}$", lambda a: Interval(-INF, a - 1)),
        (rf"^<\s*{_NUM}$", lambda a: Interval(-INF, a - 1)),
        (rf"^<=\s*{_NUM}$", lambda a: Interval(-INF, a)),
        (rf"^(?:above|more than|over)\s+{_NUM}$", lambda a: Interval(a + 1, INF)),
        (rf"^(?:at least\s+)?{_NUM}\s*(?:\+|or more|and above|or higher)$", lambda a: Interval(a, INF)),
        (rf"^at least\s+{_NUM}$", lambda a: Interval(a, INF)),
        (rf"^>=\s*{_NUM}$", lambda a: Interval(a, INF)),
        (rf"^{_NUM}$", lambda a: Interval(a, a)),
    ]
    for pat, make in pats:
        m = re.match(pat, t)
        if m:
            return make(_n(m.group(1)))
    m = re.match(rf"^{_NUM}\s*-\s*{_NUM}$", t)
    if m:
        return Interval(_n(m.group(1)), _n(m.group(2)))
    return None


@dataclass(frozen=True)
class MarginBucket:
    party: str | None  # D / R / I, or None when only a candidate name is given
    who: str | None  # candidate surname when the label names a person
    lo: float  # margin points, lower bound (inclusive)
    hi: float  # upper bound (exclusive), INF for open-ended


def margin_bucket(m: Market) -> MarginBucket | None:
    """Polymarket-style margin buckets: "Democrat 5-10%", "Republican 20%+", "Collins 0-5%", "Democrat Wins"."""
    label = m.outcome.strip()
    hit = re.match(r"^(.+?)\s+(\d+(?:\.\d+)?)\s*[-–]\s*(\d+(?:\.\d+)?)%?$", label)
    if hit:
        who, lo, hi = hit.group(1), float(hit.group(2)), float(hit.group(3))
    else:
        hit = re.match(r"^(.+?)\s+(\d+(?:\.\d+)?)%?\s*\+$", label)
        if hit:
            who, lo, hi = hit.group(1), float(hit.group(2)), INF
        else:
            hit = re.match(r"^(.+?)\s+wins?$", label, re.I)
            if not hit:
                return None
            who, lo, hi = hit.group(1), 0.0, INF
    p = None
    for party, rx in _PARTY_LABEL.items():
        if rx.match(_norm(who)):
            p = party
    return MarginBucket(p, None if p else surname(who), lo, hi)


def kalshi_margin_rung(m: Market) -> tuple[str, float] | None:
    """Kalshi margin ladder rung: (party, k) for "margin of victory for <party> ... at least k"."""
    if m.venue != "kalshi" or m.strike_type not in ("greater", "greater_or_equal") or m.floor_strike is None:
        return None
    q = _norm(m.question)
    party = "D" if "for democrats" in q else "R" if "for republicans" in q else None
    return (party, m.floor_strike) if party else None


_COMBO_KALSHI = re.compile(r"governor winner be (\w+) party and .*senate winner be (\w+) party", re.I)
_COMBO_PM_SWEEP = re.compile(r"\b(democrats|republicans) sweep\b", re.I)
_COMBO_PM_SPLIT = re.compile(r"(democrats|republicans) win the .*governor election and (democrats|republicans) win "
                             r"the .*senate election", re.I)
# Polymarket US: question "<State> Senate and Governor Combo", outcome "Dems sweep" or "Reps win Gov, Dems win Senate".
_COMBO_PU_EVENT = re.compile(r"\bsenate and governor combo\b", re.I)
_COMBO_PU_SWEEP = re.compile(r"^(dems|reps) sweep$", re.I)
_COMBO_PU_SPLIT = re.compile(r"^(dems|reps) win gov, (dems|reps) win senate$", re.I)


def combo_cell(m: Market) -> tuple[str, str] | None:
    """(governor party, senate party) for a Governor/Senate combo cell."""
    def p(word: str) -> str:
        return "D" if word.lower().startswith("dem") else "R"

    hit = _COMBO_KALSHI.search(m.question)
    if hit:
        return p(hit.group(1)), p(hit.group(2))
    hit = _COMBO_PM_SPLIT.search(m.question)
    if hit:
        return p(hit.group(1)), p(hit.group(2))
    hit = _COMBO_PM_SWEEP.search(m.question)
    if hit:
        return p(hit.group(1)), p(hit.group(1))
    if _COMBO_PU_EVENT.search(m.question):
        label = m.outcome.strip()
        if hit := _COMBO_PU_SWEEP.match(label):
            return p(hit.group(1)), p(hit.group(1))
        if hit := _COMBO_PU_SPLIT.match(label):
            return p(hit.group(1)), p(hit.group(2))
    return None
