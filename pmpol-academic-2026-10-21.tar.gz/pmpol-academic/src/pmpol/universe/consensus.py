"""Cross-venue consensus: one probability per contract from every venue that lists it, recalibrated
with our own L2 base rates (version 2, 2026-10-03; method notes in docs/OSS_SURVEY.md parts 8 and 9).

  1. Equivalence classes: markets joined by single-leg cross-venue "equivalent" relations whose legs
     were identified structurally, by a person's Wikidata identity, by the same full name in the same
     race, or by the same party-list label in the same race (2026-10-05); name keys, titles and text similarity are left out for precision. A
     class joined by an identity or a label says so, and its estimate's analytic confidence is lowered.
     Quotes are admitted only with a two-sided book no wider than 10 points.
  2. No-arbitrage band: each venue says the probability is in [bid - fee, ask + fee]. If the bands of
     the venues do not overlap, the venues disagree after fees: no point estimate is published, the
     quotes are shown side by side (team rule: conflicting sources are not resolved by picking one).
  3. Log-linear pooling (Genest & Zidek 1986) with weights from the quote's uncertainty in logit space
     (delta method): sigma = (spread / 2) / (m (1 - m)) + sigma0, w = 1 / sigma^2. A one-point spread at
     3% is about four times wider in logit terms than at 50%, so a probability-unit weight would
     over-trust tail quotes. sigma0 = 0.10 is a floor for rule and model risk.
     Venues of one family (Polymarket and Polymarket US share traders and information) are pooled
     first and count once, with the weight of their best member. The pooled value is clipped into
     the no-arbitrage band. Its uncertainty assumes a correlation of 0.5 between families.
  4. Recalibration: p* = sigmoid(b logit p), with b from kb/L2/market_calibration.yaml for the venues
     in the class and the horizon nearest to the time left, shrunk toward 1 by n / (n + 200) and
     reported with its 95% band. b > 1 (prices compressed toward 50%) makes this the "extremizing"
     correction of Satopaa et al. 2014 and Baron et al. 2014, but estimated out of sample rather than
     assumed; and no extra extremizing is added for information diversity (Satopaa et al. 2016),
     because venues linked by arbitrageurs share nearly all their information. The intercept a is
     reported but not applied: applied to every outcome of one race it would make them no longer sum
     to 1. The slope alone is symmetric, so a two-outcome race stays coherent.

Pooled prices are not independent evidence and the calibration was fitted on single-venue prices;
both are stated as caveats on every estimate. The output is an L5 inference, never a fact.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime

from pmpol.assumptions import cite
from pmpol.kb import KnowledgeBase
from pmpol.models import Market, Relation
from pmpol.proof import Proof, likelihood
from pmpol.universe.index import Universe, live
from pmpol.venues import ASSUMED_FEES, info, source_url

EPS = 0.005
MAX_SPREAD = 0.10
SIGMA0 = 0.10  # logit-units floor on each quote's uncertainty
RHO = 0.5  # correlation between venue families (uncertainty band only) when the KB has no estimate
RHO_FACT = "consensus.family_correlation"  # L2 estimate, `pmpol famcorr --write-kb`
SHIFT_FACT = "consensus.venue_shift."  # + family: directional bias toward 50%, probability points, `pmpol famcorr`
SHIFT_WIDTH = 0.1  # the shift fades to zero within about this distance of 50% (tanh)
NOISE_FACT = "consensus.venue_noise."  # + family: extra quote noise in probability points, `pmpol famcorr`
SHRINK_N0 = 200  # pseudo-markets pulling the calibration slope toward 1
FAMILY = {"polymarket_us": "polymarket"}
MATCH_CAVEAT = {
    "entity": "各平台的同一個選項是用人物的 Wikidata 身分連起來的（不是結構欄位）；連結錯了，合併的就不是同一個合約。",
    "name": "各平台的同一個選項是靠同一場選舉裡相同的全名連起來的（這個人沒有 Wikidata 身分）；拼法不同的同一人不會合併，"
            "同名的不同人會被誤併（同一場選舉裡極少見）。",
    "label": "各平台的同一個選項是靠同一場選舉裡相同的名稱（政黨名單或單名）連起來的；名稱相同但所指不同時，合併就是錯的。",
}  # venues pooled together before pooling across families


def family_rho(kb: KnowledgeBase | None) -> tuple[float, str | None]:
    """(rho, fact id): the L2 estimate from the knowledge base (pmpol.universe.family_corr), else RHO."""
    f = kb.facts.get(RHO_FACT) if kb else None
    if f is None or not isinstance(f.value, dict) or "rho" not in f.value:
        return RHO, None
    return min(max(float(f.value["rho"]), 0.0), 1.0), f.id


def venue_noise(kb: KnowledgeBase | None) -> dict[str, tuple[float, str]]:
    """family -> (extra noise in probability units, fact id): venues whose quotes stray from the others more than
    their spread shows (PredictIt), estimated by pmpol.universe.family_corr."""
    out = {}
    for fid, f in (kb.facts.items() if kb else ()):
        if fid.startswith(NOISE_FACT) and isinstance(f.value, dict) and "extra" in f.value:
            out[fid[len(NOISE_FACT):]] = (max(float(f.value["extra"]), 0.0), fid)
    return out


def venue_shift(kb: KnowledgeBase | None) -> dict[str, tuple[float, str]]:
    """family -> (shift toward the nearer extreme, probability units; fact id): a venue whose prices are pressed
    toward 50% (PredictIt), estimated by pmpol.universe.family_corr."""
    out = {}
    for fid, f in (kb.facts.items() if kb else ()):
        if fid.startswith(SHIFT_FACT) and isinstance(f.value, dict) and "shift" in f.value:
            out[fid[len(SHIFT_FACT):]] = (float(f.value["shift"]), fid)
    return out


def unshift_p(p: float, shift: float) -> float:
    """Move a price `shift` toward the nearer extreme (undoing a pull toward 50%), smoothly to zero at 50%, and never
    more than half the way to that extreme (a 0.3% longshot cannot be moved a whole point down)."""
    if not shift:
        return p
    move = shift * math.tanh((p - 0.5) / SHIFT_WIDTH)
    return p + (max(move, -p / 2) if move < 0 else min(move, (1 - p) / 2))


def _unshifted(m: Market, shift: float) -> Market:
    """The quote as used in the pool: bid and ask moved by the same amount (from the mid's side of 50%)."""
    if not shift or m.bid is None or m.ask is None:
        return m
    from dataclasses import replace

    move = unshift_p(m.mid, shift) - m.mid
    return replace(m, bid=min(max(m.bid + move, 0.0), 1.0), ask=min(max(m.ask + move, 0.0), 1.0))


def _logit(p: float) -> float:
    p = min(max(p, EPS), 1 - EPS)
    return math.log(p / (1 - p))


def _sigmoid(x: float) -> float:
    return 1 / (1 + math.exp(-x))


@dataclass
class Consensus:
    group: str
    markets: list[Market]
    pooled: float  # weighted logit mean; a reference for deviations even when the venues disagree
    recalibrated: float | None  # None without calibration data, or when the venues disagree after fees
    horizon: int | None
    weights: dict[str, float] = field(default_factory=dict)  # market key -> weight (family members share one)
    params: tuple[float, float] | None = None  # (a, b) as fitted, weighted over venues
    params_from: list[str] = field(default_factory=list)  # fact ids
    slope: float | None = None  # b after shrinkage toward 1
    band: tuple[float, float] | None = None  # no-arbitrage band; None when the venue bands do not overlap
    interval: tuple[float, float] | None = None  # 95% band of the (recalibrated) estimate
    rho: float = RHO  # correlation between families used for the band
    rho_from: str | None = None  # KB fact id, None when the default was used
    noise_from: list[str] = field(default_factory=list)  # KB fact ids of venues' extra quote noise
    match: str = "rule"  # weakest way the class's legs were identified (MATCHES)
    shift_from: list[str] = field(default_factory=list)  # KB fact ids of venues' directional bias, removed first

    @property
    def disagree(self) -> bool:
        return self.band is None

    def deviations(self) -> list[tuple[Market, float]]:
        """Each venue's mid minus the pooled consensus."""
        return [(m, m.mid - self.pooled) for m in self.markets]


MATCHES = ("rule", "entity", "name", "label")  # how the legs were identified (pmpol.propositions.relations), strongest first


def classes(u: Universe, relations: list[Relation], admit: tuple[str, ...] = MATCHES) -> list[tuple[str, list[str], str]]:
    """Union-find over single-leg cross-venue equivalences whose resolution conditions do not differ materially
    (pmpol.propositions.resolution) and whose legs were identified structurally ("rule"), by a person's Wikidata
    identity ("entity"), by the same full name in the same race ("name"; a person-party bridge is not the same
    contract) or by the same party-list label in the same race ("label"). Returns (group, market keys, weakest
    match): an estimate from a class joined by a weaker match inherits that match's analytic confidence."""
    parent: dict[str, str] = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    group_of: dict[str, str] = {}
    match_of: dict[str, str] = {}
    for r in relations:
        if r.kind != "equivalent" or not r.cross_venue or r.confidence not in admit or r.rules == "material":
            continue
        if r.confidence == "name" and not r.template.endswith(":same_set"):
            continue
        if len(r.lhs) == 1 and len(r.rhs) == 1:
            a, b = find(r.lhs[0]), find(r.rhs[0])
            parent[a] = b
            group_of[r.lhs[0]] = group_of[r.rhs[0]] = r.group
            for k in (r.lhs[0], r.rhs[0]):
                match_of[k] = max(match_of.get(k, r.confidence), r.confidence, key=MATCHES.index)
    out: dict[str, list[str]] = {}
    for k in parent:
        out.setdefault(find(k), []).append(k)
    return [(group_of.get(ks[0], ""), sorted(ks), max((match_of[k] for k in ks), key=MATCHES.index))
            for ks in out.values() if len(ks) >= 2]


def _horizon_days(markets: list[Market], now: datetime | None) -> float | None:
    """Days to close, from venues whose close time is the event date (Kalshi's is a far backstop)."""
    if now is None:
        return None
    days = []
    for m in markets:
        if m.venue == "kalshi" or not m.close_time:
            continue
        try:
            d = datetime.fromisoformat(m.close_time.replace("Z", "+00:00"))
        except ValueError:
            continue
        if d.tzinfo is None:
            continue
        days.append((d - now).total_seconds() / 86400)
    return min(days) if days else None


def _bucket(days: float | None) -> int:
    if days is None:
        return 7
    return 1 if days <= 3 else 7 if days <= 15 else 30


def _sigma(m: Market, extra: float = 0.0) -> float:
    """Logit-space uncertainty of a quote: half the spread plus the venue's extra noise (both in probability
    units, so they grow toward the tails), and a floor for rule and model risk."""
    p = min(max(m.mid, EPS), 1 - EPS)
    return (m.spread / 2 + extra) / (p * (1 - p)) + SIGMA0


def _band(m: Market) -> tuple[float, float]:
    return m.bid - m.taker_fee(m.bid), m.ask + m.taker_fee(m.ask)


def estimate(u: Universe, keys: list[str], group: str, kb: KnowledgeBase | None, now: datetime | None,
             max_spread: float = MAX_SPREAD) -> Consensus | None:
    ms = [u.markets[k] for k in keys if k in u.markets and live(u.markets[k])]
    ms = [m for m in ms if m.spread is not None and m.bid is not None and 0 <= m.spread <= max_spread + 1e-9]
    if len({m.venue for m in ms}) < 2:
        return None
    shifts = venue_shift(kb)
    calc = {m.key: _unshifted(m, shifts.get(FAMILY.get(m.venue, m.venue), (0.0, ""))[0]) for m in ms}
    lo = max(_band(calc[m.key])[0] for m in ms)
    hi = min(_band(calc[m.key])[1] for m in ms)
    band = (max(lo, 0.0), min(hi, 1.0)) if lo <= hi else None

    # Within a family: weighted logit mean, counted once with its best member's weight.
    fams: dict[str, list[Market]] = {}
    for m in ms:
        fams.setdefault(FAMILY.get(m.venue, m.venue), []).append(m)
    noise = venue_noise(kb)
    fam_logit, fam_sigma, w = {}, {}, {}
    for f, members in fams.items():
        extra = noise.get(f, (0.0, ""))[0]
        mw = {m.key: 1 / _sigma(calc[m.key], extra) ** 2 for m in members}
        fam_logit[f] = sum(mw[m.key] * _logit(calc[m.key].mid) for m in members) / sum(mw.values())
        fam_sigma[f] = min(_sigma(calc[m.key], extra) for m in members)
        for m in members:
            w[m.key] = mw[m.key] / sum(mw.values()) / fam_sigma[f] ** 2
    fw = {f: 1 / fam_sigma[f] ** 2 for f in fams}
    total = sum(fw.values())
    x = sum(fw[f] * fam_logit[f] for f in fams) / total
    rho, rho_fact = family_rho(kb)
    var = sum(fw[f] * fw[g] * (1 if f == g else rho) * fam_sigma[f] * fam_sigma[g] for f in fams for g in fams) / total ** 2
    pooled = _sigmoid(x)
    if band is not None:
        pooled = min(max(pooled, band[0]), band[1])
        x = _logit(pooled)

    h = _bucket(_horizon_days(ms, now))
    params, n, se, used, wsum = [0.0, 0.0], 0.0, 0.0, [], 0.0
    for m in ms:
        f = kb.facts.get(f"calibration.{m.venue}.politics.h{h}") if kb else None
        if f is None:
            continue
        params[0] += w[m.key] * f.value["intercept_a"]
        params[1] += w[m.key] * f.value["slope_b"]
        n += w[m.key] * f.value.get("n", 0)
        se += w[m.key] * f.value.get("slope_b_se", 0.0)
        wsum += w[m.key]
        if f.id not in used:
            used.append(f.id)
    ab = slope = recal = None
    sd = math.sqrt(var)
    interval = (_sigmoid(x - 1.96 * sd), _sigmoid(x + 1.96 * sd))
    if wsum:
        ab = (params[0] / wsum, params[1] / wsum)
        n, se = n / wsum, se / wsum
        k = n / (n + SHRINK_N0)
        slope = 1 + (ab[1] - 1) * k
        if band is not None:
            recal = _sigmoid(slope * x)
            ends = [_sigmoid(b * z) for b in (1 + (ab[1] - 1.96 * se - 1) * k, 1 + (ab[1] + 1.96 * se - 1) * k)
                    for z in (x - 1.96 * sd, x + 1.96 * sd)]
            interval = (min(ends), max(ends))
    return Consensus(group, ms, pooled, recal, h, w, ab, used, slope, band, interval if band else None, rho,
                     rho_fact, sorted(noise[f][1] for f in fams if f in noise),
                     shift_from=sorted(shifts[f][1] for f in fams if f in shifts and shifts[f][0]))


def explain(c: Consensus, kb: KnowledgeBase | None, observed_at: str) -> Proof:
    outcome = c.markets[0].outcome or "Yes"
    if c.disagree:
        head = "扣掉手續費後各平台的報價區間沒有交集，不給點估計：" + "、".join(
            f"{info(m.venue).code} {100 * m.mid:.1f}%" for m in c.markets)
    else:
        head = f"共識機率 {100 * c.pooled:.1f}%"
        if c.recalibrated is not None:
            head += f"，校準後 {100 * c.recalibrated:.1f}%（{likelihood(c.recalibrated)}）"
        if c.interval:
            head += f"；95% 區間 {100 * c.interval[0]:.0f}–{100 * c.interval[1]:.0f}%"
    p = Proof(f"跨平台共識｜{c.group}｜{outcome}", head,
              result={"pooled": None if c.disagree else round(c.pooled, 4),
                      "recalibrated": None if c.recalibrated is None else round(c.recalibrated, 4),
                      "venues": len(c.markets), "horizon_days": c.horizon, "disagree": c.disagree,
                      "band": None if c.band is None else [round(x, 4) for x in c.band],
                      "interval": None if c.interval is None else [round(x, 4) for x in c.interval]})
    if c.match != "rule":  # the analytic confidence (pmpol.confidence) reads the match from here
        p.result["confidence"] = c.match
        p.caveats.append(MATCH_CAVEAT[c.match])
    qids = []
    total = sum(c.weights.values())
    for m in c.markets:
        qid = f"quote:{m.key}"
        lo, hi = _band(m)
        fam = f"，與 {info(FAMILY[m.venue]).code} 同一家族" if m.venue in FAMILY else ""
        p.add("L4", f"{info(m.venue).code} {outcome}：買 {100 * m.bid:.1f}／賣 {100 * m.ask:.1f}（扣費後區間 "
                    f"{100 * lo:.1f}–{100 * hi:.1f}%，權重 {c.weights[m.key] / total:.0%}{fam}）",
              source_url(m), observed_at, kind="data", id=qid)
        qids.append(qid)
    if c.disagree:
        p.add("L5", "各平台扣費後的區間沒有交集：平台之間真的不一致，並列呈現，不選邊", kind="logic", id="band",
              inputs=tuple(qids))
    else:
        p.add("L5", f"無套利區間（各平台區間的交集）：{100 * c.band[0]:.1f}–{100 * c.band[1]:.1f}%", kind="logic",
              id="band", inputs=tuple(qids))
    venues = {m.venue for m in c.markets}
    assumed = cite(p, "family_correlation", "consensus_quote_floor", "consensus_max_spread")
    if venues & set(FAMILY):
        assumed += cite(p, "venue_family")
    if venues & ASSUMED_FEES:
        assumed += cite(p, "assumed_fees")
    if "kalshi" in venues:
        assumed += cite(p, "kalshi_close_backstop")
    if c.rho_from and kb and c.rho_from in kb.facts:
        f = kb.facts[c.rho_from]
        p.add("L2", f"不同家族之間報價誤差的相關係數 ρ = {c.rho:.2f}（95% 區間 {f.value['ci_low']:.2f}–"
                    f"{f.value['ci_high']:.2f}；{f.value['n_contracts']:,} 個跨家族合約的報價差距）", c.rho_from,
              str(f.recorded_at), kind="data", id="rho")
        assumed.append("rho")
    for fid in c.noise_from:
        f = kb.facts[fid]
        fam = fid[len(NOISE_FACT):]
        p.add("L2", f"{info(fam).label} 的報價比價差顯示的更偏離其他平台：不確定度另加 {100 * f.value['extra']:.1f} 個百分點"
                    f"（95% 區間 {100 * f.value['ci_low']:.1f}–{100 * f.value['ci_high']:.1f}），權重因此降低，越靠近 0 或 100% 降得越多",
              fid, str(f.recorded_at), kind="data", id=f"noise:{fam}")
        assumed.append(f"noise:{fam}")
    for fid in c.shift_from:
        f = kb.facts[fid]
        fam = fid[len(SHIFT_FACT):]
        movers = [m for m in c.markets if FAMILY.get(m.venue, m.venue) == fam]
        moved = "、".join(f"{100 * m.mid:.1f}% → {100 * unshift_p(m.mid, f.value['shift']):.1f}%" for m in movers)
        p.add("L2", f"{info(fam).label} 的價格被壓向 50%（冷門偏貴、熱門偏便宜）：合併前往兩端移回 "
                    f"{100 * f.value['shift']:.1f} 個百分點（95% 區間 {100 * f.value['ci_low']:.1f}–"
                    f"{100 * f.value['ci_high']:.1f}；越靠近 50% 移得越少）：{moved}", fid, str(f.recorded_at),
              kind="data", id=f"shift:{fam}")
        assumed.append(f"shift:{fam}")
    p.add("L5", f"對數勝算加權平均（權重＝1／logit 空間的不確定度²，同一家族只算一次），限制在無套利區間內："
                f"{100 * c.pooled:.1f}%", "Genest & Zidek 1986", kind="logic", id="pool",
          inputs=tuple(qids) + ("band",) + tuple(assumed))
    if c.params is not None:
        for fid in c.params_from:
            f = kb.facts[fid]
            p.add("L2", f"{f.subject}、截止前 {c.horizon} 天：校準斜率 b = {f.value['slope_b']:.2f}"
                        f"（±{1.96 * f.value.get('slope_b_se', 0):.2f}）、截距 a = {f.value['intercept_a']:.2f}"
                        f"（{f.value['n']:,} 個已結算市場）", fid, str(f.recorded_at), kind="data", id=f"cal:{fid}")
        a, b = c.params
        if c.recalibrated is not None:
            transfer = cite(p, "calibration_transfers", "calibration_shrinkage")
            p.add("L5", f"重新校準（只用斜率，向 1 收縮後 b = {c.slope:.2f}）：σ({c.slope:.2f} × logit({100 * c.pooled:.1f}%))"
                        f" = {100 * c.recalibrated:.1f}%", "Satopää et al. 2014; Baron et al. 2014", kind="logic",
                  id="recal", inputs=tuple(["pool"] + [f"cal:{fid}" for fid in c.params_from] + transfer))
        p.caveats.append(f"截距 a = {a:.2f}（YES 普遍被高估的傾向）沒有套用，因為套用到同一場比賽的每個選項後，"
                         "加總就不再是 1。")
    else:
        p.caveats.append("這幾個平台還沒有校準資料，沒有做重新校準。")
    p.caveats += ["各平台的價格不是互相獨立的證據（同一批套利者在多個平台交易），合併後的信心不能當成更高；"
                  f"區間用的不同家族之間相關係數是 {c.rho:.2f}"
                  + ("（從跨平台報價差距估計，只涵蓋各平台各自的報價誤差；所有平台一起錯的部分無法估計）。"
                     if c.rho_from else "（假設值）。"),
                  "校準參數是用單一平台的價格擬合的，用在合併價格上是近似。"]
    devs = sorted(c.deviations(), key=lambda t: -abs(t[1]))
    if abs(devs[0][1]) >= 0.05:
        m, d = devs[0]
        p.alt(f"{info(m.venue).label} 偏離共識 {100 * d:+.1f} 點", "supports",
              "單一平台和其他平台加權共識的差距；可能是該平台的交易者族群不同，或報價過時")
    return p


def run(u: Universe, relations: list[Relation], kb: KnowledgeBase | None, observed_at: str = "") -> list[Consensus]:
    try:
        now = datetime.fromisoformat(observed_at) if observed_at else None
    except ValueError:
        now = None
    out = []
    for group, keys, match in classes(u, relations):
        c = estimate(u, keys, group, kb, now)
        if c is not None:
            c.match = match
            out.append(c)
    return out
