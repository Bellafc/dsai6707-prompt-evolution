"""In-memory index over the tagged universe: events, markets, races and themes."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

from pmpol.models import Event, Market
from pmpol.universe.outcomes import party_of, surname
from pmpol.universe.taxonomy import Tags, next_election_across_venues, place_across_venues, tag_event


@dataclass
class Universe:
    events: dict[str, Event] = field(default_factory=dict)  # event key -> event
    tags: dict[str, Tags] = field(default_factory=dict)  # event key -> tags
    markets: dict[str, Market] = field(default_factory=dict)  # market key -> market
    market_event: dict[str, str] = field(default_factory=dict)  # market key -> event key
    # race key -> venue -> measure -> [event keys]
    races: dict[str, dict[str, dict[str, list[str]]]] = field(default_factory=dict)
    clusters: dict[str, str] = field(default_factory=dict)  # event key -> cluster id
    cluster_labels: dict[str, str] = field(default_factory=dict)  # cluster id -> readable label

    @classmethod
    def build(cls, events: list[Event]) -> "Universe":
        u = cls()
        races: dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        for e in events:
            if e.key in u.events:
                continue
            u.events[e.key] = e
            u.tags[e.key] = tag_event(e)
            for m in e.markets:
                u.markets[m.key] = m
                u.market_event[m.key] = e.key
        place_across_venues(u.events, u.tags)
        next_election_across_venues(u.events, u.tags)
        for e in u.events.values():
            t = u.tags[e.key]
            if t.race_key:
                races[t.race_key][e.venue][t.measure].append(e.key)
        u.races = {k: {v: dict(ms) for v, ms in vs.items()} for k, vs in races.items()}
        return u

    def race_events(self, race_key: str, venue: str, measure: str) -> list[Event]:
        return [self.events[k] for k in self.races.get(race_key, {}).get(venue, {}).get(measure, [])]

    def sibling_race(self, race_key: str, office: str) -> str:
        """Same contest key with another office (e.g. the Senate race of a Governor combo)."""
        country, juris, _, year, stage = race_key.split("|")
        return "|".join((country, juris, office, year, stage))

    def candidate_parties(self, race_key: str) -> dict[str, str]:
        """Surname -> party, learned from the race's winner markets on both venues."""
        out: dict[str, str] = {}
        for venue in self.races.get(race_key, {}):
            for e in self.race_events(race_key, venue, "winner"):
                for m in e.markets:
                    p = party_of(m)
                    s = surname(m.outcome)
                    if p and s:
                        out.setdefault(s, p)
        return out


def live(m: Market) -> bool:
    return m.active and m.bid is not None and m.ask is not None and m.ask > 0
