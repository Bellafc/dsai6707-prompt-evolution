"""Universe pipeline: crawl -> tag -> cluster -> relate -> check -> report / graph."""

from __future__ import annotations

import gzip
import json
import re
import sys
import time
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from pmpol import constraints
from pmpol.models import Event, Market, Relation, Signal
from pmpol.propositions.resolution import STATUS_ZH
from pmpol.universe.cluster import build_clusters, text_matches, text_relations, theme_of
from pmpol.universe.explain import explain_event_signal, explain_relation, explain_suspect, signal_id
from pmpol.universe.index import Universe, live
from pmpol.universe.quality import suspect_label_swaps
from pmpol.universe.relations import build_relations, check, enrich_depth, enrich_event_depth, mid_gap
from pmpol.universe.taxonomy import TOPICS
from pmpol.venues import VENUES, info, source_url, venue_order
from pmpol.venues.cryptocom import CryptoComClient
from pmpol.venues.gemini import GeminiClient
from pmpol.venues.kalshi import KalshiClient
from pmpol.venues.limitless import LimitlessClient
from pmpol.venues.opinion import OpinionClient
from pmpol.venues.polymarket import PolymarketClient
from pmpol.venues.polymarket_us import PolymarketUSClient
from pmpol.venues.predictit import PredictItClient
from pmpol.venues.smarkets import SmarketsClient

KALSHI_CATEGORIES = {"Elections", "Politics", "World", "Economics"}  # Economics: macro markets for pmpol macro
POLYMARKET_TAGS = ("politics", "elections", "geopolitics", "world", "global-elections", "midterms", "trump",
                   "us-politics", "congress", "courts", "foreign-policy", "middle-east", "ukraine", "china",
                   "tariffs", "economic-policy", "immigration", "economy", "fed-rates")

TOPIC_ZH = {
    "elections_us": "美國選舉", "elections_intl": "國際選舉", "us_government": "美國政府與司法",
    "geopolitics": "地緣政治", "economy_policy": "經濟政策", "media": "媒體與發言", "other": "其他",
}
TEMPLATE_ZH = {
    "cross_venue_winner": "跨平台・勝選", "cross_venue_nomination": "跨平台・提名", "cross_venue_control": "跨平台・控制權",
    "cross_venue_seat_count": "跨平台・席次區間", "cross_venue_margin": "跨平台・勝差", "cross_venue_combo": "跨平台・組合",
    "margin_implies_winner": "勝差 ⇒ 勝選", "margin_sum_winner": "勝差區間加總 = 勝選", "combo_marginal": "組合邊際 = 單場",
    "cross_venue_text": "跨平台・文字配對", "cross_venue_deadline": "跨平台・截止日蘊含",
}


def _tpl_zh(template: str) -> str:
    from pmpol.propositions.relations import label

    return label(template) or TEMPLATE_ZH.get(template, template)


def crawl(venues: tuple[str, ...] = tuple(VENUES), log=sys.stderr, run=None) -> list[Event]:
    """Fetch every political event on the given venues. A venue that fails is reported and skipped.
    With a pmpol.runs.Run, each venue's outcome is recorded as a source ("venue:<name>")."""
    events: list[Event] = []
    for venue in venues:
        t0 = time.monotonic()
        try:
            got = list(_crawl_venue(venue, log))
        except Exception as e:  # one venue down must not stop the others
            print(f"{venue}: FAILED ({e})", file=log)
            if run is not None:
                run.source(f"venue:{venue}", False, 0, time.monotonic() - t0, str(e))
            continue
        print(f"{venue}: {len(got)} events", file=log)
        if run is not None:
            run.source(f"venue:{venue}", True, len(got), time.monotonic() - t0)
        events += got
    return events


def _crawl_venue(venue: str, log):
    if venue == "kalshi":
        yield from KalshiClient().iter_events(categories=KALSHI_CATEGORIES)
    elif venue == "polymarket":
        seen = set()
        pm = PolymarketClient()
        for tag in POLYMARKET_TAGS:
            n = 0
            for e in pm.iter_events(tag_slug=tag):
                if e.event_id not in seen:
                    seen.add(e.event_id)
                    n += 1
                    yield e
            print(f"polymarket tag {tag}: +{n}", file=log)
    elif venue == "polymarket_us":
        yield from PolymarketUSClient().iter_events()
    elif venue == "gemini":
        yield from GeminiClient().iter_events()
    elif venue == "smarkets":
        yield from SmarketsClient().iter_events()
    elif venue == "cryptocom":
        yield from CryptoComClient().iter_events()
    elif venue == "opinion":
        yield from OpinionClient().iter_events()
    elif venue == "predictit":
        yield from PredictItClient().iter_events()
    elif venue == "limitless":
        yield from LimitlessClient().iter_events()
    else:
        raise ValueError(f"unknown venue {venue}")


def save_snapshot(events: list[Event], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt", encoding="utf-8") as f:
        json.dump([asdict(e) for e in events], f, ensure_ascii=False)


def load_snapshot(path: Path) -> list[Event]:
    with gzip.open(path, "rt", encoding="utf-8") as f:
        raw = json.load(f)
    return [Event(**{**e, "markets": [Market(**m) for m in e["markets"]]}) for e in raw]


@dataclass
class UniverseRun:
    universe: Universe
    rule_relations: list[Relation]
    text_relations: list[Relation]
    rule_signals: list[Signal]
    text_signals: list[Signal]
    event_signals: list[Signal]
    gaps: list[tuple[float, Relation]] = field(default_factory=list)
    entity_graph: object | None = None  # pmpol.entities.graph.EntityGraph when entities are enabled
    suspects: dict[str, str] = field(default_factory=dict)  # event key -> why its labels look wrong
    dropped: list[Relation] = field(default_factory=list)  # relations removed because a leg is suspect
    proofs: dict[str, object] = field(default_factory=dict)  # signal id -> pmpol.proof.Proof
    consensus: list = field(default_factory=list)  # pmpol.universe.consensus.Consensus
    observed_at: str = ""  # snapshot time of the quotes
    crosscheck: object | None = None  # pmpol.propositions.derive.Comparison: templates vs ontology
    template_only: list = field(default_factory=list)  # [(Relation, Signal)] template violations the ontology lacks
    direct_keys: set = field(default_factory=set)  # (kind, lhs, rhs) of direct relations (for the graph)
    unread: dict = field(default_factory=dict)  # market key -> why the ontology could not read it
    candidates: dict = field(default_factory=dict)  # race -> L1 general-election candidates (entities.candidates)
    divergences: list = field(default_factory=list)  # market consensus outside the experts' ratings (entities.ratings)
    outside_views: list = field(default_factory=list)  # House control consensus next to the midterm base rate
    recession_views: list = field(default_factory=list)  # technical-recession markets next to the GDP base rate
    president_views: list = field(default_factory=list)  # White House party markets next to the incumbent record
    baselines: list = field(default_factory=list)  # official-statistics markets next to the series' own history
    coherence: object = None  # pmpol.coherence.Result: the nearest coherent prices
    n_props: int = 0  # markets the proposition ontology read
    candidate_conflicts: list = field(default_factory=list)  # where those lists contradict the venues' labels


def run(events: list[Event], min_edge: float = 0.005, depth: bool = True, entities: bool = True, books=None,
        observed_at: str = "", kb=None, proofs: bool = True, run_id: str = "") -> UniverseRun:
    from pmpol.propositions import relations as onto_rel
    from pmpol.propositions.derive import direct

    if kb is None:  # one knowledge base for the rules (election methods, chamber sizes) and the proofs
        from pmpol.kb import KnowledgeBase
        kb = KnowledgeBase.load()
    u = Universe.build(events)
    build_clusters(u)
    # The proposition ontology is the source of relations; the hand-written templates run as a cross-check.
    templates = build_relations(u)
    index, wd_people, candidates, race_ratings, candidacies = None, [], {}, {}, []
    if entities:  # people get Wikidata identities (QIDs) and L1 candidate lists when the sources are available
        from pmpol.entities import candidates as cand
        from pmpol.entities import wd_peps, wikidata
        from pmpol.entities.graph import load_index
        from pmpol.entities import ratings as rt
        index, wd_people, candidates, race_ratings = load_index(u), wd_peps.load(), cand.load(), rt.load()
        candidacies = wikidata.load()
    onto = onto_rel.build(u, templates, index, wd_people, kb, candidates, candidacies)
    rules = onto.relations
    texts = text_relations(u, text_matches(u))
    related = {frozenset(r.lhs + r.rhs) for r in rules}
    texts = [r for r in texts if frozenset(r.lhs + r.rhs) not in related]  # already read by the ontology
    suspects = suspect_label_swaps(u)
    bad = {m.key for k in suspects for m in u.events[k].markets}
    dropped = [r for r in templates + texts if bad & set(r.lhs + r.rhs)]
    rules = [r for r in rules if not bad & set(r.lhs + r.rhs)]
    texts = [r for r in texts if not bad & set(r.lhs + r.rhs)]
    templates = [r for r in templates if not bad & set(r.lhs + r.rhs)]
    pairs = [(r, s) for r in rules + texts if (s := check(u, r, min_edge))]
    violated = {frozenset(r.lhs + r.rhs) for r, _ in pairs}
    template_only = sorted(((r, s) for r in templates if (s := check(u, r, min_edge))
                            and frozenset(r.lhs + r.rhs) not in violated), key=lambda t: -t[1].edge)
    direct_keys = {(d.kind, tuple(d.lhs), tuple(d.rhs)) for d in direct(onto.derived, onto.parsed.props)}
    rule_sig = sorted((s for r, s in pairs if r.confidence != "text"), key=lambda s: -s.edge)
    text_sig = sorted((s for r, s in pairs if r.confidence == "text"), key=lambda s: -s.edge)
    event_sig = constraints.scan(u.events.values(), min_edge=min_edge)
    if depth:  # `books`: live venue books, or the sizes recorded with the snapshot (relations.RecordedBooks)
        enrich_depth(u, rule_sig, books)
        enrich_event_depth(u, sorted(event_sig, key=lambda s: -s.edge), books)
    proof_map = {}
    if proofs:
        for r, s in pairs:
            s.payload["id"] = signal_id(s)
            proof_map[s.payload["id"]] = explain_relation(u, r, s, kb, observed_at)
        for s in event_sig:
            s.payload["id"] = signal_id(s)
            proof_map[s.payload["id"]] = explain_event_signal(u, s, observed_at)
        for k, note in suspects.items():
            proof_map[f"suspect:{k}"] = explain_suspect(u, k, note, observed_at)
        from pmpol.universe import consensus as cons

        consensus_rows = cons.run(u, rules, kb, observed_at)
        for c in consensus_rows:
            proof_map[f"consensus:{c.markets[0].key}"] = cons.explain(c, kb, observed_at)
        from pmpol.runs import code_version, module_version

        meta = {"generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "generator": {"module": "pmpol.universe", **code_version(),
                              "code_version": module_version("pmpol.universe", "pmpol.proof", "pmpol.models")},
                "quotes_observed_at": observed_at, "run_id": run_id}
        for p in proof_map.values():
            p.meta = meta
    gaps = sorted(((g, r) for r in rules if (g := mid_gap(u, r)) is not None), key=lambda t: -abs(t[0]))
    eg = None
    if entities:
        from pmpol.entities.graph import build_entity_graph
        eg = build_entity_graph(u, index)
    run_ = UniverseRun(u, rules, texts, rule_sig, text_sig, event_sig, gaps, eg, suspects, dropped, proof_map,
                       observed_at=observed_at, crosscheck=onto.crosscheck, template_only=template_only,
                       direct_keys=direct_keys, unread=onto.parsed.unparsed, candidates=candidates,
                       n_props=len(onto.parsed.props))
    if candidates:
        from pmpol.propositions.derive import person_party_conflicts

        run_.candidate_conflicts = person_party_conflicts(u, onto.parsed.props, candidates)
    if proofs:
        run_.consensus = consensus_rows
        if race_ratings:  # an evidence line independent of the markets
            run_.divergences = rating_divergences(u, consensus_rows, race_ratings)
            for d in run_.divergences:
                proof_map[f"divergence:{d.race}|{d.party}"] = explain_divergence(d, observed_at)
        run_.outside_views = outside_views(consensus_rows, kb)  # the outside view: a base rate, not a market
        from pmpol import coherence

        # only relations we trust: structural or name/descriptor matches, and no material difference in the rules
        run_.coherence = coherence.run(u, [r for r in rules if r.confidence in ("rule", "entity", "name", "descriptor")
                                           and r.rules != "material"])
        for o in run_.outside_views:
            proof_map[f"reference:{o.group}"] = explain_outside_view(o, observed_at, kb)
        run_.president_views = president_views(consensus_rows, kb)
        for o in run_.president_views:
            proof_map[f"reference:{o.group}"] = explain_president_view(o, observed_at, kb)
        run_.recession_views = recession_views(u, kb)
        for v in run_.recession_views:
            proof_map[f"reference:{v.group}"] = explain_recession(v, observed_at, kb)
        run_.baselines = baselines(u, onto.parsed.props)
        for b in run_.baselines:
            proof_map[f"reference:{b.group}"] = explain_baseline(b, observed_at)
    return run_


def consensus_signal(c) -> Signal:
    """A consensus estimate as a storable signal (subject: the class's first market key)."""
    dev = max((abs(d) for _, d in c.deviations()), default=0.0)
    return Signal("consensus", "estimate", c.markets[0].key, round(dev, 4), {
        "group": c.group, "mids": {m.key: round(m.mid, 4) for m in c.markets}, "disagree": c.disagree,
        "pooled": None if c.disagree else round(c.pooled, 4),
        "recalibrated": None if c.recalibrated is None else round(c.recalibrated, 4),
        "band": None if c.band is None else [round(x, 4) for x in c.band],
        "interval": None if c.interval is None else [round(x, 4) for x in c.interval],
        "horizon_days": c.horizon})


def _in_graph(res: UniverseRun, r: Relation, violated: set) -> bool:
    """The graph keeps direct relations, text matches and every violated relation; the rest follow from
    them through ladders inside one event."""
    if not r.template.startswith("onto:") or not res.direct_keys:
        return True
    return (r.kind, tuple(r.lhs), tuple(r.rhs)) in res.direct_keys or frozenset(r.lhs + r.rhs) in violated


def export_proofs(res: UniverseRun, path: Path) -> int:
    """Every signal with its proof (steps + graph) as JSON, for the viewer and for audit."""
    u = res.universe
    rows = []
    for group, signals in (("rule", res.rule_signals), ("text", res.text_signals), ("event", res.event_signals)):
        for s in signals:
            p = res.proofs.get(s.payload.get("id", ""))
            if p is None:
                continue
            legs = s.payload.get("sell", []) + s.payload.get("buy", [])
            if group == "event":
                venues = [u.events[s.subject].venue]
            else:
                venues = sorted({leg[0].split(":", 1)[0] for leg in legs}, key=venue_order)
            rows.append({"id": s.payload["id"], "group": group, "kind": s.kind, "subject": s.subject,
                         "edge": s.edge, "venues": [info(v).code for v in venues],
                         # market keys, for the viewer's price history (an event's legs are prices, not markets)
                         "markets": sorted({leg[0] for leg in legs if isinstance(leg, (list, tuple))}),
                         "confidence": s.payload.get("confidence", "rule"), "rules": p.result.get("rules", ""),
                         "title": p.title,
                         "proof": {**p.to_dict(), "graph": p.graph()}})
    for c in res.consensus:
        key = f"consensus:{c.markets[0].key}"
        p = res.proofs[key]
        dev = max((abs(d) for _, d in c.deviations()), default=0.0)
        rows.append({"id": key, "group": "consensus", "kind": "consensus", "subject": c.group, "edge": round(dev, 4),
                     "venues": sorted({info(m.venue).code for m in c.markets}), "confidence": "rule",
                     "markets": [m.key for m in c.markets],
                     "title": p.title, "proof": {**p.to_dict(), "graph": p.graph()}})
    for d in res.divergences:
        key = f"divergence:{d.race}|{d.party}"
        p = res.proofs[key]
        rows.append({"id": key, "group": "evidence", "kind": "rating_divergence", "subject": d.race,
                     "edge": round(d.gap, 4), "venues": [], "confidence": "rule", "title": p.title,
                     "proof": {**p.to_dict(), "graph": p.graph()}})
    for o in res.outside_views:
        key = f"reference:{o.group}"
        p = res.proofs[key]
        rows.append({"id": key, "group": "evidence", "kind": "outside_view", "subject": o.group,
                     "edge": round(o.gap, 4), "venues": [], "confidence": "rule", "title": p.title,
                     "proof": {**p.to_dict(), "graph": p.graph()}})
    for o in res.president_views:
        key = f"reference:{o.group}"
        p = res.proofs[key]
        rows.append({"id": key, "group": "evidence", "kind": "outside_view", "subject": o.group,
                     "edge": round(o.gap, 4), "venues": [], "confidence": "rule", "title": p.title,
                     "proof": {**p.to_dict(), "graph": p.graph()}})
    for v in res.recession_views:
        key = f"reference:{v.group}"
        p = res.proofs[key]
        rows.append({"id": key, "group": "evidence", "kind": "outside_view", "subject": v.group,
                     "edge": round(v.gap or 0.0, 4), "venues": [info(v.market.venue).code], "confidence": "rule",
                     "markets": [v.market.key],
                     "title": p.title, "proof": {**p.to_dict(), "graph": p.graph()}})
    for b in res.baselines:
        key = f"reference:{b.group}"
        p = res.proofs[key]
        rows.append({"id": key, "group": "evidence", "kind": "outside_view", "subject": b.group,
                     "edge": round(b.worst, 4), "venues": sorted({info(m.venue).code for m, _, _ in b.rows}),
                     "confidence": "rule", "markets": [m.key for m, _, _ in b.rows],
                     "title": p.title, "proof": {**p.to_dict(), "graph": p.graph()}})
    for key, p in res.proofs.items():
        if key.startswith("suspect:"):
            rows.append({"id": key, "group": "quality", "kind": "label_swap", "subject": key[8:], "edge": 0.0,
                         "venues": [info(u.events[key[8:]].venue).code], "confidence": "rule", "title": p.title,
                         "proof": {**p.to_dict(), "graph": p.graph()}})
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"observed_at": res.observed_at, "signals": rows}, ensure_ascii=False, default=str))
    return len(rows)


def rating_divergences(u: Universe, consensus_rows, race_ratings) -> list:
    """Consensus probabilities of a party winning a race, against the experts' ratings of that race."""
    from pmpol.entities.ratings import compare
    from pmpol.universe.outcomes import party_of

    market = {}
    for c in consensus_rows:
        if c.disagree or not c.group.startswith("winner("):
            continue
        party = party_of(c.markets[0])
        if party in ("D", "R"):
            market[(c.group[len("winner("):-1], party)] = c.recalibrated if c.recalibrated is not None else c.pooled
    return compare(market, race_ratings)


@dataclass
class OutsideViewRow:
    group: str  # "control(United States|house|2026)"
    view: object  # pmpol.reference.OutsideView
    markets: dict  # party -> (consensus probability, venues disagree after fees)
    interval: tuple[float, float] = (0.0, 1.0)  # Wilson 95% band of the base rate

    @property
    def market(self) -> float | None:
        """Consensus probability that the president's party holds the chamber (from either side's market)."""
        v = self.view
        if v.president_party in self.markets:
            return self.markets[v.president_party][0]
        other = next(iter(self.markets.values()), None)
        return None if other is None else 1 - other[0]

    @property
    def gap(self) -> float:
        return 0.0 if self.market is None else self.market - self.view.share


CHAMBER_ZH = {"house": "眾議院", "senate": "參議院"}


def outside_views(consensus_rows, kb) -> list[OutsideViewRow]:
    """House and Senate control consensus estimates of a midterm year, next to the reference class (pmpol.reference)."""
    from pmpol.reference import outside_view, wilson
    from pmpol.universe.outcomes import party_of

    groups: dict[str, dict] = {}
    for c in consensus_rows:
        m = re.fullmatch(r"control\(United States\|(house|senate)\|(\d{4})\)", c.group)
        party = party_of(c.markets[0]) if m else None
        if party in ("D", "R"):
            p = c.recalibrated if c.recalibrated is not None else c.pooled
            groups.setdefault(c.group, {})[party] = (p, c.disagree)
    out = []
    for group, markets in sorted(groups.items()):
        v = outside_view(kb, int(group[-5:-1]), group.split("|")[1])
        if v is not None:
            out.append(OutsideViewRow(group, v, markets, wilson(v.keeps, v.n)))
    return out


@dataclass
class PresidentViewRow:
    group: str  # "winner(United States|US|president|2028|general)"
    view: object  # pmpol.presidential.PresidentialView
    markets: dict  # party -> (consensus probability, venues disagree after fees)

    @property
    def market(self) -> float | None:
        """Consensus probability that the incumbent party keeps the White House (from either side's market)."""
        v = self.view
        if v.party in self.markets:
            return self.markets[v.party][0]
        other = next(iter(self.markets.values()), None)
        return None if other is None else 1 - other[0]

    @property
    def gap(self) -> float:
        return 0.0 if self.market is None else self.market - self.view.share


def president_views(consensus_rows, kb) -> list[PresidentViewRow]:
    """Party-level White House consensus estimates, next to the incumbent party's record (pmpol.presidential)."""
    from pmpol.presidential import outside_view
    from pmpol.universe.outcomes import party_of

    groups: dict[str, dict] = {}
    for c in consensus_rows:
        m = re.fullmatch(r"winner\(United States\|US\|president\|(\d{4})\|general\)", c.group)
        if not m or _person_outcome(c.markets[0]):
            continue
        party = party_of(c.markets[0])
        if party in ("D", "R"):
            p = c.recalibrated if c.recalibrated is not None else c.pooled
            groups.setdefault(c.group, {})[party] = (p, c.disagree)
    out = []
    for group, markets in sorted(groups.items()):
        v = outside_view(kb, int(group.split("|")[3]))
        if v is not None:
            out.append(PresidentViewRow(group, v, markets))
    return out


def _person_outcome(m) -> bool:
    """A candidate's market ("JD Vance (R)") names a person, not the party: its price is not the party's chance."""
    from pmpol.universe.outcomes import _norm

    return re.search(r"\((d|r|i)\)\s*$", _norm(m.outcome)) is not None


def explain_president_view(o: PresidentViewRow, observed_at: str, kb):
    """The incumbent party's record and the market side by side: L1 records, L0 term limit, L2 classes, L4 consensus."""
    from pmpol.assumptions import cite
    from pmpol.presidential import MODEL_FACT
    from pmpol.proof import Proof

    v = o.view
    r = v.rates
    pp = v.party

    def rate(d):
        return "—" if not d["n"] else (f"{d['kept']}/{d['n']}（{100 * d['share']:.0f}%；Wilson 95% 區間 "
                                       f"{100 * d['wilson95'][0]:.0f}–{100 * d['wilson95'][1]:.0f}%）")

    mk = "" if o.market is None else f"；市場共識 {100 * o.market:.0f}%"
    p = Proof(f"外部視角｜{o.group}",
              f"參考類別（{v.rows[0]['year']}–{v.rows[-1]['year']} 年 {r['all']['n']} 次總統選舉）：執政黨（{pp}）守住白宮 "
              f"{rate(r['all'])}；只執政一任時 {rate(r['first_term'])}，開放席次時 {rate(r['open_seat'])}{mk}："
              "子類別互相矛盾，並列，不選邊")
    p.result = {"base_rate": r["all"]["share"], "first_term": r["first_term"]["share"],
                "open_seat": r["open_seat"]["share"], **({"market": round(o.market, 4)} if o.market is not None else {})}
    terms, party, rec = (kb.facts[f] for f in v.facts[:3])
    p.add("L1", f"選舉日在任總統：{v.president}（{terms.source.title}）", terms.id, str(terms.recorded_at), kind="data",
          id="president")
    p.add("L1", f"{party.subject} 的政黨：{party.value}", party.id, str(party.recorded_at), kind="data", id="party")
    inputs = ["president", "party"]
    if len(v.facts) > 3:
        lim = kb.facts[v.facts[3]]
        p.add("L0", f"任期限制：{lim.source.quote}（{lim.source.title}）", lim.id, str(lim.recorded_at), kind="rule",
              id="term_limit")
        inputs.append("term_limit")
    seat = "總統可以再參選" if v.eligible else "總統已當選兩次、不能再參選：開放席次"
    tenure = {True: f"{pp} 只執政一任", False: f"{pp} 已執政兩任以上", None: "執政任數不明"}[v.first_term]
    p.add("L5", f"{v.year} 年的條件：{seat}；{tenure}", kind="logic", id="case", inputs=tuple(inputs))
    rows = "、".join(f"{x['year']} {x['party']}{'✓' if x['kept'] else '✗'}" for x in v.rows)
    p.add("L2", f"1952 年以來執政黨守住白宮與否（隔年 1 月 21 日在任總統的政黨）：{rows}", rec.id, str(rec.recorded_at),
          kind="data", id="class")
    ref = cite(p, "presidential_reference_class")
    p.add("L5", f"全部 {rate(r['all'])}；一任 {rate(r['first_term'])}、兩任以上 {rate(r['two_terms_or_more'])}；"
                f"總統參選 {rate(r['president_running'])}、開放席次 {rate(r['open_seat'])}",
          "Abramowitz（time for change）；Kahneman & Lovallo 1993", kind="logic", id="base",
          inputs=("case", "class", *ref))
    both = [] if v.first_term is None else [x for x in v.rows if (x["terms_held"] == 1) == v.first_term
                                              and x["terms_held"] is not None and x["running"] == v.eligible]
    if both:
        k = sum(x["kept"] for x in both)
        p.add("L5", f"兩個條件同時符合的先例只有 {len(both)} 次（{'、'.join(str(x['year']) for x in both)}），守住 {k} 次："
                    "太少，不能當基準率", kind="logic", id="both", inputs=("case", "class"))
    mids = []
    for party_, (prob, disagree) in sorted(o.markets.items()):
        sid = f"market:{party_}"
        p.add("L4", f"跨平台共識：{party_} 贏得白宮 {100 * prob:.1f}%" + ("（各平台扣費後的區間沒有交集，這是參考值）"
                                                                 if disagree else ""),
              "data/proofs.json#consensus", observed_at, kind="data", id=sid)
        mids.append(sid)
    if o.market is not None:
        lo, hi = min(r["first_term"]["wilson95"][0], r["open_seat"]["wilson95"][0]), \
            max(r["first_term"]["wilson95"][1], r["open_seat"]["wilson95"][1])
        p.add("L5", f"市場（{pp} 守住白宮 {100 * o.market:.0f}%）{'在' if lo <= o.market <= hi else '不在'}兩個子類別的區間"
                    f"（{100 * lo:.0f}–{100 * hi:.0f}%）之內；和全部的基準率差 {100 * o.gap:+.0f} 點", kind="logic",
              id="compare", inputs=("base", *mids))
    fund = kb.facts.get(MODEL_FACT)
    if v.model and fund is not None:
        fv = v.model
        p.add("L2", f"基本面（{fv.get('model', '')}；{fv.get('sample', '')}）：斜率 b = {fv.get('b')}（t = {fv.get('b_t')}，"
                    f"R² = {fv.get('r2')}）。{v.year} 年 1–8 月的所得還沒有公布，只能看條件表："
                    + "、".join(f"所得 {float(x):+.0f}% → 得票率 {s['share']}%" for x, s in fv.get("scenarios", {}).items()),
              fund.id, str(fund.recorded_at), kind="data", id="fundamentals")
        p.caveats.append(f"基本面要等 {v.year} 年 8 月的所得資料才能代入；2020 年紓困金讓所得成長 6.6%，執政黨仍然落選，"
                         "所得在疫情期間不是好的經濟指標。")
    p.alt("候選人本身（提名人是誰、現任副總統是否參選）比執政黨的任數更重要", "unchecked",
          "參考類別只看政黨；提名市場和民調這兩條線另外看")
    p.alt("選舉人團和普選票不同（2000、2016 年）", "unchecked",
          "紀錄用選舉人團（市場的結算方式），基本面的得票率是普選票")
    p.caveats.append("基準率是 L2 的歷史頻率、市場是 L4 觀測，兩者都不是事實；19 次選舉、子類別只有 8–11 次，區間很寬。")
    return p


def explain_outside_view(o: OutsideViewRow, observed_at: str, kb):
    """The base rate and the market side by side: L1 records, the L2 reference class, L4 consensus; never resolved."""
    from pmpol.assumptions import cite
    from pmpol.proof import Proof

    v = o.view
    lo, hi = o.interval
    pp = v.president_party
    senate = v.chamber == "senate"
    room = CHAMBER_ZH[v.chamber]
    mk = "" if o.market is None else f"；市場共識 {100 * o.market:.0f}%"
    p = Proof(f"外部視角｜{o.group}",
              f"參考類別（{v.rows[0]['year']}–{v.rows[-1]['year']} 年 {v.n} 次期中選舉）：總統所屬政黨（{pp}）以現在的 "
              f"{v.seats} 席，過去的席次變化只有 {v.keeps} 次能保住多數，基準率 {100 * v.share:.0f}%（95% 區間 "
              f"{100 * lo:.0f}–{100 * hi:.0f}%）{mk}：兩條證據線並列，不選邊",
              result={"base_rate": round(v.share, 4), "interval": [round(lo, 4), round(hi, 4)], "keeps": v.keeps,
                      "n": v.n, "president_party": pp, "seats": v.seats, "needed": v.needed,
                      "market": None if o.market is None else round(o.market, 4), "gap": round(o.gap, 4)})
    house, terms, party, cls = (kb.facts[f] for f in v.facts)
    if senate:
        p.add("L1", f"第 {max(int(k) for k in house.value)} 屆國會選舉後，{pp} 在參議院有 {v.seats} 席（共 {v.total} 席；"
                    f"同黨的副總統可打破平手，所以 {v.total // 2} 席就能控制）", house.id, str(house.recorded_at),
              kind="data", id="seats")
    else:
        p.add("L1", f"第 {max(int(k) for k in house.value)} 屆國會選舉的初步結果，{pp} 在眾議院有 {v.seats} 席（過半要 218 席）",
              house.id, str(house.recorded_at), kind="data", id="seats")
    p.add("L1", f"現任總統：{party.subject}（任期涵蓋 {v.year} 年 11 月的選舉日；{terms.source.title}）", terms.id,
          str(terms.recorded_at), kind="data", id="president")
    p.add("L1", f"{party.subject} 的政黨：{party.value}", party.id, str(party.recorded_at), kind="data", id="party")
    changes = "、".join(f"{r['year']} {r['change']:+d}" for r in v.rows)
    p.add("L2", f"1946 年以來期中選舉總統政黨在{room}的席次變化：{changes}", cls.id, str(cls.recorded_at), kind="data",
          id="class")
    ref = cite(p, "midterm_reference_class")
    p.add("L5", f"保住多數要求變化 ≥ {v.needed:+d} 席：{v.keeps}/{v.n} 次（{100 * v.share:.0f}%；Wilson 95% 區間 "
                f"{100 * lo:.0f}–{100 * hi:.0f}%）", "Kahneman & Lovallo 1993", kind="logic", id="base",
          inputs=("seats", "president", "party", "class", *ref))
    mids = []
    for party_, (prob, disagree) in sorted(o.markets.items()):
        sid = f"market:{party_}"
        p.add("L4", f"跨平台共識：{party_} 控制{room} {100 * prob:.1f}%" + ("（各平台扣費後的區間沒有交集，這是參考值）"
                                                                     if disagree else ""),
              "data/proofs.json#consensus", observed_at, kind="data", id=sid)
        mids.append(sid)
    if o.market is not None:
        p.add("L5", f"市場（{pp} 保住多數 {100 * o.market:.0f}%）{'在' if lo <= o.market <= hi else '不在'}基準率的 95% 區間內，"
                    f"差 {100 * o.gap:+.0f} 點", kind="logic", id="compare", inputs=("base", *mids))
    from pmpol.fundamentals import FACT as FUND

    fund = None if senate else kb.facts.get(FUND)  # the fundamentals model is fitted on House seat changes
    if fund is not None and isinstance(fund.value, dict):
        fv = fund.value
        pk = next((val for key, val in fv.items() if key.startswith("p_change_at_least_")), None)
        p.add("L2", f"基本面（{fv.get('model', '')}；{fv.get('sample', '')}）：斜率 b = {fv.get('b')}（t = {fv.get('b_t')}，"
                    f"R² = {fv.get('r2')}），{v.year} 年的所得成長代入後，總統政黨保住多數的機率 "
                    f"{'—' if pk is None else f'{100 * pk:.0f}%'}", fund.id, str(fund.recorded_at), kind="data",
              id="fundamentals")
        if pk is not None:
            p.result["fundamentals_p"] = pk
        if abs(fv.get("b_t") or 0) < 2:
            p.caveats.append("基本面這條線很弱：所得成長的斜率和 0 分不開（|t| < 2），模型幾乎沒有解釋力；缺的是總統支持度。")
    recent = [r for r in v.rows if r["year"] >= 1994]
    if recent:
        k = sum(r["change"] >= v.needed for r in recent)
        p.alt("近年的期中選舉變動較小（選區重劃、極化），早期樣本高估了席次流失", "unchecked",
              f"只用 1994 年以後的 {len(recent)} 次：{k}/{len(recent)}（{100 * k / len(recent):.0f}%）；"
              f"1994 年以前的 {v.n - len(recent)} 次：{v.keeps - k}/{v.n - len(recent)}")
    p.alt("這次的條件（總統支持度、經濟、退休席次）和平均的期中選舉不同", "unchecked",
          "參考類別沒有條件化；民調和基本面這兩條證據線還沒有資料來源")
    p.caveats.append("基準率是 L2 的歷史頻率、市場是 L4 觀測，兩者都不是事實；一致不代表正確，只代表兩條線沒有互相否定。")
    if senate:
        p.alt("這次改選的是哪些席次（哪一黨守得多、在哪些州）比全國氣氛更重要", "unchecked",
              "參議院每次只改選三分之一，參考類別看不到改選席次的組成；各州的勝選市場和專家評級才看得到")
        p.caveats += ["席次是來源表格「選舉後立即」的兩黨席次：無黨籍（含和某黨同一黨團的）不算進任何一黨，少數幾屆反映了之後的換黨"
                      "（來源有註明）；現有席次也不是今天的實際席次。",
                      "控制權假設副總統和總統同黨（破平手），並假設無黨籍議員的黨團歸屬不變。"]
    else:
        p.caveats += ["席次是每屆選舉的初步結果（來源的定義）：變化是選舉對選舉，期間的補選、出缺和換黨都不算；現有席次也不是今天的實際席次。",
                      "席次總數（435）和過半門檻（218）假設和過去相同。"]
    return p


def explain_divergence(d, observed_at: str):
    """Market and experts side by side: L4 consensus, L3 ratings, the band assumption; never resolved."""
    from pmpol.assumptions import cite
    from pmpol.proof import Proof

    lo, hi = d.band
    p = Proof(f"市場和專家評級並列｜{d.race}｜{d.party}",
              f"市場共識 {100 * d.market:.0f}%，專家評級的中位數對應 {100 * lo:.0f}–{100 * hi:.0f}%"
              f"（差 {100 * d.gap:+.0f} 點）：兩條獨立的證據線不一致，並列呈現、不選邊",
              result={"market": round(d.market, 4), "band": [lo, hi], "gap": round(d.gap, 4), "party": d.party})
    p.add("L4", f"跨平台共識：{d.party} 勝選 {100 * d.market:.1f}%", "data/proofs.json#consensus", observed_at,
          kind="data", id="market")
    rid = []
    for i, r in enumerate(d.ratings):
        sid = f"rating{i}"
        p.add("L3", f"{r.rater}：{r.category}{(' ' + r.party) if r.party else ''}"
                    f"（對 {d.party} 的勝率帶 {100 * r.band(d.party)[0]:.0f}–{100 * r.band(d.party)[1]:.0f}%）",
              f"https://en.wikipedia.org/wiki/{r.page}", r.as_of, kind="data", id=sid)
        rid.append(sid)
    bands = cite(p, "rating_probability_bands")
    p.add("L5", f"評級中位數的勝率帶 {100 * lo:.0f}–{100 * hi:.0f}%，市場在帶外 {100 * abs(d.gap):.0f} 點", kind="logic",
          id="compare", inputs=("market", *rid, *bands))
    p.alt("市場有評級者還沒反映的資訊（例如最新民調、候選人醜聞）", "unchecked", "比較評級日期和最近的新聞")
    p.alt("評級過時（評級日期早）", "supports" if any(r.as_of and r.as_of[-4:] < "2026" for r in d.ratings) else "unchecked",
          "評級日期：" + "、".join(f"{r.rater[:12]} {r.as_of or '?'}" for r in d.ratings[:5]))
    p.alt("評級類別對應的勝率帶不準（假設）", "unchecked", "還沒有用歷史評級和結果擬合")
    p.caveats.append("專家評級是 L3 判斷，市場價格是 L4 觀測；兩者都不是事實。不一致本身是值得追查的線索。")
    return p


def export_graph(res: UniverseRun, path: Path) -> None:
    """Nodes = events (with tags and cluster), edges = relations (with current violation size)."""
    u = res.universe
    violated = {frozenset(leg[0] for leg in s.payload.get("sell", []) + s.payload.get("buy", []))
                for s in res.rule_signals + res.text_signals}
    data = {
        "nodes": [{
            "id": k, "venue": e.venue, "title": e.title, **u.tags[k].to_dict(),
            "cluster": u.clusters.get(k), "cluster_label": u.cluster_labels.get(u.clusters.get(k, ""), ""),
            "theme": theme_of(u, k), "markets": [m.key for m in e.markets if m.active],
        } for k, e in u.events.items()],
        "edges": [{
            **r.to_dict(),
            "lhs_events": sorted({u.market_event[m] for m in r.lhs if m in u.market_event}),
            "rhs_events": sorted({u.market_event[m] for m in r.rhs if m in u.market_event}),
            "edge_now": s.edge if (s := check(u, r, min_edge=-10.0)) else None,
        } for r in res.rule_relations + res.text_relations if _in_graph(res, r, violated)],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False))


# --- report -------------------------------------------------------------------------

def _pct(x) -> str:
    return "—" if x is None else f"{100 * x:.1f}"


def _legs(legs) -> str:
    """Legs are (market key, outcome, price[, size])."""
    return " + ".join(f"{leg[1] or leg[0].split(':', 1)[1][:40]} @{_pct(leg[2])}" for leg in legs)


def _venue_of(legs) -> str:
    vs = sorted({leg[0].split(":", 1)[0] for leg in legs}, key=venue_order)
    return "/".join(info(v).code for v in vs)


def _rules_lines(res: UniverseRun) -> list[str]:
    """How the cross-venue relations' resolution conditions compare, and where the violations fall."""
    cross = [r for r in res.rule_relations if r.cross_venue and r.rules]
    if not cross:
        return []
    count = Counter(r.rules for r in cross)
    viol = Counter(res.proofs[s.payload["id"]].result.get("rules", "") for s in res.rule_signals
                   if s.payload.get("id") in res.proofs)
    order = ("equivalent", "unverified", "minor", "material")
    L = ["### 跨平台的結算條件比對", "",
         "同一個命題，各平台的結算規則還是可能不同：判定依據（媒體宣布、官方認證、宣誓就任）、候選人被替換時跟不跟著換、"
         "是否包含決選、計算窗從哪天開始、宣布辭職算不算。「沒寫」不當成差異。", "",
         "| 比對結果 | 跨平台關係 | 扣費後違反 |", "|---|---|---|"]
    L += [f"| {STATUS_ZH[k]} | {count[k]:,} | {viol[k]:,} |" for k in order if count[k] or viol[k]]
    diffs = Counter(d for r in cross if r.rules in ("material", "minor")
                    for d in r.rules_detail.split("；") if d.startswith("不同："))
    if diffs:
        L += ["", "最常見的差異：" + "；".join(f"{d[3:]}（{n:,}）" for d, n in diffs.most_common(4))]
    L.append("")
    return L


def _crosscheck_lines(res: UniverseRun) -> list[str]:
    c = res.crosscheck
    if c is None:
        return []
    total = len(c.agree) + len(c.disagree) + len(c.not_covered)
    L = ["## 3b. 模板交叉驗證", "",
         f"手寫模板產生 {total:,} 條關係：本體推出相同結論 **{len(c.agree):,}**"
         f"（{100 * len(c.agree) / max(total, 1):.1f}%）、結論不同 **{len(c.disagree):,}**、本體讀不懂 {len(c.not_covered):,}。"
         "結論不同的每一條都要查：可能是模板錯，也可能是本體錯。", ""]
    for r, why in c.disagree[:15]:
        L.append(f"- 不同：`{r.template}` {r.group}：{' + '.join(r.lhs)} ／ {' + '.join(r.rhs)} → {why}")
    reasons = Counter(why.split(":")[0] for _, why in c.not_covered)
    if reasons:
        L.append("- 本體讀不懂的原因：" + "；".join(f"{w}（{n:,}）" for w, n in reasons.most_common(4)))
    L += ["", f"模板有、本體沒有的扣費後違反：**{len(res.template_only)}** 條"
              + ("（本體讀不懂這些市場，或兩者對關係的判斷不同；列出來人工確認）" if res.template_only else "") + "。", ""]
    for r, s in res.template_only[:10]:
        why = "；".join(sorted({res.unread[k] for k in r.lhs + r.rhs if k in res.unread})) or "本體有讀，但沒有推出這條關係"
        L.append(f"- {100 * s.edge:+.1f} 點 `{r.template}` {r.group}：{why}")
    L.append("")
    return L


def _divergence_lines(res: UniverseRun) -> list[str]:
    if not res.divergences:
        return []
    L = [f"### 市場和專家評級並列（獨立的證據線，{len(res.divergences)} 處不一致）", "",
         "專家評級（Cook、Inside Elections、Sabato、DDHQ、Silver Bulletin 等，取自維基百科各選舉頁面的彙整）依假設的勝率帶"
         "換算，和跨平台共識比較；差 5 點以上列出。兩邊都不是事實，並列、不選邊。", "",
         "| 選舉 | 政黨 | 市場共識 | 評級中位數的勝率帶 | 差 | 評級 |", "|---|---|---|---|---|---|"]
    for d in res.divergences[:30]:
        rs = "、".join(f"{r.rater[:14]} {r.category}{(' ' + r.party) if r.party else ''}" for r in d.ratings[:4])
        L.append(f"| {d.race} | {d.party} | {100 * d.market:.0f}% | {100 * d.band[0]:.0f}–{100 * d.band[1]:.0f}% | "
                 f"{100 * d.gap:+.0f} | {rs} |")
    return L + [""]


@dataclass
class RecessionView:
    group: str  # "recession(United States|technical|2026Q4-2027Q4)|kalshi:KXRECSSNBER-27"
    market: object  # pmpol.models.Market
    title: str
    outlook: object  # pmpol.recession.Outlook
    model: float | None = None  # yield-curve probability of an NBER recession within 12 months (pmpol.macro)

    @property
    def gap(self) -> float | None:
        b = self.outlook.base_rate
        return None if b is None or self.market.mid is None else self.market.mid - b


def _yield_curve(data: Path = Path("data")) -> float | None:
    try:
        rows = json.loads((data / "macro" / "regimes.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    rows = rows.get("signals", rows) if isinstance(rows, dict) else rows
    for r in rows:
        if str(r.get("title", "")).startswith("殖利率曲線推估的衰退機率（美國"):
            prob = (r.get("result") or {}).get("probability")
            return float(prob) if isinstance(prob, (int, float)) else None
    return None


def recession_views(u: Universe, kb, data: Path = Path("data")) -> list[RecessionView]:
    """Live U.S. two-negative-quarters markets next to the GDP reference class (pmpol.recession)."""
    from pmpol import recession as rc

    growth, rates = rc.growth_from_kb(kb), rc.rates_from_kb(kb)
    if not growth or not rates:
        return []
    model = _yield_curve(data)
    out = []
    for k, m in sorted(u.markets.items()):
        if not m.active or m.bid is None or m.ask is None:
            continue
        ev = u.events.get(u.market_event.get(k, ""))
        w = rc.read_window(m.rules or "", ev.title if ev else "")
        if w is None:
            continue
        o = rc.outlook(w, growth, rates)
        group = f"recession(United States|technical|{rc.q_name(w.first)}-{rc.q_name(w.last)})|{k}"
        out.append(RecessionView(group, m, ev.title if ev else m.question, o, model))
    return out


def explain_recession(v: RecessionView, observed_at: str, kb):
    """Market, GDP base rate and yield-curve model side by side; never resolved."""
    from pmpol import recession as rc
    from pmpol.assumptions import cite
    from pmpol.proof import Proof

    o, m = v.outlook, v.market
    b = o.base_rate
    w = o.window
    win = f"{rc.q_name(w.first)}–{rc.q_name(w.last)}"
    base_txt = "—" if b is None else f"{100 * b:.0f}%"
    p = Proof(f"外部視角｜{v.title}（{win}）",
              f"技術性衰退（連續兩季實質 GDP 負成長）的參考類別：剩下 {o.unknown} 季，歷史上 {base_txt}"
              f"（{o.hits}/{o.cases}）；市場 {100 * m.mid:.0f}%"
              + ("" if v.model is None else f"；殖利率曲線模型（NBER 衰退、12 個月）{100 * v.model:.0f}%")
              + "：證據線並列，不選邊",
              result={"base_rate": None if b is None else round(b, 4), "market": round(m.mid, 4),
                      "gap": None if v.gap is None else round(v.gap, 4), "unknown_quarters": o.unknown,
                      "hits": o.hits, "n": o.cases, "decided": o.decided, "wider": w.wider,
                      **({"fundamentals_p": round(v.model, 4)} if v.model is not None else {})})
    gdp, cls = kb.facts[rc.GDP_FACT], kb.facts[rc.BASE_FACT]
    known = "、".join(f"{q} {g:+.1f}%" for q, g in o.known) or "還沒有任何一季公布"
    p.add("L0", f"結算規則：{win} 之間連續兩季實質 GDP 季增年率為負（BEA）"
                + ("；另有其他條件也算（例如 NBER 認定），比技術性定義寬" if w.wider else ""), source_url(m), kind="rule",
          id="rule")
    p.add("L1", f"窗口內已公布的季度：{known}", gdp.id, str(gdp.recorded_at), kind="data", id="known")
    state = "負" if o.last_negative else "正（或還沒有）"
    p.add("L2", f"1947 年以來，最後一季為{state}成長時，接下來 {o.unknown} 季內出現連續兩季負成長的比例："
                f"{o.hits}/{o.cases}", cls.id, str(cls.recorded_at), kind="data", id="class")
    fpr = kb.facts.get("us.gdp.first_print_record")
    first_rate = None
    if fpr is not None and isinstance(fpr.value, dict) and "base_rates_first_pos" in fpr.value:
        fv = fpr.value
        n = o.unknown
        if not o.last_negative and n in fv["base_rates_first_pos"]:
            a, b1 = fv["base_rates_first_pos"][n]
            c, d = fv["base_rates_latest_pos"][n]
            first_rate = a / b1 if b1 else None
            p.add("L2", f"用初估（BEA 第一次公布，ALFRED 版本，{fv['sample']}）：接下來 {n} 季內湊成連續兩季負成長 {a}/{b1}；"
                        f"同期用修正後的數字 {c}/{d}。初估和現在正負號不同的季度 {len(fv['sign_flips'])} 個；"
                        f"只有初估是連續兩季負成長的：{'、'.join(q for q in fv['negative_pairs_first'] if q not in fv['negative_pairs_latest']) or '無'}",
                  fpr.id, str(fpr.recorded_at), kind="data", id="first_prints")
        recent = fv.get("recent_first_prints") or {}
        flips = [f"{q}（初估 {recent[q]:+.1f}、現在 {g:+.1f}）" for q, g in o.known
                 if q in recent and (recent[q] < 0) != (g < 0)]
        if flips:
            p.caveats.append("窗口內已公布的季度，初估和現在的正負號不同：" + "、".join(flips) + "；結算看規則指定的那次公布。")
    if first_rate is not None:
        p.result["first_print_base_rate"] = round(first_rate, 4)
    ref = cite(p, "technical_recession_reference_class")
    p.add("L5", f"基準率 {base_txt}" + ("（已公布的資料已經出現連續兩季負成長）" if o.decided else ""),
          "Kahneman & Lovallo 1993", kind="logic", id="base", inputs=("rule", "known", "class", *ref))
    p.add("L4", f"{info(m.venue).code}：買 {100 * m.bid:.1f}／賣 {100 * m.ask:.1f}", source_url(m), observed_at,
          kind="data", id="market")
    if b is not None:
        rel = ("高於" if m.mid > b else "低於") + f"基準率 {100 * abs(m.mid - b):.0f} 點"
        p.add("L5", f"市場{rel}" + ("；這個市場的定義比技術性衰退寬，價格本來就應該不低於技術性衰退的機率" if w.wider else ""),
              kind="logic", id="compare", inputs=("base", "market"))
    if v.model is not None:
        p.add("L5", f"殖利率曲線 probit 模型（紐約聯儲）：未來 12 個月 NBER 認定衰退的機率 {100 * v.model:.0f}%（總經層的推論，"
                    "定義和時間都和這個市場不同）", "data/macro/regimes.json", observed_at, kind="data", id="model")
    p.alt("這次的經濟條件和戰後平均不同（關稅、利率、財政）", "unchecked",
          "參考類別沒有條件化；殖利率曲線是唯一的條件化模型，而且定義不同")
    p.caveats += ["基準率是 L2 的歷史頻率、市場是 L4 觀測、殖利率曲線是另一個模型的 L5 推論，三者都不是事實。",
                  "1947 年以來的基準率用最新修正後的數字；市場依規則指定的那次公布結算（通常是初估）。1992 年以後的比較"
                  "（`pmpol gdp-realtime`）顯示，初估湊成連續兩季負成長的頻率比修正後高（2022 年上半年只有初估是）。",
                  "歷史窗口互相重疊，樣本不獨立；1940–50 年代的季度波動比現在大，早期樣本可能高估。"]
    if not o.known and o.unknown:
        p.caveats.append("窗口還沒開始（中間可能還有尚未公布、但不在窗口內的季度），基準率用「最後一季為正」近似。")
    return p


@dataclass
class Baseline:
    group: str  # the indicator variable, e.g. "indicator(us_unemployment|2026-11, pct, step 0.1)"
    outlook: object  # pmpol.baseline.Outlook
    source: str  # cached series file
    rows: list = field(default_factory=list)  # (market, label, historical probability)

    @property
    def worst(self) -> float:
        """Largest gap between a market's mid and the historical probability of its interval."""
        return max((abs(m.mid - q) for m, _, q in self.rows), default=0.0)


MAX_BASELINE_SPREAD = 0.10  # the consensus's cut: wider books carry no price worth comparing


def baselines(u: Universe, props, data: Path = Path("data")) -> list[Baseline]:
    """Live markets on a monthly statistic (pmpol.baseline.SERIES) next to the series' own history."""
    from pmpol import baseline as bl

    cache = data / "fundamentals"
    by_var: dict = {}
    for p in props:
        if p.var.kind != "indicator":
            continue
        series = p.var.subject.split("|")[0]
        period = bl.period_of(p.var.subject)
        m = u.markets.get(p.market)
        if series not in bl.SERIES or period is None or m is None or not m.active or m.bid is None or m.ask is None:
            continue
        if m.ask - m.bid > MAX_BASELINE_SPREAD:  # an empty book's mid (bid 0, ask 1) says nothing
            continue
        by_var.setdefault((series, period, p.var.id if hasattr(p.var, "id") else str(p.var)), []).append((p, m))
    values_of: dict = {}
    out = []
    for (series, period, vid), items in sorted(by_var.items()):
        if series not in values_of:
            values_of[series] = bl.load_values(series, cache)
        values, path = values_of[series]
        o = bl.outlook(series, period, values) if values else None
        if o is None:
            continue
        b = Baseline(vid, o, str(path))
        for p, m in sorted(items, key=lambda t: (t[0].spans[0].lo if t[0].spans else 0)):
            b.rows.append((m, m.outcome or m.question, o.probability(p.spans)))
        out.append(b)
    return out


def explain_baseline(b: Baseline, observed_at: str):
    """Each interval's market price next to the share of historical outcomes inside it; never resolved."""
    from pmpol import baseline as bl
    from pmpol.assumptions import cite
    from pmpol.proof import Proof

    o = b.outlook
    name = bl.ZH.get(o.series, o.series)
    nd = 2 if o.step < 0.1 else 1  # decimals as the agency publishes
    agency = bl.SOURCE_ZH.get(o.code, "BLS，經 FRED")
    worst_m, _, worst_q = max(b.rows, key=lambda r: abs(r[0].mid - r[2]))
    if o.published:
        head = (f"{o.period} 已經公布：{o.last_value:.{nd}f}%；市場還在交易的區間依公布值就能判定（以結算規則指定的那次公布為準）")
    elif o.method == "calendar":
        head = (f"已公布到 {o.last_month}（12 個月 {o.last_value:.{nd}f}%）；剩下 {o.horizon} 個月用 {o.start[:4]} 年以來同月份的月增率，"
                f"{len(o.outcomes)} 年；和市場差最多的區間「{worst_m.outcome}」：市場 {100 * worst_m.mid:.0f}%、歷史 {100 * worst_q:.0f}%")
    else:
        head = (f"從最新公布的 {o.last_month}（{o.last_value:.{nd}f}%）往後 {o.horizon} 個月，{o.start[:4]} 年以來同樣時距的變化"
                f"有 {len(o.outcomes)} 次；和市場差最多的區間「{worst_m.outcome}」：市場 {100 * worst_m.mid:.0f}%、歷史 "
                f"{100 * worst_q:.0f}%")
    p = Proof(f"外部視角｜{name} {o.period}", head + "：兩條證據線並列，不選邊",
              result={"series": o.series, "period": o.period, "last_month": o.last_month, "last_value": o.last_value,
                      "horizon_months": o.horizon, "n": len(o.outcomes), "published": o.published,
                      "method": o.method, "worst_gap": round(b.worst, 4),
                      "rows": [{"market": m.key, "label": lab, "mid": round(m.mid, 4), "historical": round(q, 4)}
                               for m, lab, q in b.rows]})
    p.add("L1", f"{o.code}（{agency}）最新公布：{o.last_month}" + ("（12 個月）" if o.method == "calendar" else "")
          + f" {o.last_value:.{nd}f}%", bl.url(o.code), o.last_month, kind="data", id="last")
    ref = []
    if not o.published and o.method == "calendar":
        p.add("L1", f"{o.code} {o.start} 以來的月增率（{len(o.outcomes)} 年的同月份）", bl.url(o.code), o.last_month,
              kind="data", id="history")
        ref = cite(p, "inflation_calendar_month_reference_class")
        p.add("L5", f"已公布的月份固定，剩下 {o.horizon} 個月換成過去某一年同月份的月增率，連乘成 12 個月率、四捨五入到 0.01，"
                    "落在各區間的比例", kind="logic", id="dist", inputs=("last", "history", *ref))
    elif not o.published:
        p.add("L1", f"{o.code} {o.start} 以來的月資料（{len(o.outcomes)} 個 {o.horizon} 個月時距）", bl.url(o.code),
              o.last_month, kind="data", id="history")
        ref = cite(p, "indicator_change_reference_class")
        p.add("L5", f"每個歷史起點的 {o.horizon} 個月變化加到最新值、四捨五入到 0.1，落在各區間的比例", kind="logic",
              id="dist", inputs=("last", "history", *ref))
    for i, (m, lab, q) in enumerate(b.rows):
        p.add("L4", f"{info(m.venue).code}「{lab}」：買 {100 * m.bid:.1f}／賣 {100 * m.ask:.1f}；歷史 {100 * q:.0f}%",
              source_url(m), observed_at, kind="data", id=f"m{i}")
    p.caveats.append("歷史分布是 L5 推論、市場是 L4 觀測，兩者都不是事實；差距大不代表市場錯，市場可能知道歷史看不到的事（政策、震盪、預測調查）。")
    if o.method == "calendar":
        p.caveats += ["12 個月率由 IBGE 的月增率連乘後四捨五入，偶爾會和公布的 12 個月數字差 0.01；結算以規則指定的那次公布為準。",
                      "Kalshi 的規則只寫「巴西 12 個月（年）通膨率」，沒有寫明是 IPCA；這裡當成 IPCA。"]
        if not o.published:
            p.caveats.append(f"{o.start[:4]} 年以來的樣本包含 2002–03、2015–16 年的高通膨，會讓分布的尾巴偏寬。")
    else:
        p.caveats += ["數字由指數自己計算後四捨五入，偶爾會和 BLS 公布的數字差 0.1；結算以規則指定的那次公布為準。",
                      "月份按題目寫的資料月份處理（例如 11 月的失業率，12 月初公布）。"]
        if not o.published:
            p.caveats.append(f"{o.start[:4]} 年以來的樣本包含 2020 年疫情和 2021–22 年通膨的極端值，會讓分布的尾巴比平常寬。")
    p.alt("市場在用歷史分布以外的資訊（預測調查、即時資料、政策訊號）", "unchecked",
          "沒有接市場共識調查（例如彭博、費城聯儲 SPF）；即時資料只有總經層的幾條序列")
    return p


def _outside_view_lines(res: UniverseRun) -> list[str]:
    if not res.outside_views and not res.president_views and not res.recession_views and not res.baselines:
        return []
    L = [] if not res.outside_views else ["### 外部視角：期中選舉的基準率（參考類別）", "",
         "1946 年以來每次期中選舉，總統所屬政黨在眾議院和參議院的席次變化（眾議院史官辦公室和參議院歷史辦公室的席次表、"
         "Miller Center 的政黨，`pmpol reference`）。換算成「以現在的席次，過去的變化有幾次會讓總統政黨保住多數」"
         "（參議院由同黨的副總統破平手），和市場共識並列；兩邊都不是事實，不選邊。參議院每次只改選三分之一，參考類別看不到改選席次的組成。",
         "", "| 選舉 | 總統政黨 | 現有席次 | 能承受的變化 | 基準率（保住多數） | 95% 區間 | 市場共識（總統政黨） |",
         "|---|---|---|---|---|---|---|"]
    for o in res.outside_views:
        v = o.view
        lo, hi = o.interval
        mk = f"{100 * o.market:.0f}%" if o.market is not None else "—"
        L.append(f"| {o.group} | {v.president_party} | {v.seats} | ≥ {v.needed:+d} 席 | {v.keeps}/{v.n}（{100 * v.share:.0f}%）"
                 f" | {100 * lo:.0f}–{100 * hi:.0f}% | {mk} |")
    if res.president_views:
        L += ["", "### 外部視角：總統選舉的執政黨紀錄", "",
              "1952 年以來每次總統選舉，執政黨有沒有守住白宮（`pmpol presidential`）。全部、執政一任或兩任以上、總統參選或"
              "開放席次，各自的比例和市場共識並列；子類別互相矛盾時都列出來，不選邊。", "",
              "| 選舉 | 執政黨 | 本次條件 | 全部 | 一任 | 開放席次 | 市場共識（執政黨） |", "|---|---|---|---|---|---|---|"]
        for o in res.president_views:
            v, r = o.view, o.view.rates
            cond = ("可連任" if v.eligible else "開放席次") + "、" + {True: "一任", False: "兩任以上", None: "—"}[v.first_term]
            mk = f"{100 * o.market:.0f}%" if o.market is not None else "—"
            L.append(f"| {o.group} | {v.party} | {cond} | {r['all']['kept']}/{r['all']['n']} | "
                     f"{r['first_term']['kept']}/{r['first_term']['n']} | {r['open_seat']['kept']}/{r['open_seat']['n']} | {mk} |")
        L.append("")
    if res.recession_views:
        L += ["", "### 外部視角：技術性衰退（連續兩季 GDP 負成長）", "",
              "以「連續兩季實質 GDP 負成長」結算的美國衰退市場：已公布的季度是已知的，剩下的季度用 1947 年以來的歷史頻率"
              "（`pmpol recession`）；殖利率曲線模型的定義（NBER 衰退、12 個月）不同，只並列參考。", "",
              "| 市場 | 平台 | 窗口 | 剩下的季度 | 基準率 | 市場 | 殖利率曲線 | 定義較寬 |", "|---|---|---|---|---|---|---|---|"]
        for v in res.recession_views:
            o = v.outlook
            b = "—" if o.base_rate is None else f"{100 * o.base_rate:.0f}%（{o.hits}/{o.cases}）"
            mdl = "—" if v.model is None else f"{100 * v.model:.0f}%"
            L.append(f"| {v.title[:40]} | {info(v.market.venue).code} | {v.group.split('|')[2].rstrip(')')} | {o.unknown} | "
                     f"{b} | {100 * v.market.mid:.0f}% | {mdl} | {'是' if o.window.wider else '否'} |")
        L.append("")
    if res.baselines:
        from pmpol import baseline as bl

        L += ["", "### 外部視角：官方統計的歷史分布", "",
              "失業率和 CPI 的題目：從最新公布值往後 k 個月，用 1990 年以來同樣時距的變化，算各區間的歷史比例，和市場並列"
              "（`pmpol baseline` 下載序列）。巴西 IPCA 的 12 個月率：已公布的月份固定，剩下的月份用 2000 年以來同月份的月增率"
              "（保留基期效應）。已公布的月份直接依公布值判定。下表是每個變數裡市場和歷史差最多的區間。", "",
              "| 變數 | 最新公布 | 往後 | 差最多的區間 | 市場 | 歷史 |", "|---|---|---|---|---|---|"]
        for b in sorted(res.baselines, key=lambda b: -b.worst):
            o = b.outlook
            m, lab, q = max(b.rows, key=lambda r: abs(r[0].mid - r[2]))
            nd = 2 if o.step < 0.1 else 1
            L.append(f"| {bl.ZH.get(o.series, o.series)} {o.period} | {o.last_month} {o.last_value:.{nd}f}% | "
                     f"{'已公布' if o.published else f'{o.horizon} 個月'} | {info(m.venue).code}「{lab[:30]}」 | "
                     f"{100 * m.mid:.0f}% | {100 * q:.0f}% |")
        L.append("")
    return L + [""]


def _candidate_lines(res: UniverseRun) -> list[str]:
    """How the person-party bridge is grounded, and where the L1 candidate lists contradict the labels."""
    bridges = [r for r in res.rule_relations if r.template.endswith(":bridge_person_party")]
    if not bridges and not res.candidate_conflicts:
        return []
    listed = sum(any(g.startswith("data:candidates:") for g in r.grounds) for r in bridges)
    L = ["### 候選人 ⇔ 政黨的依據", "",
         f"{len(bridges):,} 條「候選人 ⇔ 政黨」關係：{listed:,} 條引用 L1 大選候選人名單（維基百科，提議中），"
         f"{len(bridges) - listed:,} 條沒有名單、仍依賴「從標籤學到」的假設。名單有 {len(res.candidates):,} 場選舉"
         f"（`pmpol candidates`）。", ""]
    if res.candidate_conflicts:
        L += [f"名單和平台標籤不一致、因此沒有建立關係的：{len(res.candidate_conflicts)} 處（兩邊並列，不選邊；請人工確認）。", ""]
        L += [f"- {c}" for c in res.candidate_conflicts[:30]]
        L.append("")
    return L


def render_report(res: UniverseRun, generated_at: str, top: int = 40, residual_lines: list[str] | None = None) -> str:
    u = res.universe
    L = [f"# 政治預測市場全景報告 — {generated_at}", ""]

    ev_by_venue = Counter(e.venue for e in u.events.values())
    live_by_venue = Counter(m.venue for m in u.markets.values() if live(m))
    venues = sorted(ev_by_venue, key=venue_order)
    races_multi = sum(1 for v in u.races.values() if len(v) >= 2)
    venue_cnt = Counter(len(v) for v in u.races.values())
    head = " | ".join(f"{info(v).label}（{info(v).code}）" for v in venues)
    L += ["## 1. 覆蓋範圍", "",
          f"| | {head} | 合計 |", "|---|" + "---|" * (len(venues) + 1),
          f"| 事件 | {' | '.join(f'{ev_by_venue[v]:,}' for v in venues)} | {len(u.events):,} |",
          f"| 有報價的市場 | {' | '.join(f'{live_by_venue[v]:,}' for v in venues)} | {sum(live_by_venue.values()):,} |",
          "",
          f"- 選舉類可辨識的競選（race key）：**{len(u.races):,}** 個，其中至少兩個平台都有的 **{races_multi:,}** 個"
          f"（{'、'.join(f'{n} 個平台 {c:,} 個' for n, c in sorted(venue_cnt.items(), reverse=True) if n >= 2)}）",
          f"- 分群：**{len(set(u.clusters.values())):,}** 群（選舉依競選精確分群，其餘依文字相似度）",
          f"- 關係：結構規則 **{len(res.rule_relations):,}** 條、文字配對 **{len(res.text_relations):,}** 條（待人工確認）",
          ""]

    L += ["## 2. 主題地圖", "", f"| 主題 | {' | '.join(info(v).code for v in venues)} | 主要子類 |",
          "|---|" + "---|" * (len(venues) + 1)]
    by_topic: dict[str, Counter] = defaultdict(Counter)
    sub: dict[str, Counter] = defaultdict(Counter)
    for k, t in u.tags.items():
        by_topic[t.topic][u.events[k].venue] += 1
        if t.topic.startswith("elections"):
            sub[t.topic][f"{t.office}"] += 1
        else:
            sub[t.topic][u.cluster_labels.get(u.clusters.get(k, ""), "")] += 1
    for topic in TOPICS:
        c = by_topic.get(topic)
        if not c:
            continue
        top_sub = ", ".join(f"{name} ({n})" for name, n in sub[topic].most_common(6))
        L.append(f"| {TOPIC_ZH[topic]} | {' | '.join(f'{c[v]:,}' for v in venues)} | {top_sub} |")
    L.append("")

    L += ["## 3. 關係（來源：命題本體）", "",
          "每個市場讀成「變數 ∈ 集合」，關係用集合運算和少數橋接規則推出來（`docs/PROPOSITION_ONTOLOGY.md`）。"
          "手寫模板仍然在跑，當作獨立的交叉驗證（第 3b 節）。",
          "",
          "| 關係類型 | 關係數 | 兩邊都有報價 | 扣費後違反 |", "|---|---|---|---|"]
    rel_count = Counter(r.template for r in res.rule_relations + res.text_relations)
    checked = Counter(r.template for r in res.rule_relations + res.text_relations
                      if all(k in u.markets and live(u.markets[k]) for k in r.lhs + r.rhs))
    viol = Counter(s.kind for s in res.rule_signals + res.text_signals)
    for tpl, n in rel_count.most_common():
        L.append(f"| {_tpl_zh(tpl)} | {n:,} | {checked[tpl]:,} | {viol[tpl]:,} |")
    L.append("")

    L += _rules_lines(res)
    L += _crosscheck_lines(res)
    L += _candidate_lines(res)
    L += _divergence_lines(res)
    L += _outside_view_lines(res)
    if res.coherence is not None:
        from pmpol import coherence

        L += coherence.render(res.coherence, res.universe)

    L += ["## 4. 結構規則違反（扣除 taker 手續費後，可執行價）", "",
          "賣出 = 在 bid 賣 YES（等同買 NO）；買入 = 在 ask 買 YES。深度欄是各腿在報價上可成交量的最小值（列表沒有數量的平台由訂單簿補上，只查前 60 筆）。"
          f"平台代號：{'、'.join(f'{info(v).code} = {info(v).label}' for v in venues)}。",
          "",
          "「規則」欄是兩邊結算條件的比對（`propositions/resolution.py`）：有實質差異的不一定是違反。"
          "「信心」是分析信心（和邊際大小無關，`pmpol/confidence.py`）：依賴沒有根據的假設、實質差異的規則或只靠標題配對的是低。",
          "",
          "| 邊際 | 關係類型 | 變數 / 群組 | 賣出 | 買入 | 平台 | 深度 | 規則 | 信心 |", "|---|---|---|---|---|---|---|---|---|"]
    from pmpol.confidence import ZH as CONF_ZH

    for s in res.rule_signals[:top]:
        p = s.payload
        size = "—" if p["min_size"] is None else f"{p['min_size']:,.0f}"
        proof = res.proofs.get(p.get("id"))
        rules = STATUS_ZH.get(proof.result.get("rules", ""), "") if proof else ""
        conf = CONF_ZH[proof.confidence()[0]] if proof else "—"
        L.append(f"| {100 * s.edge:+.1f} | {_tpl_zh(s.kind)} | {s.subject} | {_legs(p['sell'])} | "
                 f"{_legs(p['buy'])} | {_venue_of(p['sell'] + p['buy'])} | {size} | {rules or '—'} | {conf} |")
    L.append("")

    L += ["## 5. 中間價的最大不一致（盤口夠緊、但不一定能成交）", "",
          "| 差距 | 關係類型 | 變數 / 群組 | 說明 |", "|---|---|---|---|"]
    for g, r in res.gaps[:20]:
        L.append(f"| {100 * g:+.1f} | {_tpl_zh(r.template)} | {r.group} | {r.note} |")
    L.append("")

    L += ["## 6. 單一事件內部的約束違反", "", "| 邊際 | 類型 | 事件 |", "|---|---|---|"]
    for s in res.event_signals[:15]:
        L.append(f"| {100 * s.edge:+.1f} | {s.kind} | {s.subject} — {s.payload.get('title', '')[:70]} |")
    if not res.event_signals:
        L.append("| — | 無 | |")
    L.append("")

    L += ["## 7. 文字配對（待人工確認規則後才算數）", "",
          "| 邊際 | 配對 | 賣出 | 買入 |", "|---|---|---|---|"]
    for s in res.text_signals[:20]:
        p = s.payload
        L.append(f"| {100 * s.edge:+.1f} | {p['note'][:110]} | {_legs(p['sell'])} | {_legs(p['buy'])} |")
    L.append("")

    if res.consensus:
        devs = sorted(((d, m, c) for c in res.consensus for m, d in c.deviations()), key=lambda t: -abs(t[0]))
        by_venue = Counter(info(m.venue).code for d, m, c in devs if abs(d) >= 0.05)
        L += [f"## 7a. 跨平台共識（{len(res.consensus):,} 組同一合約）", "",
              "同一合約在多個平台的價格合併成一個機率：先看扣掉手續費後各平台的報價區間有沒有交集（沒有交集就是真的不一致，"
              "不給點估計），再用 logit 空間的不確定度加權平均（Polymarket 和 Polymarket US 同一家族只算一次），"
              "最後用已結算市場算出的校準斜率重新校準。方法見 docs/ARCHITECTURE.md 第 8g 節。",
              f"扣費後仍不一致、不給點估計的：{sum(c.disagree for c in res.consensus):,} 組。"
              f"偏離 ≥ 5 點的次數，依平台：{'、'.join(f'{v} {n}' for v, n in by_venue.most_common())}", "",
              "| 偏離 | 平台 | 競選 | 選項 | 該平台 | 共識 | 校準後（95% 區間） |", "|---|---|---|---|---|---|---|"]
        for d, m, c in devs[:20]:
            if c.disagree:
                cons_txt, rc = f"不一致（加權 {100 * c.pooled:.1f}%）", "—"
            else:
                cons_txt = f"{100 * c.pooled:.1f}%"
                rc = "—" if c.recalibrated is None else (f"{100 * c.recalibrated:.1f}%（{100 * c.interval[0]:.0f}–"
                                                          f"{100 * c.interval[1]:.0f}%）")
            L.append(f"| {100 * d:+.1f} | {info(m.venue).code} | {c.group} | {m.outcome[:30]} | {100 * m.mid:.1f}% | "
                     f"{cons_txt} | {rc} |")
        L.append("")

    if res.suspects:
        L += [f"## 7b. 疑似標籤顛倒（{len(res.suspects)} 個事件，相關的 {len(res.dropped)} 條關係已排除，請到平台頁面人工確認）", "",
              "判斷規則：同一場競選，這個平台的 D 和 R 價格都和至少兩個其他平台的中位數相差 30 個百分點以上，而且方向相反。", ""]
        L += [f"- `{k}` {u.events[k].title}：{note}" for k, note in sorted(res.suspects.items())]
        L.append("")

    if residual_lines:
        L += residual_lines
    else:
        other = [u.events[k].title for k, t in u.tags.items() if t.topic == "other"]
        L += [f"## 8. 未分類事件（{len(other)} 個，用來擴充分類規則）", ""]
        L += [f"- {t}" for t in other[:25]]
        L.append("")
    unplaced = sorted(u.events[k].title for k, t in u.tags.items()
                      if t.office in ("mayor", "local") and t.topic == "elections_us" and not t.place)
    if unplaced:
        L += [f"### 8e. 地點未確認的地方選舉（{len(unplaced)} 個，暫時當成美國）", "",
              "標題、平台標籤、規則文字都沒寫州或國家，同一城市同一年在其他平台也沒有證據。和美國城市撞名的不猜"
              "（例如 London、Hamilton、Richmond），請人工確認後補進地名表或規則。", ""]
        L += [f"- {t}" for t in unplaced[:40]]
        L.append("")
    if res.entity_graph is not None:
        from pmpol.entities.graph import summarize
        L += summarize(u, res.entity_graph)
    return "\n".join(L)
