"""Clusters and cross-venue matching for events without a structured race key.

Elections with a race key are clustered by that key (exact). Everything else is
clustered by TF-IDF text similarity within its topic, and matched across venues by
mutual-best cosine similarity. Text matches are candidates: their relations carry
confidence "text" and should be checked against both venues' rules.
"""

from __future__ import annotations

import re
from collections import defaultdict
from itertools import combinations

import numpy as np
from sklearn.cluster import AgglomerativeClustering
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from pmpol.models import Event, Relation
from pmpol.universe.index import Universe
from pmpol.universe.outcomes import _norm, surname
from pmpol.venues import venue_order

_STOP = ["will", "the", "be", "by", "in", "of", "a", "an", "to", "on", "who", "what", "which", "before", "after",
         "next", "win", "winner", "election", "2025", "2026", "2027", "2028", "2029", "2030"]


def _doc(e: Event) -> str:
    outcomes = " ".join(m.outcome for m in e.markets[:12] if m.outcome)
    return f"{e.title} {e.title} {outcomes}"


def theme_of(u: Universe, key: str) -> str:
    t = u.tags[key]
    if t.race_key:
        return f"{t.topic}/{t.country}/{t.office}/{t.year}"
    return f"{t.topic}/{t.country or '-'}"


def build_clusters(u: Universe, distance: float = 0.75) -> None:
    """Fill u.clusters (event key -> cluster id) and u.cluster_labels."""
    loose: dict[str, list[str]] = defaultdict(list)
    for key, t in u.tags.items():
        if t.race_key:
            cid = f"race:{t.race_key}"
            u.clusters[key] = cid
            u.cluster_labels[cid] = f"{t.office} · {t.jurisdiction} · {t.year}" + (f" · {t.stage}" if t.stage != "general" else "")
        else:
            loose[t.topic].append(key)

    for topic, keys in loose.items():
        if len(keys) == 1:
            u.clusters[keys[0]] = f"{topic}:0"
            u.cluster_labels[f"{topic}:0"] = u.events[keys[0]].title[:60]
            continue
        vec = TfidfVectorizer(stop_words=_STOP, ngram_range=(1, 2), min_df=1, sublinear_tf=True)
        try:
            X = vec.fit_transform([_doc(u.events[k]) for k in keys])
        except ValueError:  # no term left in any title (all stop words): one cluster each
            for i, k in enumerate(keys):
                u.clusters[k] = f"{topic}:e{i}"
                u.cluster_labels[f"{topic}:e{i}"] = u.events[k].title[:60]
            continue
        empty = np.asarray(X.sum(axis=1)).ravel() == 0  # titles of stop words only: cosine is undefined for them
        for i in np.where(empty)[0]:
            u.clusters[keys[i]] = f"{topic}:e{i}"
            u.cluster_labels[f"{topic}:e{i}"] = u.events[keys[i]].title[:60]
        keep = np.where(~empty)[0]
        if len(keep) == 0:
            continue
        keys, X = [keys[i] for i in keep], X[keep]
        if len(keys) == 1:
            u.clusters[keys[0]] = f"{topic}:0"
            u.cluster_labels[f"{topic}:0"] = u.events[keys[0]].title[:60]
            continue
        labels = AgglomerativeClustering(n_clusters=None, metric="cosine", linkage="average",
                                         distance_threshold=distance).fit_predict(X.toarray())
        terms = np.array(vec.get_feature_names_out())
        for lab in set(labels):
            idx = np.where(labels == lab)[0]
            cid = f"{topic}:{lab}"
            weights = np.asarray(X[idx].sum(axis=0)).ravel()
            top = [t for t in terms[np.argsort(-weights)] if not re.fullmatch(r"\d+", t)][:3]
            u.cluster_labels[cid] = " / ".join(top)
            for i in idx:
                u.clusters[keys[i]] = cid


def text_matches(u: Universe, min_sim: float = 0.6) -> list[tuple[str, str, float]]:
    """Mutual-best cross-venue pairs among events that have no race key."""
    by_topic: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
    for key, t in u.tags.items():
        if not t.race_key:
            by_topic[t.topic][u.events[key].venue].append(key)
    pairs = []
    for topic, venues in by_topic.items():
        for va, vb in combinations(sorted(venues, key=venue_order), 2):
            pairs += _mutual_best(u, venues[va], venues[vb], min_sim)
    return pairs


def _mutual_best(u: Universe, ks: list[str], ps: list[str], min_sim: float) -> list[tuple[str, str, float]]:
    pairs = []
    if ks and ps:
        vec = TfidfVectorizer(stop_words=_STOP, ngram_range=(1, 2), sublinear_tf=True)
        vec.fit([u.events[k].title for k in ks + ps])
        S = cosine_similarity(vec.transform([u.events[k].title for k in ks]),
                              vec.transform([u.events[k].title for k in ps]))
        best_p, best_k = S.argmax(axis=1), S.argmax(axis=0)
        for i, j in enumerate(best_p):
            if best_k[j] == i and S[i, j] >= min_sim:
                a, b = u.tags[ks[i]], u.tags[ps[j]]
                if a.year and b.year and a.year != b.year:
                    continue
                pairs.append((ks[i], ps[j], float(S[i, j])))
    return pairs


def _label(text: str) -> str:
    return _norm(re.sub(r"\(.*?\)", "", text)).strip(" ?.")


def _close_days(a, b) -> float | None:
    from datetime import datetime
    if not a.close_time or not b.close_time:
        return None
    from datetime import timezone

    def parse(t: str) -> datetime:
        d = datetime.fromisoformat(t.replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)  # some venues omit the zone; read as UTC
    return (parse(b.close_time) - parse(a.close_time)).total_seconds() / 86400


def _pair_relation(x, y, group: str, note: str, deadline_like: bool) -> Relation | None:
    """Equivalent when both settle at about the same time; for deadline questions an earlier
    deadline implies the later one; otherwise the pair is too uncertain to relate."""
    days = _close_days(x, y)
    if days is None or abs(days) <= 7:
        return Relation("equivalent", [x.key], [y.key], "cross_venue_text", group, "text", note)
    if not deadline_like:
        return None
    early, late = (x, y) if days > 0 else (y, x)
    return Relation("implies", [early.key], [late.key], "cross_venue_deadline", group, "text",
                    note + " (earlier deadline implies later)")


def text_relations(u: Universe, pairs: list[tuple[str, str, float]]) -> list[Relation]:
    """Align outcomes of text-matched events; every relation is marked for manual review."""
    out = []
    for ka, kb, sim in pairs:
        a, b = u.events[ka], u.events[kb]
        ma = [m for m in a.markets if m.active]
        mb = [m for m in b.markets if m.active]
        group = u.clusters.get(ka, "")
        note = f"title similarity {sim:.2f}: “{a.title}” ~ “{b.title}”"
        deadline_like = "by_date" in (u.tags[ka].measure, u.tags[kb].measure) or \
            bool(re.search(r"\bby\b|before|in 20\d\d", a.title + " " + b.title, re.I))
        if len(ma) == 1 and len(mb) == 1:
            if r := _pair_relation(ma[0], mb[0], group, note, deadline_like):
                out.append(r)
            continue
        for keyfn in (lambda m: _label(m.outcome), lambda m: surname(m.outcome)):
            la: dict = {}
            for m in ma:
                la.setdefault(keyfn(m), []).append(m)
            lb: dict = {}
            for m in mb:
                lb.setdefault(keyfn(m), []).append(m)
            hits = [(la[k][0], lb[k][0]) for k in la.keys() & lb.keys()
                    if k and len(la[k]) == 1 and len(lb[k]) == 1]
            if hits:
                out += [r for x, y in hits if (r := _pair_relation(x, y, group, note, deadline_like))]
                break
    return out
