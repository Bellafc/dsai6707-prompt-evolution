"""How correlated are the quote errors of different venue families, and which venues are noisier than their
spread shows? (the consensus band's rho and per-venue extra noise)

The consensus (pmpol.universe.consensus) gives each family's pooled logit an uncertainty

    sigma_f = (spread / 2 + extra_f) / (m (1 - m)) + sigma0

and assumes a correlation rho between families. extra_f is a venue's quote noise beyond its spread, in
probability units like the spread, so in logit terms it grows toward 0 and 100% (zero for most venues). Under that
model the gap between two families on the same contract, d = x_f - x_g, is N(0, V) with

    V = sigma_f^2 + sigma_g^2 - 2 rho sigma_f sigma_g,

so the gaps observed on contracts listed by several families identify the parameters, given the sigma model:

  1. rho from the pairs of venues without extra noise: the rho at which the model's 95% interval for d covers 95%
     of the observed gaps (`coverage_rho`). The band is a 95% band and the gaps are heavy-tailed, so a normal
     likelihood fit (also reported) answers a different question.
  2. for each venue listed as noisy (PredictIt), extra_f from its pairs with the other venues, given rho, by the
     same 95% coverage rule (`fit_noise`).

Intervals are a cluster bootstrap over contracts (one contract's gaps persist across snapshots), refitting both.

A noisy venue's gaps can also have a direction. PredictIt's are pressed toward 50% (longshots dear, favourites
cheap, by about a point either way; 2026-10-04). That part is estimated first, as a shift toward the nearer
extreme (`fit_shift`, in probability units, smoothed near 50% with SHIFT_WIDTH), and removed from its quotes
before rho and the extra noise are fitted, so the extra noise is what is left after the bias (2026-10-05). The
consensus applies the same shift to the venue's quotes before pooling.

What this does not identify: an error every family shares relative to the outcome (all venues wrong the same
way). It cancels in every gap, and with binary outcomes it cannot be told apart from the outcome's own
uncertainty; the part of it that is systematic shows up as the calibration slope b (kb/L2/market_calibration.yaml),
which the consensus applies with its own interval.
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass, field
from datetime import date
from typing import Iterable

import numpy as np

from pmpol.models import Event
from pmpol.universe import consensus as cons
from pmpol.universe.index import live

Z95 = 1.959964
FACT_ID = cons.RHO_FACT
NOISY = ("predictit",)  # venues whose pairs covered under 90% with one rho (2026-10-04); see the report
SHIFTED = ("predictit",)  # venues whose directional bias is estimated and removed (fit_shift)
LEVELS = ((0, .05), (.05, .15), (.15, .5), (.5, .85), (.85, .95), (.95, 1.0001))


@dataclass(frozen=True)
class Gap:
    contract: int  # index of the equivalence class
    snapshot: str
    pair: str  # "kalshi-polymarket" (families, sorted)
    d: float  # logit gap between the two families' pooled quotes (first minus second)
    a_f: float  # spread part of each family's sigma (sigma minus the floor), logit units
    a_g: float
    p_f: float = 0.5  # each family's pooled probability
    p_g: float = 0.5

    @property
    def families(self) -> tuple[str, str]:
        f, g = self.pair.split("-")
        return f, g


def collect(classes: list[tuple[str, list[str]]], snapshots: Iterable[tuple[str, list[Event]]]) -> list[Gap]:
    """Family-pair gaps on every contract listed by two or more families, with the consensus's own filters
    (live two-sided book, spread <= 10 points) and its within-family pooling."""
    out = []
    for name, events in snapshots:
        mk = {m.key: m for e in events for m in e.markets}
        for ci, (_, keys) in enumerate(classes):
            ms = [mk[k] for k in keys if k in mk and live(mk[k])]
            ms = [m for m in ms if m.spread is not None and m.bid is not None
                  and 0 <= m.spread <= cons.MAX_SPREAD + 1e-9]
            fams: dict[str, list] = {}
            for m in ms:
                fams.setdefault(cons.FAMILY.get(m.venue, m.venue), []).append(m)
            if len(fams) < 2:
                continue
            x, a = {}, {}
            for f, members in fams.items():
                w = [1 / cons._sigma(m) ** 2 for m in members]
                x[f] = sum(wi * cons._logit(m.mid) for wi, m in zip(w, members)) / sum(w)
                a[f] = min(cons._sigma(m) for m in members) - cons.SIGMA0
            fs = sorted(fams)
            for i, f in enumerate(fs):
                for g in fs[i + 1:]:
                    out.append(Gap(ci, name, f"{f}-{g}", x[f] - x[g], a[f], a[g], _sig(x[f]), _sig(x[g])))
    return out


def _sig(z: float) -> float:
    return 1 / (1 + math.exp(-z))


def _other_p(g: Gap, family: str) -> float:
    return g.p_g if g.families[0] == family else g.p_f


def _own_gap(g: Gap, family: str) -> float:
    """Probability gap, the family minus the other venue."""
    return (g.p_f - g.p_g) * (1 if g.families[0] == family else -1)


def fit_shift(gaps: list[Gap], family: str) -> float:
    """Shift (probability units) toward the nearer extreme that removes `family`'s pull toward 50%: least squares
    of its gap to the other venues on -tanh((p_other - 0.5) / SHIFT_WIDTH). Positive: its prices are pressed
    toward 50% (longshots dear, favourites cheap). Uses the other venue's price, so the venue's own noise does not
    sort itself into the sign."""
    mine = [g for g in gaps if family in g.families]
    s = np.array([math.tanh((_other_p(g, family) - 0.5) / cons.SHIFT_WIDTH) for g in mine])
    d = np.array([_own_gap(g, family) for g in mine])
    return float(-(d @ s) / (s @ s)) if len(mine) and s @ s > 0 else 0.0


def unshift(gaps: list[Gap], shifts: dict[str, float]) -> list[Gap]:
    """The gaps with each shifted family's pooled price moved back by its shift (cons.unshift_p)."""
    out = []
    for g in gaps:
        f, h = g.families
        if not (shifts.get(f) or shifts.get(h)):
            out.append(g)
            continue
        pf = cons.unshift_p(g.p_f, shifts.get(f, 0.0))
        pg = cons.unshift_p(g.p_g, shifts.get(h, 0.0))
        d = g.d + (cons._logit(pf) - cons._logit(g.p_f)) - (cons._logit(pg) - cons._logit(g.p_g))
        out.append(Gap(g.contract, g.snapshot, g.pair, d, g.a_f, g.a_g, pf, pg))
    return out


def _scaled(gaps: list[Gap], rho: float, noise: dict[str, float] | None, s0: float) -> np.ndarray:
    """|d| / sqrt(V): inside the 95% interval when <= 1.96."""
    noise = noise or {}
    d = np.array([g.d for g in gaps])
    sf = np.array([g.a_f + s0 + noise.get(g.families[0], 0.0) / (g.p_f * (1 - g.p_f)) for g in gaps])
    sg = np.array([g.a_g + s0 + noise.get(g.families[1], 0.0) / (g.p_g * (1 - g.p_g)) for g in gaps])
    return np.abs(d) / np.sqrt(sf ** 2 + sg ** 2 - 2 * rho * sf * sg)


def coverage(gaps: list[Gap], rho: float, noise: dict[str, float] | None = None, s0: float = cons.SIGMA0) -> float:
    """Share of gaps inside the model's 95% interval."""
    return float(np.mean(_scaled(gaps, rho, noise, s0) <= Z95)) if gaps else float("nan")


def coverage_rho(gaps: list[Gap], noise: dict[str, float] | None = None, s0: float = cons.SIGMA0,
                 q: float = 0.95) -> float:
    """rho at which the model's q interval covers a share q of the gaps; clipped to [-1, 1] (-1: the gaps are
    wider than the sigma model allows even with opposite errors; 1: narrower than it allows with equal ones)."""
    from scipy.optimize import brentq
    from scipy.stats import norm

    z = norm.ppf(0.5 + q / 2)

    def h(rho):
        return np.quantile(_scaled(gaps, rho, noise, s0), q) - z

    lo, hi = h(-0.999), h(0.999)
    if lo > 0:
        return -1.0
    if hi < 0:
        return 1.0
    return float(brentq(h, -0.999, 0.999))


def fit_noise(gaps: list[Gap], family: str, rho: float, s0: float = cons.SIGMA0, cap: float = 0.25) -> float:
    """Extra noise (probability units) for `family` at which its gaps are covered 95% of the time, given rho;
    0 when they already are."""
    from scipy.optimize import brentq

    def h(e):
        return np.quantile(_scaled(gaps, rho, {family: e}, s0), 0.95) - Z95

    if h(0.0) <= 0:
        return 0.0
    if h(cap) > 0:
        return cap
    return float(brentq(h, 0.0, cap))


def fit(gaps: list[Gap], noisy: Iterable[str] = NOISY) -> tuple[float, dict[str, float]]:
    """(rho, extra noise per noisy family): rho from the pairs without a noisy venue, then each noisy venue's
    extra noise from its pairs with the others."""
    noisy = [f for f in noisy if any(f in g.families for g in gaps)]
    base = [g for g in gaps if not set(g.families) & set(noisy)]
    rho = coverage_rho(base or gaps)
    noise = {}
    for f in noisy:
        sub = [g for g in gaps if f in g.families and not (set(g.families) - {f}) & set(noisy)]
        noise[f] = fit_noise(sub, f, rho) if sub else 0.0
    return rho, noise


def normal_mle_rho(gaps: list[Gap], s0: float = cons.SIGMA0) -> float:
    """Gaussian maximum likelihood with one rho and no extra noise; dominated by the many small gaps."""
    from scipy.optimize import minimize_scalar

    d = np.array([g.d for g in gaps])
    af, ag = np.array([g.a_f for g in gaps]) + s0, np.array([g.a_g for g in gaps]) + s0

    def nll(rho):
        v = af ** 2 + ag ** 2 - 2 * rho * af * ag
        return 0.5 * float(np.sum(np.log(v) + d ** 2 / v))

    return float(minimize_scalar(nll, bounds=(-0.999, 0.999), method="bounded").x)


def bootstrap(gaps: list[Gap], noisy: Iterable[str] = NOISY, reps: int = 300, seed: int = 1,
              shifted: Iterable[str] = ()) -> tuple[tuple[float, float], dict[str, tuple[float, float]],
                                                    dict[str, tuple[float, float]]]:
    """95% intervals of rho, each extra noise and each shift, resampling contracts (a contract's gaps go together);
    the shifts are refitted and removed in every resample."""
    rng = np.random.default_rng(seed)
    by: dict[int, list[Gap]] = {}
    for g in gaps:
        by.setdefault(g.contract, []).append(g)
    ids = list(by)
    rhos, noises, shifts = [], [], []
    for _ in range(reps):
        pick = rng.choice(len(ids), len(ids))
        sample = [g for i in pick for g in by[ids[i]]]
        sh = {f: fit_shift(sample, f) for f in shifted if any(f in g.families for g in sample)}
        r, n = fit(unshift(sample, sh), noisy)
        rhos.append(r)
        noises.append(n)
        shifts.append(sh)

    def ci(vals):
        lo, hi = np.quantile(vals, [0.025, 0.975])
        return float(lo), float(hi)

    fams = {f for n in noises for f in n}
    sfams = {f for s in shifts for f in s}
    return (ci(rhos), {f: ci([n.get(f, 0.0) for n in noises]) for f in sorted(fams)},
            {f: ci([s.get(f, 0.0) for s in shifts]) for f in sorted(sfams)})


@dataclass
class Estimate:
    rho: float
    ci: tuple[float, float]
    noise: dict[str, float]
    noise_ci: dict[str, tuple[float, float]]
    n_gaps: int
    n_contracts: int
    snapshots: list[str]
    rho_single: float  # one rho for every pair, no extra noise (the first estimate, 2026-10-04)
    mle: float
    coverage_at_prior: float  # one rho = 0.5, no extra noise (the original assumption)
    coverage_after: float
    # pair, gaps, contracts, the pair's own rho, coverage before (rho_single, no noise), after (rho, noise)
    pairs: list[tuple[str, int, int, float, float, float]] = field(default_factory=list)
    # noisy family -> [(band of the other venue's probability, gaps, mean probability gap noisy minus other,
    #                    coverage before, after)]
    levels: dict[str, list[tuple[tuple[float, float], int, float, float, float]]] = field(default_factory=dict)
    shift: dict[str, float] = field(default_factory=dict)  # family -> shift toward the extremes (fit_shift)
    shift_ci: dict[str, tuple[float, float]] = field(default_factory=dict)
    # shifted family -> [(band, gaps, mean gap after removing the shift, coverage after)]
    levels_after: dict[str, list[tuple[tuple[float, float], int, float, float]]] = field(default_factory=dict)


def estimate(gaps: list[Gap], noisy: Iterable[str] = NOISY, reps: int = 300, min_pair_gaps: int = 200,
             shifted: Iterable[str] = SHIFTED) -> Estimate:
    noisy = tuple(noisy)
    raw = gaps
    shifts = {f: fit_shift(raw, f) for f in shifted if any(f in g.families for g in raw)}
    gaps = unshift(raw, shifts)  # everything below is fitted on quotes with the directional bias removed
    rho, noise = fit(gaps, noisy)
    rho_single = coverage_rho(raw)
    pairs = []
    for pair, n in Counter(g.pair for g in gaps).most_common():
        sub = [g for g in gaps if g.pair == pair]
        if n >= min_pair_gaps:
            pairs.append((pair, n, len({g.contract for g in sub}), coverage_rho(sub), coverage(sub, rho_single),
                          coverage(sub, rho, noise)))
    levels, levels_after = {}, {}
    for f in set(noise) | set(shifts):
        rows, after = [], []
        mine = [g for g in raw if f in g.families]
        mine_after = [g for g in gaps if f in g.families]
        for lo, hi in LEVELS:
            # binned by the other venue's price: binning by the noisy venue's own price would sort its noise
            # into the bins (regression to the mean)
            sub = [g for g in mine if lo <= _other_p(g, f) < hi]
            if sub:
                gap = float(np.mean([_own_gap(g, f) for g in sub]))
                rows.append(((lo, min(hi, 1.0)), len(sub), gap, coverage(sub, rho_single), coverage(sub, rho, noise)))
            sub2 = [g for g in mine_after if lo <= _other_p(g, f) < hi]
            if sub2 and f in shifts:
                after.append(((lo, min(hi, 1.0)), len(sub2), float(np.mean([_own_gap(g, f) for g in sub2])),
                              coverage(sub2, rho, noise)))
        levels[f] = rows
        if after:
            levels_after[f] = after
    rho_ci, noise_ci, shift_ci = bootstrap(raw, noisy, reps, shifted=tuple(shifts))
    return Estimate(rho, rho_ci, noise, noise_ci, len(gaps), len({g.contract for g in gaps}),
                    sorted({g.snapshot for g in gaps}), rho_single, normal_mle_rho(gaps), coverage(raw, 0.5),
                    coverage(gaps, rho, noise), pairs, levels, shifts, shift_ci, levels_after)


_ZH = {"kalshi": "Kalshi", "polymarket": "Polymarket（含 US）", "smarkets": "Smarkets", "predictit": "PredictIt",
       "cryptocom": "Crypto.com", "gemini": "Gemini", "limitless": "Limitless", "opinion": "Opinion"}


def _pair_zh(pair: str) -> str:
    return " ↔ ".join(_ZH.get(f, f) for f in pair.split("-"))


def render(e: Estimate, generated: str) -> str:
    noise_txt = "；".join(f"{_ZH.get(f, f)} 另加 **{100 * v:.1f} 個百分點**（{100 * e.noise_ci[f][0]:.1f}–"
                         f"{100 * e.noise_ci[f][1]:.1f}）" for f, v in e.noise.items())
    L = [f"# 跨平台家族的相關係數與平台雜訊 — {generated}", "",
         "共識（全景報告第 7a 節）的 95% 區間依賴兩個參數：不同平台家族之間報價誤差的相關係數 ρ，以及某些平台比價差顯示的"
         "更大的報價雜訊。這份報告用同一合約在不同家族之間的報價差距估計它們（`pmpol famcorr`，方法見 "
         "`universe/family_corr.py`）。結果是 L2 基準（從資料估計的參數），不是事實。", "",
         "## 1. 結果", "",
         f"- **ρ = {e.rho:.2f}**（95% 叢集自助法區間 {e.ci[0]:.2f}–{e.ci[1]:.2f}），用不含額外雜訊平台的配對估計",
         *(["- 方向性偏差（先移除，再估 ρ 和雜訊）：" + "；".join(
             f"{_ZH.get(f, f)} 的價格被壓向 50%，往兩端移回 **{100 * v:.1f} 個百分點**（{100 * e.shift_ci[f][0]:.1f}–"
             f"{100 * e.shift_ci[f][1]:.1f}）" for f, v in e.shift.items())] if e.shift else []),
         *([f"- 額外雜訊（機率單位，和價差一樣換算到 logit，越靠近 0 或 100% 越大；偏差移除後剩下的）：{noise_txt}"]
           if e.noise else []),
         f"- 加上之後，模型的 95% 區間涵蓋全部差距的 {100 * e.coverage_after:.1f}%",
         f"- 對照：所有配對共用一個 ρ、沒有額外雜訊時 ρ = {e.rho_single:.2f}（被雜訊大的平台拉低）；"
         f"原本假設的 ρ = 0.5 涵蓋 {100 * e.coverage_at_prior:.1f}%",
         f"- 樣本：{e.n_contracts:,} 個至少兩個家族都有報價的合約，{e.n_gaps:,} 個「家族配對 × 快照」的差距，"
         f"{len(e.snapshots)} 個快照（{e.snapshots[0]} 到 {e.snapshots[-1]}）", "",
         "## 2. 怎麼估計", "",
         "- 每個家族的報價不確定度 σ = (價差／2 + 額外雜訊)／(p(1 − p)) + 下限 0.10；在模型下，兩個家族的差距 d 服從 "
         "N(0, σ_f² + σ_g² − 2ρσ_fσ_g)。",
         "- 先用不含額外雜訊平台的配對，選 ρ 讓模型的 95% 區間剛好涵蓋 95% 的差距；再給定 ρ，用該平台和其他平台的配對，"
         "選額外雜訊讓它的差距也涵蓋 95%。差距尾巴很厚，常態概似估計"
         f"（{e.mle:.2f}）會被大量的小差距主導，回答的是另一個問題。",
         "- 額外雜訊用機率單位（和價差一樣），不是 logit 的常數：雜訊大的平台通常在冷門和熱門合約偏離最多，"
         "logit 常數會讓中段的區間過寬、兩端仍然不夠。",
         "- 同一合約在不同快照的差距會持續，所以自助法以合約為單位重抽，每次重估兩個參數。", ""]
    for f, rows in e.levels.items():
        L += [f"## 3. {_ZH.get(f, f)} 的偏離：有方向，不只是雜訊", "",
              f"| 其他平台的機率 | 差距數 | 平均差距（{_ZH.get(f, f)} 減其他平台，百分點） | 加雜訊前涵蓋率 | 加雜訊後 |",
              "|---|---|---|---|---|"]
        L += [f"| {100 * lo:.0f}–{100 * hi:.0f}% | {n:,} | {100 * gap:+.1f} | {100 * b:.1f}% | {100 * a:.1f}% |"
              for (lo, hi), n, gap, b, a in rows]
        L.append("")
        after = e.levels_after.get(f)
        if after:
            L += [f"移除 {100 * e.shift[f]:.1f} 個百分點的方向性偏差之後（共識也這樣處理 {_ZH.get(f, f)} 的報價）：", "",
                  "| 其他平台的機率 | 差距數 | 平均差距（百分點） | 涵蓋率（ρ、雜訊重估後） |", "|---|---|---|---|"]
            L += [f"| {100 * lo:.0f}–{100 * hi:.0f}% | {n:,} | {100 * gap:+.1f} | {100 * a:.1f}% |"
                  for (lo, hi), n, gap, a in after]
            L.append("")
        if rows and rows[0][2] > 0 and rows[-1][2] < 0:
            L += [f"- 冷門合約 {_ZH.get(f, f)} 偏貴、熱門合約偏便宜：價格被壓向 50%。"
                  + ("這個方向性偏差現在先估計、從報價移除（越靠近 50% 移得越少），剩下的才當成額外雜訊。" if after else
                     "這是有方向的偏差，額外雜訊只是把它當成雜訊處理（降低權重、加寬區間），共識的點估計仍會被它往 50% 拉一點。")]
            if f == "predictit":
                L.append("- 可能的原因（推測，未驗證）：PredictIt 收獲利的 10% 和提款的 5%，每人每個合約上限 850 美元，資金鎖到結算"
                         "沒有利息；押冷門不會發生的一方要鎖 97 美分賺 3 美分，扣費後的報酬低於無風險利率，所以沒人賣，冷門一直偏貴。")
        L.append("")
    L += ["## 4. 各家族配對（差距 ≥ 200 個）", "",
          "| 家族配對 | 差距數 | 合約數 | 各自估計的 ρ | 單一 ρ 時的涵蓋率 | 現在的涵蓋率 |", "|---|---|---|---|---|---|"]
    L += [f"| {_pair_zh(p)} | {n:,} | {c:,} | {r:.2f} | {100 * b:.1f}% | {100 * a:.1f}% |"
          for p, n, c, r, b, a in e.pairs]
    L += ["", "- 「各自估計的 ρ」是 −1 或 1 時落在邊界：−1 代表差距比 σ 模型允許的還大（即使兩邊誤差方向相反），"
          "1 代表差距比模型預期的小很多，幾乎沒有自己的資訊。", ""]
    noisy = [(pr, a) for pr, _, _, _, _, a in e.pairs if a < 0.90]
    echo = [(pr, r) for pr, _, _, r, _, _ in e.pairs if r >= 0.95]
    if noisy or echo:
        L += ["### 要注意的配對", ""]
        L += [f"- {_pair_zh(pr)}：現在的 95% 區間只涵蓋 {100 * a:.1f}%，至少一邊的報價雜訊比模型的大；含這兩個平台的共識，"
              "區間偏窄" for pr, a in noisy]
        L += [f"- {_pair_zh(pr)}：ρ = {r:.2f}，差距幾乎都在價差以內：可能是一邊跟著另一邊報價，也可能只是一邊的價差很寬"
              "（σ 被價差撐大，差距再小也落在區間內）。兩種情況下它都幾乎沒有自己的資訊；後者的權重已經被寬價差壓低"
              "（Crypto.com 是這種：2026-10-05 價差中位數 7 點，和 Kalshi、Polymarket 都差 1.5 點、同一時段一起動，"
              "共識權重中位數 4%，所以不併入任何家族）" for pr, r in echo]
        L.append("")
    L += ["## 5. 限制", "",
          "- 估計的是「σ 模型裡共同部分的比例」：所有平台一起錯（相對於真實結果）的誤差，在每個差距裡都互相抵消，"
          "而且在二元結果下和結果本身的不確定性分不開，所以無法從報價或結算資料識別。這部分中有系統性的那一塊，"
          "就是校準斜率 b（`kb/L2/market_calibration.yaml`），共識已經連同它的區間一起套用。",
          "- 額外雜訊只給登記為雜訊大的平台（目前 PredictIt，因為它的配對在單一 ρ 下涵蓋率低於 90%）；"
          "其他平台若出現同樣的情況，要加進 `family_corr.NOISY` 再重估。",
          "- ρ、額外雜訊和下限 0.10 一起決定區間寬度；這裡固定下限。",
          "- 樣本集中在 Kalshi ↔ Polymarket，而且只有一天多的快照；資料累積後要重估。", ""]
    return "\n".join(L)


_SOURCE = ["    source:",
           "      title: pmpol snapshots of cross-venue equivalent contracts (venue order books)",
           "      url: https://github.com/bellafc/polymarket_politics/blob/claude/gallant-ritchie-j6n5c8/src/pmpol/universe/family_corr.py",
           "    admiralty: B3",
           "    status: proposed"]


def kb_yaml(e: Estimate, recorded: date) -> str:
    pairs = "; ".join(f"{p} {r:.2f}" for p, _, _, r, _, _ in e.pairs)
    span = f"{e.snapshots[0]}..{e.snapshots[-1]}"
    lines = [
        "# Generated by `pmpol famcorr --write-kb`; review before marking the facts reviewed.",
        "facts:",
        f"  - id: {FACT_ID}",
        "    layer: L2",
        "    subject: Cross-venue consensus",
        "    predicate: correlation_of_quote_errors_between_venue_families",
        f"    value: {{rho: {e.rho:.4f}, ci_low: {e.ci[0]:.4f}, ci_high: {e.ci[1]:.4f}, n_gaps: {e.n_gaps}, "
        f"n_contracts: {e.n_contracts}, snapshots: {len(e.snapshots)}, rho_single: {e.rho_single:.3f}, "
        f"normal_mle: {e.mle:.3f}, coverage_at_0_5: {e.coverage_at_prior:.3f}, coverage: {e.coverage_after:.3f}}}",
        *_SOURCE,
        f"    recorded_at: {recorded.isoformat()}",
        f"    note: \"rho at which the consensus model's 95% interval covers 95% of cross-family gaps between venues "
        f"without extra noise ({span}); per pair: {pairs}. Method: pmpol.universe.family_corr.\""]
    for f, v in e.noise.items():
        lo, hi = e.noise_ci[f]
        lines += [
            f"  - id: {cons.NOISE_FACT}{f}",
            "    layer: L2",
            f"    subject: {_ZH.get(f, f)} quotes",
            "    predicate: extra_quote_noise_beyond_spread_probability_points",
            f"    value: {{extra: {v:.4f}, ci_low: {lo:.4f}, ci_high: {hi:.4f}, rho: {e.rho:.3f}}}",
            *_SOURCE,
            f"    recorded_at: {recorded.isoformat()}",
            f"    note: \"Extra noise (probability units, added to half the spread) at which this venue's gaps to the "
            f"other venues are covered 95% of the time, given rho ({span}); fitted after removing the venue's "
            f"directional shift when it has one. Method: pmpol.universe.family_corr.\""]
    for f, v in e.shift.items():
        lo, hi = e.shift_ci[f]
        lines += [
            f"  - id: {cons.SHIFT_FACT}{f}",
            "    layer: L2",
            f"    subject: {_ZH.get(f, f)} quotes",
            "    predicate: pull_toward_fifty_percent_probability_points",
            f"    value: {{shift: {v:.4f}, ci_low: {lo:.4f}, ci_high: {hi:.4f}, width: {cons.SHIFT_WIDTH}}}",
            *_SOURCE,
            f"    recorded_at: {recorded.isoformat()}",
            f"    note: \"How far this venue's prices sit closer to 50% than the other venues' (longshots dear, favourites "
            f"cheap), in probability units, fading to zero near 50% as tanh((p - 0.5) / width) ({span}); least squares "
            f"on the other venue's price, 95% cluster bootstrap over contracts. The consensus moves the venue's quotes "
            f"back by this amount before pooling. Method: pmpol.universe.family_corr.\""]
    return "\n".join(lines + [""])
