"""Jurisdiction dictionaries: U.S. states and countries (names and demonyms)."""

from __future__ import annotations

import re

US_STATES = {
    "Alabama": "AL", "Alaska": "AK", "Arizona": "AZ", "Arkansas": "AR", "California": "CA",
    "Colorado": "CO", "Connecticut": "CT", "Delaware": "DE", "Florida": "FL", "Georgia": "GA",
    "Hawaii": "HI", "Idaho": "ID", "Illinois": "IL", "Indiana": "IN", "Iowa": "IA", "Kansas": "KS",
    "Kentucky": "KY", "Louisiana": "LA", "Maine": "ME", "Maryland": "MD", "Massachusetts": "MA",
    "Michigan": "MI", "Minnesota": "MN", "Mississippi": "MS", "Missouri": "MO", "Montana": "MT",
    "Nebraska": "NE", "Nevada": "NV", "New Hampshire": "NH", "New Jersey": "NJ", "New Mexico": "NM",
    "New York": "NY", "North Carolina": "NC", "North Dakota": "ND", "Ohio": "OH", "Oklahoma": "OK",
    "Oregon": "OR", "Pennsylvania": "PA", "Rhode Island": "RI", "South Carolina": "SC",
    "South Dakota": "SD", "Tennessee": "TN", "Texas": "TX", "Utah": "UT", "Vermont": "VT",
    "Virginia": "VA", "Washington": "WA", "West Virginia": "WV", "Wisconsin": "WI", "Wyoming": "WY",
    "District of Columbia": "DC",
}
STATE_CODES = set(US_STATES.values())

# canonical country -> extra aliases (demonyms, short names). The canonical name matches too.
COUNTRIES: dict[str, list[str]] = {
    "United States": ["U.S.", "US", "USA", "American", "America"],
    "Canada": ["Canadian"],
    "Mexico": ["Mexican"],
    "Brazil": ["Brazilian"],
    "Argentina": ["Argentine", "Argentinian"], "Chile": ["Chilean"], "Colombia": ["Colombian"],
    "Peru": ["Peruvian"], "Venezuela": ["Venezuelan", "Maduro"], "Ecuador": ["Ecuadorian"],
    "Bolivia": ["Bolivian"], "Paraguay": ["Paraguayan"], "Uruguay": ["Uruguayan"],
    "Costa Rica": [], "Honduras": ["Honduran"], "Guatemala": ["Guatemalan"], "Cuba": ["Cuban"],
    "Haiti": ["Haitian"], "Dominican Republic": ["Dominican"], "Panama": ["Panamanian"],
    "United Kingdom": ["UK", "U.K.", "British", "Britain", "England", "Scotland", "Scottish", "Wales", "Welsh"],
    "Ireland": ["Irish"], "France": ["French", "Macron"], "Germany": ["German", "Bundestag", "Berlin"],
    "Italy": ["Italian"], "Spain": ["Spanish"], "Portugal": ["Portuguese"], "Netherlands": ["Dutch"],
    "Belgium": ["Belgian"], "Switzerland": ["Swiss"], "Austria": ["Austrian"], "Sweden": ["Swedish"],
    "Norway": ["Norwegian"], "Denmark": ["Danish", "Greenland"], "Finland": ["Finnish"],
    "Iceland": ["Icelandic"], "Poland": ["Polish"], "Czech Republic": ["Czech", "Czechia"],
    "Slovakia": ["Slovak", "Košice", "Bratislava"], "Hungary": ["Hungarian", "Orbán", "Orban"],
    "Romania": ["Romanian"], "Bulgaria": ["Bulgarian"], "Greece": ["Greek"], "Serbia": ["Serbian"],
    "Croatia": ["Croatian"], "Slovenia": ["Slovenian"], "Bosnia and Herzegovina": ["Bosnia", "Bosnian"],
    "Albania": ["Albanian"], "Kosovo": [], "Moldova": ["Moldovan"], "Ukraine": ["Ukrainian", "Zelensky", "Zelenskyy", "Kyiv"],
    "Russia": ["Russian", "Putin", "Kremlin", "Moscow"], "Belarus": ["Belarusian"], "Georgia (country)": ["Tbilisi"],
    "Armenia": ["Armenian"], "Azerbaijan": ["Azerbaijani"], "Turkey": ["Turkish", "Türkiye", "Erdogan", "Erdoğan"],
    "Estonia": ["Estonian"], "Latvia": ["Latvian"], "Lithuania": ["Lithuanian"],
    "Israel": ["Israeli", "Netanyahu", "Knesset"], "Palestine": ["Palestinian", "Gaza", "West Bank", "Hamas"],
    "Lebanon": ["Lebanese", "Hezbollah", "Nabatieh"], "Syria": ["Syrian"], "Iraq": ["Iraqi"],
    "Iran": ["Iranian", "Khamenei", "Tehran"], "Saudi Arabia": ["Saudi"], "Yemen": ["Yemeni", "Houthi", "Houthis"],
    "Jordan (country)": ["Jordanian", "Amman"], "Egypt": ["Egyptian"], "Qatar": ["Qatari"], "United Arab Emirates": ["UAE", "Emirati"],
    "Oman": ["Omani"], "Kuwait": ["Kuwaiti"], "Bahrain": ["Bahraini"],
    "China": ["Chinese", "Xi Jinping", "Beijing", "PRC"], "Taiwan": ["Taiwanese", "Taipei"],
    "Hong Kong": [], "Japan": ["Japanese"], "South Korea": ["Korean", "Seoul"], "North Korea": ["Kim Jong Un", "Pyongyang"],
    "India": ["Indian", "Modi"], "Pakistan": ["Pakistani"], "Bangladesh": ["Bangladeshi"],
    "Sri Lanka": ["Sri Lankan"], "Nepal": ["Nepali", "Nepalese"], "Afghanistan": ["Afghan", "Taliban"],
    "Thailand": ["Thai"], "Vietnam": ["Vietnamese"], "Philippines": ["Philippine", "Filipino"],
    "Indonesia": ["Indonesian"], "Malaysia": ["Malaysian"], "Singapore": ["Singaporean"],
    "Myanmar": ["Burmese"], "Cambodia": ["Cambodian"], "Mongolia": ["Mongolian"],
    "Australia": ["Australian"], "New Zealand": [], "Nigeria": ["Nigerian"], "South Africa": ["South African"],
    "Kenya": ["Kenyan"], "Ethiopia": ["Ethiopian"], "Ghana": ["Ghanaian"], "Senegal": ["Senegalese"],
    "Ivory Coast": ["Côte d'Ivoire", "Ivorian"], "Cameroon": ["Cameroonian"], "Uganda": ["Ugandan"],
    "Tanzania": ["Tanzanian"], "Zimbabwe": ["Zimbabwean"], "Zambia": ["Zambian"], "Malawi": ["Malawian"],
    "Mozambique": [], "Angola": ["Angolan"], "Sudan": ["Sudanese"], "Libya": ["Libyan"], "Tunisia": ["Tunisian"],
    "Algeria": ["Algerian"], "Morocco": ["Moroccan"], "Guinea-Bissau": [], "Guinea": ["Guinean"],
    "Mali": ["Malian"], "Burkina Faso": [], "Benin": ["Beninese"], "Togo": [],
    "Gabon": [], "DR Congo": ["Congo", "Congolese"], "Somalia": ["Somali"], "Rwanda": ["Rwandan"],
    "Madagascar": [], "Botswana": [], "Namibia": [], "Cyprus": ["Cypriot"], "Malta": ["Maltese"],
    "Vatican City": ["Vatican", "Holy See", "Pope", "papal", "conclave"],
    "Luxembourg": [], "Kazakhstan": [], "Uzbekistan": [], "Kyrgyzstan": [], "Tajikistan": [],
}

# Sub-national regions abroad: region -> country. Regions also identify their country.
REGIONS: dict[str, str] = {
    **{r: "Brazil" for r in (
        "São Paulo", "Rio de Janeiro", "Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Federal District",
        "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará",
        "Paraíba", "Paraná", "Pernambuco", "Piauí", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia",
        "Roraima", "Santa Catarina", "Sergipe", "Tocantins")},
    **{r: "Canada" for r in (
        "Quebec", "Québec", "Ontario", "Alberta", "British Columbia", "Manitoba", "Saskatchewan", "Nova Scotia",
        "New Brunswick", "Newfoundland", "Prince Edward Island")},
    **{r: "Mexico" for r in (
        "Baja California", "Baja California Sur", "Nuevo León", "Jalisco", "Sonora", "Chihuahua", "Coahuila",
        "Querétaro", "Guanajuato", "Michoacán", "Campeche", "Colima", "Nayarit", "Zacatecas", "Sinaloa")},
    **{r: "Germany" for r in (
        "Bavaria", "Saxony", "Sachsen-Anhalt", "Saxony-Anhalt", "Thuringia", "Brandenburg", "Hesse",
        "Mecklenburg-Vorpommern", "Baden-Württemberg", "North Rhine-Westphalia", "Lower Saxony")},
    **{r: "Germany" for r in ("Schleswig-Holstein", "Saarland", "Rhineland-Palatinate", "Rheinland-Pfalz")},
    **{r: "United Kingdom" for r in ("Scotland", "Wales", "Northern Ireland", "Holborn")},
    # Swedish regions (regional councils are elected with the general election).
    **{r: "Sweden" for r in (
        "Blekinge", "Dalarna", "Gotland", "Gävleborg", "Halland", "Jämtland", "Jönköping", "Kalmar", "Kronoberg",
        "Norrbotten", "Skåne", "Sörmland", "Södermanland", "Uppsala", "Värmland", "Västerbotten", "Västernorrland",
        "Västmanland", "Västra Götaland", "Örebro", "Östergötland")},
    # Australian states (not "Victoria": it is also a city in British Columbia).
    **{r: "Australia" for r in (
        "Tasmania", "New South Wales", "Queensland", "Western Australia", "South Australia", "Northern Territory")},
    # Taiwan's municipalities and counties (local elections, 2026-11-28).
    **{r: "Taiwan" for r in (
        "Taipei", "New Taipei", "Taoyuan", "Taichung", "Tainan", "Kaohsiung", "Keelung", "Hsinchu", "Miaoli",
        "Changhua", "Nantou", "Yunlin", "Chiayi", "Pingtung", "Yilan", "Hualien", "Taitung", "Penghu", "Kinmen",
        "Lienchiang")},
}

_STATE_RE = re.compile(r"\b(" + "|".join(sorted(map(re.escape, US_STATES), key=len, reverse=True)) + r")\b")
_country_alias: dict[str, str] = {}
for _c, _aliases in COUNTRIES.items():
    # "Georgia (country)" style names are ambiguous on their own; match only their aliases.
    if " (" not in _c:
        _country_alias[_c] = _c
    for _a in _aliases:
        _country_alias[_a] = _c
for _r, _c in REGIONS.items():
    _country_alias.setdefault(_r, _c)
_REGION_RE = re.compile(r"(?<![\w.])(" + "|".join(sorted(map(re.escape, REGIONS), key=len, reverse=True)) + r")(?![\w])")
_COUNTRY_RE = re.compile(r"(?<![\w.])(" + "|".join(sorted(map(re.escape, _country_alias), key=len, reverse=True)) + r")(?![\w])")


def find_states(text: str) -> list[str]:
    """U.S. state codes mentioned by full name (order of appearance, unique)."""
    out = []
    for m in _STATE_RE.finditer(text):
        if re.match(r"\s+(?:County|Parish)\b", text[m.end():]):
            continue  # "Washington County, Ohio": a county named after a state, not the state
        code = US_STATES[m.group(1)]
        if code not in out:
            out.append(code)
    return out


def find_countries(text: str) -> list[str]:
    """Countries mentioned by name, demonym or a strongly associated name (unique, in order)."""
    out = []
    for m in _COUNTRY_RE.finditer(text):
        c = _country_alias[m.group(1)]
        if c not in out:
            out.append(c)
    return out


def find_region(text: str) -> str | None:
    """First sub-national region abroad mentioned in the text."""
    m = _REGION_RE.search(text)
    return m.group(1) if m else None


def sub_jurisdiction(title: str, country: str) -> str:
    """Finest place a foreign contest is about: "Brazil/Bahia", "Nigeria/Rivers", "Canada/Quebec/Saint-François"."""
    names = [country.split(" (")[0], *COUNTRIES.get(country, [])]
    alt = "|".join(sorted(map(re.escape, names), key=len, reverse=True))
    m = re.match(rf"^([A-Z][^,:?]*?),\s*(?:{alt})\b", title)
    if m:
        return f"{country}/{m.group(1).strip()}"
    region = find_region(title)
    if region:
        lead = re.match(rf"^(.+?)\s+{re.escape(region)}\b", title)
        if lead and not re.search(r"election|senate|governor|place|who|will|next", lead.group(1), re.I):
            return f"{country}/{region}/{lead.group(1).strip()}"
        return f"{country}/{region}"
    return country


CA_PROVINCES = {
    "Ontario": "ON", "Quebec": "QC", "British Columbia": "BC", "Alberta": "AB", "Manitoba": "MB",
    "Saskatchewan": "SK", "Nova Scotia": "NS", "New Brunswick": "NB", "Newfoundland and Labrador": "NL",
    "Prince Edward Island": "PE", "Yukon": "YT", "Northwest Territories": "NT", "Nunavut": "NU",
}
_CA_CODES = {**{c: n for n, c in CA_PROVINCES.items()}, "PEI": "Prince Edward Island"}


def place_of(qualifier: str) -> tuple[str, str | None] | None:
    """(country, region) named by the qualifier after a city: "ON", "British Columbia", "NV", "Florida", "Peru".
    None when it names no known place. A two-letter code is a U.S. state unless it is a Canadian province."""
    q = qualifier.strip().rstrip(".").strip()
    if q in _CA_CODES:
        return "Canada", _CA_CODES[q]
    if q in STATE_CODES:
        return "United States", q
    for name, code in CA_PROVINCES.items():
        if q.lower() == name.lower():
            return "Canada", name
    for name, code in US_STATES.items():
        if q.lower() == name.lower():
            return "United States", code
    for alias, country in _country_alias.items():
        if q.lower() == alias.lower() and alias not in REGIONS:
            return country, None
    for region, country in REGIONS.items():
        if q.lower() == region.lower():
            return country, region
    return None
