"""Rule-based event tagging: topic, office, measure, jurisdiction, year, stage.

Deterministic and explainable on purpose: every tag can be traced to a pattern, and
untagged events are listed in the universe report so the rules can be extended.
An LLM tagger can later fill the gaps, but the rules stay the auditable baseline.
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import asdict, dataclass

from pmpol.models import Event
from pmpol.universe.geo import (
    STATE_CODES,
    US_STATES,
    find_countries,
    find_region,
    find_states,
    place_of,
    sub_jurisdiction,
)

TOPICS = ("elections_us", "elections_intl", "us_government", "geopolitics", "economy_policy", "media", "other")


@dataclass(frozen=True)
class Tags:
    topic: str
    office: str | None = None
    measure: str = "binary"
    jurisdiction: str | None = None  # "TX", "TX-18", a country, ...
    country: str | None = None
    year: int | None = None
    stage: str = "general"
    variant: str = ""  # which question about the contest: "", "2nd", "3rd", "seat" (wins any seat), ...
    # local races (mayor, county, council): what placed the city in its country. "title" ("Barrie, ON"),
    # "category" (the venue's own tag), "rules" ("... mayor of Reno, NV"), "cross-venue" (the same city and
    # year placed on another venue), "gazetteer" (a foreign city whose name no U.S. city shares), or ""
    # (nothing: the U.S. is assumed, and the universe report lists these)
    place: str = ""

    @property
    def race_key(self) -> str | None:
        """Identity of one contest question; all measures of the same race share it."""
        if self.topic not in ("elections_us", "elections_intl") or not self.office or not self.jurisdiction:
            return None
        stage = self.stage + (f"/{self.variant}" if self.variant else "")
        return "|".join(str(x) for x in (self.country, self.jurisdiction, self.office, self.year, stage))

    def to_dict(self) -> dict:
        return asdict(self)


def _rx(*words: str) -> re.Pattern:
    return re.compile("|".join(words), re.I)


_DISTRICT = re.compile(r"\b([A-Z]{2})-(\d{1,2}|AL)\b")
_STATE_NAMES = "|".join(sorted(map(re.escape, US_STATES), key=len, reverse=True))
_DISTRICT_LONG = re.compile(rf"\b({_STATE_NAMES})(?:'s)? (\d{{1,2}})(?:st|nd|rd|th)? (?:District|House)"
                            rf"|\b({_STATE_NAMES})-(\d{{1,2}})\b", re.I)  # second form: Gemini "Montana-01"
_AT_LARGE = re.compile(rf"\b({_STATE_NAMES})[ -]at[ -]large\b", re.I)

# Office patterns, checked in order; the first hit wins.
_OFFICES: list[tuple[str, re.Pattern]] = [
    ("ballot", _rx(r"ballot measure", r"referend", r"\bproposition\b", r"amendment pass", r"ballot")),
    ("parliament", _rx(r"national assembly", r"parliament", r"bundestag", r"knesset", r"lok sabha",
                       r"legislative election", r"federal election", r"most seats", r"chamber of deputies", r"\bMPs?\b",
                       r"house of commons", r"riding")),
    ("state_leg", _rx(r"state senate", r"state house", r"state assembly", r"state legislat", r"house of delegates",
                      r"state senate district", r"legislative supermajorit")),
    ("lt_governor", _rx(r"lieutenant governor", r"lt\.? governor")),
    ("governor", _rx(r"governor", r"gubernatorial")),
    ("attorney_general", _rx(r"attorney general")),
    ("state_exec", _rx(r"secretary of state", r"treasurer", r"auditor", r"comptroller", r"insurance commissioner",
                       r"superintendent", r"agriculture commissioner", r"railroad commissioner",
                       r"labor commissioner", r"public service commission", r"land commissioner",
                       r"chief financial officer", r"controller")),
    ("state_court", _rx(r"supreme court (?:place|position|seat|justice|winner|election|retention)")),
    ("mayor", _rx(r"mayor")),
    ("local", _rx(r"district attorney", r"county (?:executive|commission|judge|clerk)", r"city council",
                  r"sheriff", r"school board", r"council member", r"magistrate", r"county attorney")),
    ("senate", _rx(r"senate", r"senator")),
    ("house", _rx(r"house race", r"house seat", r"house election", r"u\.s\. house", r"house seats",
                  r"house winner", r"\bthe house\b", r"house majority", r"congressional district",
                  r"\bu\.s\.? house\b")),
    ("president", _rx(r"president", r"presidency", r"popular vote", r"electoral college", r"caucus winner",
                      r"primary winner", r"presidential ticket", r"national convention")),
    ("head_of_government", _rx(r"prime minister", r"chancellor", r"premier\b", r"taoiseach")),
    ("leadership", _rx(r"speaker", r"majority leader", r"minority leader", r"party leader", r"leader of the")),
]
# Sub-national elections abroad that name no office of _OFFICES (they would otherwise fall back to "parliament").
_LOCAL_INTL = re.compile(r"(?<!federal )(?<!legislative )\bcouncil election|(?<!federal )(?<!legislative )\bcouncil\b.*\belection"
                         r"|\blocal elections?\b|\bcouncillors?\b|\bmunicipal elections?\b|\bregional elections?\b", re.I)
_STATE_ONLY_OFFICES = {"lt_governor", "attorney_general", "state_exec", "state_court", "state_leg"}

_ELECTORAL = _rx(r"election", r"elected", r"\bwin(?:s|ner)?\b", r"primary", r"nominee", r"runoff", r"\brace\b",
                 r"vote", r"ballot", r"seats?\b", r"midterm", r"caucus", r"\bplace\b", r"control",
                 r"margin", r"turnout", r"district", r"proposition", r"combo",
                 r"^next (?:governing |lord )?mayor of")  # "Next Mayor of Brno": the next holder is chosen by election

_MEASURES: list[tuple[str, re.Pattern]] = [
    ("prop", _rx(r"endorse", r"campaign for", r"\bdebate", r"concede", r"drop out", r"run for", r"announce",
                 r"recount", r"called by", r"\bcall\b.*\b(?:race|election)", r"certif", r"lawsuit", r"rally")),
    ("county", _rx(r"county winner", r"which counties", r"counties will")),
    ("margin", _rx(r"margin of victory", r"\bwin by\b", r"\bmargin\b")),
    ("turnout", _rx(r"turnout")),
    ("vote_share", _rx(r"vote percent", r"vote share", r"% of the vote", r"percentage of the vote", r"vote %")),
    ("combo", _rx(r"combo", r"\bsweep\b", r"parlay", r"trifecta")),
    ("comparison", _rx(r"\bcloser\b", r"closest", r"larger margin", r"more votes than")),
    ("seat_count", _rx(r"how many .*seats", r"seats will", r"of seats", r"seats\?", r"seat count", r"seats held", r"number of .*seats",
                       r"seats after", r"hold .* seats")),
    ("control", _rx(r"\bcontrol\b", r"which party will win the (?:u\.s\. )?(?:house|senate|state)",
                    r"\b(?:house|senate) midterm winner\b",
                    r"who will win the presidency, house")),
    ("nomination", _rx(r"nominee", r"nomination", r"primary")),
    ("winner", _rx(r"winner", r"who will win", r"\bwin the\b", r"\belected\b", r"\bnext (?:president|prime minister|"
                   r"mayor|governor|chancellor|leader|speaker)", r"\b\d(?:st|nd|rd|th) place\b")),
    ("count", _rx(r"how many", r"number of", r"# ", r"\bposts?\b", r"tweets")),
    ("by_date", _rx(r"\bby\b.*\?", r"\bbefore\b", r"by\.\.\.", r"\bby\s*$", r"\bin 20\d\d\?", r"^when will")),
    ("winner", _rx(r"election")),
]

_TOPIC_GEO = _rx(r"\bwar\b", r"military", r"\bstrikes?\b", r"ceasefire", r"invade", r"invasion", r"troops",
                 r"missile", r"nuclear", r"sanction", r"regime", r"\bcoup\b", r"annex", r"territory", r"hormuz",
                 r"strait", r"blockade", r"drone", r"\battack", r"hostage", r"peace (?:deal|agreement|talks)",
                 r"treaty", r"\bnato\b", r"out as (?:leader|president|prime minister)", r"leader of",
                 r"\bclash\b", r"\bbomb", r"airspace", r"warship", r"\bnavy\b", r"recogni[sz]e", r"\bmeet with\b",
                 r"\bvisit\b", r"\bsummit\b", r"travel", r"abraham accords", r"\bbrics\b", r"\beu\b",
                 r"european union", r"\bun\b", r"united nations")
_TOPIC_ECON = _rx(r"tariff", r"\bfed\b", r"federal reserve", r"interest rate", r"rate (?:cut|hike)", r"recession",
                  r"inflation", r"\bgdp\b", r"\btax", r"debt ceiling", r"budget", r"stimulus", r"crypto", r"bitcoin",
                  r"ethereum", r"\breserve\b", r"dollari[sz]e", r"currency", r"oil", r"stock", r"trade deal",
                  r"\bdeficit\b", r"revenue", r"spending", r"price", r"economy", r"unemployment", r"jobs report",
                  # indicators and sectors seen among unclassified events (residual monitor, 2026-10-03)
                  r"\bcpi\b", r"\bpce\b", r"\bpmi\b", r"\bism\b", r"labor force", r"employment", r"\bjobs\b",
                  r"payroll", r"\byoy\b", r"year-over-year", r"month-over-month", r"\bcorn\b", r"\bcotton\b",
                  r"\bwheat\b", r"\bsoybeans?\b", r"\bcoal\b", r"\bcrop", r"bushels", r"production\b",
                  r"home sales", r"home value", r"home prices", r"housing", r"farmland", r"money supply", r"\bm2\b",
                  r"\bdxy\b", r"electricity", r"\bercot\b", r"\bipo\b", r"container volume", r"\bopec\b",
                  r"treasur(?:y|ies) (?:yield|bills?|bonds?|transactions)", r"tokenized", r"data cent(?:er|re)s?",
                  r"diesel", r"gasoline", r"retail sales", r"consumer (?:confidence|sentiment)", r"hotel",
                  r"\bski", r"mortgage", r"delinquen", r"\bgdpnow\b", r"central bank", r"rate decision",
                  r"saving rate", r"debt limit", r"student loan", r"pension", r"\bdefaults?\b", r"\bsofr\b",
                  r"largest company", r"market cap", r"\byen\b", r"layoffs", r"i bond", r"social security")
_TOPIC_GOV = _rx(r"trump", r"\bbiden\b", r"\bvance\b", r"white house", r"cabinet", r"executive order", r"pardon",
                 r"impeach", r"congress", r"\bbill\b", r"\bact\b", r"shutdown", r"scotus", r"supreme court",
                 r"\bdoge\b", r"deport", r"\bice\b", r"\bfbi\b", r"\bcia\b", r"secretary", r"nominat", r"confirm",
                 r"filibuster", r"epstein", r"\bmusk\b", r"government", r"senate", r"\bhouse\b", r"\blaw\b",
                 r"legislation", r"veto", r"indict", r"convict", r"court", r"judge", r"ruling", r"\bfda\b",
                 r"\bagency\b", r"federal", r"governor", r"mayor", r"party", r"resign", r"\bout\b", r"approval",
                 # politics seen among unclassified events (residual monitor, 2026-10-03)
                 r"\b(?:dnc|rnc|dccc|nrcc|dscc|nrsc)\b", r"national committee", r"cash on hand", r"disbursements",
                 r"\bpac\b", r"fundrais", r"leave office", r"departure", r"exit date", r"step down", r"arrest",
                 r"\bcharged\b", r"\bdebate", r"redistrict", r"gerrymander", r"trifecta", r"referend",
                 r"ballot (?:measure|initiative)", r"presiden(?:t|tial)", r"candidacy", r"run for office",
                 r"attorney general", r"\bmamdani\b", r"\bnyc\b", r"new york city", r"senators?\b",
                 r"\bmidterms?\b", r"supermajority", r"filibuster", r"sentenced", r"\bprison\b", r"\bjail\b",
                 r"custody", r"charges dropped", r"criminal case", r"disbarred", r"antitrust", r"\bftc\b", r"\bfcc\b",
                 r"\bhhs\b", r"\bcms\b", r"medicaid", r"retirement", r"question \d", r"measures? will pass",
                 r"\bvote to\b", r"national convention", r"special session", r"daylight saving", r"regulator")
# Government questions about leaders abroad, when no single country is named.
_FOREIGN = _rx(r"\bworld leaders?\b", r"\bforeign leaders?\b", r"\bafrican\b", r"\beuropean\b", r"\basian\b",
               r"\blatin american\b", r"\bheads? of (?:state|government)\b")
_TOPIC_MEDIA = _rx(r"tweets?", r"\bposts?\b", r"truth social", r"\bsay\b", r"\bmention", r"insult", r"interview",
                   r"podcast", r"followers", r"\bx account\b")

_YEAR = re.compile(r"\b(20[2-4]\d)\b")


def _district(text: str) -> str | None:
    m = _DISTRICT.search(text)
    if m and m.group(1) in STATE_CODES:
        n = m.group(2)
        return f"{m.group(1)}-{'AL' if n == 'AL' else int(n):02}" if n != "AL" else f"{m.group(1)}-AL"
    m = _DISTRICT_LONG.search(text)
    if m:
        state, n = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
        return f"{US_STATES[_title(state)]}-{int(n):02}"
    m = _AT_LARGE.search(text)
    if m:
        return f"{US_STATES[_title(m.group(1))]}-AL"
    return None


def _title(name: str) -> str:
    for k in US_STATES:
        if k.lower() == name.lower():
            return k
    return name


def _year(e: Event, text: str) -> tuple[int | None, bool]:
    """(year, explicit). Not explicit when inferred from the markets' close times."""
    m = _YEAR.search(text)
    if m:
        return int(m.group(1)), True
    if e.venue == "kalshi":
        for seg in e.event_id.split("-")[1:]:
            m = re.match(r"^(\d{2})([A-Z]{3}\d{0,2})?$", seg)
            if m:
                return 2000 + int(m.group(1)), True
    m = _YEAR.search(e.event_id)
    if m:
        return int(m.group(1)), True
    if re.search(r"midterm|120th congress", text, re.I):
        return 2026, True
    closes = sorted(m.close_time for m in e.markets if m.close_time)
    return (int(closes[0][:4]), False) if closes else (None, False)


_PLACE = re.compile(r"\b(\d)(?:st|nd|rd|th) place\b|\b(first|second|third|fourth|fifth) place\b", re.I)
_ORD = {"first": "1", "second": "2", "third": "3", "fourth": "4", "fifth": "5"}
_VARIANT_FLAGS = [
    ("seat", _rx(r"any seat", r"win a seat", r"enter (?:the )?(?:knesset|parliament)", r"threshold", r"anyseat")),
    ("multi", _rx(r"\bwinners\b")),
    ("held", _rx(r"seats held", r"most seats held")),
    ("advance", _rx(r"advance", r"qualif", r"make (?:it to )?the (?:second round|runoff)", r"finish (?:in )?top")),
    ("h2h", _rx(r"\bvs\.?\b", r"\b[A-Z][\w'\-]+ or [A-Z][\w'\-]+\b")),
    ("vp", _rx(r"\bVP\b", r"vice[- ]president")),
    ("individual", _rx(r"\(individual\)", r"by individual", r"\(person\)")),
    ("senate", _rx(r"state senate")),
    ("lower", _rx(r"state house", r"state assembly", r"house of delegates")),
]
_PARTY_WORDS = [("R", r"republican"), ("D", r"democratic|democrat"), ("L", r"libertarian"), ("G", r"\bgreen\b")]


def _variant(title: str, event_id: str, stage: str) -> str:
    """Which question about a contest an event asks; different variants are different variables."""
    text = f"{title} {event_id}"
    parts = []
    m = _PLACE.search(title)
    if m:
        n = m.group(1) or _ORD[m.group(2).lower()]
        if n != "1":
            parts.append(f"place{n}")
    else:
        m = re.search(r"\b(second|third|2nd|3rd)\b", title, re.I)
        if m and not re.search(r"second round|2nd round|third round", title, re.I):
            parts.append("place" + {"second": "2", "2nd": "2", "third": "3", "3rd": "3"}[m.group(1).lower()])
    parts += [name for name, rx in _VARIANT_FLAGS if rx.search(text)]
    if stage == "primary":
        parts += [p for p, rx in _PARTY_WORDS if re.search(rx, title, re.I)][:1]
    return "/".join(parts)


_NAME = r"[^\W\d_][\w .'\-]*?"  # a place name; the first letter may be accented (Žilina, Košice)
_CITY = [re.compile(rf"^(?:who will be (?:the )?)?(?:next )?(?:lord |governing )?mayor of ({_NAME})"
                    rf"(?:\s*\([^)]*\))?\s*(?:\?| in | after|$)", re.I),
         re.compile(rf"^who will be elected ({_NAME}) mayor\b", re.I),
         re.compile(rf"^({_NAME}),? (?:[A-Z]{{2,3}} )?(?:lord )?mayor(?:al)? (?:election|race|winner)", re.I),
         re.compile(rf"^({_NAME}) (?:lord )?mayor(?:al)?\b", re.I)]
_CITY_ALIASES = {"la": "los angeles", "nyc": "new york city"}


def _city(title: str) -> str | None:
    title = re.sub(r"[\u2010-\u2015]", "-", re.sub(r"^20\d\d\s+", "", title.strip()))
    for rx in _CITY:
        m = rx.search(title)
        if m:
            name = re.sub(r"^(?:20\d\d|next|the)\s+", "", m.group(1).strip(), flags=re.I).lower()
            name = re.sub(r",.*$", "", name).strip()  # "barrie, on" -> "barrie"
            return _CITY_ALIASES.get(name, name) or None
    return None


# Foreign cities with local-race markets whose names no U.S. city with such markets shares; used only when
# neither the title, the venue's tags nor the rules place the city. Names shared with U.S. places (London,
# Hamilton, Richmond, Victoria, Surrey, Martin, Clarence, Brighton, ...) are deliberately absent: those need
# evidence from the market itself or from the same race on another venue.
GAZETTEER = {
    **{c: "Canada" for c in ("toronto", "vancouver", "ottawa", "winnipeg", "mississauga", "nanaimo", "kamloops",
                             "saanich", "niagara-on-the-lake", "burnaby", "coquitlam", "kelowna", "brampton",
                             "greater sudbury", "thunder bay", "sault ste. marie", "oakville", "kitchener",
                             "charlottetown", "whistler", "revelstoke")},
    **{c: "Australia" for c in ("huon valley", "launceston", "waratah-wynyard", "hobart", "glenorchy", "kingborough",
                                "derwent valley", "meander valley", "west tamar", "northern midlands", "sorell",
                                "burnie", "devonport")},
    **{c: "Slovakia" for c in ("žilina", "nitra", "poprad", "trenčín", "trnava", "banská bystrica", "prešov",
                               "košice", "bratislava")},
    **{c: "Peru" for c in ("lima", "cusco", "chiclayo", "huancayo", "piura", "trujillo", "maynas")},
    "kraków": "Poland", "prague": "Czech Republic", "yokohama": "Japan", "johannesburg": "South Africa",
    "greater manchester": "United Kingdom",
}

_CATEGORY_US = {"us", "united-states", *(s.lower().replace(" ", "-") for s in US_STATES)}
_RULES_PLACE = r"([A-Z][A-Za-z.]*(?: [A-Z][A-Za-z.]*)*)"


def _place_from_category(category: str) -> str | None:
    tokens = {t.strip().lower() for t in re.split(r"[,/]", category) if t.strip()}
    if tokens & _CATEGORY_US:
        return "United States"
    for t in sorted(tokens):
        hit = place_of(t.replace("-", " "))
        if hit and hit[0] != "United States":
            return hit[0]
    return None


def _place_from_rules(rules: str, city: str | None) -> str | None:
    if city:
        for m in re.finditer(rf"(?i:{re.escape(city)})(?: city)?, {_RULES_PLACE}", rules):
            words = m.group(1).split()
            for n in range(len(words), 0, -1):  # "British Columbia" before "British"
                hit = place_of(" ".join(words[:n]))
                if hit:
                    return hit[0]
    states = find_states(rules)
    found = {c for c in find_countries(rules) if c != "United States"}
    if region := find_region(rules):
        found.add(place_of(region)[0])
    if states and not found:
        return "United States"
    if len(found) == 1 and not states:
        return found.pop()
    return None


def local_place(e: Event, title: str, city: str | None) -> tuple[str | None, str]:
    """(country, how) for a local race: the title's qualifier, the venue's tags, then the rules; (None, "")
    when nothing places it. Strong evidence first; the gazetteer and the cross-venue step come later."""
    m = re.match(r"^(?:20\d\d\s+)?[^,]+,\s*([A-Za-z. ]+?)\s+(?:lord )?mayor", title, re.I)
    if m and (hit := place_of(m.group(1))):
        return hit[0], "title"
    if c := _place_from_category(e.category):
        return c, "category"
    rules = next((mk.rules for mk in e.markets if mk.rules), "")
    if rules and (c := _place_from_rules(rules, city)):
        return c, "rules"
    return None, ""


def _first(patterns: list[tuple[str, re.Pattern]], text: str) -> str | None:
    for name, rx in patterns:
        if rx.search(text):
            return name
    return None


def tag_event(e: Event) -> Tags:
    title = e.title
    sample_q = next((m.question for m in e.markets if m.question), "")
    text = f"{title} || {sample_q}"

    district = _district(title) or _district(sample_q)
    states = find_states(title) or find_states(sample_q)
    countries = [c for c in find_countries(title) if c != "United States"] or \
                [c for c in find_countries(sample_q) if c != "United States"]
    country = countries[0] if countries else None
    # Kalshi labels some U.S. contests with a country-sounding word (e.g. "Georgia"); U.S. state wins.
    if states and country in ("Georgia (country)",):
        country = None
    # A U.S. congressional district, or "New Mexico" read as Mexico, is a U.S. contest.
    if district or (country == "Mexico" and re.search(r"\bnew mexico\b", text, re.I)):
        country = None

    office = _first(_OFFICES, title) or _first(_OFFICES, sample_q)
    if office is None and re.search(r"\b(?:VP|vice[- ]president(?:ial)?)\b", title, re.I) and \
            re.search(r"nominee|nomination", title, re.I):
        office = "president"  # "Democratic VP Nominee 2028": the presidential ticket (variant vp)
    if office == "parliament" and re.search(r"prime minister|\bpremier\b|chancellor", title, re.I):
        office = "head_of_government"  # "Legislative Election - Next Prime Minister" asks who governs, not who tops the poll
    if office in (None, "parliament") and _LOCAL_INTL.search(title):
        office = "local"  # "Welsh Local Elections", "City of Edinburgh Council election": not a national election
    if office is None and country and re.search(r"election|elections\b", title, re.I):
        office = "parliament"  # national election in a parliamentary system, unless an office is named
    if district and office not in ("state_leg", "ballot"):
        office = "house"
    if office == "local" and re.search(r"\b[A-Z][\w.']* v\. [A-Z]", text):
        office = None  # a case caption ("Younge v. Fulton ... District Attorney's Office") is not a local race
    if office in _STATE_ONLY_OFFICES and not states and not country:
        office = None  # e.g. "Secretary of State" in the federal cabinet
    measure = _first(_MEASURES, title) or _first(_MEASURES, sample_q) or "binary"
    stage = ("primary" if re.search(r"primary|nominee|nomination", text, re.I)
             else "runoff" if re.search(r"runoff", text, re.I)
             else "first_round" if re.search(r"first round|1st round", text, re.I)
             else "general")
    year, explicit = _year(e, title)
    variant = _variant(title, e.event_id, stage)

    electoral = bool(office) and bool(_ELECTORAL.search(text)) and office != "leadership"
    place = ""
    if electoral and office in ("mayor", "local"):
        city = _city(title)
        if country is None:
            found, place = local_place(e, title, city)
            if found is None and city in GAZETTEER:
                found, place = GAZETTEER[city], "gazetteer"
            if found and found != "United States":
                country = found
        else:
            place = "title"
    if electoral and country is None and year and not explicit and year % 2:
        year -= 1  # U.S. general elections fall in even years; markets often settle the year after
    if electoral and (country is None):
        jurisdiction = district or (states[0] if states else ("US" if office in ("senate", "house", "president") else None))
        if office in ("mayor", "local"):
            jurisdiction = _city(title) or jurisdiction
        return Tags("elections_us", office, measure, jurisdiction, "United States", year, stage, variant, place)
    if electoral and country:
        jurisdiction = sub_jurisdiction(title, country)
        if office in ("mayor", "local") and (city := _city(title)):
            jurisdiction = f"{country}/{city}"
        elif office == "local" and jurisdiction in (None, country) and (name := _local_name(title, office)):
            jurisdiction = f"{country}/{name.split(':')[0].strip()}"  # each council or local election is its own race
        return Tags("elections_intl", office, measure, jurisdiction, country, year, stage, variant, place)

    if _TOPIC_GEO.search(title) and not _TOPIC_ECON.search(title):
        topic = "geopolitics"
    elif _TOPIC_ECON.search(title):
        topic = "economy_policy"
    elif _TOPIC_MEDIA.search(title):
        topic = "media"
    elif _TOPIC_GOV.search(title):
        topic = "us_government" if not country and not _FOREIGN.search(title) else "geopolitics"
    elif country:
        topic = "geopolitics"
    else:
        topic = "other"
    return Tags(topic, office, measure, country or (states[0] if states else None), country, year, stage)


def _local_name(title: str, office: str | None) -> str | None:
    """The place a local race is about: the city for a mayor, else the office as titled ("harris county judge")."""
    if office == "mayor":
        return _city(title)
    if office != "local":
        return None
    name = re.sub(r"^20\d\d\s+|\b(?:election|winner)\b|\?", " ", title.lower())
    return " ".join(name.split()) or None


def place_across_venues(events: dict[str, Event], tags: dict[str, Tags]) -> int:
    """A local race nothing placed (assumed U.S.) takes the country that other venues' markets for the same city
    and year were placed in, when they all agree. Returns how many were moved abroad."""
    placed: dict[tuple[str, int], set[str]] = {}
    for k, t in tags.items():
        city = _local_name(events[k].title, t.office)
        if city and t.place and t.year:
            placed.setdefault((city, t.year), set()).add(t.country or "")
    moved = 0
    for k, t in tags.items():
        if t.office not in ("mayor", "local") or t.place or t.topic != "elections_us":
            continue
        city = _local_name(events[k].title, t.office)
        found = placed.get((city, t.year)) if city else None
        if not found or len(found) != 1:
            continue
        country = next(iter(found))
        if country == "United States":
            tags[k] = Tags(**{**t.to_dict(), "place": "cross-venue"})
        elif country:
            tags[k] = Tags(**{**t.to_dict(), "topic": "elections_intl", "country": country,
                              "jurisdiction": f"{country}/{city}", "place": "cross-venue"})
            moved += 1
    return moved


_NEXT_ELECTION = re.compile(r"\b(?:after|in|at|of) (?:the )?next (?:\w+ )?elections?\b", re.I)


def next_election_across_venues(events: dict[str, Event], tags: dict[str, Tags]) -> int:
    """"Prime Minister after the next election" names no year, and the year then comes from the markets' close
    times, which can be a far backstop (2028 for an election in 2026). Such a question takes the earliest year that
    other questions about the same office name explicitly, when that year is not later than the inferred one.
    Returns how many were moved."""
    explicit: dict[tuple, set[int]] = defaultdict(set)
    for k, t in tags.items():
        if t.race_key and t.year and _year(events[k], events[k].title)[1]:
            explicit[(t.country, t.jurisdiction, t.office, t.stage, t.variant)].add(t.year)
    moved = 0
    for k, t in tags.items():
        e = events[k]
        if not t.race_key or not t.year or not _NEXT_ELECTION.search(e.title) or _year(e, e.title)[1]:
            continue
        years = {y for y in explicit.get((t.country, t.jurisdiction, t.office, t.stage, t.variant), ()) if y <= t.year}
        if years and min(years) != t.year:
            tags[k] = Tags(**{**t.to_dict(), "year": min(years)})
            moved += 1
    return moved

