"""U.S. real GDP as first published, from ALFRED vintages (2026-10-07).

Technical-recession markets settle on BEA's advance estimates ("advance estimates will be considered"), while the
reference class in pmpol.recession counts negative quarters in today's revised series. The two differ: an advance
print below zero can be revised up, and the other way round. ALFRED keeps every vintage of real GDP (GDPC1, levels,
from December 1991; earlier vintages are GNP), so the first print of each quarter's growth can be rebuilt:

  first print   the earliest vintage that contains the quarter: each quarter is probed 35, 45, 55, 75 and 95 days
                after it ends (the advance estimate comes about four weeks after, the second about a month later, so
                the first probe holding the quarter holds its first print; shutdowns that delayed the advance
                estimate, as in 2019 and 2025, are covered by the later probes)
  growth        ((level_q / level_q-1)^4 - 1) x 100 on that vintage, rounded to 0.1 as BEA publishes it

The record: how often the first print's sign differs from today's, which quarter pairs were negative in first
prints and in revised data, and the technical-recession base rates of pmpol.recession recomputed on first prints.
Rebuilding growth from rounded levels can differ from BEA's published rate by 0.1 now and then; a print within 0.1 of
zero is listed so its sign can be checked by hand.
"""

from __future__ import annotations

import csv
import io
import time
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

from pmpol import USER_AGENT

ALFRED = "https://alfred.stlouisfed.org/graph/alfredgraph.csv?id={ids}&vintage_date={dates}"
CACHE = Path("data/realtime")
SERIES = "GDPC1"
FIRST = "1991Q4"  # GDPC1 vintages begin in December 1991
PROBES = (35, 45, 55, 75, 95)  # days after the quarter ends
BATCH = 12  # ALFRED returns at most 12 vintages per request
FACT = "us.gdp.first_print_record"


def _get(url: str) -> str:
    import httpx

    r = httpx.get(url, timeout=90, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
    r.raise_for_status()  # a refusal or a rate limit stops here, never retried
    return r.text


def quarters(first: str, last: str) -> list[str]:
    out, y, q = [], int(first[:4]), int(first[-1])
    while f"{y}Q{q}" <= last:
        out.append(f"{y}Q{q}")
        y, q = (y + 1, 1) if q == 4 else (y, q + 1)
    return out


def quarter_end(q: str) -> date:
    y, n = int(q[:4]), int(q[-1])
    return date(y, 12, 31) if n == 4 else date(y, 3 * n + 1, 1) - timedelta(days=1)


def _obs_quarter(d: str) -> str:
    return f"{d[:4]}Q{(int(d[5:7]) - 1) // 3 + 1}"


def fetch_vintages(dates: list[str], cache: Path = CACHE, get=None, pause: float = 2.0) -> dict[str, dict[str, float]]:
    """vintage date -> {quarter: level} for the given vintage dates (requests of up to 12, cached)."""
    get = get or _get
    cache.mkdir(parents=True, exist_ok=True)
    out = {}
    for i in range(0, len(dates), BATCH):
        batch = dates[i:i + BATCH]
        path = cache / f"{SERIES}_{batch[0]}_{batch[-1]}_{len(batch)}.csv"
        if path.exists():
            text = path.read_text(encoding="utf-8")
        else:
            text = get(ALFRED.format(ids=",".join([SERIES] * len(batch)), dates=",".join(batch)))
            path.write_text(text, encoding="utf-8")
            time.sleep(pause)
        rows = list(csv.reader(io.StringIO(text)))
        if not rows:
            continue
        head, body = rows[0], rows[1:]
        for d in batch:
            col = f"{SERIES}_{d.replace('-', '')}"
            if col not in head:
                continue
            j = head.index(col)
            out[d] = {_obs_quarter(r[0]): float(r[j]) for r in body if len(r) > j and r[j] not in ("", ".")}
    return out


def previous(q: str) -> str:
    y, n = int(q[:4]), int(q[-1])
    return f"{y - 1}Q4" if n == 1 else f"{y}Q{n - 1}"


def growth(levels: dict[str, float], q: str) -> float | None:
    prev = previous(q)
    if q not in levels or prev not in levels:
        return None
    return round(((levels[q] / levels[prev]) ** 4 - 1) * 100, 1)


def first_prints(qs: list[str], today: date, cache: Path = CACHE, get=None, pause: float = 2.0) -> dict[str, tuple[float, str]]:
    """quarter -> (first-print growth, vintage date), probing later dates only for quarters not found yet."""
    out: dict[str, tuple[float, str]] = {}
    todo = list(qs)
    for days in PROBES:
        want = {q: (quarter_end(q) + timedelta(days=days)).isoformat() for q in todo}
        want = {q: d for q, d in want.items() if d <= today.isoformat()}
        if not want:
            break
        vint = fetch_vintages(sorted(set(want.values())), cache, get, pause)
        for q, d in want.items():
            g = growth(vint.get(d, {}), q)
            if g is not None:
                out[q] = (g, d)
        todo = [q for q in todo if q not in out]
        if not todo:
            break
    return out


@dataclass
class Record:
    sample: str
    quarters: int
    sign_flips: list[dict]  # {quarter, first, latest}
    near_zero: list[str]  # first prints within 0.1 of zero
    pairs_first: list[str]  # second quarter of each negative pair in first prints
    pairs_latest: list[str]  # the same in today's series
    rates_first: dict
    rates_latest: dict
    recent: dict = None  # the last 12 quarters' first prints


def record(first: dict[str, tuple[float, str]], latest: list[tuple[str, float]]) -> Record:
    from pmpol.recession import base_rates

    lat = dict(latest)
    qs = [q for q in sorted(first) if q in lat]
    fp = [(q, first[q][0]) for q in qs]
    lt = [(q, lat[q]) for q in qs]
    flips = [{"quarter": q, "first": first[q][0], "latest": lat[q]} for q in qs if (first[q][0] < 0) != (lat[q] < 0)]

    def pairs(series):
        return [series[i][0] for i in range(1, len(series)) if series[i][1] < 0 and series[i - 1][1] < 0]

    return Record(f"{qs[0]}..{qs[-1]}", len(qs), flips, [q for q in qs if abs(first[q][0]) <= 0.1],
                  pairs(fp), pairs(lt), base_rates(fp, 8), base_rates(lt, 8),
                  {q: first[q][0] for q in sorted(first)[-12:]})


def _rate(r: list[int]) -> str:
    return "—" if not r[1] else f"{100 * r[0] / r[1]:.1f}% ({r[0]}/{r[1]})"


def render(rec: Record) -> str:
    L = ["# 美國實質 GDP：初估和修正後（ALFRED 歷史版本）", "",
         "技術性衰退市場用 BEA 的初估結算，參考類別原本用今天修正後的數字。這裡用 ALFRED 的 GDPC1 版本重建每一季第一次公布的"
         "年化季增率，和今天的數字比。", "",
         f"- 樣本：{rec.sample}，{rec.quarters} 季",
         f"- 正負號不同：{len(rec.sign_flips)} 季（" + "、".join(f"{f['quarter']} 初估 {f['first']:+.1f} → 現在 {f['latest']:+.1f}"
                                                        for f in rec.sign_flips) + "）",
         f"- 初估在 ±0.1 以內（重算可能和 BEA 公布的差 0.1，要人工核對正負號）：{'、'.join(rec.near_zero) or '無'}",
         f"- 連續兩季負成長（第二季）：初估 {'、'.join(rec.pairs_first) or '無'}；修正後 {'、'.join(rec.pairs_latest) or '無'}",
         "", "## 基準率：之後 n 季內湊成連續兩季負成長的比例（上一季為正）", "",
         "| n | 初估 | 修正後 |", "|---|---|---|"]
    for n in (1, 2, 3, 4, 6, 8):
        L.append(f"| {n} | {_rate(rec.rates_first['pos'][n])} | {_rate(rec.rates_latest['pos'][n])} |")
    return "\n".join(L + [""])


def kb_yaml(rec: Record, recorded: date) -> str:
    def rates(r):
        return "{" + ", ".join(f"{n}: [{r['pos'][n][0]}, {r['pos'][n][1]}]" for n in (1, 2, 3, 4, 6, 8)) + "}"

    flips = ", ".join(f"{{quarter: {f['quarter']}, first: {f['first']}, latest: {f['latest']}}}" for f in rec.sign_flips)
    return "\n".join([
        "# Generated by `pmpol gdp-realtime --write-kb`; review before marking the fact reviewed.", "facts:",
        f"- id: {FACT}", "  layer: L2", "  subject: U.S. real GDP growth (BEA), first print vs latest",
        "  predicate: first_print_record",
        f"  value: {{sample: '{rec.sample}', quarters: {rec.quarters}, sign_flips: [{flips}], "
        f"near_zero: [{', '.join(rec.near_zero)}], negative_pairs_first: [{', '.join(rec.pairs_first)}], "
        f"negative_pairs_latest: [{', '.join(rec.pairs_latest)}], base_rates_first_pos: {rates(rec.rates_first)}, "
        f"base_rates_latest_pos: {rates(rec.rates_latest)}, "
        f"recent_first_prints: {{{', '.join(f'{q}: {g}' for q, g in (rec.recent or {}).items())}}}}}",
        "  source:", "    title: ALFRED vintages of GDPC1 (BEA via the St. Louis Fed)",
        "    url: https://alfred.stlouisfed.org/series?seid=GDPC1",
        "    license: BEA data public domain", "  admiralty: A2", "  status: proposed",
        f"  recorded_at: {recorded.isoformat()}",
        "  note: Computed by pmpol.gdp_realtime; first print = earliest vintage holding the quarter (probes 35-95 days "
        "after quarter end); growth rebuilt from levels, rounded to 0.1.", ""])
