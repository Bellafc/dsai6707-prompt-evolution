"""Evidence: an item of outside information about a proposition, with the times that matter.

The reverse engine asks one question of every price move: was the information public before the market moved?
That needs four times, kept apart (ARCHITECTURE 9, layer 2):

  occurred_at    when the reported thing happened in the world (often not readable; "" = unknown)
  published_at   when it first became public (a news item's publication or first-seen time)
  received_at    when this system fetched it
  moved          when the market moved: the window between two snapshots, from the move itself

`timing()` places an item against a move: "before" (public before the move started: the move may simply react
to it), "during" (public inside the window: cannot tell which came first at snapshot resolution), "after" (the
market moved first). Only "after" items make a lead; they are found by the follow-up search 72 hours later.

Grading follows the Admiralty code like the knowledge base: source reliability A-F and information credibility
1-6. Nothing is graded automatically yet, so items start at F6 ("cannot be judged"). The direction an item
pushes (supports YES or NO) is not inferred automatically either: "unclear" until a person or a later model
says otherwise. Evidence is L1 (an observation of what was published), never a fact about the world.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone

TIMINGS = ("before", "during", "after", "unknown")
STANCES = ("supports_yes", "supports_no", "unclear")


@dataclass(frozen=True)
class Evidence:
    claim: str  # what it is about: "market:<key>" (or a proposition variable id)
    text: str  # headline or statement
    source: str  # publisher or domain
    url: str
    published_at: str = ""
    received_at: str = ""
    occurred_at: str = ""
    reliability: str = "F"  # Admiralty source reliability, F = cannot be judged
    credibility: str = "6"  # Admiralty information credibility, 6 = cannot be judged
    stance: str = "unclear"
    via: str = ""  # how it was found: gdelt, google_news, ...

    def to_dict(self) -> dict:
        return asdict(self)


def _t(iso: str) -> datetime | None:
    if not iso:
        return None
    try:
        t = datetime.fromisoformat(iso.replace("Z", "+00:00"))
    except ValueError:
        try:  # GDELT seendate: 20261003T091500Z
            t = datetime.strptime(iso, "%Y%m%dT%H%M%SZ")
        except ValueError:
            return None
    return t if t.tzinfo else t.replace(tzinfo=timezone.utc)


def timing(e: Evidence, moved_from: str, moved_to: str) -> str:
    """Where the item's publication falls against the move window [moved_from, moved_to]."""
    t, a, b = _t(e.published_at), _t(moved_from), _t(moved_to)
    if t is None or a is None or b is None:
        return "unknown"
    return "before" if t < a else "after" if t > b else "during"


def from_news(claim: str, articles: list[dict], via: str, received_at: str | None = None) -> list[Evidence]:
    """Evidence items from news search results ({title, url, domain, seendate})."""
    now = received_at or datetime.now(timezone.utc).isoformat(timespec="seconds")
    out = []
    for a in articles:
        when = _t(a.get("seendate", ""))
        out.append(Evidence(claim, a.get("title", ""), a.get("domain", ""), a.get("url", ""),
                            when.isoformat(timespec="seconds") if when else "", now, via=via))
    return out


def summary(items: list[Evidence], moved_from: str, moved_to: str) -> dict[str, int]:
    counts = {k: 0 for k in TIMINGS}
    for e in items:
        counts[timing(e, moved_from, moved_to)] += 1
    return counts
