"""Real-time record of the Sahm rule, from ALFRED vintages (2026-10-06).

The macro layer computes the Sahm rule on today's revised unemployment rate, but a signal is only worth what it
said at the time. ALFRED (the St. Louis Fed's archive of past vintages, keyless CSV) gives the unemployment rate as
it was published: for every month m since 1970 the series as of the 15th of the next month, a few days after the
employment report. On each vintage the rule is recomputed with the data then available:

  Sahm(m) = (3-month average of the rate, ending at the latest month) - (lowest 3-month average of the 12 months
            before it); a signal when it first reaches 0.5 point

Each signal episode is set against the NBER business-cycle peaks (FRED USREC, first recession month): a hit when it
fires during a recession or within 12 months before one starts, a false alarm otherwise. The same is done on the
revised series, so the two records can be compared. The result is an L2 frequency the Sahm proof cites in place of
the caveat that it used revised data.
"""

from __future__ import annotations

import csv
import io
import time
from datetime import date
from pathlib import Path

from pmpol import USER_AGENT

ALFRED = "https://alfred.stlouisfed.org/graph/alfredgraph.csv?id={ids}&vintage_date={dates}"
FRED = "https://fred.stlouisfed.org/graph/fredgraph.csv?id={id}"
CACHE = Path("data/realtime")
START = "1970-01"
BATCH = 12  # ALFRED returns at most 12 vintages per request
THRESHOLD = 0.5
LEAD = 12  # months before a recession start that still count as a hit
FACT = "macro.sahm_rule.real_time_record"


def _shift(month: str, n: int) -> str:
    y, m = int(month[:4]), int(month[5:7]) - 1 + n
    return f"{y + m // 12}-{m % 12 + 1:02d}"


def months(start: str, end: str) -> list[str]:
    out, m = [], start
    while m <= end:
        out.append(m)
        m = _shift(m, 1)
    return out


def _get(url: str) -> str:
    import httpx

    r = httpx.get(url, timeout=90, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
    r.raise_for_status()
    return r.text


def fetch_vintages(data_months: list[str], cache: Path = CACHE, get=None, pause: float = 2.0) -> dict[str, list[float]]:
    """data month m -> the UNRATE values (oldest first) as published on the 15th of the month after m."""
    get = get or _get
    cache.mkdir(parents=True, exist_ok=True)
    out = {}
    for i in range(0, len(data_months), BATCH):
        batch = data_months[i:i + BATCH]
        dates = [f"{_shift(m, 1)}-15" for m in batch]
        path = cache / f"UNRATE_{dates[0]}_{dates[-1]}.csv"
        if path.exists():
            text = path.read_text(encoding="utf-8")
        else:
            text = get(ALFRED.format(ids=",".join(["UNRATE"] * len(batch)), dates=",".join(dates)))
            path.write_text(text, encoding="utf-8")
            time.sleep(pause)
        rows = list(csv.reader(io.StringIO(text)))
        head, body = rows[0], rows[1:]
        for j, m in enumerate(batch):
            col = head.index(f"UNRATE_{dates[j].replace('-', '')}") if f"UNRATE_{dates[j].replace('-', '')}" in head else None
            if col is None:
                continue
            vals = [(r[0][:7], float(r[col])) for r in body if len(r) > col and r[col] not in ("", ".")]
            vals = [v for mm, v in vals if mm <= m]  # the vintage may already hold the next month
            if vals:
                out[m] = vals
    return out


def fetch_current(series: str, cache: Path = CACHE, get=None, today: date | None = None) -> dict[str, float]:
    get = get or _get
    path = cache / f"{series}_{(today or date.today()).isoformat()}.csv"
    if not path.exists():
        cache.mkdir(parents=True, exist_ok=True)
        path.write_text(get(FRED.format(id=series)), encoding="utf-8")
    out = {}
    for row in csv.DictReader(io.StringIO(path.read_text(encoding="utf-8"))):
        v = row.get(series)
        if v not in (None, "", "."):
            out[row["observation_date"][:7]] = float(v)
    return out


def sahm(values: list[float]) -> float | None:
    """The Sahm indicator at the last value of a monthly series (oldest first)."""
    if len(values) < 15:
        return None
    avg3 = [sum(values[i - 2:i + 1]) / 3 for i in range(2, len(values))]
    return avg3[-1] - min(avg3[-13:-1])


def recession_starts(usrec: dict[str, float]) -> list[str]:
    ms = sorted(usrec)
    return [m for i, m in enumerate(ms) if usrec[m] >= 1 and (i == 0 or usrec[ms[i - 1]] < 1)]


def episodes(indicator: dict[str, float], threshold: float = THRESHOLD) -> list[str]:
    """Months where the indicator first reaches the threshold after being below it."""
    out, above = [], False
    for m in sorted(indicator):
        now = indicator[m] >= threshold - 1e-9
        if now and not above:
            out.append(m)
        above = now
    return out


def score(triggers: list[str], usrec: dict[str, float], lead: int = LEAD) -> list[dict]:
    starts = recession_starts(usrec)
    rows = []
    for t in triggers:
        during = usrec.get(t, 0) >= 1
        ahead = [s for s in starts if 0 <= _months(t, s) <= lead]
        ref = next((s for s in reversed(starts) if s <= t), None) if during else (ahead[0] if ahead else None)
        rows.append({"month": t, "outcome": "hit" if during or ahead else "false_alarm",
                     "recession_start": ref, "months_after_start": None if ref is None else _months(ref, t)})
    return rows


def _months(a: str, b: str) -> int:
    return (int(b[:4]) - int(a[:4])) * 12 + int(b[5:7]) - int(a[5:7])


def record(vintages: dict[str, list[float]], revised: dict[str, float], usrec: dict[str, float],
           start: str = START) -> dict:
    rt = {m: s for m, vals in vintages.items() if m >= start and (s := sahm(vals)) is not None}
    rev_vals = [revised[m] for m in sorted(revised)]
    keys = sorted(revised)
    rv = {}
    for i, m in enumerate(keys):
        if m >= start and (s := sahm(rev_vals[:i + 1])) is not None:
            rv[m] = s
    last = max(m for m in usrec)  # NBER dates lag: triggers after the last dated month cannot be scored yet
    out = {"sample": f"{min(rt)}..{max(rt)}", "threshold": THRESHOLD, "lead_months": LEAD,
           "recession_starts": [s for s in recession_starts(usrec) if s >= start]}
    for name, ind in (("real_time", rt), ("revised", rv)):
        trig = episodes(ind)
        rows = score([t for t in trig if t <= last], usrec)
        out[name] = {"triggers": rows, "unscored": [t for t in trig if t > last],
                     "hits": sum(r["outcome"] == "hit" for r in rows),
                     "false_alarms": sum(r["outcome"] == "false_alarm" for r in rows),
                     "missed": sorted(set(out["recession_starts"]) - {r["recession_start"] for r in rows
                                                                       if r["outcome"] == "hit"}),
                     "latest": [max(ind), round(ind[max(ind)], 3)]}
    return out


def kb_yaml(rec: dict, recorded: date) -> str:
    from pmpol.reference import _yaml

    rt, rv = rec["real_time"], rec["revised"]
    fact = {"id": FACT, "layer": "L2", "subject": "Sahm rule (U.S.)", "predicate": "real_time_signal_record",
            "value": rec,
            "source": {"title": "ALFRED vintages of UNRATE (BLS via the St. Louis Fed) and the NBER recession "
                                "indicator USREC (FRED)",
                       "url": "https://alfred.stlouisfed.org/series?seid=UNRATE",
                       "license": "BLS data public domain; NBER dates cited as facts"},
            "admiralty": "A2", "status": "proposed", "recorded_at": recorded,
            "note": f"Real time: {rt['hits']} hits, {rt['false_alarms']} false alarms, missed {rt['missed'] or 'none'}; "
                    f"revised data: {rv['hits']} hits, {rv['false_alarms']} false alarms. Vintage = the 15th of the "
                    "month after each data month. Generated by `pmpol realtime --write-kb`."}
    return "# Generated by `pmpol realtime --write-kb`; review before marking the facts reviewed.\n" + _yaml({"facts": [fact]})
