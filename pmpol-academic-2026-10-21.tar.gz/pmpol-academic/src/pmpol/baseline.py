"""Statistical baseline for official-statistics markets (2026-10-06).

A market such as "Unemployment in November above 3.7%?" or "CPI year-over-year in December exactly 2.5%?" is a
question about one future release of a public series whose history we can read. The outside view is the
series' own record: how far it has moved over the same horizon in the past.

  last value    the latest published month L of the series (BLS via FRED, rounded to 0.1 as BLS publishes)
  horizon       k = months from L to the market's month
  distribution  every change v(t + k) - v(t) since BASE_START, added to the last value and rounded to 0.1
  probability   the share of those outcomes inside each market's interval (the ontology's spans, in tenths)

It is an L5 inference from L1 data, shown next to the market; the key assumption is that the recent past moves
like the sample (`indicator_change_reference_class`). Months already published are not forecasts: the published
value decides them, and a market still trading against it is listed as such.

Series and how BLS defines the published number:
  us_unemployment   UNRATE, seasonally adjusted rate
  us_cpi_yoy        CPIAUCNS, 12-month change of the not seasonally adjusted index (the headline BLS figure)
  us_core_cpi_yoy   CPILFENS, same for core
  us_cpi_mom        CPIAUCSL, 1-month change of the seasonally adjusted index
  us_core_cpi_mom   CPILFESL, same for core
Computing a change from the index can differ from the published rounded figure by 0.1 now and then; stated as a
caveat.

Other countries (2026-10-06):
  br_ipca_12m       IPCA (IBGE, SIDRA table 1737, variable 63: monthly change, two decimals). The 12-month rate is
                    the compounded monthly changes, rounded to 0.01 as IBGE publishes. A k-month change of a
                    12-month rate ignores base effects (the month dropping out a year earlier), so the outside view
                    here keeps the published months fixed and fills each month not yet published with the same
                    calendar month of one past year since BASE_START_BR (inflation targeting began in mid-1999), one
                    outcome per year (`inflation_calendar_month_reference_class`).
"""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

from pmpol import USER_AGENT

DATA = Path("data/fundamentals")
BASE_START = "1990-01"  # sample start, fixed before looking at the fit
BASE_START_BR = "2000-01"  # first full year of Brazil's inflation targeting (adopted June 1999), fixed in advance
SIDRA = "https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/63/p/all"  # IPCA, monthly change (%), all months
SERIES = {
    "us_unemployment": ("UNRATE", "level"),
    "us_cpi_yoy": ("CPIAUCNS", "yoy"),
    "us_core_cpi_yoy": ("CPILFENS", "yoy"),
    "us_cpi_mom": ("CPIAUCSL", "mom"),
    "us_core_cpi_mom": ("CPILFESL", "mom"),
    "br_ipca_12m": ("IPCA_MOM", "compound12"),  # IBGE via SIDRA, not FRED
}
STEP = {"br_ipca_12m": 0.01}  # published decimals; 0.1 otherwise
SOURCE_ZH = {"IPCA_MOM": "IBGE SIDRA 表 1737"}
ZH = {"us_unemployment": "失業率", "us_cpi_yoy": "CPI 年增率", "us_core_cpi_yoy": "核心 CPI 年增率",
      "us_cpi_mom": "CPI 月增率", "us_core_cpi_mom": "核心 CPI 月增率", "br_ipca_12m": "巴西 IPCA 12 個月"}


def url(code: str) -> str:
    return SIDRA if code == "IPCA_MOM" else f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={code}"


def step_of(series: str) -> float:
    return STEP.get(series, 0.1)


def fetch(code: str, cache: Path = DATA, get=None, today: date | None = None) -> Path:
    """Download one series (FRED's CSV, or SIDRA's JSON for IPCA) to the cache, one file per day."""
    path = cache / f"{code}_{(today or date.today()).isoformat()}.{_ext(code)}"
    if path.exists():
        return path
    if get is None:
        import httpx

        def get(u):
            r = httpx.get(u, timeout=60, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
            r.raise_for_status()
            return r.text
    text = get(url(code))
    cache.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def _ext(code: str) -> str:
    return "json" if code == "IPCA_MOM" else "csv"


def latest_cached(code: str, cache: Path = DATA) -> Path | None:
    files = sorted(cache.glob(f"{code}_*.{_ext(code)}"))
    return files[-1] if files else None


def monthly(text: str) -> dict[str, float]:
    """FRED's CSV, or SIDRA's JSON (first row is the header; periods like 202608; "..." when not available)."""
    if text.lstrip().startswith("["):
        import json

        out = {}
        for row in json.loads(text)[1:]:
            try:
                out[f"{row['D3C'][:4]}-{row['D3C'][4:6]}"] = float(row["V"])
            except (KeyError, ValueError):
                continue
        return out
    out = {}
    for row in csv.DictReader(io.StringIO(text)):
        vals = [v for k, v in row.items() if k != "observation_date"]
        if vals and vals[0] not in ("", "."):
            out[row["observation_date"][:7]] = float(vals[0])
    return out


def _shift(month: str, n: int) -> str:
    y, m = int(month[:4]), int(month[5:7]) - 1 + n
    return f"{y + m // 12}-{m % 12 + 1:02d}"


def compound(rates: list[float]) -> float:
    """Monthly percent changes -> the percent change over all of them."""
    acc = 1.0
    for r in rates:
        acc *= 1 + r / 100
    return 100 * (acc - 1)


def derived(raw: dict[str, float], how: str) -> dict[str, float]:
    """The published figure, rounded to 0.1: the level, or the 1- or 12-month percent change of an index; for
    "compound12", the 12-month change from monthly changes, rounded to 0.01."""
    if how == "compound12":
        out = {}
        for m in raw:
            window = [_shift(m, -i) for i in range(12)]
            if all(w in raw for w in window):
                out[m] = round(compound([raw[w] for w in window]), 2)
        return out
    if how == "level":
        return {m: round(v, 1) for m, v in raw.items()}
    lag = 12 if how == "yoy" else 1
    return {m: round(100 * (v / raw[p] - 1), 1) for m, v in raw.items() if (p := _shift(m, -lag)) in raw}


def months_between(a: str, b: str) -> int:
    return (int(b[:4]) - int(a[:4])) * 12 + int(b[5:7]) - int(a[5:7])


@dataclass
class Outlook:
    series: str
    code: str
    period: str  # the market's month
    last_month: str
    last_value: float
    horizon: int  # months ahead; <= 0: already published
    outcomes: list[float] = field(default_factory=list)  # simulated values (one per historical start month)
    step: float = 0.1  # the published grid (the ontology's spans count these steps)
    method: str = "change"  # "change": k-month changes; "calendar": same calendar months of past years
    start: str = BASE_START

    @property
    def published(self) -> bool:
        return self.horizon <= 0

    def probability(self, spans) -> float:
        """Share of outcomes inside the union of spans (in grid steps, as the ontology stores them)."""
        if not self.outcomes:
            return float("nan")
        return sum(any(_inside(round(x / self.step), s) for s in spans) for x in self.outcomes) / len(self.outcomes)


def _inside(v: int, s) -> bool:
    lo_ok = v >= s.lo if s.lo_closed else v > s.lo
    hi_ok = v <= s.hi if s.hi_closed else v < s.hi
    return lo_ok and hi_ok


def outlook(series: str, period: str, values: dict[str, float], start: str = BASE_START) -> Outlook | None:
    """The distribution of the series in `period` from the k-month changes since `start`; when `period` is
    published, its value alone."""
    code, how = SERIES[series]
    if how == "compound12":
        return outlook_calendar(series, period, values)
    if not values:
        return None
    last = max(values)
    if period in values:  # already published: the value decides it
        return Outlook(series, code, period, period, values[period], months_between(last, period), [values[period]])
    k = months_between(last, period)
    if k <= 0:
        return None
    hist = sorted(m for m in values if m >= start)
    outs = [round(values[last] + values[_shift(m, k)] - values[m], 1) for m in hist if _shift(m, k) in values]
    return Outlook(series, code, period, last, values[last], k, outs)


def outlook_calendar(series: str, period: str, rates: dict[str, float], start: str = BASE_START_BR) -> Outlook | None:
    """A 12-month rate in `period` from monthly changes: the published months fixed, each later month taken from
    the same calendar month of one past year (all later months from the same year), one outcome per year."""
    code = SERIES[series][0]
    if not rates:
        return None
    last = max(rates)
    window = [_shift(period, -i) for i in range(11, -1, -1)]
    k = months_between(last, period)
    if k <= 0:
        if not all(w in rates for w in window):
            return None
        v = round(compound([rates[w] for w in window]), 2)
        return Outlook(series, code, period, period, v, k, [v], 0.01, "calendar", start)
    known = [rates[w] for w in window if w <= last]
    if len(known) != sum(w <= last for w in window):
        return None
    missing = [w for w in window if w > last]
    outs = []
    for back in range(1, 100):
        past = [_shift(w, -12 * back) for w in missing]
        if past[0] < start:
            break
        if all(p in rates for p in past):
            outs.append(round(compound(known + [rates[p] for p in past]), 2))
    last12 = [_shift(last, -i) for i in range(12)]
    lv = round(compound([rates[w] for w in last12]), 2) if all(w in rates for w in last12) else float("nan")
    return Outlook(series, code, period, last, lv, k, outs, 0.01, "calendar", start)


def load_values(series: str, cache: Path = DATA) -> tuple[dict[str, float], Path | None]:
    """The series as the outlook reads it: published figures, or monthly changes for "compound12"."""
    code, how = SERIES[series]
    path = latest_cached(code, cache)
    if path is None:
        return {}, None
    raw = monthly(path.read_text(encoding="utf-8"))
    return (raw if how == "compound12" else derived(raw, how)), path


_PERIOD = re.compile(r"^(\d{4}-\d{2})$")


def period_of(subject: str) -> str | None:
    """"us_unemployment|2026-11" -> "2026-11" (monthly variables only)."""
    parts = subject.split("|")
    return parts[1] if len(parts) == 2 and _PERIOD.match(parts[1]) else None
