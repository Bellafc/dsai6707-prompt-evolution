"""Daily brief: one page from the outputs of the latest cycle, for a reader with three minutes.

It only re-reads what the other steps wrote (the signals table, run manifests, data/*.json and the
reports); it computes nothing new, so every line can be traced to the step and proof behind it.
"""

from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from pmpol import runs
from pmpol.propositions.resolution import STATUS_ZH


def _latest(pattern: str, reports: Path) -> Path | None:
    files = sorted(reports.glob(pattern))
    return files[-1] if files else None


def _last_counts(conn: sqlite3.Connection, command: str) -> dict:
    try:
        row = conn.execute("SELECT counts FROM runs WHERE command = ? AND status LIKE 'ok%' ORDER BY started_at DESC "
                           "LIMIT 1", (command,)).fetchone()
    except sqlite3.OperationalError:
        return {}
    return json.loads(row[0]) if row and row[0] else {}


def _snapshot_times(conn: sqlite3.Connection) -> list[str]:
    return [r[0] for r in conn.execute("SELECT DISTINCT ts FROM signals WHERE module = 'relations' ORDER BY ts")]


def new_violations(conn: sqlite3.Connection) -> tuple[str, str, list[tuple[float, str, str]], int]:
    """Relation and single-event violations in the latest snapshot that were not in the previous one:
    (latest time, previous time, [(edge, kind, sig_id)], number that disappeared)."""
    times = _snapshot_times(conn)
    if not times:
        return "", "", [], 0
    latest = times[-1]
    prev = times[-2] if len(times) > 1 else ""

    def rows(ts):
        return {r[2]: (r[0], r[1]) for r in conn.execute(
            "SELECT edge, kind, sig_id FROM signals WHERE ts = ? AND module IN ('relations', 'constraints')", (ts,))}

    now, before = rows(latest), rows(prev) if prev else {}
    new = sorted(((e, k, sid) for sid, (e, k) in now.items() if sid not in before), reverse=True)
    gone = len([sid for sid in before if sid not in now])
    return latest, prev, new, gone


def render(conn: sqlite3.Connection, reports: Path = Path("reports"), data: Path = Path("data"),
           now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    proofs = {}
    if (data / "proofs.json").exists():
        proofs = {s["id"]: s for s in json.loads((data / "proofs.json").read_text(encoding="utf-8"))["signals"]}
    uni, mov, settle = (_last_counts(conn, c) for c in ("universe", "movers", "settle"))
    latest, prev, new, gone = new_violations(conn)
    movers = json.loads((data / "movers.json").read_text(encoding="utf-8"))["signals"] \
        if (data / "movers.json").exists() else []
    silent = [m for m in movers if m["kind"] == "silent_move"]
    settled = json.loads((data / "settlement.json").read_text(encoding="utf-8"))["signals"] \
        if (data / "settlement.json").exists() else []
    flagged = sorted((s for s in settled if s["edge"] >= 0.05), key=lambda s: -s["edge"])
    # cycle steps are left out: the brief is itself a step, and the cycle records its steps only when it ends, so
    # here they would be the previous cycle's (`pmpol status` and the scheduler's notification cover steps)
    health = [h for h in runs.health(conn, now)
              if (h.stale or h.failures_in_a_row) and not h.source.startswith("step:")]

    L = [f"# 每日簡報 — {now:%Y-%m-%d %H:%M} UTC", "",
         "把最近一次循環的所有輸出整理成一頁。每一行都來自某個步驟的輸出，詳細推理在查看器和各份報告裡。", ""]
    L += ["## 一句話", "",
          f"最新快照 {str(uni.get('observed_at', latest))[:16]}：{uni.get('events', 0):,} 個事件、"
          f"{uni.get('violations', 0):,} 條扣費後違反"
          + (f"（和上一個快照比，新出現 {len(new):,} 條、消失 {gone:,} 條）；" if prev else "（沒有上一個快照可比）；")
          + f"價格異動 {mov.get('moves', 0):,} 個，其中沉默異動 {len(silent)} 個；"
          f"結算資料已確定但價格偏離的 {len(flagged)} 個；"
          + (f"有 {len(health)} 個來源失敗或過期。" if health else "所有來源正常。"), ""]

    L += _requirements(data)
    L += _signposts(conn)
    L += _premortem(data)

    L += ["## 1. 這次看不到什麼", ""]
    L += [f"- `{h.source}`：" + (f"連續失敗 {h.failures_in_a_row} 次" if h.failures_in_a_row
                                 else f"過期（最後成功 {(h.last_ok or '從未')[:16]}）") for h in health] or ["- 沒有。"]
    L.append("")

    if not prev:
        new = []  # with no earlier snapshot nothing is "new"; the universe report lists every violation
    L += [f"## 2. 新出現的一致性違反（{len(new):,} 條，前 8 條）" if prev else "## 2. 新出現的一致性違反", "",
          f"和上一個快照（{prev[:16] or '—'}）相比，這次才出現的違反。扣費、按可執行價計算；跨地區的平台通常無法兩邊交易。", ""]
    for edge, kind, sid in new[:8]:
        p = proofs.get(sid)
        title = p["title"] if p else kind
        venues = "/".join(p.get("venues", [])) if p else ""
        rules = STATUS_ZH.get(p.get("rules", ""), "") if p else ""
        L.append(f"- **{100 * edge:+.1f} 點**　{title}（{venues}）" + (f"　規則：{rules}" if rules else ""))
    if not new:
        L.append("- 沒有新的。" if prev else "- 沒有上一個快照可比（第一次執行或全新環境），全部違反見全景報告第 4 節。")
    L.append("")

    L += [f"## 3. 沉默異動（{len(silent)} 個）", "",
          "價格明顯變動、查不到新聞、其他平台也沒動。只是給人工追查的線索，不是結論；72 小時後系統會自動重查新聞。", ""]
    L += [f"- {s['title'].replace('價格異動｜', '')}：{s['proof']['conclusion']}" for s in silent] or ["- 沒有。"]
    lanes = {k[5:]: v for k, v in mov.items() if k.startswith("lane_")}
    if lanes:
        L.append("- 這次所有異動的分類：" + "、".join(f"{k} {v}" for k, v in sorted(lanes.items())))
    L.append("")

    L += [f"## 4. 結算資料檢查（讀懂 {settle.get('markets', 0):,} 個市場）", ""]
    L += [f"- **偏離 {100 * s['edge']:.0f} 點**　{s['title']}：{s['proof']['conclusion']}" for s in flagged[:8]] or \
        ["- 沒有已確定但價格偏離的市場。"]
    L.append("")

    if f := _latest("*_universe.md", reports):
        text = f.read_text(encoding="utf-8")
        i, j = text.find("### 8a."), text.find("### 8b.")
        L += ["## 5. 殘差監測：新出現、讀不懂的題目", "",
              f"- 未分類事件 {100 * uni.get('residual_unclassified_share', 0):.1f}%、"
              f"本體讀不懂的市場 {100 * uni.get('residual_unparsed_share', 0):.1f}%、"
              f"新出現且完全讀不懂 {uni.get('residual_new_unread', 0)} 個"]
        if 0 <= i < j:
            L += [line for line in text[i:j].splitlines()[2:] if line.startswith("- ")][:6]
        L.append("")

    if f := _latest("*_track.md", reports):
        text = f.read_text(encoding="utf-8")
        i, j = text.find("## 2. 結果"), text.find("## 3.")
        rows = [line for line in text[i:j].splitlines() if line.startswith("| `")] if 0 <= i < j else []
        L += ["## 6. 訊號成績單（只看登記後的前瞻樣本）", "",
              "| 主張 | 前瞻樣本 | 前瞻指標值 | 前瞻判定 | 全部樣本 | 全部指標值 | 未觀測 |", "|---|---|---|---|---|---|---|"]
        L += rows
        L.append("")

    if f := _latest("*_universe.md", reports):
        m = re.search(r"扣費後仍不一致、不給點估計的：([\d,]+) 組。偏離 ≥ 5 點的次數，依平台：(.+)", f.read_text(encoding="utf-8"))
        if m:
            L += ["## 7. 跨平台共識", "", f"- 扣掉手續費後各平台仍不一致、不給點估計的：{m.group(1)} 組",
                  f"- 單一平台偏離共識 ≥ 5 點的次數：{m.group(2)}", ""]
    if f := _latest("*_propositions.md", reports):
        text = f.read_text(encoding="utf-8")
        cover = re.search(r"有效市場 ([\d,]+) 個，讀成命題的 ([\d,]+) 個（(\d+)%）", text)
        comp = re.search(r"本體推出相同結論的 \*\*([\d,]+)\*\*（([\d.]+)%），結論不同的 \*\*([\d,]+)\*\*", text)
        new = re.search(r"共 ([\d,]+) 條；其中\*\*直接關係 ([\d,]+) 條\*\*", text)
        viol = re.search(r"扣費後按可執行價計算的違反：([\d,]+) 條", text)
        L += ["## 8. 關係來源（命題本體）與模板交叉驗證", ""]
        if cover:
            L.append(f"- 讀成命題的市場：{cover.group(2)} / {cover.group(1)}（{cover.group(3)}%）")
        if comp:
            L.append(f"- 手寫模板（交叉驗證）：一致 {comp.group(1)}（{comp.group(2)}%），不同 {comp.group(3)}"
                     + ("（不同的每一條都要查：可能是模板錯，也可能是本體錯）" if comp.group(3) != "0" else ""))
        if new and viol:
            L.append(f"- 本體推出、模板沒有的關係 {new.group(1)} 條（直接關係 {new.group(2)} 條），其中扣費後違反 {viol.group(1)} 條"
                     "（已併入第 2 節的違反）")
        L.append("")
    L += _judgment_changes(conn)
    return "\n".join(L)


def _requirements(data: Path) -> list[str]:
    """Section 0: the stated questions (config/requirements.toml), their headline answers and evidence gaps."""
    from pmpol import requirements as rq

    try:
        reqs = rq.load()
    except (OSError, ValueError):
        return []
    ev = rq.gather(data)
    L = ["## 0. 需求清單：要回答的問題（`pmpol requirements`）", ""]
    for r in reqs:
        c = rq.cover(r, ev)
        head = c.answers[0] if c.answers else None
        ans = f"{head[0].split('｜', 1)[-1]}：{head[1]}" if head else ("沒有跨平台共識" if c.markets else "沒有相關市場")
        L.append(f"- **{r.question}** {ans}" + (f"；缺：{'、'.join(rq.LINES[x] for x in c.gaps)}" if c.gaps else ""))
    return L + [""]


def _signposts(conn: sqlite3.Connection) -> list[str]:
    """Triggered signposts of load-bearing assumptions (pmpol.signposts): the assumption needs its planned action."""
    import tomllib

    from pmpol.signposts import CONFIG, latest

    trig = [r for r in latest(conn) if r[2] == "triggered"]
    if not trig:
        return []
    actions = {s["id"]: s.get("action", "") for s in tomllib.loads(CONFIG.read_text(encoding="utf-8")).get("signpost", [])}
    L = [f"## 0b. 承重假設的路標觸發了（{len(trig)} 個，`pmpol signposts`）", ""]
    for sid, aid, _, _, detail in trig:
        L.append(f"- `{aid}`：{detail}。行動：{actions.get(sid, '見 config/signposts.toml')}")
    return L + [""]


def _premortem(data: Path) -> list[str]:
    """Section 0c: for each stated question's answer, the likeliest way it turns out wrong (pmpol premortem)."""
    try:
        pms = json.loads((data / "premortem.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    rows = [p for p in pms if p["why"].startswith("需求清單") and p["failures"]]
    if not rows:
        return []
    L = ["## 0c. 事前驗屍：這些答案最可能錯在哪裡（`pmpol premortem`）", ""]
    for p in rows:
        case = [f for f in p["failures"] if f["attacks"] != "model"] or p["failures"]
        L.append(f"- {p['title'].split('｜', 1)[-1]}：{case[0]['reason']}")
    return L + [""]


def _judgment_changes(conn: sqlite3.Connection, top: int = 8) -> list[str]:
    """Consensus estimates that moved since the last full record, with the inputs that changed (pmpol.judgments)."""
    from pmpol.judgments import changes

    moved = [c for c in changes(conn, kind="consensus") if abs(c.delta) >= 0.05]
    if not moved:
        return []
    L = [f"## 9. 判斷的改變與原因（共識機率變動 ≥ 5 點：{len(moved)} 個）", "",
         "每個判斷改變時，比對它依據的輸入步驟（報價、事實、假設），列出哪些變了。", ""]
    for c in moved[:top]:
        why = "；".join(f"{new[:70]}（之前：{old[:50]}）" for _, old, new in c.changed[:2]) or "依據的輸入沒有變（可能是新增或移除了某個平台）"
        L.append(f"- {c.subject[:60]}：{100 * c.old_value:.0f}% → {100 * c.new_value:.0f}%"
                 f"（{c.old_ts[:16]} → {c.new_ts[:16]}）；改變的輸入：{why}")
    return L + [""]
