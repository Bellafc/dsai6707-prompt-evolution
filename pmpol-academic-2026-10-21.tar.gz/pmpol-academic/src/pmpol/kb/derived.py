"""Facts the knowledge base can recompute from a primary source, and the check that they still agree.

`pmpol kb derive` re-derives each one; a mismatch means the YAML is stale (or the source changed)
and must be reviewed before anything depends on it.
"""

from __future__ import annotations

from collections import Counter


def senate_holdover(legislators: list[dict], term_end_after: str = "2027-01-03") -> dict:
    """Senators whose current term runs past the 2026 election cycle, by caucus (independents counted
    with the party they caucus with). Also returns the states whose seats are up."""
    held, up = Counter(), []
    for p in legislators:
        t = p["terms"][-1]
        if t["type"] != "sen":
            continue
        party = {"Democrat": "D", "Republican": "R"}.get(t.get("caucus") or t["party"], "I")
        if t["end"] > term_end_after:
            held[party] += 1
        else:
            up.append(t["state"])
    return {"D": held["D"], "R": held["R"], **({"I": held["I"]} if held["I"] else {}), "up": sorted(up)}


def check(kb) -> list[dict]:
    """Compare derivable facts with their primary sources (downloads, cached for a day)."""
    import json

    from pmpol.entities.sources import CONGRESS_URL, _cached
    from pmpol.senate.config import load_config

    out = []
    calc = senate_holdover(json.loads(_cached("congress_legislators_current.json", CONGRESS_URL)))
    fact = kb.facts.get("us.senate.2026_holdover")
    races = sorted(r.state for r in load_config().races)
    out.append({"fact": "us.senate.2026_holdover", "kb": fact.value if fact else None,
                "computed": {k: v for k, v in calc.items() if k != "up"},
                "ok": fact is not None and {k: v for k, v in calc.items() if k != "up"} == fact.value,
                "note": f"{len(calc['up'])} seats up; config lists {len(races)} races; "
                        + ("same states" if calc["up"] == races else f"differ: {sorted(set(calc['up']) ^ set(races))}")})
    return out
