"""What did we know, and when: fact versions and past states of the knowledge base, from Git history.

The knowledge base is curated YAML under kb/, reviewed through Git, so Git already holds every version. Facts
carry their own two times (valid_from/valid_to: when true in the world; recorded_at: when we learned it); this
adds the third, when the repository said so:

  versions(fact_id)  each commit where the fact appeared, changed (value, status, source) or disappeared
  as_of(when)        the knowledge base as it was in the last commit at or before `when`

Only committed history counts: uncommitted edits are not "known" yet.
"""

from __future__ import annotations

import subprocess
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import yaml

from pmpol.kb import KB_DIR, KnowledgeBase

REPO = KB_DIR.parent


def _git(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=REPO, capture_output=True, text=True, check=True).stdout


def commits() -> list[tuple[str, datetime]]:
    """Commits that touched kb/, oldest first: (sha, commit time in UTC)."""
    out = []
    for line in _git("log", "--format=%H %cI", "--", "kb").splitlines():
        sha, when = line.split(" ", 1)
        out.append((sha, datetime.fromisoformat(when).astimezone(timezone.utc)))
    return out[::-1]


def _files_at(sha: str) -> dict[str, str]:
    names = [n for n in _git("ls-tree", "-r", "--name-only", sha, "kb").splitlines() if n.endswith(".yaml")]
    return {n: _git("show", f"{sha}:{n}") for n in names}


def _facts_at(sha: str) -> dict[str, dict]:
    out = {}
    for text in _files_at(sha).values():
        for item in (yaml.safe_load(text) or {}).get("facts", []) or []:
            if isinstance(item, dict) and "id" in item:
                out[item["id"]] = item
    return out


@dataclass
class Version:
    commit: str
    when: datetime
    change: str  # "added", "changed", "removed"
    value: object = None
    status: str = ""
    source: str = ""


def versions(fact_id: str) -> list[Version]:
    out: list[Version] = []
    last = None
    for sha, when in commits():
        f = _facts_at(sha).get(fact_id)
        state = None if f is None else (repr(f.get("value")), f.get("status", ""), repr(f.get("source")))
        if state == last:
            continue
        if f is None:
            out.append(Version(sha[:10], when, "removed"))
        else:
            out.append(Version(sha[:10], when, "added" if last is None else "changed", f.get("value"),
                               f.get("status", ""), (f.get("source") or {}).get("title", "")))
        last = state
    return out


def as_of(when: datetime) -> tuple[KnowledgeBase, str | None]:
    """(knowledge base, commit) as of `when`; an empty knowledge base before the first commit."""
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    before = [sha for sha, t in commits() if t <= when]
    if not before:
        return KnowledgeBase(), None
    sha = before[-1]
    with tempfile.TemporaryDirectory() as tmp:
        for name, text in _files_at(sha).items():
            path = Path(tmp) / Path(name).relative_to("kb")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
        return KnowledgeBase.load(tmp), sha[:10]
