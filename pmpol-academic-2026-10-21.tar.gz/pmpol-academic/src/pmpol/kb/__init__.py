"""Knowledge base: the layered, sourced foundation every inference must trace back to.

Layers (team consensus, see README):
  L0 institutional rules   constitutions, statutes; hard constraints
  L1 current facts         who holds what, schedules; valid within a time window
  L2 base rates            historical frequencies; priors
  L3 expert consensus      ratings, external forecasts, geopolitical relations; graded
(L4 market observations and L5 system inferences live elsewhere and are never stored here.)

Facts are curated YAML files under kb/, reviewed through Git. Each fact carries two
times (valid_from/valid_to = when it is true in the world; recorded_at = when we
learned it), a source with a verbatim quote where possible, an Admiralty grade
(source reliability A-F + information credibility 1-6) and a review status.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import hashlib
import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

import yaml

KB_DIR = Path(__file__).resolve().parents[3] / "kb"
LAYERS = ("L0", "L1", "L2", "L3")
STATUSES = ("proposed", "reviewed", "disputed")
_ADMIRALTY = re.compile(r"^[A-F][1-6]$")


@dataclass(frozen=True)
class Source:
    title: str
    url: str
    quote: str | None = None  # verbatim text that must appear at `url`
    license: str | None = None


@dataclass(frozen=True)
class Fact:
    id: str
    layer: str
    subject: str
    predicate: str
    value: Any
    source: Source
    admiralty: str
    status: str
    recorded_at: date
    valid_from: date | None = None
    valid_to: date | None = None
    derived_from: tuple[str, ...] = ()
    note: str = ""
    file: str = ""

    def valid_at(self, when: date) -> bool:
        return (self.valid_from is None or self.valid_from <= when) and (self.valid_to is None or when <= self.valid_to)


@dataclass
class KnowledgeBase:
    facts: dict[str, Fact] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    @classmethod
    def load(cls, root: Path | str = KB_DIR) -> "KnowledgeBase":
        kb = cls()
        for path in sorted(Path(root).rglob("*.yaml")):
            raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            for i, item in enumerate(raw.get("facts", [])):
                where = f"{path.relative_to(root)}#{i}"
                try:
                    fact = _parse(item, str(path.relative_to(root)))
                except (KeyError, TypeError, ValueError) as e:
                    kb.errors.append(f"{where}: cannot parse ({e})")
                    continue
                if fact.id in kb.facts:
                    kb.errors.append(f"{where}: duplicate id {fact.id}")
                    continue
                kb.facts[fact.id] = fact
        kb.errors += kb.validate()
        return kb

    def conflicts(self) -> list[list[Fact]]:
        """Groups of facts that say different things about the same subject and predicate over overlapping
        validity periods. Team rule: conflicting sources are shown side by side, never resolved by picking one,
        so every fact in such a group must be marked `disputed`."""
        groups: dict[tuple[str, str], list[Fact]] = {}
        for f in self.facts.values():
            groups.setdefault((f.subject.strip().lower(), f.predicate.strip().lower()), []).append(f)
        out = []
        for fs in groups.values():
            if len(fs) < 2 or len({repr(f.value) for f in fs}) < 2:
                continue
            clash = [f for f in fs if any(g is not f and repr(g.value) != repr(f.value) and _overlap(f, g) for g in fs)]
            if clash:
                out.append(sorted(clash, key=lambda f: f.id))
        return out

    def rivals(self, fact_id: str) -> list[Fact]:
        """The other facts in `fact_id`'s conflict group (what other sources say)."""
        if getattr(self, "_rivals", None) is None or self._rivals[0] != len(self.facts):
            index = {f.id: [g for g in group if g.id != f.id] for group in self.conflicts() for f in group}
            self._rivals = (len(self.facts), index)
        return self._rivals[1].get(fact_id, [])

    def validate(self) -> list[str]:
        out = []
        for group in self.conflicts():
            unmarked = [f.id for f in group if f.status != "disputed"]
            if unmarked:
                out.append(f"conflicting facts must all be marked disputed (shown side by side): "
                           f"{', '.join(f.id for f in group)}; not marked: {', '.join(unmarked)}")
        for f in self.facts.values():
            p = f"{f.file}:{f.id}"
            if f.layer not in LAYERS:
                out.append(f"{p}: layer must be one of {LAYERS}")
            if f.status not in STATUSES:
                out.append(f"{p}: status must be one of {STATUSES}")
            if not _ADMIRALTY.match(f.admiralty):
                out.append(f"{p}: admiralty grade must look like A1..F6")
            if not f.source.url.startswith(("http://", "https://")):
                out.append(f"{p}: source url missing")
            if f.layer == "L0" and f.status == "reviewed" and not f.source.quote and not f.derived_from:
                out.append(f"{p}: reviewed L0 rules need a verbatim source quote")
            if f.valid_from and f.valid_to and f.valid_from > f.valid_to:
                out.append(f"{p}: valid_from after valid_to")
            for d in f.derived_from:
                if d not in self.facts:
                    out.append(f"{p}: derived_from unknown fact {d}")
        return out

    def get(self, fact_id: str) -> Fact:
        return self.facts[fact_id]

    def value(self, fact_id: str, default: Any = None) -> Any:
        f = self.facts.get(fact_id)
        return default if f is None else f.value

    def query(self, subject: str | None = None, predicate: str | None = None, at: date | None = None,
              layer: str | None = None) -> list[Fact]:
        out = [f for f in self.facts.values()
               if (subject is None or f.subject == subject) and (predicate is None or f.predicate == predicate)
               and (layer is None or f.layer == layer) and (at is None or f.valid_at(at))]
        return sorted(out, key=lambda f: f.id)

    def by_country(self) -> dict[str, list[Fact]]:
        out: dict[str, list[Fact]] = {}
        for f in self.facts.values():
            out.setdefault(f.id.split(".", 1)[0], []).append(f)
        return out


def _overlap(a: Fact, b: Fact) -> bool:
    lo = max(d for d in (a.valid_from, b.valid_from, date.min) if d is not None)
    hi = min(d for d in (a.valid_to, b.valid_to, date.max) if d is not None)
    return lo <= hi


def _date(x) -> date | None:
    if x in (None, ""):
        return None
    return x if isinstance(x, date) else date.fromisoformat(str(x))


def _parse(item: dict, file: str) -> Fact:
    src = item["source"]
    return Fact(
        id=item["id"], layer=item["layer"], subject=item["subject"], predicate=item["predicate"],
        value=item["value"],
        source=Source(src["title"], src["url"], src.get("quote"), src.get("license")),
        admiralty=str(item["admiralty"]), status=item["status"], recorded_at=_date(item["recorded_at"]),
        valid_from=_date(item.get("valid_from")), valid_to=_date(item.get("valid_to")),
        derived_from=tuple(item.get("derived_from", ())), note=item.get("note", ""), file=file,
    )


# --- online source verification ------------------------------------------------------

def _page_text(raw: str) -> str:
    import html

    text = re.sub(r"<script.*?</script>|<style.*?</style>|<[^>]+>", " ", raw, flags=re.S)
    return re.sub(r"\s+", " ", html.unescape(text))


_QUOTES = str.maketrans({"\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"', "\u00a0": " "})


def _norm(text: str) -> str:
    """Case, whitespace and quote-mark insensitive (pages often use curly apostrophes)."""
    return re.sub(r"\s+", " ", text.translate(_QUOTES)).strip().casefold()


MIN_PAGE = 500  # characters: shorter pages are block or error pages, not sources
REPO = "github.com/bellafc/polymarket_politics"


def quote_kind(f: Fact) -> str:
    """What a missing quote means: "computed" (a base rate this system computed; its source is the method and the
    data, not a sentence), "dataset" (a machine-readable file or API: there is no prose to quote; the value is checked
    against the data instead), or "text" (a page or document a sentence should be quoted from)."""
    url, note = f.source.url or "", f.note or ""
    if REPO in url or re.search(r"\bpmpol\b|`pmpol", note):
        return "computed"
    if re.search(r"\.(json|csv)(\?|$)|/api/|//api\.|gamma-api|fredgraph\.csv|/trade-api/", url):
        return "dataset"
    return "text"


def pdf_text(data: bytes) -> str:
    """Text of a PDF via the pdftotext program (poppler; run as a separate program, not imported)."""
    import shutil
    import subprocess

    exe = shutil.which("pdftotext")
    if exe is None:
        raise ValueError("a PDF, and pdftotext is not installed to read it")
    out = subprocess.run([exe, "-q", "-", "-"], input=data, capture_output=True, timeout=120)
    if out.returncode != 0:
        raise ValueError(f"pdftotext failed ({out.returncode})")
    return out.stdout.decode("utf-8", "replace")


def verify_sources(kb: KnowledgeBase, cache: Path = Path("data/kb_sources"), fetch=None) -> dict[str, str]:
    """Fetch every quoted source once and check the quote appears verbatim (whitespace and case
    insensitive). Returns fact id -> "verified" | "quote not found" | "unreachable: ..." | "no quote"."""
    import httpx

    def default_fetch(url: str) -> str:
        r = httpx.get(url, timeout=60, follow_redirects=True, headers={"User-Agent": USER_AGENT})
        r.raise_for_status()
        return pdf_text(r.content) if r.content[:5] == b"%PDF-" else r.text

    fetch = fetch or default_fetch
    cache.mkdir(parents=True, exist_ok=True)
    pages: dict[str, str | Exception] = {}
    out = {}
    for f in sorted(kb.facts.values(), key=lambda f: f.id):
        if not f.source.quote:
            out[f.id] = "no quote" if quote_kind(f) == "text" else quote_kind(f)
            continue
        url = f.source.url
        if url not in pages:
            path = cache / (hashlib.sha1(url.encode()).hexdigest() + ".txt")
            try:
                if not path.exists():
                    text = _page_text(fetch(url))
                    if len(text) < MIN_PAGE:  # a block or error page ("temporarily inaccessible from your location")
                        raise ValueError(f"page of {len(text)} characters, probably a block or error page")
                    path.write_text(text, encoding="utf-8")
                text = path.read_text(encoding="utf-8")
                if len(text) < MIN_PAGE:  # cached before this check existed: drop it, so a later run fetches again
                    path.unlink()
                    raise ValueError(f"cached page of {len(text)} characters, probably a block or error page")
                pages[url] = text
            except Exception as e:  # report, do not stop
                pages[url] = e
        page = pages[url]
        if isinstance(page, Exception):
            out[f.id] = f"unreachable: {page}"
        else:
            out[f.id] = "verified" if _norm(f.source.quote) in _norm(page) else "quote not found"
    return out
