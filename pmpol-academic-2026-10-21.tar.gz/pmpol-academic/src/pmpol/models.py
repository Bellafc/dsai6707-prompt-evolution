"""Core objects shared by every module.

Market       a raw contract on one venue, with its top-of-book quote
Event        a venue's grouping of markets (often mutually exclusive outcomes)
Signal       any module's output: an implied price, a constraint violation, an anomaly
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class Market:
    venue: str  # a key of pmpol.venues.VENUES, e.g. "kalshi", "polymarket", "polymarket_us", "gemini"
    market_id: str  # Kalshi ticker / Polymarket(US) market slug / Gemini instrument symbol
    event_id: str  # Kalshi event ticker / Polymarket(US) event slug / Gemini event ticker
    question: str
    outcome: str  # short label: Kalshi yes_sub_title, Polymarket groupItemTitle
    rules: str = ""
    bid: float | None = None  # best YES bid, dollars per $1 contract
    ask: float | None = None  # best YES ask
    last: float | None = None
    bid_size: float | None = None
    ask_size: float | None = None
    volume: float | None = None
    close_time: str | None = None
    active: bool = True
    # Structured strike, when the venue provides one (Kalshi): "greater", "less", "between", ...
    strike_type: str | None = None
    floor_strike: float | None = None
    cap_strike: float | None = None
    token_id: str | None = None  # venue order-book id for the YES side (Polymarket CLOB token)
    # Taker fee per $1 contract = fee_rate * (p * (1 - p)) ** fee_exponent.
    fee_rate: float = 0.0
    fee_exponent: float = 1.0
    # Commission on net winnings (Smarkets, PredictIt). The side of a leg is not known here, so
    # taker_fee charges it on the larger possible profit: a conservative upper bound.
    profit_commission: float = 0.0

    @property
    def key(self) -> str:
        return f"{self.venue}:{self.market_id}"

    @property
    def mid(self) -> float | None:
        if self.bid is not None and self.ask is not None and self.ask > 0:
            return (self.bid + self.ask) / 2
        return self.last

    def taker_fee(self, price: float) -> float:
        return (self.fee_rate * (price * (1 - price)) ** self.fee_exponent
                + self.profit_commission * max(price, 1 - price))

    @property
    def spread(self) -> float | None:
        if self.bid is None or self.ask is None:
            return None
        return self.ask - self.bid


@dataclass
class Event:
    venue: str
    event_id: str
    title: str
    category: str = ""
    mutually_exclusive: bool = False
    markets: list[Market] = field(default_factory=list)

    @property
    def key(self) -> str:
        return f"{self.venue}:{self.event_id}"


@dataclass
class Signal:
    module: str  # producer, e.g. "senate_seats", "constraints"
    kind: str  # e.g. "implied_price", "sum_violation", "ladder_violation"
    subject: str  # market key or group key the signal is about
    edge: float  # signed size in probability points (model - market, or arbitrage margin)
    payload: dict[str, Any] = field(default_factory=dict)
    ts: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="seconds"))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Relation:
    """A logical identity between YES payoffs of market legs.

    kind = "equivalent":  sum(YES of lhs) == sum(YES of rhs) in every outcome
    kind = "implies":     sum(YES of lhs) <= sum(YES of rhs) in every outcome
    Legs on each side must be mutually exclusive outcomes, so each side pays 0 or 1.
    """

    kind: str
    lhs: list[str]  # market keys
    rhs: list[str]
    template: str  # which rule produced it, e.g. "cross_venue_winner"
    group: str  # race key or cluster id it belongs to
    # "rule" (structural), "text" (similarity match, verify rules); ontology relations also use "name", "label",
    # "descriptor" and "title" (pmpol.propositions.relations)
    confidence: str = "rule"
    note: str = ""
    rules: str = ""  # cross-venue resolution check: equivalent / unverified / minor / material (propositions.resolution)
    rules_detail: str = ""  # what was compared, in words
    grounds: tuple[str, ...] = ()  # grounds of this relation beyond its inference rule's (propositions.rules)

    @property
    def cross_venue(self) -> bool:
        return len({k.split(":", 1)[0] for k in self.lhs + self.rhs}) > 1

    @property
    def key(self) -> str:
        return f"{self.template}:{'+'.join(sorted(self.lhs))}={'+'.join(sorted(self.rhs))}"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
