"""L1 candidate lists: who is on the general-election ballot of a U.S. race, and for which party.

Source: the "General election" results box of English Wikipedia's race pages (House pages per state with a
section per district, Senate and governor pages per state), which lists every candidate on the general ballot
with their party once the primaries are over. Licence CC BY-SA 4.0 (attribution: the page URL in every record).
Fetched with `action=raw` (one request per page, a pause between requests, cached under data/candidates/; the
API endpoints are rate-limited from cloud addresses). A refusal (403, the robot policy) or a rate limit (429) stops
the run: we do not retry in a loop or disguise the client; the cached lists, if any, are kept.

These are L1 facts in the proposed state: Wikipedia is a secondary source (Admiralty B3). The person-party bridge
of the proposition ontology cites the list instead of the assumption that labels identify the party's only
candidate; where the list contradicts the labels, the bridge is not derived and the conflict is listed.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from pmpol.universe.geo import US_STATES

DATA = Path("data/candidates")
LICENCE = "CC BY-SA 4.0 (Wikipedia)"
UA = "pmpol/0.1 (https://github.com/bellafc/polymarket_politics; research, read-only)"  # Wikimedia UA policy
STATE_NAME = {code: name for name, code in US_STATES.items()}
AT_LARGE = {"AK", "DE", "ND", "SD", "VT", "WY"}  # one House seat: the state page has no district sections


@dataclass(frozen=True)
class Candidate:
    race: str  # race subject: "United States|TX-35|house|2026|general"
    name: str
    party: str  # "D", "R", or the party's name
    page: str  # Wikipedia page title
    section: str
    fetched_at: str

    @property
    def url(self) -> str:
        return f"https://en.wikipedia.org/wiki/{self.page}"


def page_for(subject: str) -> tuple[str, str] | None:
    """(page title, section heading) for a race subject; None for races we do not cover."""
    parts = subject.split("|")
    if len(parts) != 5 or parts[0] != "United States" or parts[4] != "general":
        return None
    juris, office, year = parts[1], parts[2], parts[3]
    state = STATE_NAME.get(juris[:2])
    if state is None:
        return None
    s = state.replace(" ", "_")
    if office == "house":
        if juris[:2] in AT_LARGE:
            return f"{year}_United_States_House_of_Representatives_election_in_{s}", ""
        district = juris.split("-")[1] if "-" in juris else ""
        if not district.isdigit():
            return None
        return f"{year}_United_States_House_of_Representatives_elections_in_{s}", f"District {int(district)}"
    if office == "senate":
        return f"{year}_United_States_Senate_election_in_{s}", ""
    if office == "governor":
        return f"{year}_{s}_gubernatorial_election", ""
    return None


def _templates(text: str, name: str) -> list[str]:
    """Bodies of {{name ...}} templates, brace-aware (candidates can be nested templates like {{ubl|..}})."""
    out, i = [], 0
    while True:
        i = text.find("{{" + name, i)
        if i < 0:
            return out
        depth, j = 0, i
        while j < len(text):
            if text.startswith("{{", j):
                depth += 1
                j += 2
            elif text.startswith("}}", j):
                depth -= 1
                j += 2
                if depth == 0:
                    break
            else:
                j += 1
        out.append(text[i + 2 + len(name):j - 2])
        i = j


def _field(body: str, key: str) -> str:
    """Value of `| key = value` in a template body, nested templates included."""
    depth, parts, cur = 0, [], []
    i = 0
    while i < len(body):
        if body.startswith("{{", i) or body.startswith("[[", i):
            depth += 1
            cur.append(body[i:i + 2])
            i += 2
            continue
        if body.startswith("}}", i) or body.startswith("]]", i):
            depth -= 1
            cur.append(body[i:i + 2])
            i += 2
            continue
        if body[i] == "|" and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(body[i])
        i += 1
    parts.append("".join(cur))
    for p in parts:
        k, sep, v = p.partition("=")
        if sep and k.strip() == key:
            return v.strip()
    return ""


def _plain(value: str) -> str:
    """"{{ubl|[[Katie Hobbs]] (incumbent)|..}}" -> "Katie Hobbs"; "[[Mike Collins (politician)|Mike Collins]]" ->
    "Mike Collins"."""
    v = value
    m = re.match(r"\{\{\s*(?:ubl|unbulleted list|plainlist)\s*\|(.*)\}\}\s*$", v, re.S | re.I)
    if m:  # a ticket: the first name is the candidate for the office
        v = m.group(1).split("|")[0] if "[[" not in m.group(1).split("|")[0] or "]]" in m.group(1).split("|")[0] \
            else re.match(r"(\[\[.*?\]\][^|]*)", m.group(1)).group(1)
    v = re.sub(r"\[\[(?:[^|\]]*\|)?([^\]]*)\]\]", r"\1", v)
    v = re.sub(r"<ref[^>]*/>|<ref.*?</ref>|\{\{.*?\}\}|<[^>]+>", "", v, flags=re.S)
    v = re.sub(r"\((?:incumbent|write-in)\)", "", v, flags=re.I)
    return " ".join(v.split()).strip(" ,'")


def party_code(party: str) -> str:
    p = party.lower()
    if "democratic" in p and "republican" not in p:
        return "D"
    if "republican" in p:
        return "R"
    return re.sub(r"\s*\(united states\)", "", party, flags=re.I).strip()


def _sections(text: str) -> list[tuple[int, int, int, str]]:
    """(start of body, level, heading position, heading) for every heading."""
    return [(m.end(), len(m.group(1)), m.start(), m.group(2)) for m in
            re.finditer(r"^(=+)\s*(.+?)\s*=+\s*$", text, re.M)]


def _span(text: str, heads, k: int) -> str:
    end = next((h[2] for h in heads[k + 1:] if h[1] <= heads[k][1]), len(text))
    return text[heads[k][0]:end]


def parse(text: str, race: str, page: str, section: str = "", fetched_at: str = "") -> list[Candidate]:
    """General-election candidates of one race from a page's wikitext ([] when the page has no such box)."""
    heads = _sections(text)
    scope = text
    if section:
        k = next((i for i, h in enumerate(heads) if h[3].strip().lower() == section.lower()), None)
        if k is None:
            return []
        scope = _span(text, heads, k)
        heads = _sections(scope)
    g = next((i for i, h in enumerate(heads) if h[3].strip().lower().startswith("general election")), None)
    if g is None:
        return []
    general = _span(scope, heads, g)
    out = []
    for tpl in ("Election box candidate with party link", "Election box winning candidate with party link"):
        for body in _templates(general, tpl):
            name, party = _plain(_field(body, "candidate")), _field(body, "party")
            if name and party:
                out.append(Candidate(race, name, party_code(party), page, section or "General election", fetched_at))
    return out


def fetch(pages: list[str], pause: float = 3.0, get=None, max_age_days: float = 7) -> dict[str, str]:
    """Raw wikitext per page, from the cache (younger than max_age_days) or Wikipedia (one request per page; stops
    at the first 429, keeping older cached copies)."""
    import httpx

    get = get or (lambda url: httpx.get(url, headers={"User-Agent": UA}, timeout=60, follow_redirects=True))
    raw = DATA / "wiki"
    raw.mkdir(parents=True, exist_ok=True)
    out = {}
    for i, page in enumerate(pages):
        f = raw / f"{page}.wiki"
        if f.exists() and time.time() - f.stat().st_mtime < max_age_days * 86400:
            out[page] = f.read_text(encoding="utf-8")
            continue
        r = get(f"https://en.wikipedia.org/w/index.php?title={page}&action=raw")
        if r.status_code in (403, 429):  # refused or rate-limited: stop, keep older copies, try on a later run
            out.update({q: (raw / f"{q}.wiki").read_text(encoding="utf-8") for q in pages[i:]
                        if (raw / f"{q}.wiki").exists()})
            break
        if r.status_code == 200:
            f.write_text(r.text, encoding="utf-8")
            out[page] = r.text
        if i < len(pages) - 1:
            time.sleep(pause)
    return out


def build(subjects: list[str], pause: float = 3.0, get=None) -> list[Candidate]:
    """Candidate lists for the given race subjects; written to data/candidates/candidates.json."""
    wanted = {s: page_for(s) for s in subjects}
    pages = sorted({ps[0] for ps in wanted.values() if ps})
    texts = fetch(pages, pause, get)
    now = datetime.now(timezone.utc).isoformat(timespec="minutes")
    out = []
    for subject, ps in sorted(wanted.items()):
        if ps and ps[0] in texts:
            out += parse(texts[ps[0]], subject, ps[0], ps[1], now)
    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / "candidates.json").write_text(json.dumps([asdict(c) for c in out], ensure_ascii=False, indent=1),
                                          encoding="utf-8")
    from pmpol.entities import ratings  # the same pages carry the experts' race ratings (L3)

    ratings.save([r for subject, ps in sorted(wanted.items()) if ps and ps[0] in texts
                  for r in ratings.parse(texts[ps[0]], subject, ps[0], ps[1])])
    return out


def load(path: Path = DATA / "candidates.json") -> dict[str, list[Candidate]]:
    """race subject -> its general-election candidates; empty when nothing was fetched."""
    if not path.exists():
        return {}
    out: dict[str, list[Candidate]] = {}
    for d in json.loads(path.read_text(encoding="utf-8")):
        c = Candidate(**d)
        out.setdefault(c.race, []).append(c)
    return out


def same_person(label: str, name: str) -> bool:
    """A market label and a listed candidate of the same race are one person: same surname, compatible first
    names, middle initials and suffixes that agree when both are given."""
    from pmpol.propositions.people import compatible_first, parse_name

    a, b = parse_name(label), parse_name(name)
    if not a or not b or a.last != b.last or not compatible_first(a.first, b.first):
        return False
    if a.suffix and b.suffix and a.suffix != b.suffix:
        return False
    if a.middle and b.middle and a.middle[0][0] != b.middle[0][0]:
        return False
    return True
