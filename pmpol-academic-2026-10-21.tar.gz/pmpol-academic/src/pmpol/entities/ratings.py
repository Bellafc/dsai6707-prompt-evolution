"""L3 expert race ratings: an evidence line independent of the markets (Cook, Inside Elections, Sabato,
Decision Desk HQ, Silver Bulletin), as tabulated with their dates in the "Predictions" table of Wikipedia's race
pages (the same pages, and the same cache, as pmpol.entities.candidates; CC BY-SA 4.0, each rating attributed
to its rater and dated).

Ratings are expert judgments (L3), not facts. To compare them with market prices, each category is read as a
band of win probability for the favoured party (`BANDS`, a registered key assumption until it is fitted to
past ratings and results). Markets and raters that disagree are shown side by side, never resolved.
"""

from __future__ import annotations

import json
import re
import statistics
from dataclasses import asdict, dataclass
from pathlib import Path

from pmpol.entities.candidates import DATA, _sections, _span

# win probability of the favoured party, by category (assumption "rating_probability_bands")
BANDS = {"safe": (0.95, 1.0), "solid": (0.95, 1.0), "likely": (0.85, 0.95), "lean": (0.65, 0.85),
         "tilt": (0.55, 0.65), "tossup": (0.35, 0.65)}
ORDER = ("tossup", "tilt", "lean", "likely", "safe")


@dataclass(frozen=True)
class Rating:
    race: str
    rater: str
    category: str  # safe, likely, lean, tilt, tossup
    party: str  # the favoured party ("D", "R"); "" for a toss-up
    as_of: str  # as written ("July 14, 2026")
    page: str

    def band(self, party: str) -> tuple[float, float]:
        """Win-probability band this rating gives `party`."""
        lo, hi = BANDS[self.category]
        if self.category == "tossup" or party == self.party:
            return lo, hi
        return round(1 - hi, 4), round(1 - lo, 4)


_TEMPLATE = re.compile(r"\{\{\s*(?:USRaceRating|US political race rating)\s*\|([^}]*)\}\}", re.I)


def parse(text: str, race: str, page: str, section: str = "") -> list[Rating]:
    """Ratings in the "Predictions" table of a race (inside `section` for House district pages)."""
    heads = _sections(text)
    scope = text
    if section:
        k = next((i for i, h in enumerate(heads) if h[3].strip().lower() == section.lower()), None)
        if k is None:
            return []
        scope = _span(text, heads, k)
        heads = _sections(scope)
    k = next((i for i, h in enumerate(heads) if h[3].strip().lower().startswith("predictions")), None)
    if k is None:
        return []
    out = []
    for row in _span(scope, heads, k).split("\n|-"):
        tpl = _TEMPLATE.search(row)
        rater = re.search(r"\[\[(?:[^|\]]*\|)?([^\]]+)\]\]", row)
        if not tpl or not rater:
            continue
        args = [a.strip().lower() for a in tpl.group(1).split("|")]
        category = args[0].replace("-", "").replace(" ", "")
        if category == "solid":
            category = "safe"
        if category not in BANDS:
            continue
        party = (args[1].upper() if len(args) > 1 and args[1] in ("d", "r") else "") if category != "tossup" else ""
        date = re.findall(r"\n\|\s*([A-Z][a-z]+ \d{1,2}, 20\d\d)\s*$", row.split("\n|}")[0].rstrip())
        out.append(Rating(race, rater.group(1).strip(), category, party, date[-1] if date else "", page))
    return out


def save(ratings: list[Rating], path: Path = DATA / "ratings.json") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps([asdict(r) for r in ratings], ensure_ascii=False, indent=1), encoding="utf-8")


def load(path: Path = DATA / "ratings.json") -> dict[str, list[Rating]]:
    if not path.exists():
        return {}
    out: dict[str, list[Rating]] = {}
    for d in json.loads(path.read_text(encoding="utf-8")):
        out.setdefault(d["race"], []).append(Rating(**d))
    return out


@dataclass
class Divergence:
    race: str
    party: str
    market: float  # consensus probability that `party` wins
    band: tuple[float, float]  # the raters' median band for `party`
    ratings: list[Rating]

    @property
    def gap(self) -> float:
        lo, hi = self.band
        return self.market - hi if self.market > hi else self.market - lo if self.market < lo else 0.0


def median_band(ratings: list[Rating], party: str) -> tuple[float, float]:
    bands = [r.band(party) for r in ratings]
    return statistics.median(b[0] for b in bands), statistics.median(b[1] for b in bands)


def compare(market: dict[tuple[str, str], float], ratings: dict[str, list[Rating]], min_gap: float = 0.05
            ) -> list[Divergence]:
    """market: (race, party) -> consensus probability. Races where the market sits outside the raters' median
    band by at least `min_gap`."""
    out = []
    for (race, party), p in market.items():
        rs = ratings.get(race)
        if not rs:
            continue
        d = Divergence(race, party, p, median_band(rs, party), rs)
        if abs(d.gap) >= min_gap:
            out.append(d)
    return sorted(out, key=lambda d: -abs(d.gap))
