"""Wikidata politicians via OpenSanctions' "wd_peps" extract (people, positions, occupancies, with QIDs).

Why not the Wikidata APIs directly: the query service and the action API block requests from shared cloud
addresses ("robot policy", HTTP 403/429; in October 2026 still for this host's Python client); OpenSanctions
publishes a daily extract of every politically exposed person in Wikidata. Candidacies, which the extract lacks,
are queried directly where the query service allows it (pmpol.entities.wikidata). License: OpenSanctions data is CC BY-NC 4.0 (research use; a licence is needed for
commercial use), built from Wikidata (CC0).

The extract has one name per person and no aliases, so it cannot tell nicknames apart, and two people with one
name (a sheriff father and a congressional-candidate son, both "Mike Bouchard") look the same. It is therefore
used only with evidence: pmpol.entities.people links a market candidate to a QID when the person holds or held
the very office the race is for.

The raw file (~335 MB) is cached under data/entities/; a compact subset (people whose surname appears in our
markets, with their positions) is written next to it and is what the pipeline reads.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import json
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

URL = "https://data.opensanctions.org/datasets/latest/wd_peps/entities.ftm.json"
RAW = Path("data/entities/wd_peps.ftm.json")
COMPACT = Path("data/entities/wd_peps_people.json")
LICENCE = "OpenSanctions wd_peps (from Wikidata): CC BY-NC 4.0"


@dataclass
class Person:
    qid: str
    name: str
    countries: list[str] = field(default_factory=list)  # ISO-2 lower
    birth: str = ""
    dead: bool = False
    positions: list[dict] = field(default_factory=list)  # {"name", "country", "start", "end"}


def download(path: Path = RAW, fetch=None) -> Path:
    """Stream the extract to disk (cached; delete the file to refresh)."""
    if path.exists():
        return path
    import httpx

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".part")
    if fetch is not None:
        tmp.write_bytes(fetch(URL))
    else:
        with httpx.stream("GET", URL, timeout=600, follow_redirects=True, headers={"User-Agent": USER_AGENT}) as r:
            r.raise_for_status()
            with open(tmp, "wb") as f:
                for chunk in r.iter_bytes():
                    f.write(chunk)
    tmp.rename(path)
    return path


def compact(raw: Path, surnames: set[str], norm) -> list[Person]:
    """People whose last name (normalised by `norm`) is in `surnames`, with their positions. Two passes over
    the file: people first, then the occupancies and positions that belong to them."""
    people: dict[str, Person] = {}
    with open(raw, encoding="utf-8") as f:
        for line in f:
            if '"schema":"Person"' not in line:
                continue
            r = json.loads(line)
            p = r["properties"]
            names = p.get("name", [])
            if not names or not any(norm(n).split()[-1:] and norm(n).split()[-1] in surnames for n in names):
                continue
            people[r["id"]] = Person(r["id"], names[0], sorted(set(p.get("citizenship", []) + p.get("country", []))),
                                     min(p.get("birthDate", [""])), bool(p.get("deathDate")))
    occupancies: dict[str, list[dict]] = defaultdict(list)
    posts: dict[str, dict] = {}
    with open(raw, encoding="utf-8") as f:
        for line in f:
            if '"schema":"Occupancy"' in line:
                r = json.loads(line)
                p = r["properties"]
                for holder in p.get("holder", []):
                    if holder in people:
                        for post in p.get("post", []):
                            occupancies[holder].append({"post": post, "start": min(p.get("startDate", [""])),
                                                        "end": max(p.get("endDate", [""]))})
            elif '"schema":"Position"' in line:
                r = json.loads(line)
                p = r["properties"]
                posts[r["id"]] = {"name": (p.get("name") or [r.get("caption", "")])[0],
                                  "country": sorted(p.get("country", []))}
    for qid, occ in occupancies.items():
        for o in occ:
            post = posts.get(o["post"])
            if post:
                people[qid].positions.append({"name": post["name"], "country": post["country"], "start": o["start"],
                                              "end": o["end"]})
    return list(people.values())


def save(people: list[Person], path: Path = COMPACT) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps([p.__dict__ for p in people], ensure_ascii=False))


def load(path: Path = COMPACT) -> list[Person]:
    if not path.exists():
        return []
    return [Person(**d) for d in json.loads(path.read_text(encoding="utf-8"))]
