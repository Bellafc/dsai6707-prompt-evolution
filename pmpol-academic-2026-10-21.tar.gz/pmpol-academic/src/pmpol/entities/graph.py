"""Entity resolution, market linking and the person/office graph.

Linking rule of thumb (market text is short, so precision first):
  - full-name match on any 2-4 word span of the title, outcome labels or question;
  - surname-only match on a capitalised word that is not a common word, a demonym or
    somebody else's first name; the person must be a candidate in this very race, or the
    only match from the event's state, or the only matching "prominent" person (member of
    Congress, Cabinet-level official, head of state/government, minister) in the same
    U.S.-vs-foreign context;
  - anything still ambiguous is dropped.
Merging across sources: same Wikidata id, else a shared full name with compatible state
and country, else (for name variants such as Pete/Peter) the single prominent person with
the same surname and a first name sharing its first three letters.
"""

from __future__ import annotations

import json
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import networkx as nx

from pmpol.entities import sources
from pmpol.entities.sources import Entity
from pmpol.universe.geo import COUNTRIES, US_STATES
from pmpol.universe.index import Universe
from pmpol.universe.outcomes import _norm
from pmpol.venues import info, venue_order

# Words that are also surnames of prominent people but far more often mean something else.
_STOP = {w.lower() for w in [
    *US_STATES, *COUNTRIES, "house", "senate", "party", "trade", "court", "price", "march", "will", "who", "next",
    "says", "said", "visit", "meet", "general", "state", "union", "green", "labour", "liberal", "national", "people",
    "power", "major", "press", "justice", "james", "john", "james", "king", "young", "white", "black", "brown",
    "rice", "hunt", "banks", "grant", "rich", "love", "may", "moore", "lee", "long", "law", "case", "hill",
    "bishop", "cotton", "turner", "miller", "smith", "johnson", "williams", "jones", "davis", "wilson", "taylor",
    "thomas", "scott", "allen", "carter", "mann", "nunn", "wild", "fields", "lowe", "best", "good", "strong",
    "street", "chair", "speaker", "leader", "minister", "president", "governor", "mayor", "senator", "sanders",
    "kennedy", "jackson", "harris", "warner", "graham", "paul", "collins", "murphy", "booker", "baldwin"]}
# "Sanders", "Kennedy", "Harris" ... name several prominent people; they still link by full name.
_STOP |= {a.lower() for aliases in COUNTRIES.values() for a in aliases}
# Surnames that are also common first names link only by full name.
_STOP |= {"jack", "ryan", "scott", "franklin", "sean", "kevin", "henry", "george", "frank", "mark", "kelly", "dean",
          "adams", "craig", "neal", "allred", "ross", "russell", "marshall", "cole", "lucas", "mason", "carl", "glenn",
          "wesley", "morgan", "jordan", "riley", "hayes", "gray", "grace", "rose", "august", "june", "april"}
_TITLES = {"gov", "governor", "sen", "senator", "rep", "president", "secretary", "minister", "mayor", "leader",
           "chancellor", "prime", "judge", "speaker", "ambassador", "general", "director", "chairman", "chair", "dr",
           "mr", "mrs", "ms", "king", "queen", "prince", "will", "when", "who", "what", "does", "did", "can", "has",
           "is", "how", "which", "where", "why", "and", "or", "vs", "trump", "first", "next", "former", "ex"}


@dataclass
class Mention:
    entity: str
    method: str  # "full" or "surname"
    where: str  # "title", "outcome", "question"


@dataclass
class EntityIndex:
    entities: dict[str, Entity] = field(default_factory=dict)
    by_alias: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))
    by_surname: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))
    load_log: list[str] = field(default_factory=list)
    _prominent_by_surname: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))

    @classmethod
    def build(cls, batches: list[tuple[str, list[Entity]]]) -> "EntityIndex":
        idx = cls()
        for name, ents in batches:
            merged = sum(idx._add(e) for e in ents)
            idx.load_log.append(f"{name}: {len(ents):,} records, {merged:,} merged into existing entities")
        for eid, e in idx.entities.items():
            for a in e.aliases:
                if len(a.split()) >= 2:
                    idx.by_alias[a].add(eid)
            # Everyone is indexed by surname; prominence and context decide whether a bare surname links.
            if e.surname and len(e.surname) >= 4 and e.surname not in _STOP:
                idx.by_surname[e.surname].add(eid)
        return idx

    def _add(self, e: Entity) -> bool:
        """Merge into an existing entity when the same Wikidata id, or a shared full name with
        compatible geography; returns True when merged."""
        target = None
        if e.wikidata and e.wikidata in self.entities:
            target = self.entities[e.wikidata]
        else:
            # A name with a middle part merges only on that full name: its "first last" variant would make
            # "Daniel J. Sullivan" (an Alaska Senate candidate) the senator "Daniel S. Sullivan".
            long = [a for a in e.aliases if len(a.split()) >= 3]
            keys = long or [a for a in e.aliases if len(a.split()) >= 2]
            hits = {i for a in keys for i in self.by_alias.get(a, ())}
            hits = [self.entities[i] for i in hits if _compatible(self.entities[i], e) and _suffix_fits(e, self.entities[i])]
            if len(hits) == 1:
                target = hits[0]
            elif not hits and e.surname and not long:  # a middle name ("Daniel J.") is not a nickname match
                # "Pete Hegseth" vs "Peter Hegseth": same surname, compatible first name, one prominent match.
                firsts = {a.split()[0][:3] for a in e.aliases if a}
                near = [x for x in (self.entities[i] for i in self._prominent_by_surname.get(e.surname, ()))
                        if _compatible(x, e) and firsts & {a.split()[0][:3] for a in x.aliases if a}]
                if len(near) == 1:
                    target = near[0]
        if target is None:
            self.entities[e.id] = e
            for a in e.aliases:  # keep the alias index live so later batches can merge
                if len(a.split()) >= 2:
                    self.by_alias[a].add(e.id)
            if e.prominent and e.surname:
                self._prominent_by_surname[e.surname].add(e.id)
            return False
        target.aliases |= e.aliases
        target.races |= e.races
        target.positions += [p for p in e.positions if p not in target.positions]
        target.sources |= e.sources
        target.prominent |= e.prominent
        if target.prominent and target.surname:
            self._prominent_by_surname[target.surname].add(target.id)
        for attr in ("state", "district", "party", "country", "wikidata"):
            if getattr(target, attr) is None:
                setattr(target, attr, getattr(e, attr))
        for a in e.aliases:
            if len(a.split()) >= 2:
                self.by_alias[a].add(target.id)
        return True

    # --- linking ---------------------------------------------------------------

    def link_text(self, text: str, where: str, us_context: bool, state: str | None = None,
                  race: str | None = None) -> list[Mention]:
        out = []
        words = re.findall(r"[A-Za-zÀ-ÿ][\w'\-.]*", text)
        norm = [_norm(w).replace(".", "") for w in words]
        used = set()
        for n in (4, 3, 2):
            for i in range(len(norm) - n + 1):
                if any(j in used for j in range(i, i + n)):
                    continue
                ids = self.by_alias.get(" ".join(norm[i:i + n]))
                eid = self._pick(ids, us_context, state, race, surname_only=False)
                if eid:
                    out.append(Mention(eid, "full", where))
                    used.update(range(i, i + n))
        for i, (raw, w) in enumerate(zip(words, norm)):
            if i in used or not raw[:1].isupper() or w in _STOP:
                continue
            if i + 1 < len(words) and words[i + 1][:1].isupper() and norm[i + 1] not in _STOP:
                continue  # followed by another capitalised word: probably someone else's first name
            first = norm[i - 1] if i > 0 and words[i - 1][:1].isupper() and norm[i - 1] not in _TITLES else None
            eid = self._pick(self.by_surname.get(w), us_context, state, race, surname_only=True)
            if eid and first and not self._first_name_fits(eid, first):
                continue  # "Ruben Rocha" is not "Paulo Rocha"
            if eid:
                out.append(Mention(eid, "surname", where))
        return out

    def _first_name_fits(self, eid: str, first: str) -> bool:
        """Pete fits Peter, Jim fits James? (only by shared prefix), Nancy does not fit Dave."""
        names = {a.split()[0] for a in self.entities[eid].aliases if a}
        return any(n[:3] == first[:3] for n in names)

    def _pick(self, ids, us_context: bool, state: str | None, race: str | None, surname_only: bool) -> str | None:
        """Choose one entity for a matched span, or None when the context leaves it ambiguous.

        Preference: a candidate in this very race, then someone from the event's state, then
        (surname-only) a single prominent person; foreign people never link in U.S. context
        on a bare surname, and vice versa.
        """
        if not ids:
            return None
        ents = [self.entities[i] for i in ids]
        if surname_only or len(ents) > 1:
            ents = [e for e in ents if (e.country == "us") == us_context]
        if race:
            in_race = [e for e in ents if race in e.races]
            if len(in_race) == 1:
                return in_race[0].id
        if state:
            local = [e for e in ents if e.state == state]
            if len(local) == 1:
                return local[0].id
            if len(local) > 1:
                return None
            if surname_only:
                ents = [e for e in ents if e.state is None]  # a different state's politician: skip
        if surname_only:
            ents = [e for e in ents if e.prominent]
        return ents[0].id if len(ents) == 1 else None


_SUFFIX = re.compile(r"[\s,]+(jr|sr|ii|iii|iv)\.?\s*$", re.I)


def _suffix(name: str) -> str:
    m = _SUFFIX.search(re.sub(r"\(.*?\)", "", name).strip())
    return m.group(1).lower() if m else ""


def _suffix_fits(new: Entity, existing: Entity) -> bool:
    """"Donald Trump Jr." never merges into "Donald Trump" (name variants drop suffixes); a name without a
    suffix may still be the official "Frank Pallone, Jr."."""
    s, t = _suffix(new.name), _suffix(existing.name)
    if s:
        return s == t
    # no suffix written: fits an official record that has one, not another market label that has one
    return not t or existing.sources != {"markets"}


def _compatible(a: Entity, b: Entity) -> bool:
    if a.state and b.state and a.state != b.state:
        return False
    if a.country and b.country and a.country != b.country:
        return False
    return True


def load_index(universe: Universe, log=sys.stderr) -> EntityIndex:
    batches = []
    for name, fn in (("seed", sources.seed), ("congress-legislators", sources.congress),
                     ("opensanctions:us_plum_book", lambda: sources.opensanctions("us_plum_book")),
                     ("opensanctions:us_cia_world_leaders", lambda: sources.opensanctions("us_cia_world_leaders")),
                     ("wikidata", sources.wikidata_leaders)):
        try:
            batches.append((name, fn()))
        except Exception as e:  # a missing source narrows coverage but must not stop the run
            print(f"entity source {name} unavailable: {e}", file=log)
    batches.append(("market candidates", sources.market_candidates(universe)))
    return EntityIndex.build(batches)


@dataclass
class EntityGraph:
    index: EntityIndex
    mentions: dict[str, list[Mention]]  # event key -> mentions
    graph: nx.Graph

    def events_of(self, eid: str) -> list[str]:
        return [n for n in self.graph.neighbors(f"entity:{eid}") if n.startswith("event:")]


def build_entity_graph(u: Universe, index: EntityIndex) -> EntityGraph:
    g = nx.Graph()
    mentions: dict[str, list[Mention]] = {}
    for key, e in u.events.items():
        t = u.tags[key]
        us = t.country in (None, "United States") or t.topic in ("elections_us", "us_government")
        state = t.jurisdiction[:2] if us and t.jurisdiction and t.jurisdiction[:2] in US_STATES.values() else None
        ctx = dict(us_context=us, state=state, race=t.race_key)
        found = index.link_text(e.title, "title", **ctx)
        for m in e.markets[:40]:
            if m.active and m.outcome:
                found += index.link_text(m.outcome, "outcome", **ctx)
        q = next((m.question for m in e.markets if m.question), "")
        found += index.link_text(q, "question", **ctx)
        uniq = {f.entity: f for f in found}
        if not uniq:
            continue
        mentions[key] = list(uniq.values())
        g.add_node(f"event:{key}", kind="event", title=e.title, venue=e.venue, topic=t.topic)
        for f in uniq.values():
            g.add_edge(f"event:{key}", f"entity:{f.entity}", kind="mentions", method=f.method, where=f.where)
    for eid, ent in index.entities.items():
        node = f"entity:{eid}"
        if node not in g:
            continue
        g.nodes[node].update(kind="person", name=ent.name, party=ent.party, country=ent.country, state=ent.state,
                             positions=ent.positions[:5], sources=sorted(ent.sources))
        if ent.party:
            g.add_edge(node, f"party:{ent.party}", kind="member_of")
        for p in ent.positions[:5]:
            g.add_edge(node, f"position:{p.lower()}|{ent.country or ''}", kind="holds")
        for r in ent.races:
            g.add_edge(node, f"race:{r}", kind="candidate_in")
    return EntityGraph(index, mentions, g)


def summarize(u: Universe, eg: EntityGraph, top: int = 25) -> list[str]:
    """Report section (Traditional Chinese)."""
    idx, g = eg.index, eg.graph
    L = ["## 9. 人物與實體圖譜", ""]
    L += [f"- 實體來源：{'；'.join(idx.load_log)}",
          f"- 合併後人物：**{len(idx.entities):,}** 位；其中可用姓氏單獨連結的高知名度人物 **"
          f"{sum(e.prominent for e in idx.entities.values()):,}** 位",
          f"- 連到至少一位人物的事件：**{len(eg.mentions):,} / {len(u.events):,}**"
          f"（{100 * len(eg.mentions) / max(len(u.events), 1):.0f}%）", ""]
    rows = []
    for eid, ent in idx.entities.items():
        node = f"entity:{eid}"
        if node not in g:
            continue
        evs = [n[6:] for n in g.neighbors(node) if n.startswith("event:")]
        topics = Counter(u.tags[k].topic for k in evs)
        venues = {u.events[k].venue for k in evs}
        rows.append((len(evs), ent, topics, venues))
    rows.sort(key=lambda r: -r[0])
    L += ["### 事件最多的人物", "", "| 人物 | 黨派 / 國家 | 現任職位 | 事件數 | 平台 | 主題分佈 |", "|---|---|---|---|---|---|"]
    for n, ent, topics, venues in rows[:top]:
        L.append(f"| {ent.name} | {ent.party or ''} {ent.country or ''} | {'; '.join(ent.positions[:2])[:60]} | {n} | "
                 f"{'/'.join(info(v).code for v in sorted(set(venues), key=venue_order))} | "
                 f"{', '.join(f'{k} {c}' for k, c in topics.most_common(4))} |")
    bridges = [r for r in rows if len(r[2]) >= 2]
    L += ["", f"### 跨主題的橋接人物（{len(bridges)} 位）", "",
          "同一個人同時出現在不同主題的市場中，是建立長邏輯鏈的入口（例如官員去留 ↔ 地緣政治 ↔ 選舉）。", ""]
    for n, ent, topics, _ in bridges[:15]:
        sample = [u.events[k[6:]].title for k in list(g.neighbors(f"entity:{ent.id}")) if k.startswith("event:")][:3]
        L.append(f"- **{ent.name}**（{', '.join(topics)}）：{' ／ '.join(sample)}")
    L.append("")
    return L


def export(eg: EntityGraph, path: Path) -> None:
    g = eg.graph
    data = {"nodes": [{"id": n, **{k: v for k, v in d.items()}} for n, d in g.nodes(data=True)],
            "edges": [{"source": a, "target": b, **d} for a, b, d in g.edges(data=True)]}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False))


_PARTY_NAMES = {"D": "Democratic Party", "R": "Republican Party", "I": "Independent"}


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", _norm(text)).strip("-")[:80]


def to_ftm(eg: EntityGraph):
    """Linked entities as FollowTheMoney-shaped records (Person, Position, Occupancy,
    Organization, Membership), so they can be merged with OpenSanctions/nomenklatura tooling."""
    seen = set()
    for eid, e in eg.index.entities.items():
        if f"entity:{eid}" not in eg.graph:
            continue
        props = {"name": [e.name], "alias": sorted(a for a in e.aliases if a != _norm(e.name))[:10]}
        if e.country:
            props["country"] = [e.country]
        if e.wikidata:
            props["wikidataId"] = [e.wikidata]
        props["topics"] = ["role.pep"] if e.prominent else []
        yield {"id": eid, "schema": "Person", "properties": props, "datasets": sorted(e.sources)}
        for p in e.positions[:5]:
            pid = f"pos-{_slug(p)}-{e.country or 'xx'}"
            if pid not in seen:
                seen.add(pid)
                yield {"id": pid, "schema": "Position",
                       "properties": {"name": [p], **({"country": [e.country]} if e.country else {})}}
            yield {"id": f"occ-{_slug(eid)}-{pid}", "schema": "Occupancy",
                   "properties": {"holder": [eid], "post": [pid], "status": ["current"]}}
        if e.party:
            oid = f"party-{_slug(e.party)}-{e.country or 'xx'}"
            if oid not in seen:
                seen.add(oid)
                yield {"id": oid, "schema": "Organization",
                       "properties": {"name": [_PARTY_NAMES.get(e.party, e.party)], "topics": ["pol.party"]}}
            yield {"id": f"mem-{_slug(eid)}-{oid}", "schema": "Membership",
                   "properties": {"member": [eid], "organization": [oid]}}


def export_ftm(eg: EntityGraph, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for rec in to_ftm(eg):
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
