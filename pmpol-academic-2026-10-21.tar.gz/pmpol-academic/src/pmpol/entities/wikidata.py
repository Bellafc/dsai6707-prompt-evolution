"""Wikidata, queried directly (2026-10-06): candidacies in upcoming elections.

The query service blocked this host until October 2026, so people came only from OpenSanctions' wd_peps extract
(positions held). That extract cannot place a newcomer: a Taiwanese county candidate who never held office has a
Wikidata item, but no position. Wikidata records candidacy too: "candidacy in election" (P3602) on the person,
and on the election item its date (P585), the office contested (P541), the jurisdiction (P1001) and the country
(P17). pmpol.propositions.people uses a candidacy as evidence only when the election is the race's own: the same
year and the office contested is the race's office in the race's place.

Wikimedia's user-agent policy asks for a descriptive agent with contact details; pmpol.USER_AGENT names the
project and its repository. A refusal or a rate limit (403, 429) stops the refresh and is not retried; the
previous file stays in use. Wikidata is CC0.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

from pmpol import USER_AGENT

ENDPOINT = "https://query.wikidata.org/sparql"
CANDIDACIES = Path("data/entities/wd_candidacies.json")
LICENCE = "Wikidata (CC0), query service"
YEARS = (2026, 2028)  # elections the markets ask about

QUERY = """SELECT ?person ?personLabel ?election ?electionLabel ?date ?officeLabel ?jurLabel ?countryLabel WHERE {
  ?person p:P3602 ?st . ?st ps:P3602 ?election .
  ?election wdt:P585 ?date .
  FILTER(?date >= "%d-01-01T00:00:00Z"^^xsd:dateTime && ?date < "%d-01-01T00:00:00Z"^^xsd:dateTime)
  OPTIONAL { ?election wdt:P541 ?office . }
  OPTIONAL { ?election wdt:P1001 ?jur . }
  OPTIONAL { ?election wdt:P17 ?country . }
  FILTER NOT EXISTS { ?person wdt:P570 ?death . }
  SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
}"""


@dataclass
class Candidacy:
    qid: str
    name: str
    election: str  # QID of the election item
    label: str  # the election's English label
    year: int
    offices: list[str] = field(default_factory=list)  # offices contested (P541), English labels
    places: list[str] = field(default_factory=list)  # jurisdictions (P1001) and countries (P17), English labels


def sparql(query: str, get=None) -> dict:
    if get is not None:
        return json.loads(get(query))
    import httpx

    r = httpx.get(ENDPOINT, params={"query": query, "format": "json"}, timeout=120,
                  headers={"User-Agent": USER_AGENT, "Accept": "application/sparql-results+json"})
    r.raise_for_status()  # a refusal or a rate limit stops here, never retried
    return r.json()


def _qid(uri: str) -> str:
    return uri.rsplit("/", 1)[-1]


def parse(raw: dict) -> list[Candidacy]:
    """One Candidacy per (person, election), offices and places collected over the result rows. Items without an
    English label (the label service returns the QID) are skipped: there is no name to match."""
    by: dict[tuple[str, str], Candidacy] = {}
    for b in raw.get("results", {}).get("bindings", []):
        qid, name = _qid(b["person"]["value"]), b.get("personLabel", {}).get("value", "")
        if not name or name == qid:
            continue
        key = (qid, _qid(b["election"]["value"]))
        c = by.get(key)
        if c is None:
            c = by[key] = Candidacy(qid, name, key[1], b.get("electionLabel", {}).get("value", ""),
                                    int(b["date"]["value"][:4]))
        for k, out in (("officeLabel", c.offices), ("jurLabel", c.places), ("countryLabel", c.places)):
            v = b.get(k, {}).get("value")
            if v and v not in out:
                out.append(v)
    return list(by.values())


def refresh(path: Path = CANDIDACIES, get=None, years: tuple[int, int] = YEARS) -> list[Candidacy]:
    out = parse(sparql(QUERY % (years[0], years[1] + 1), get))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps([asdict(c) for c in out], ensure_ascii=False), encoding="utf-8")
    return out


def load(path: Path = CANDIDACIES) -> list[Candidacy]:
    if not path.exists():
        return []
    return [Candidacy(**c) for c in json.loads(path.read_text(encoding="utf-8"))]
