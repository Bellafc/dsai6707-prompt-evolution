"""Entity sources: who holds which office, in which party and country.

Every loader returns `Entity` records and caches its raw download under data/entities/.
Sources and licenses:
  congress-legislators   CC0          U.S. Congress, with Wikidata QIDs, state, district, party
  OpenSanctions          CC BY-NC 4.0 us_plum_book (U.S. political appointees, incl. Cabinet),
                                      us_cia_world_leaders (heads of state/government, ministers)
  Wikidata               CC0          optional; set PMPOL_WIKIDATA_UA to a descriptive user agent
  seed file              -            a few offices no dataset covers (President, Vice President)
  market candidates      -            people named in our own winner/nomination markets
Note: OpenSanctions data is non-commercial; fine for research, needs a license for trading use.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import json
import os
import re
import time
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

import httpx

from pmpol.universe.geo import COUNTRIES, US_STATES
from pmpol.universe.outcomes import _norm, party_of, surname

CACHE = Path("data/entities")
SEED = Path(__file__).resolve().parents[3] / "config" / "entities_seed.toml"
CONGRESS_URL = "https://unitedstates.github.io/congress-legislators/legislators-current.json"
OPENSANCTIONS_URL = "https://data.opensanctions.org/datasets/latest/{dataset}/targets.nested.json"
WIKIDATA_URL = "https://query.wikidata.org/sparql"

# Positions in the Plum Book that make a person a headline figure.
_PROMINENT_US = re.compile(r"^(secretary(?! to)\b|attorney general|director, federal bureau|director of national "
                           r"intelligence|director, central intelligence|administrator of the environmental|"
                           r"united states trade representative|chief of staff to the president|representative of "
                           r"the united states .*united nations|director of the office of management)", re.I)


@dataclass
class Entity:
    id: str
    kind: str  # "person"
    name: str
    aliases: set[str] = field(default_factory=set)  # normalised full-name variants
    country: str | None = None  # ISO-2 lower ("us", "ye")
    state: str | None = None  # U.S. state code
    district: str | None = None  # "TX-18"
    party: str | None = None  # D / R / I or a foreign party name
    positions: list[str] = field(default_factory=list)  # current positions
    races: set[str] = field(default_factory=set)  # race keys the person is a candidate in
    prominent: bool = False  # may be linked by surname alone
    wikidata: str | None = None
    sources: set[str] = field(default_factory=set)

    @property
    def surname(self) -> str | None:
        return surname(self.name)


def name_variants(name: str) -> set[str]:
    """Normalised variants: full name, "first last", and without initials/suffixes."""
    base = _norm(re.sub(r"\(.*?\)", "", name)).replace(".", "")
    base = re.sub(r"[^a-z' \-]", " ", base)
    words = [w for w in base.split() if w not in ("jr", "sr", "ii", "iii", "iv")]
    if not words:
        return set()
    out = {" ".join(words)}
    if len(words) > 2:
        out.add(f"{words[0]} {words[-1]}")
        out.add(" ".join(w for w in words if len(w) > 1))
    return out


def _cached(name: str, url: str, max_age_h: float = 24) -> bytes:
    path = CACHE / name
    if path.exists() and time.time() - path.stat().st_mtime < max_age_h * 3600:
        return path.read_bytes()
    for attempt in range(3):
        try:
            r = httpx.get(url, timeout=120, follow_redirects=True, headers={"User-Agent": USER_AGENT})
            r.raise_for_status()
            break
        except httpx.HTTPError:
            if attempt == 2:
                if path.exists():  # stale cache beats nothing
                    return path.read_bytes()
                raise
            time.sleep(2 * (attempt + 1))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(r.content)
    return r.content


_PARTY = {"Democrat": "D", "Republican": "R", "Independent": "I"}


def congress() -> list[Entity]:
    out = []
    for p in json.loads(_cached("congress_legislators_current.json", CONGRESS_URL)):
        term = p["terms"][-1]
        n = p["name"]
        full = n.get("official_full") or f"{n['first']} {n['last']}"
        aliases = name_variants(full) | name_variants(f"{n['first']} {n['last']}")
        if n.get("nickname"):
            aliases |= name_variants(f"{n['nickname']} {n['last']}")
        district = None
        if term["type"] == "rep":
            d = term.get("district", 0)
            district = f"{term['state']}-{'AL' if d == 0 else f'{d:02}'}"
        out.append(Entity(
            id=p["id"].get("wikidata") or f"bioguide:{p['id']['bioguide']}", kind="person", name=full,
            aliases=aliases, country="us", state=term["state"], district=district,
            party=_PARTY.get(term.get("party"), term.get("party")),
            positions=["U.S. Senator" if term["type"] == "sen" else "U.S. Representative"],
            prominent=True, wikidata=p["id"].get("wikidata"), sources={"congress-legislators"}))
    return out


def opensanctions(dataset: str) -> list[Entity]:
    raw = _cached(f"os_{dataset}.json", OPENSANCTIONS_URL.format(dataset=dataset))
    out = []
    for line in raw.splitlines():
        r = json.loads(line)
        if r.get("schema") != "Person":
            continue
        props = r["properties"]
        current, countries = [], set(props.get("citizenship", []) + props.get("country", []))
        for occ in props.get("positionOccupancies", []):
            if "ended" in occ["properties"].get("status", []):
                continue
            for post in occ["properties"].get("post", []):
                cap = post["caption"]
                current.append(cap.title() if cap.isupper() else cap)  # Plum Book positions are in capitals
                countries |= set(post["properties"].get("country", []))
        if not current:
            continue
        names = props.get("name", []) + props.get("alias", [])
        # CIA and Plum Book write surnames (or whole names) in capitals.
        display = " ".join(w.title() if w.isupper() and len(w) > 1 else w for w in r["caption"].split())
        aliases = set().union(*(name_variants(n) for n in names)) if names else set()
        if dataset == "us_plum_book":
            prominent = any(_PROMINENT_US.match(p) for p in current)  # case-insensitive pattern
        else:
            prominent = True  # CIA World Leaders lists only heads of state/government and ministers
        out.append(Entity(
            id=(props.get("wikidataId") or [None])[0] or f"os:{r['id']}", kind="person", name=display,
            aliases=aliases, country=sorted(countries)[0] if countries else None, positions=current,
            prominent=prominent, wikidata=(props.get("wikidataId") or [None])[0], sources={f"opensanctions:{dataset}"}))
    return out


def seed() -> list[Entity]:
    if not SEED.exists():
        return []
    with open(SEED, "rb") as f:
        raw = tomllib.load(f)
    return [Entity(id=p["id"], kind="person", name=p["name"],
                   aliases=set().union(*(name_variants(a) for a in [p["name"], *p.get("aliases", [])])),
                   country=p.get("country"), state=p.get("state"), party=p.get("party"),
                   positions=p.get("positions", []), prominent=True, wikidata=p.get("wikidata"),
                   sources={"seed"}) for p in raw.get("person", [])]


_WD_LEADERS = """SELECT ?person ?personLabel ?countryLabel ?posLabel WHERE {
  ?country wdt:P31 wd:Q6256. { ?country p:P35 ?st. ?st ps:P35 ?person. } UNION { ?country p:P6 ?st. ?st ps:P6 ?person. }
  FILTER NOT EXISTS { ?st pq:P582 ?end } BIND(IF(EXISTS{?country p:P35 ?st}, "head of state", "head of government") AS ?posLabel)
  SERVICE wikibase:label { bd:serviceParam wikibase:language "en". } }"""


def wikidata_leaders() -> list[Entity]:
    """Heads of state and government from Wikidata; skipped unless PMPOL_WIKIDATA_UA is set.

    Wikidata requires a descriptive user agent with contact details and blocks some cloud IPs.
    """
    ua = os.environ.get("PMPOL_WIKIDATA_UA")
    if not ua:
        return []
    r = httpx.get(WIKIDATA_URL, params={"query": _WD_LEADERS, "format": "json"},
                  headers={"User-Agent": ua}, timeout=90)
    r.raise_for_status()
    out = []
    for b in r.json()["results"]["bindings"]:
        qid = b["person"]["value"].rsplit("/", 1)[-1]
        name = b["personLabel"]["value"]
        out.append(Entity(id=qid, kind="person", name=name, aliases=name_variants(name), positions=[
            f"{b['posLabel']['value']} of {b['countryLabel']['value']}"], prominent=True, wikidata=qid,
            sources={"wikidata"}))
    return out


_NOT_PERSON = re.compile(
    r"\d|%|\bparty\b|democrat|republican|independent|\bother\b|\bwins?\b|\byes\b|\bno\b|governor|senat|"
    r"attorney|secretary|general|\bstate\b|county|district|house|president|mayor|court|council|commission|"
    r"assembly|treasurer|auditor|comptroller|\bcity\b|\bnone\b|undecided|coalition|alliance|front|movement|"
    r"\bunion\b|liberal|conservative|labou?r|green|socialist|national|people|before|after|by\b", re.I)
_PLACES = {_norm(x) for x in [*US_STATES, *COUNTRIES]}


def market_candidates(universe) -> list[Entity]:
    """People named as outcomes of election winner/nomination markets, with their race and party."""
    out: dict[str, Entity] = {}
    for key, t in universe.tags.items():
        if not t.race_key or t.measure not in ("winner", "nomination", "margin", "vote_share"):
            continue
        for m in universe.events[key].markets:
            label = re.sub(r"\(.*?\)", "", m.outcome).strip()
            if not label or len(label.split()) < 2 or surname(label) is None:
                continue
            if _NOT_PERSON.search(label) or _norm(label) in _PLACES:
                continue
            variants = name_variants(label)
            if not variants:
                continue
            sfx = re.search(r"[\s,]+(jr|sr|ii|iii|iv)\.?\s*$", label, re.I)  # Donald Trump Jr. is not Donald Trump
            ident = (f"cand:{min(variants)}{' ' + sfx.group(1).lower() if sfx else ''}|{t.country}|"
                     f"{(t.jurisdiction or '').split('-')[0]}")
            e = out.setdefault(ident, Entity(
                id=ident, kind="person", name=label, country="us" if t.country == "United States" else None,
                state=(t.jurisdiction or "")[:2] if t.country == "United States" and t.jurisdiction
                and t.jurisdiction[:2] in US_STATES.values() else None,
                sources={"markets"}))
            e.aliases |= variants
            e.races.add(t.race_key)
            e.party = e.party or party_of(m)
    return list(out.values())
