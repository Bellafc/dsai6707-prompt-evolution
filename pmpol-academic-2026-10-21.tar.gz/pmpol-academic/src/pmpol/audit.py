"""Foundation health: the logic audit of 2026-10-04 as a repeatable check (`pmpol audit`, `pmpol status`).

What it measures, from the latest runs and the files they wrote:
  coverage     share of active markets the proposition ontology reads (the rest is residual, still monitored)
  grounding    how each derived relation is grounded: probability axioms only, a knowledge-base fact, an L1
               record (candidate lists), or a key assumption (by the weakest status it cites)
  provenance   the data contracts on proof files: every conclusion traces to L0-L4, every quote has a source
               and time; every relation comes from a declared rule whose grounds exist
  knowledge    knowledge-base errors (including conflicts not marked disputed), conflict groups, overdue checks
"""

from __future__ import annotations

import json
import sqlite3
from collections import Counter
from datetime import date

ORDER = ("axioms", "kb_fact", "kb_fact_proposed", "l1_record", "assumption_solid", "assumption_caveated",
         "assumption_unsupported")
ZH = {"axioms": "只靠機率公理", "kb_fact": "引用已審核的知識庫事實", "kb_fact_proposed": "引用提議中（未審核）的知識庫事實",
      "l1_record": "引用 L1 記錄（候選人名單、市場規則定義的集合）",
      "assumption_solid": "依賴穩固的假設", "assumption_caveated": "依賴有保留的假設",
      "assumption_unsupported": "依賴沒有根據的假設"}


def grounding(relations, book=None, assumptions: dict | None = None, kb=None) -> Counter:
    """Relations by their weakest ground (ORDER, strongest first)."""
    from pmpol.propositions.rules import load

    if assumptions is None:
        from pmpol.assumptions import load as load_assumptions

        assumptions = load_assumptions()
    book = book or load()
    if kb is None:
        from pmpol.kb import KnowledgeBase

        kb = KnowledgeBase.load()
    out: Counter = Counter()
    for r in relations:
        if not r.template.startswith("onto:"):
            continue
        weakest = "axioms"
        for g in book.grounds(r.template.rsplit(":", 1)[-1], r.grounds):
            kind, _, ref = g.partition(":")
            reviewed = kind == "kb" and ref in kb.facts and kb.facts[ref].status == "reviewed"
            level = (("kb_fact" if reviewed else "kb_fact_proposed") if kind == "kb" else "l1_record" if kind == "data" else
                     f"assumption_{assumptions[ref].status}" if kind == "assumption" and ref in assumptions else "axioms")
            if ORDER.index(level) > ORDER.index(weakest):
                weakest = level
        out[weakest] += 1
    return out


def _latest(conn: sqlite3.Connection, command: str) -> tuple[str, dict] | None:
    row = conn.execute("SELECT id, counts FROM runs WHERE command = ? ORDER BY id DESC LIMIT 1", (command,)).fetchone()
    return (row[0], json.loads(row[1] or "{}")) if row else None


def section(conn: sqlite3.Connection, today: date | None = None) -> list[str]:
    from pmpol.assumptions import load as load_assumptions
    from pmpol.kb import KnowledgeBase

    today = today or date.today()
    L = ["## 0. 地基健康（邏輯審計，`pmpol audit`）", ""]
    uni = _latest(conn, "universe")
    if uni is None:
        return L + ["- 還沒有全景執行的紀錄。", ""]
    run_id, c = uni
    read, unread = c.get("propositions"), c.get("unread")
    if read is not None and unread is not None:
        L.append(f"- 本體讀懂的有效市場：{read:,} / {read + unread:,}（{100 * read / max(read + unread, 1):.1f}%）")
    g = c.get("grounding") or {}
    if g:
        total = sum(g.values())
        L.append("- 推出的關係依據（取最弱的一個）：" + "；".join(
            f"{ZH[k]} {g.get(k, 0):,}（{100 * g.get(k, 0) / max(total, 1):.1f}%）" for k in ORDER if g.get(k)))
    checks = conn.execute("SELECT source, name, ok, observed FROM checks WHERE run_id = ? AND (source = 'rules' OR "
                          "source LIKE 'proofs:%')", (run_id,)).fetchall()
    bad = [f"{s}/{n}（{o}）" for s, n, ok, o in checks if not ok]
    L.append(f"- 資料契約（推理證明可追溯、報價有來源和時間、關係都來自宣告的規則）：{len(checks) - len(bad)} / "
             f"{len(checks)} 通過" + (f"；未通過：{'、'.join(bad)}" if bad else ""))
    kb = KnowledgeBase.load()
    L.append(f"- 知識庫：{len(kb.facts)} 筆事實，錯誤 {len(kb.errors)} 個，並列的衝突 {len(kb.conflicts())} 組"
             + (f"（{kb.errors[0][:80]}）" if kb.errors else ""))
    try:  # human review under the two-person rule (pmpol.review)
        from pmpol import review

        st = review.state(kb, review.load_reviews(), review.proposers(), review.citations())
        rc = st.counts()
        top = [it.fact.id for it in st.queue() if st.bucket(it) == "proposed"][:3]
        L.append(f"- 人工審核（兩人規則，`pmpol review`）：有審核紀錄的 {rc.get('reviewed', 0)}、舊制已審核但沒有紀錄的 "
                 f"{rc.get('legacy', 0)}、提議中 {rc.get('proposed', 0)}、審核後內容又改的 {rc.get('stale', 0)}、"
                 f"不合規的審核紀錄 {sum(e.startswith('review of') for e in st.errors)}"
                 + (f"；最該先審的：{'、'.join(top)}" if top else ""))
        from pmpol import agent_review

        ac = agent_review.counts(agent_review.summarize(kb, agent_review.load()))
        if sum(ac.values()) > ac.get("none", 0):
            L.append(f"- 多 Agent 預審（不算審核，`pmpol review agents`）：全數通過等人簽核 {ac.get('ready', 0)}、"
                     f"有異議 {ac.get('objection', 0)}、部分通過或不確定 {ac.get('partial', 0)}、未預審 {ac.get('none', 0)}")
    except (OSError, ValueError, KeyError):
        pass
    from pmpol.signposts import latest

    sp = latest(conn)
    if sp:
        trig = [i for i, _, state, _, _ in sp if state == "triggered"]
        L.append(f"- 承重假設的路標（`pmpol signposts`）：{len(sp)} 個，觸發 {len(trig)} 個"
                 + (f"（{'、'.join(trig)}）" if trig else "") + f"，沒有讀數 {sum(r[2] == 'no_data' for r in sp)} 個")
    reg = load_assumptions()
    weak = sorted(a.id for a in reg.values() if a.status == "unsupported")
    overdue = sorted(a.id for a in reg.values() if a.overdue(today))
    L.append(f"- 關鍵假設 {len(reg)} 個；沒有根據的 {len(weak)} 個（{'、'.join(weak) or '無'}）；過了檢查日期的 "
             f"{len(overdue)} 個")
    try:  # analytic confidence of the published proofs (pmpol.confidence), apart from likelihood
        from pathlib import Path

        rows = json.loads(Path("data/proofs.json").read_text(encoding="utf-8")).get("signals", [])
        conf = Counter((r.get("kind") == "consensus", r.get("proof", {}).get("analytic_confidence")) for r in rows)
        for is_cons, name in ((False, "結構違反"), (True, "跨平台共識")):
            n = {lv: conf.get((is_cons, lv), 0) for lv in ("high", "moderate", "low")}
            if sum(n.values()):
                L.append(f"- {name}的分析信心：高 {n['high']:,}、中 {n['moderate']:,}、低 {n['low']:,}")
    except (OSError, ValueError):
        pass
    from pmpol.track.lifecycle import lifecycle

    lc = lifecycle(conn, "relations")
    if lc.snapshots:
        L.append(f"- 結構違反的生命週期（{len(lc.snapshots)} 個快照）：開著 {lc.open:,}"
                 + (f"（中位數已存在 {lc.median_open_hours:.1f} 小時）" if lc.median_open_hours is not None else "")
                 + f"、已關閉 {lc.closed:,}"
                 + (f"（中位數存在 {lc.median_closed_hours:.1f} 小時）" if lc.median_closed_hours is not None else "")
                 + f"、關了又出現 {lc.reopened:,}")
    cand = _latest(conn, "candidates")
    if cand:
        cc = cand[1]
        L.append(f"- L1 候選人名單：{cc.get('races_listed', 0)} / {cc.get('races_wanted', 0)} 場選舉有名單"
                 + ("（這台主機抓不到時，「候選人 ⇔ 政黨」仍依賴假設）" if not cc.get("races_listed") else ""))
    L.append("")
    return L
