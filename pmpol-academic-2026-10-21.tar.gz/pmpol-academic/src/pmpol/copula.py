"""One-factor Gaussian (or Student t) copula for ordered categorical outcomes.

Each race i has a latent score X_i = sqrt(rho) * Z + sqrt(1 - rho) * e_i, with Z the
shared national swing and e_i race-specific noise, both standard normal. Outcomes are
ordered on one axis (e.g. D < I < R) and race i lands in category k when X_i falls
between the thresholds implied by its market probabilities. Marginals therefore match
the market exactly for any rho; rho only controls how much the races move together.

This is the same construction as the Vasicek / CDO base-correlation model: fitting rho
to seat-count markets gives a market-implied correlation.

Student t (2026-10-06): X_i = (sqrt(rho) * Z + sqrt(1 - rho) * e_i) / S with S = sqrt(V / nu), V chi-square with nu
degrees of freedom and shared by every race. Each X_i is t-distributed, so marginals still match the market (the
thresholds come from the t quantiles), but a small S scales every race's draw up at once: joint extremes (one party
sweeping the close races) are more likely than under the Gaussian copula with the same rho. That is tail
dependence; the Gaussian copula has none, which is the usual explanation of a correlation skew (sweep markets
implying a higher rho than control markets). Given (Z, S) the races are independent, so the seat count is still a
convolution, integrated over both factors.
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from scipy.special import gammaln, roots_genlaguerre
from scipy.stats import norm
from scipy.stats import t as student_t

_EPS = 1e-12


def gauss_hermite_normal(n: int = 64) -> tuple[np.ndarray, np.ndarray]:
    """Nodes and weights integrating against the standard normal density."""
    nodes, weights = hermegauss(n)
    return nodes, weights / weights.sum()


def student_scale_nodes(nu: float, n: int = 12) -> tuple[np.ndarray, np.ndarray]:
    """Nodes s = sqrt(V / nu) and weights for V ~ chi-square(nu): generalized Gauss-Laguerre in u = V / 2."""
    u, w = roots_genlaguerre(n, nu / 2 - 1)
    w = w / np.exp(gammaln(nu / 2))
    return np.sqrt(2 * u / nu), w / w.sum()


def conditional_probs(probs: Sequence[float], rho: float, z: float, s: float = 1.0,
                      nu: float | None = None) -> np.ndarray:
    """Category probabilities of one race given the common factor Z = z (and, for the t copula, the common scale
    S = s; `nu` its degrees of freedom).

    `probs` are ordered category probabilities summing to 1.
    """
    p = np.clip(np.asarray(probs, dtype=float), 0.0, None)
    p = p / p.sum()
    if rho <= 0 and nu is None:
        return p
    cum = np.clip(np.cumsum(p)[:-1], _EPS, 1 - _EPS)
    thresholds = student_t.ppf(cum, nu) if nu is not None else norm.ppf(cum)
    rho = min(max(rho, 0.0), 1 - 1e-9)
    cond_cum = norm.cdf((thresholds * s - np.sqrt(rho) * z) / np.sqrt(1 - rho))
    edges = np.concatenate([[0.0], cond_cum, [1.0]])
    return np.diff(edges)


def conditional_table(probs: np.ndarray, rho: float, z: np.ndarray, s: np.ndarray | None = None,
                      nu: float | None = None) -> np.ndarray:
    """conditional_probs for many races and nodes at once: probs [race, category] -> [node, race, category].
    The thresholds depend on the race only, so the quantile function runs once per race."""
    p = np.clip(np.asarray(probs, dtype=float), 0.0, None)
    p = p / p.sum(axis=1, keepdims=True)
    z = np.asarray(z, dtype=float)
    s = np.ones_like(z) if s is None else np.asarray(s, dtype=float)
    if rho <= 0 and nu is None:
        return np.broadcast_to(p, (len(z), *p.shape)).copy()
    cum = np.clip(np.cumsum(p, axis=1)[:, :-1], _EPS, 1 - _EPS)
    thresholds = student_t.ppf(cum, nu) if nu is not None else norm.ppf(cum)
    rho = min(max(rho, 0.0), 1 - 1e-9)
    cond = norm.cdf((thresholds[None] * s[:, None, None] - np.sqrt(rho) * z[:, None, None]) / np.sqrt(1 - rho))
    zeros, ones = np.zeros((*cond.shape[:2], 1)), np.ones((*cond.shape[:2], 1))
    return np.diff(np.concatenate([zeros, cond, ones], axis=2), axis=2)
