"""SQLite persistence: market metadata, quote history and signals, for later backtests."""

from __future__ import annotations

import hashlib
import json
import sqlite3
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path

from pmpol.models import Event, Relation, Signal

DEFAULT_DB = Path("data/pmpol.sqlite")

SCHEMA = """
CREATE TABLE IF NOT EXISTS markets (
    venue TEXT, market_id TEXT, event_id TEXT, event_title TEXT, category TEXT,
    question TEXT, outcome TEXT, rules TEXT, close_time TEXT, updated_at TEXT,
    PRIMARY KEY (venue, market_id)
);
-- Quotes are immutable observations keyed by when the venue showed them (`ts` = snapshot time, the
-- valid time), so replaying a snapshot adds nothing. `recorded_at` and `run_id` say when we stored them.
CREATE TABLE IF NOT EXISTS quotes (
    ts TEXT, venue TEXT, market_id TEXT, bid REAL, ask REAL, last REAL,
    bid_size REAL, ask_size REAL, volume REAL
);
-- Market terms, one row per distinct version of the rules text (a venue can edit rules mid-life).
CREATE TABLE IF NOT EXISTS market_versions (
    venue TEXT, market_id TEXT, rules_sha TEXT, close_time TEXT, rules TEXT, first_seen TEXT, last_seen TEXT,
    PRIMARY KEY (venue, market_id, rules_sha)
);
CREATE INDEX IF NOT EXISTS quotes_market ON quotes (venue, market_id, ts);
CREATE TABLE IF NOT EXISTS event_tags (
    venue TEXT, event_id TEXT, topic TEXT, office TEXT, measure TEXT, jurisdiction TEXT, country TEXT,
    year INTEGER, stage TEXT, variant TEXT, race_key TEXT, cluster TEXT, updated_at TEXT,
    PRIMARY KEY (venue, event_id)
);
CREATE TABLE IF NOT EXISTS relations (
    key TEXT PRIMARY KEY, kind TEXT, template TEXT, grp TEXT, confidence TEXT, lhs TEXT, rhs TEXT,
    note TEXT, first_seen TEXT, last_seen TEXT
);
CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY, name TEXT, party TEXT, country TEXT, state TEXT, district TEXT, positions TEXT,
    sources TEXT, wikidata TEXT, prominent INTEGER, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS entity_mentions (
    venue TEXT, event_id TEXT, entity_id TEXT, method TEXT, location TEXT, updated_at TEXT,
    PRIMARY KEY (venue, event_id, entity_id)
);
CREATE TABLE IF NOT EXISTS signals (
    ts TEXT, module TEXT, kind TEXT, subject TEXT, edge REAL, payload TEXT
);
-- Evidence (pmpol.evidence): outside information about a proposition, with publication and receipt times kept
-- apart; one row per (claim, url, published_at).
CREATE TABLE IF NOT EXISTS evidence (
    claim TEXT, text TEXT, source TEXT, url TEXT, published_at TEXT, received_at TEXT, occurred_at TEXT,
    reliability TEXT, credibility TEXT, stance TEXT, via TEXT, run_id TEXT,
    UNIQUE (claim, url, published_at)
);
-- Macro observations, bitemporal: `period` is when the value is true of the world, `recorded_at`
-- when we saw it. A row is only added when a value is new or revised, so revisions are kept.
CREATE TABLE IF NOT EXISTS macro_obs (
    series TEXT, source TEXT, period TEXT, value REAL, layer TEXT, recorded_at TEXT, url TEXT,
    PRIMARY KEY (series, source, period, recorded_at)
);
"""


MIGRATIONS = (
    ("quotes", "recorded_at", "TEXT"), ("quotes", "run_id", "TEXT"),
    ("signals", "recorded_at", "TEXT"), ("signals", "run_id", "TEXT"), ("signals", "sig_id", "TEXT"),
)


def connect(path: Path = DEFAULT_DB) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.executescript(SCHEMA)
    for table, col, typ in MIGRATIONS:
        if col not in {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
    try:
        _unique_indexes(conn)
    except sqlite3.IntegrityError:  # a database written before quotes were keyed by observation time
        dedupe_replays(conn)
        _unique_indexes(conn)
    return conn


def _unique_indexes(conn: sqlite3.Connection) -> None:
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS quotes_key ON quotes (venue, market_id, ts)")
    # One race can carry several signals of one kind (different legs): the signal's own id is part of the key.
    conn.execute("DROP INDEX IF EXISTS signals_key")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS signals_key2 ON signals (ts, module, kind, subject, sig_id)")


def dedupe_replays(conn: sqlite3.Connection) -> dict[str, int]:
    """Remove rows written by replaying a snapshot (before quotes were keyed by observation time, a replay
    stored the same quotes again under the replay time). A batch is a replay when its content is exactly
    the same as the previous batch's. Also removes exact duplicate keys within a batch."""
    removed = {"quotes": 0, "signals": 0}
    prev = None
    for (ts,) in conn.execute("SELECT DISTINCT ts FROM quotes ORDER BY ts").fetchall():
        rows = conn.execute("SELECT venue, market_id, bid, ask, last FROM quotes WHERE ts = ? "
                            "ORDER BY venue, market_id", (ts,)).fetchall()
        digest = hash(tuple(rows))
        if digest == prev:
            removed["quotes"] += conn.execute("DELETE FROM quotes WHERE ts = ?", (ts,)).rowcount
        prev = digest
    removed["quotes"] += conn.execute("""DELETE FROM quotes WHERE rowid NOT IN (
        SELECT MIN(rowid) FROM quotes GROUP BY venue, market_id, ts)""").rowcount
    # Signals: one run writes over a few seconds, so batch by minute.
    prev = None
    for (minute,) in conn.execute("SELECT DISTINCT substr(ts, 1, 16) FROM signals ORDER BY 1").fetchall():
        rows = conn.execute("SELECT module, kind, subject, edge FROM signals WHERE substr(ts, 1, 16) = ? "
                            "ORDER BY module, kind, subject, edge", (minute,)).fetchall()
        digest = hash(tuple(rows))
        if digest == prev:
            removed["signals"] += conn.execute("DELETE FROM signals WHERE substr(ts, 1, 16) = ?", (minute,)).rowcount
        prev = digest
    removed["signals"] += conn.execute("""DELETE FROM signals WHERE rowid NOT IN (
        SELECT MIN(rowid) FROM signals GROUP BY ts, module, kind, subject, sig_id)""").rowcount
    conn.commit()
    return removed


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def save_events(conn: sqlite3.Connection, events: Iterable[Event], observed_at: str = "", run_id: str = "") -> int:
    """Store market terms and quotes. `observed_at` is when the venue showed these quotes (the snapshot
    time); replaying the same snapshot adds no rows. Returns the number of new quotes."""
    now = _now()
    ts = observed_at or now
    n = 0
    for e in events:
        for m in e.markets:
            conn.execute(
                "INSERT OR REPLACE INTO markets VALUES (?,?,?,?,?,?,?,?,?,?)",
                (m.venue, m.market_id, e.event_id, e.title, e.category, m.question, m.outcome, m.rules,
                 m.close_time, ts),
            )
            sha = hashlib.sha256(f"{m.rules}\x00{m.close_time}".encode()).hexdigest()[:16]
            conn.execute("INSERT INTO market_versions VALUES (?,?,?,?,?,?,?) ON CONFLICT DO UPDATE SET "
                         "first_seen = MIN(first_seen, excluded.first_seen), "
                         "last_seen = MAX(last_seen, excluded.last_seen)",
                         (m.venue, m.market_id, sha, m.close_time, m.rules, ts, ts))
            if m.active:
                n += conn.execute(
                    "INSERT OR IGNORE INTO quotes VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (ts, m.venue, m.market_id, m.bid, m.ask, m.last, m.bid_size, m.ask_size, m.volume, now, run_id),
                ).rowcount
    conn.commit()
    return n


def save_signals(conn: sqlite3.Connection, signals: Iterable[Signal], observed_at: str = "", run_id: str = "") -> int:
    """Signals are keyed by the quote time they were computed from, so a replay adds nothing."""
    now = _now()
    n = 0
    for s in signals:
        payload = json.dumps(s.payload, ensure_ascii=False, sort_keys=True)
        sig_id = str(s.payload.get("id") or hashlib.sha256(payload.encode()).hexdigest()[:16])
        n += conn.execute("INSERT OR IGNORE INTO signals (ts, module, kind, subject, edge, payload, recorded_at, run_id, "
                          "sig_id) VALUES (?,?,?,?,?,?,?,?,?)",
                          (observed_at or s.ts, s.module, s.kind, s.subject, s.edge, payload, now, run_id,
                           sig_id)).rowcount
    conn.commit()
    return n


def save_evidence(conn: sqlite3.Connection, items, run_id: str = "") -> int:
    """Evidence items (pmpol.evidence.Evidence); a replay adds nothing."""
    n = 0
    for e in items:
        n += conn.execute("INSERT OR IGNORE INTO evidence VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                          (e.claim, e.text, e.source, e.url, e.published_at, e.received_at, e.occurred_at,
                           e.reliability, e.credibility, e.stance, e.via, run_id)).rowcount
    conn.commit()
    return n


def save_tags(conn: sqlite3.Connection, rows: Iterable[tuple[Event, object, str | None]]) -> None:
    """rows: (event, Tags, cluster id)."""
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    conn.executemany(
        "INSERT OR REPLACE INTO event_tags VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [(e.venue, e.event_id, t.topic, t.office, t.measure, t.jurisdiction, t.country, t.year, t.stage,
          t.variant, t.race_key, cluster, ts) for e, t, cluster in rows],
    )
    conn.commit()


def save_relations(conn: sqlite3.Connection, relations: Iterable[Relation]) -> None:
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for r in relations:
        conn.execute(
            "INSERT INTO relations VALUES (?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET last_seen = excluded.last_seen",
            (r.key, r.kind, r.template, r.group, r.confidence, json.dumps(r.lhs), json.dumps(r.rhs), r.note, ts, ts),
        )
    conn.commit()


def save_entities(conn: sqlite3.Connection, eg) -> None:
    """Persist linked entities and their event mentions (an EntityGraph from pmpol.entities)."""
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    linked = {m.entity for ms in eg.mentions.values() for m in ms}
    conn.executemany(
        "INSERT OR REPLACE INTO entities VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        [(e.id, e.name, e.party, e.country, e.state, e.district, json.dumps(e.positions, ensure_ascii=False),
          json.dumps(sorted(e.sources)), e.wikidata, int(e.prominent), ts)
         for e in eg.index.entities.values() if e.id in linked],
    )
    rows = []
    for event_key, ms in eg.mentions.items():
        venue, event_id = event_key.split(":", 1)
        rows += [(venue, event_id, m.entity, m.method, m.where, ts) for m in ms]
    conn.executemany("INSERT OR REPLACE INTO entity_mentions VALUES (?,?,?,?,?,?)", rows)
    conn.commit()


def save_macro(conn: sqlite3.Connection, fetched) -> tuple[int, int]:
    """Store macro observations from pmpol.macro.sources.Fetched; returns (new, revised) row counts."""
    new = revised = 0
    for f in fetched:
        for o in f.observations:
            row = conn.execute(
                "SELECT value FROM macro_obs WHERE series=? AND source=? AND period=? ORDER BY recorded_at DESC LIMIT 1",
                (o.series, o.source, o.period.isoformat())).fetchone()
            if row is not None and abs(row[0] - o.value) < 1e-9:
                continue
            conn.execute("INSERT OR REPLACE INTO macro_obs VALUES (?,?,?,?,?,?,?)",
                         (o.series, o.source, o.period.isoformat(), o.value, o.layer, f.recorded_at, f.url))
            if row is None:
                new += 1
            else:
                revised += 1
    conn.commit()
    return new, revised


def load_macro(conn: sqlite3.Connection, known_at: str | None = None) -> list[tuple]:
    """Latest value of each (series, source, period) as recorded on or before `known_at` (ISO time).
    Rows: (series, source, period, value, layer, recorded_at, url)."""
    q = """SELECT m.* FROM macro_obs m JOIN (
             SELECT series, source, period, MAX(recorded_at) AS r FROM macro_obs
             WHERE (? IS NULL OR recorded_at <= ?) GROUP BY series, source, period
           ) k ON m.series=k.series AND m.source=k.source AND m.period=k.period AND m.recorded_at=k.r
           ORDER BY m.series, m.source, m.period"""
    return conn.execute(q, (known_at, known_at)).fetchall()


def fill_failed_macro(conn: sqlite3.Connection, fetched) -> int:
    """For series whose fetch failed, fall back to the last stored values (marked stale in `error`).
    Returns how many series were filled."""
    from datetime import date

    from pmpol.macro.sources import Observation

    n = 0
    for f in fetched:
        if f.observations:
            continue
        rows = conn.execute(
            """SELECT m.period, m.value, m.layer, m.recorded_at FROM macro_obs m JOIN (
                 SELECT period, MAX(recorded_at) r FROM macro_obs WHERE series=? AND source=? GROUP BY period
               ) k ON m.period=k.period AND m.recorded_at=k.r WHERE m.series=? AND m.source=? ORDER BY m.period""",
            (f.spec.id, f.spec.ref, f.spec.id, f.spec.ref)).fetchall()
        if not rows:
            continue
        f.observations = [Observation(f.spec.id, f.spec.ref, date.fromisoformat(p), v, lay) for p, v, lay, _ in rows]
        f.stale_since = max(r[3] for r in rows)
        f.error = f"fetch failed ({f.error[:80]}); using stored data recorded {f.stale_since[:16]}"
        n += 1
    return n
