"""One scheduled cycle, safe to call from cron, a systemd timer or launchd.

  - a lock (data/.cycle.lock): a run that starts while the previous one is still going exits at once;
  - a time limit: the cycle is stopped after --timeout-min minutes and the run is recorded as timed out;
  - a log per run under data/logs/ (kept 30 days) and data/logs/last_run.json with the outcome;
  - optionally `git pull --ff-only` first (code updates), and afterwards a commit of reports/ only (data/ is
    never committed: the venues' terms forbid redistributing compiled quotes), pushed if asked;
  - optionally a notification to a webhook (Slack, Discord or anything that takes JSON) when a run fails.

The scheduler itself is the machine's: see deploy/ for crontab, systemd and launchd examples. The system keeps
state in data/ (snapshots, the SQLite store), which the track record and price-move checks need, so it must run
where data/ persists.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

LOCK = Path("data/.cycle.lock")
LOGS = Path("data/logs")
KEEP_DAYS = 30


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Lock:
    """An exclusive, non-blocking lock on a file; released when the process ends, even on a crash."""

    def __init__(self, path: Path = LOCK):
        self.path = path
        self.fh = None

    def acquire(self) -> bool:
        import fcntl

        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fh = open(self.path, "w")
        try:
            fcntl.flock(self.fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.fh.close()
            self.fh = None
            return False
        self.fh.write(str(os.getpid()))
        self.fh.flush()
        return True

    def release(self) -> None:
        if self.fh:
            import fcntl

            fcntl.flock(self.fh, fcntl.LOCK_UN)
            self.fh.close()
            self.fh = None


def failed_steps(log: str) -> list[str]:
    return re.findall(r"^\[cycle\] (\w+): FAILED", log, re.M)


def _git(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], capture_output=True, text=True)


def commit_reports(stamp: str, push: bool) -> str:
    """Commit reports/ if it changed; returns what happened."""
    _git("add", "reports")
    if _git("diff", "--cached", "--quiet").returncode == 0:
        return "no report changes"
    r = _git("commit", "-m", f"Scheduled cycle {stamp}: reports")
    if r.returncode != 0:
        return f"commit failed: {r.stderr.strip()[:200]}"
    if push:
        for attempt in range(4):  # network hiccups: back off 2, 4, 8 s
            p = _git("push")
            if p.returncode == 0:
                return "committed and pushed"
            time.sleep(2 ** (attempt + 1))
        return f"committed; push failed: {p.stderr.strip()[:200]}"
    return "committed"


def notify(url: str, text: str, post=None) -> None:
    """POST {"text": ..., "content": ...} (Slack and Discord field names); a failure to notify is only logged."""
    import httpx

    post = post or httpx.post
    try:
        post(url, json={"text": text, "content": text}, timeout=20)
    except Exception as e:  # never let the notifier break the run record
        print(f"notification failed: {e}", file=sys.stderr)


def prune_logs(logs: Path = LOGS, keep_days: int = KEEP_DAYS, now: datetime | None = None) -> int:
    cutoff = ((now or _now()) - timedelta(days=keep_days)).timestamp()
    n = 0
    for f in logs.glob("cycle_*.log"):
        if f.stat().st_mtime < cutoff:
            f.unlink()
            n += 1
    return n


def run(timeout_min: float = 150, pull: bool = False, commit: bool = False, push: bool = False,
        notify_url: str | None = None, cycle_args: list[str] | None = None, runner=None) -> int:
    """One scheduled cycle. Returns the cycle's exit code (0 when skipped because another run holds the lock)."""
    lock = Lock()
    if not lock.acquire():
        print("another scheduled cycle is still running; skipped", file=sys.stderr)
        return 0
    started = _now()
    stamp = f"{started:%Y-%m-%dT%H:%MZ}"
    LOGS.mkdir(parents=True, exist_ok=True)
    log_path = LOGS / f"cycle_{started:%Y%m%dT%H%MZ}.log"
    record = {"started": started.isoformat(timespec="seconds"), "log": str(log_path), "pulled": None}
    try:
        if pull:
            p = _git("pull", "--ff-only")
            record["pulled"] = p.returncode == 0
            if p.returncode != 0:
                print(f"git pull failed, running the checked-out code: {p.stderr.strip()[:200]}", file=sys.stderr)
        argv = [sys.executable, "-c", "from pmpol.cli import main; raise SystemExit(main())", "cycle",
                *(cycle_args or [])]
        runner = runner or subprocess.run
        try:
            done = runner(argv, capture_output=True, text=True, timeout=timeout_min * 60)
            code, out, timed_out = done.returncode, (done.stdout or "") + (done.stderr or ""), False
        except subprocess.TimeoutExpired as e:
            out = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
            code, timed_out = 124, True
        log_path.write_text(out, encoding="utf-8")
        record.update({"finished": _now().isoformat(timespec="seconds"), "exit_code": code, "timed_out": timed_out,
                       "failed_steps": failed_steps(out)})
        if commit:
            record["commit"] = commit_reports(stamp, push)
        prune_logs()
        (LOGS / "last_run.json").write_text(json.dumps(record, ensure_ascii=False, indent=1), encoding="utf-8")
        if notify_url and code != 0:
            why = "逾時" if timed_out else "失敗的步驟：" + ("、".join(record["failed_steps"]) or f"結束代碼 {code}")
            notify(notify_url, f"pmpol 排程循環 {stamp} 沒有完全成功（{why}）。記錄：{log_path}")
        print(f"scheduled cycle {stamp}: exit {code}{' (timed out)' if timed_out else ''}; log {log_path}",
              file=sys.stderr)
        return code
    finally:
        lock.release()


def last_run(logs: Path = LOGS) -> dict | None:
    f = logs / "last_run.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None
