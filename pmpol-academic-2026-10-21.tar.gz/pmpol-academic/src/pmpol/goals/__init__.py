"""Actor–goal layer: shared ends behind conflicting means.

Actors can fight over means (the White House pressuring the Fed on rates) while serving the same end
(the dollar's international role). The layer links markets that look unrelated but load on the same
end, so the system can (1) group them as one driver, (2) separate rhetoric about means from actions
that would cross the shared red line, and (3) watch them together in the reverse engine.

Where things live (team consensus on layers):
  L3  kb/L3/actor_goals.yaml  goal definitions, actor stances with verbatim quotes, and counter-views
                              (all contested; competing views side by side)
  L1  config/macro_series.toml  observable indicators of each goal (via `pmpol macro`)
  L4  prediction markets matched by config/goals.toml rules, each with the direction a YES would push
  L5  one Proof per goal: what the markets and indicators say now; never a hard constraint
"""

from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

from pmpol.assumptions import cite
from pmpol.kb import KnowledgeBase
from pmpol.models import Event
from pmpol.proof import Proof
from pmpol.venues import info, source_url

CONFIG = Path(__file__).resolve().parents[3] / "config" / "goals.toml"
SIGN_ZH = {1: "強化", -1: "削弱", 0: "方向有爭議"}


@dataclass
class MarketRule:
    pattern: str
    sign: int  # +1: a YES strengthens the goal; -1: weakens it; 0: contested
    note: str = ""
    exclude: str = ""

    def matches(self, text: str) -> bool:
        return bool(re.search(self.pattern, text, re.I)) and not (self.exclude and re.search(self.exclude, text, re.I))


@dataclass
class Signpost:
    """Indicators & warnings: an observable, a threshold and what crossing it would mean (an L3 judgement)."""
    label: str
    source: str  # "series:<macro id>" or "market:<regex>"
    op: str  # "<" or ">"
    threshold: float
    meaning: str = ""
    outcome: str = ""  # for markets: regex the outcome label must match (e.g. "Above 57")

    def crossed(self, value: float) -> bool:
        return value < self.threshold if self.op == "<" else value > self.threshold


@dataclass
class Goal:
    id: str  # matches kb subject "goal:<id>"
    label: str
    indicators: list[str] = field(default_factory=list)  # macro series ids
    markets: list[MarketRule] = field(default_factory=list)
    signposts: list[Signpost] = field(default_factory=list)
    news: str = ""  # news query when the goal's markets move together (pmpol.movers)


def load_goals(path: Path = CONFIG) -> list[Goal]:
    with open(path, "rb") as f:
        raw = tomllib.load(f)
    return [Goal(g["id"], g["label"], g.get("indicators", []), [MarketRule(**m) for m in g.get("market", [])],
                 [Signpost(**s) for s in g.get("signpost", [])], g.get("news", ""))
            for g in raw["goal"]]


def match_markets(goal: Goal, events: list[Event]) -> list[tuple[Event, MarketRule]]:
    out = []
    for e in events:
        text = e.title + " " + next((m.question for m in e.markets), "")
        for rule in goal.markets:
            if rule.matches(text):
                out.append((e, rule))
                break
    return out


def _fmt_value(v) -> str:
    if isinstance(v, dict):
        return "；".join(f"{k}: {x}" for k, x in v.items())
    return str(v)


def _signposts(p: Proof, goal: Goal, events: list[Event], macro, observed_at: str) -> tuple[int, int] | None:
    """Evaluate each signpost against the latest L1 value or the highest-priced matching market (L4)."""
    if not goal.signposts:
        return None
    checked = crossed = 0
    for i, sp in enumerate(goal.signposts):
        kind, _, target = sp.source.partition(":")
        value, ref, when, shown = None, "", "", ""
        if kind == "series" and macro is not None:
            spec, rows = macro.series(target)
            if rows:
                value, ref, when = rows[-1][1], spec.ref, f"{rows[-1][0]:%Y-%m}"
                shown = f"{value:,.2f}"
        elif kind == "market":
            best = None
            for e in events:
                if re.search(target, e.title + " " + next((m.question for m in e.markets), ""), re.I):
                    live = [m for m in e.markets if m.active and m.mid is not None
                            and (not sp.outcome or re.search(sp.outcome, m.outcome or "", re.I))]
                    deadlines = live and all(re.match(r"(before|by)\b", (m.outcome or "").strip(), re.I) for m in live)
                    m = (min(live, key=lambda m: (m.close_time or "9999", -(m.mid or 0))) if deadlines
                         else max(live, key=lambda m: m.mid or 0)) if live else None
                    if m is not None and (best is None or m.mid > best[0].mid):
                        best = (m, e)
            if best:
                m, e = best
                value, ref, when = m.mid, source_url(m), observed_at
                shown = f"{100 * value:.0f}%（{info(m.venue).code}｜{e.title}）"
        sid = f"sp{i}"
        p.add("L3", f"預警指標：{sp.label}（{sp.meaning}）", f"config/goals.toml#{goal.id}", kind="rule", id=f"{sid}:def")
        if value is None:
            p.add("L5", f"預警指標「{sp.label}」：沒有資料，無法檢查", kind="logic", id=sid, inputs=(f"{sid}:def",))
            continue
        checked += 1
        hit = sp.crossed(value)
        crossed += hit
        layer = "L1" if kind == "series" else "L4"
        p.add(layer, f"目前：{shown}", ref, when, kind="data", id=f"{sid}:val")
        p.add("L5", f"{'⚠️ 已觸發' if hit else '未觸發'}：{sp.label}", kind="logic", id=sid,
              inputs=(f"{sid}:def", f"{sid}:val"))
    p.result.update({"signposts": len(goal.signposts), "signposts_checked": checked, "signposts_crossed": crossed})
    return crossed, checked


def goal_proof(goal: Goal, kb: KnowledgeBase, events: list[Event] | None = None, macro=None,
               observed_at: str = "") -> Proof:
    """Everything the system knows about one shared goal, as a proof graph:
    definition and stances (L3) -> indicators (L1) and markets (L4) -> what they say now (L5)."""
    p = Proof(f"共同目的｜{goal.label}", "", result={"goal": goal.id})
    facts = [f for f in kb.facts.values() if f.subject == f"goal:{goal.id}" or f.id.startswith(f"goal.{goal.id}.")]
    defs = [f for f in facts if f.predicate == "definition"]
    for f in defs:
        p.add("L3", f"目的：{_fmt_value(f.value)}", f.id, kind="rule", id="def")
    stance_ids, counter_ids = [], []
    for f in sorted(facts, key=lambda f: f.id):
        if f.predicate.startswith("stance"):
            sid = f"kb:{f.id}"
            quote = f"「{f.source.quote}」" if f.source.quote else ""
            status = {"reviewed": "", "proposed": "（提議中）", "disputed": "（有爭議）"}[f.status]
            p.add("L3", f"{f.subject.replace('actor:', '')}：{_fmt_value(f.value)} {quote}{status}", f.id,
                  str(f.valid_from or f.recorded_at), kind="rule", id=sid)
            stance_ids.append(sid)
        elif f.predicate == "counterview":
            cid = f"kb:{f.id}"
            p.add("L3", f"反方觀點：{_fmt_value(f.value)}（{f.source.title}）", f.id, str(f.recorded_at), kind="rule",
                  id=cid)
            counter_ids.append(cid)
    if stance_ids:
        p.add("L5", f"{len(stance_ids)} 個行為者的立場：手段上的衝突和目的上的一致並列；"
                    f"另有 {len(counter_ids)} 個反方觀點質疑這個目的（目的不成立、有條件，或手段正在侵蝕它），並列，不選邊", kind="logic", id="actors",
              inputs=tuple((["def"] if defs else []) + stance_ids + counter_ids))

    ind_ids = []
    for sid in goal.indicators:
        if macro is None:
            break
        spec, rows = macro.series(sid)
        if len(rows) < 2:
            continue
        (_, v0), (p1, v1) = rows[max(0, len(rows) - 13)], rows[-1]
        iid = f"ind:{sid}"
        p.add("L1", f"{sid}：{v1:,.2f} {spec.unit}（{p1:%Y-%m}；一年前 {v0:,.2f}，{'上升' if v1 > v0 else '下降'}）",
              spec.ref, f"{p1:%Y-%m}", kind="data", id=iid)
        ind_ids.append(iid)

    weaken, strengthen, contested = [], [], []
    mkt_ids = []
    for e, rule in match_markets(goal, events or []):
        live = [m for m in e.markets if m.active and m.mid is not None]
        if not live:
            continue
        # Deadline ladders ("before 2027", "before 2031"): the nearest deadline, not the most likely one —
        # a far deadline can be near-certain for ordinary reasons (a term simply ends).
        deadlines = all(re.match(r"(before|by)\b", (m.outcome or "").strip(), re.I) for m in live)
        top = (min(live, key=lambda m: (m.close_time or "9999", -(m.mid or 0))) if deadlines
               else max(live, key=lambda m: m.mid or 0))
        mid = f"mkt:{e.key}"
        p.add("L4", f"{info(e.venue).code}｜{e.title}：{top.outcome or 'Yes'} {100 * top.mid:.0f}%"
                    f"（YES {SIGN_ZH[rule.sign]}這個目的{('；' + rule.note) if rule.note else ''}）",
              source_url(top), observed_at, kind="data", id=mid)
        mkt_ids.append(mid)
        (weaken if rule.sign < 0 else strengthen if rule.sign > 0 else contested).append((top.mid, e, top))
    weaken.sort(key=lambda t: -t[0])
    summary = [f"{len(mkt_ids)} 個相關市場（削弱類 {len(weaken)}、強化類 {len(strengthen)}、方向有爭議 {len(contested)}）"]
    if weaken:
        summary.append("削弱類機率最高：" + "、".join(f"{e.title}（{100 * pr:.0f}%）" for pr, e, _ in weaken[:3]))
    if ind_ids or mkt_ids:
        p.add("L5", "；".join(summary), kind="logic", id="state", inputs=tuple(["actors"] if stance_ids else []) +
              tuple(ind_ids + mkt_ids))
    crossed = _signposts(p, goal, events or [], macro, observed_at)
    if crossed is not None:
        summary.append(f"預警指標 {crossed[0]} / {crossed[1]} 個觸發")
    p.conclusion = "；".join(summary)
    p.result.update({"markets": len(mkt_ids), "weaken": len(weaken), "strengthen": len(strengthen),
                     "contested": len(contested)})
    cite(p, "shared_goal_interpretation")
    p.caveats += ["「共同目的」是 L3 的詮釋，有爭議；這裡只用來分群和提供先驗，不當成硬約束，市場價格仍是主要依據。",
                  "市場對應靠關鍵字規則，YES 的方向由人工設定（config/goals.toml），請一併檢查。"]
    wd = kb.facts.get("markets.words_vs_deeds")
    deeds = (wd.value or {}).get("deeds_30d") if wd is not None and isinstance(wd.value, dict) else None
    if deeds:
        lo, hi = deeds["gap_ci95"]
        p.add("L2", f"已結算的「行動」題（簽署、加徵、開除、入侵、逮捕、制裁…）：截止前 30 天平均價格 "
                    f"{100 * deeds['mean_price']:.0f}%，實際發生 {100 * deeds['yes_share']:.0f}%"
                    f"（{deeds['markets']:,} 個市場、{deeds['events']:,} 個事件；差距 95% 區間 {100 * lo:+.0f} 到 "
                    f"{100 * hi:+.0f} 點）", wd.id, str(wd.recorded_at), kind="data", id="deeds")
        p.alt("手段上的衝突只是口頭，不會越過共同紅線", "supports" if hi < 0 else "unchecked",
              f"一般性的基準率（不是針對這些行為者）：行動題在截止前 30 天被高估，實際發生的比例是價格的 "
              f"{deeds['yes_share'] / deeds['mean_price']:.0%}" + ("，區間不含 0" if hi < 0 else "，區間含 0"))
    else:
        p.alt("手段上的衝突只是口頭，不會越過共同紅線", "unchecked",
              "要用已結算市場檢驗「口頭威脅」和「真的做了」的歷史發生率（`pmpol truth words-deeds --write-kb`）")
    p.alt("這個目的不成立、只是有條件的，或手段正在侵蝕它（反方觀點）", "supports" if counter_ids else "unchecked",
          f"知識庫有 {len(counter_ids)} 個反方觀點，並列呈現")
    if macro is not None and hasattr(macro, "mark_stale"):
        macro.mark_stale(p)
    return p


# --- co-movement: the goal's markets moving together (handed to the reverse engine, pmpol.movers) -----------------

COMOVE_MIN = 0.02  # a market counts as moving at 2 points or more
COMOVE_MARKETS = 3  # at least this many moving the same way


@dataclass
class CoMove:
    goal: Goal
    # (event in the later snapshot, its market, rule sign, mid before, mid after); signed move = sign * (after - before)
    moves: list[tuple] = field(default_factory=list)

    def signed(self) -> list[float]:
        return [s * (b - a) for _, _, s, a, b in self.moves]

    @property
    def weaken(self) -> int:
        return sum(x <= -COMOVE_MIN for x in self.signed())

    @property
    def strengthen(self) -> int:
        return sum(x >= COMOVE_MIN for x in self.signed())

    @property
    def direction(self) -> int:
        """-1 the markets moved together toward weakening the goal, +1 toward strengthening, 0 no common move."""
        w, s = self.weaken, self.strengthen
        if w >= COMOVE_MARKETS and s * 3 <= w:
            return -1
        if s >= COMOVE_MARKETS and w * 3 <= s:
            return 1
        return 0


def comovement(goal: Goal, events_a: list[Event], events_b: list[Event], max_spread: float = 0.10) -> CoMove:
    """Each matched event with a signed rule: its market that moved most between the snapshots (tight books both
    times), signed by what a YES means for the goal."""
    def tight(m):
        return m.active and m.bid is not None and m.ask is not None and m.ask - m.bid <= max_spread

    before = {m.key: m for e in events_a for m in e.markets if tight(m)}
    out = CoMove(goal)
    for e, rule in match_markets(goal, events_b):
        if rule.sign == 0:
            continue
        pairs = [(m, before[m.key]) for m in e.markets if tight(m) and m.key in before]
        if not pairs:
            continue
        m, a = max(pairs, key=lambda t: abs(t[0].mid - t[1].mid))
        out.moves.append((e, m, rule.sign, a.mid, m.mid))
    return out


def comovement_proof(cm: CoMove, news, ts_a: str, ts_b: str) -> Proof:
    """A lead for a person: the goal's markets moved together; what the news says over the same window."""
    word = {-1: "削弱", 1: "強化"}[cm.direction]
    movers = [(e, m, s, a, b) for e, m, s, a, b in cm.moves if s * (b - a) * cm.direction >= COMOVE_MIN]
    p = Proof(f"共同目的的市場一起動｜{cm.goal.label}",
              f"{len(movers)} 個市場同時往「{word}這個目的」的方向移動（{ts_a[:16]} → {ts_b[:16]}）；"
              + ("沒有查新聞" if news is None else "新聞查詢失敗" if news.count is None else
                 "新聞查不到" if not news.count else f"同期新聞 {news.count} 篇"),
              result={"goal": cm.goal.id, "direction": cm.direction, "markets": len(movers),
                      "weaken": cm.weaken, "strengthen": cm.strengthen,
                      "news": None if news is None else news.count})
    ids = []
    for i, (e, m, s, a, b) in enumerate(movers):
        p.add("L4", f"{info(e.venue).code}｜{e.title}：{m.outcome or 'Yes'} {100 * a:.1f}% → {100 * b:.1f}%"
                    f"（YES {SIGN_ZH[s]}這個目的）", source_url(m), ts_b, kind="data", id=f"m{i}")
        ids.append(f"m{i}")
    p.add("L3", "市場和目的的對應（YES 是強化還是削弱）是人工設定的判斷", f"config/goals.toml#{cm.goal.id}",
          kind="rule", id="rules")
    if news is not None and news.count is not None:
        first = (news.articles or [{}])[0].get("title", "")
        p.add("L4", f"新聞（「{news.query}」，{ts_a[:16]} → {ts_b[:16]}，{news.source}）：{news.count} 篇"
                    + (f"，例如「{first}」" if first else ""), news.url or news.source, ts_b, kind="data", id="news")
        ids.append("news")
    p.add("L5", f"{len(movers)} 個市場同向（{word}），反方向 {cm.strengthen if cm.direction < 0 else cm.weaken} 個",
          kind="logic", id="together", inputs=tuple(ids + ["rules"]))
    p.alt("同一個消息同時影響這些市場（新聞、官方聲明）", "supports" if news is not None and news.count else "unchecked",
          "看同期新聞；沒有新聞時，可能是其他語言的消息或還沒報導")
    p.alt("同一批交易者在相關市場一起調整部位（不是新資訊）", "unchecked", "要看成交量和錢包，這一層還沒有做")
    p.alt("市場和目的的對應錯了（YES 的方向設反）", "unchecked", "對應規則在 config/goals.toml，需要人工檢查")
    p.caveats.append("這是給人工追查的線索，不是結論；系統不點名任何錢包或個人。")
    return p

