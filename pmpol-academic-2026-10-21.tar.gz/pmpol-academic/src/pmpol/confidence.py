"""Analytic confidence, kept apart from likelihood (ICD 203: "properly expresses and explains uncertainties").

Likelihood says how probable something is ("非常可能"); confidence says how much the judgment can be relied on,
given the quality of what it rests on. It is read from the proof itself, so every kind of proof gets one:

  low       a key assumption without basis; a disputed knowledge-base fact; resolution rules that differ
            materially; legs matched only by label, title or text similarity
  moderate  a caveated assumption; a proposed (unreviewed) knowledge-base fact; resolution rules not fully
            verified or differing in detail; legs matched by a person's name or an event descriptor
  high      none of the above: probability axioms, reviewed facts, structural matches, equivalent rules

The level is the weakest of these (one weak link is enough), and every downgrade is stated as a reason.
"""

from __future__ import annotations

from functools import lru_cache

LEVELS = ("high", "moderate", "low")
ZH = {"high": "高", "moderate": "中", "low": "低"}
_MATCH = {"entity": "moderate", "name": "moderate", "descriptor": "moderate", "label": "low", "title": "low", "text": "low"}
_MATCH_ZH = {"entity": "人物的 Wikidata 身分", "name": "人名", "descriptor": "事件描述詞", "label": "標籤", "title": "標題", "text": "文字相似"}
_RULES = {"material": ("low", "結算條件有實質差異"), "minor": ("moderate", "結算條件有細節差異"),
          "unverified": ("moderate", "結算條件未完全驗證")}


@lru_cache(maxsize=1)
def _kb():
    from pmpol.kb import KnowledgeBase

    return KnowledgeBase.load()


@lru_cache(maxsize=1)
def _assumptions():
    from pmpol.assumptions import load

    return load()


def assess(proof) -> tuple[str, list[str]]:
    """(level, reasons) for a proof; reasons explain every downgrade, weakest first."""
    found: list[tuple[str, str]] = []
    reg = _assumptions()
    for aid in proof.result.get("assumptions", []) or []:
        a = reg.get(aid)
        if a is None or a.status == "solid":
            continue
        found.append(("low" if a.status == "unsupported" else "moderate",
                      f"依賴{'沒有根據' if a.status == 'unsupported' else '有保留'}的假設「{aid}」"))
    kb = _kb()
    for s in proof.steps:
        f = kb.facts.get(s.ref)
        if f is not None and f.status in ("proposed", "disputed"):
            found.append(("low" if f.status == "disputed" else "moderate",
                          f"引用{'有爭議' if f.status == 'disputed' else '提議中（未審核）'}的事實「{f.id}」"))
    rules = proof.result.get("rules")
    if rules in _RULES:
        found.append(_RULES[rules])
    match = proof.result.get("confidence")
    if match in _MATCH:
        found.append((_MATCH[match], f"配對方式是{_MATCH_ZH[match]}"))
    if not found:
        return "high", []
    found = sorted(set(found), key=lambda x: (-LEVELS.index(x[0]), x[1]))
    return found[0][0], [why for _, why in found]


def describe(level: str, reasons: list[str]) -> str:
    """"分析信心：中（依賴有保留的假設「…」）" """
    return f"分析信心：{ZH[level]}" + (f"（{'；'.join(reasons[:4])}{'……' if len(reasons) > 4 else ''}）" if reasons else
                                    "（只依賴機率公理、已審核的事實和結構配對）")
