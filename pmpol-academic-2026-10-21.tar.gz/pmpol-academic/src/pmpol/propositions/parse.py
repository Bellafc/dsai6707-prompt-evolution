"""Read markets as propositions. Precision first: a label that does not fit a known pattern is left
unparsed with a reason, never guessed."""

from __future__ import annotations

import re
import unicodedata
from datetime import date

from pmpol.models import Event, Market
from pmpol.propositions import INF, Parsed, Prop, Span, Var, normalize
from pmpol.propositions.cabinet import parse_cabinet
from pmpol.propositions.describe import describe, option_sentence
from pmpol.propositions.indicators import parse_indicator
from pmpol.universe.outcomes import count_interval, kalshi_margin_rung, margin_bucket, name_key, party_of, surname
from pmpol.universe.taxonomy import Tags

# States whose general election can have two candidates of one party (top-two / top-four primaries):
# there "the Democrat wins" is not the same proposition as "this named Democrat wins".
TOP_TWO = {"CA", "WA", "LA", "AK"}

_MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
_NUMBER = r"(\d[\d,]*(?:\.\d+)?)"


def _ascii(text: str) -> str:
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().lower()


def _state(tags: Tags) -> str:
    return (tags.jurisdiction or "").split("-")[0]


def _bounds_note(m: Market) -> tuple[str, ...]:
    r = (m.rules or "").lower()
    if "higher range bracket" in r or "higher bracket" in r:
        return ("boundary: value on a bracket edge goes to the higher bracket [lo, hi)",)
    if "lower bound" in r:
        return ("boundary: value on an edge goes to the bracket where it is the lower bound [lo, hi)",)
    if m.venue == "kalshi":
        return ()
    return ("boundary convention not stated in the rules we hold",)


def _num(x: str, suffix: str = "") -> float:
    v = float(x.replace(",", ""))
    return v * {"k": 1e3, "m": 1e6, "b": 1e9}.get(suffix.lower(), 1)


def _kalshi_strike(m: Market) -> Span | None:
    if m.venue != "kalshi" or m.floor_strike is None and m.cap_strike is None:
        return None
    if m.strike_type == "greater_or_equal":
        return Span(m.floor_strike, INF, True, False)
    if m.strike_type == "greater":
        return Span(m.floor_strike, INF, False, False)
    if m.strike_type == "less":
        return Span(-INF, m.cap_strike, False, False)
    if m.strike_type == "less_or_equal":
        return Span(-INF, m.cap_strike, False, True)
    return None


def number_span(label: str) -> Span | None:
    """Continuous ranges: "<2.2M", "2.2M-2.4M", "Above 1.25M", "5.5%+", "3.25-4%", "At least 46%", "≥15%"."""
    t = label.strip().replace("–", "-").replace("—", "-").replace("≥", ">=").replace("≤", "<=").lower()
    t = re.sub(r"\s+", " ", t)
    n = rf"{_NUMBER}\s*([kmb])?\s*%?"
    pats = [
        (rf"^(?:<|under|below|less than) ?{n}$", lambda a, s: Span(-INF, _num(a, s), False, False)),
        (rf"^<= ?{n}$", lambda a, s: Span(-INF, _num(a, s), False, True)),
        (rf"^(?:>|above|over|more than) ?{n}$", lambda a, s: Span(_num(a, s), INF, False, False)),
        (rf"^(?:>=|at least) ?{n}$", lambda a, s: Span(_num(a, s), INF, True, False)),
        (rf"^{n} ?(?:\+|or more|or higher)$", lambda a, s: Span(_num(a, s), INF, True, False)),
    ]
    for pat, make in pats:
        hit = re.match(pat, t)
        if hit:
            return make(hit.group(1), hit.group(2) or "")
    hit = re.match(rf"^{_NUMBER}\s*([kmb])?\s*%?\s*-\s*{_NUMBER}\s*([kmb])?\s*%?$", t)
    if hit:
        s1, s2 = hit.group(2) or hit.group(4) or "", hit.group(4) or ""
        return Span(_num(hit.group(1), s1), _num(hit.group(3), s2), True, False)
    return None


def _date(text: str, default_year: int | None) -> date | None:
    hit = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:,?\s+(20\d\d))?",
                    text.lower())
    if not hit:
        return None
    year = int(hit.group(3)) if hit.group(3) else default_year
    if year is None:
        return None
    try:
        return date(year, _MONTHS[hit.group(1)], int(hit.group(2)))
    except ValueError:
        return None


TRUMP_TERM_END = date(2029, 1, 20)  # noon ET; the hours are a resolution detail like the time zone


def _year_for(lab: str, text: str, rules: str, close_time: str | None) -> int | None:
    """Year of a "Month D" deadline written without one: from the question, then the rules ("by December 31,
    2026"), then the close time when it falls on that day or the next (venues close at 11:59 PM ET)."""
    hit = re.search(r"\bby\b.*?(20\d\d)", text) or re.search(r"(20\d\d)", text)
    if hit:
        return int(hit.group(1))
    d = _date(lab, 2000)
    if d is None:
        return None
    month = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?"
    years = {int(y) for mon, day, y in re.findall(rf"({month})\s+(\d{{1,2}}),?\s+(20\d\d)", rules.lower())
             if _MONTHS[mon[:3]] == d.month and int(day) == d.day}
    if len(years) == 1:
        return years.pop()
    if close_time:
        c = date.fromisoformat(close_time[:10])
        for y in (c.year, c.year - 1):
            try:
                if 0 <= (c - date(y, d.month, d.day)).days <= 1:
                    return y
            except ValueError:
                pass
    return None


def deadline_span(label: str, question: str, rules: str = "", close_time: str | None = None) -> tuple[Span, str] | None:
    """"Before Jan 1, 2027" -> T < 2027-01-01; "May 31" with "by May 31, 2026" in the question (or the rules,
    or a close time on that day) -> T <= 2026-05-31; "Before 2030" -> T < 2030-01-01. A label that is empty,
    "Yes" reads the deadline from the question ("... in 2026?", "... before his term ends?").
    Days are ordinal numbers; the time zone is a resolution detail."""
    lab = label.strip().lower()
    q = question.lower()
    r = (rules or "").lower()
    if lab and not lab.startswith(("by ", "before ")) and (re.search(r"\bon\s*(?:\.\.\.|…|_+)\s*\??\s*$", q)
                                                           or re.search(rf"\bon {re.escape(lab)}\b", q)):
        return None  # "... on...?" / "... on September 18?" with dates as options: single days, not deadlines
    hit = re.match(r"^before (20\d\d)$", lab)
    if hit:
        return Span(-INF, date(int(hit.group(1)), 1, 1).toordinal(), False, False), "before_year"
    if re.match(r"^before (?:his|the) term (?:ends|is up)$", lab) and "trump" in q + r:
        return Span(-INF, TRUMP_TERM_END.toordinal(), False, False), "trump_term"
    if lab.startswith("before "):
        d = _date(lab, None)
        return (Span(-INF, d.toordinal(), False, False), "before_date") if d else None
    if lab and re.match(r"^(by )?(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)", lab):
        d = _date(lab, _year_for(lab, q, r, close_time))
        return (Span(-INF, d.toordinal() + 1, False, False), "by_date") if d else None
    if lab and lab != "yes":
        return None  # the label is an option (a person, a place), not a yes/no on the question
    hit = re.search(r"\bbefore (20\d\d)\b", q)
    if hit:
        return Span(-INF, date(int(hit.group(1)), 1, 1).toordinal(), False, False), "question_before_year"
    hit = re.search(r"\bbefore ((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.? \d{1,2},? 20\d\d)", q)
    if hit and (d := _date(hit.group(1), None)):
        return Span(-INF, d.toordinal(), False, False), "question_before_date"
    hit = re.search(r"\bby ((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.? \d{1,2}(?:,? 20\d\d)?)", q)
    if hit and (d := _date(hit.group(1), _year_for(hit.group(1), hit.group(1), r, close_time))):
        return Span(-INF, d.toordinal() + 1, False, False), "question_by_date"
    hit = re.search(r"\bin (20\d\d)\s*\??\s*$", q)
    if hit:
        y = int(hit.group(1))
        # "in 2026" is "before 2027" only when the window ends with the year; the rules must agree if we hold them.
        if not r or f"december 31, {y}" in r or re.search(rf"jan(?:uary)?\.? 1, {y + 1}", r):
            return Span(-INF, date(y + 1, 1, 1).toordinal(), False, False), "question_in_year"
        return None
    if re.search(r"\b(?:before|during) (?:his|trump s|trump's) term(?: ends| is up)?\b", q) and "trump" in q:
        return Span(-INF, TRUMP_TERM_END.toordinal(), False, False), "trump_term"
    return None


def _descriptor(title: str) -> str:
    t = _ascii(title)
    t = re.sub(r"\b(by|before|in)\b\s*(\.\.\.|20\d\d)?\s*\??\s*$", "", t)
    t = re.sub(r"[^a-z0-9 ]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


# --- per measure ---------------------------------------------------------------------

def _same_party_pair(e: Event) -> bool:
    """Two live options of one party in one event (possible in top-two states)."""
    ps = [p for m in e.markets if (p := party_of(m))]
    return len(ps) != len(set(ps))


_ROLE = re.compile(r"\b(majority leader|minority leader|majority whip|minority whip|speaker|president pro tempore|"
                   r"chair(?:man|woman)?)\b", re.I)


def _winner(e: Event, tags: Tags, out: Parsed) -> None:
    race = tags.race_key
    # "Winner (Individual)" lists the same contest by person: the variant is presentation, not another variable.
    race = race[:-len("/individual")] if race.endswith("/individual") else race
    if re.match(r"^\s*how many\b", e.title, re.I):
        for m in e.markets:
            out.unparsed[m.key] = "a count question tagged as winner (taxonomy)"
        return
    if _CABINET.search(e.title):
        for m in e.markets:  # "defense minister after the election": a cabinet post, appointed, not elected
            out.unparsed[m.key] = "a cabinet post tagged as winner (taxonomy)"
        return
    role = _ROLE.search(e.title)
    if role:  # "majority leader" and "minority leader" of one chamber are different variables
        race = f"{race}|role:{role.group(1).lower()}"
    # In top-two states the party identifies the winner only when the finalists are of different parties.
    top_two = _state(tags) in TOP_TWO and tags.stage == "general" and _same_party_pair(e)
    us = tags.country in ("United States", None, "")
    for m in e.markets:
        label = m.outcome.strip()
        if re.fullmatch(r"(option )?[a-e]|other|others|field|any other|none", label.lower()):
            out.unparsed[m.key] = "placeholder or catch-all option"
            continue
        # D/R/I are U.S. parties: abroad "The Democrats" (Israel), "Democratic Party" (Italy) or "Reform" (UK)
        # are other parties, kept by their label
        p = (party_of(m) or _party_with_name(label)) if us else None
        if p and not top_two:
            out.props.append(Prop(Var("winner", race), m.key, e.key, "winner_party", values=frozenset({f"party:{p}"}),
                                  notes=(f"named: {label}",) if surname(label) else ()))
            continue
        who = None if _ABBREV.search(label) else name_key(label)  # "BC NDP" is a party, not a person
        if who:
            out.props.append(Prop(Var("winner", race), m.key, e.key, "winner_person",
                                  values=frozenset({f"person:{who}"}),
                                  notes=("top-two race with two finalists of one party",) if top_two else ()))
        elif _plain_name(label):
            # A party list, coalition or single-name candidate ("Likud", "CDU", "Lula"): kept as written, so
            # only the same label on another venue is the same value.
            written = re.sub(r"\s*\(.*?\)", "", _ascii(label)).strip()  # "Hezbollah (Hezb)" -> "hezbollah"
            out.props.append(Prop(Var("winner", race), m.key, e.key, "winner_name",
                                  values=frozenset({f"name:{written}"}),
                                  notes=("option kept as its label (party list or single name)",)))
        else:
            out.unparsed[m.key] = "winner label is neither a party nor a person"


_CABINET = re.compile(r"\b(?:defen[cs]e|finance|foreign|interior|justice|security|economy|health|education)\s+minister\b|"
                      r"(?<!prime )(?<!first )(?<!chief )\bminister (?:of|for)\b", re.I)
_ABBREV = re.compile(r"\b[A-Z]{3,}\b")  # "NDP", "CDU"; not initials ("JD Vance") or "II"


def _party_with_name(label: str) -> str | None:
    """"Republican (Paxton)": the party, with the expected nominee in brackets."""
    hit = re.match(r"^\s*(\w+)\s*\([^)]*\)\s*$", _ascii(label))
    return _P.get(hit.group(1)) if hit else None


def _plain_name(label: str) -> bool:
    """A short option name without numbers or question words: not "Yes", not "", not "2nd place"."""
    t = _ascii(label).strip()
    return bool(t) and t not in ("yes", "no") and not re.search(r"\d|\?", t) and len(t.split()) <= 5


_P = {"d": "D", "dem": "D", "dems": "D", "democrat": "D", "democrats": "D", "democratic": "D",
      "r": "R", "rep": "R", "reps": "R", "republican": "R", "republicans": "R", "gop": "R"}


def balance_cell(label: str) -> tuple[str, str] | None:
    """(house party, senate party) from a balance-of-power label in any venue's wording:
    "Democrats sweep", "Dem. House & Senate", "D-House, R-Senate", "R Senate, D House",
    "Republican Senate + Democrats House". None for "Other" or anything unclear."""
    t = _ascii(label).replace(".", " ")
    sweep = re.match(r"^\s*(\w+)\s+(?:sweep|house\s*&\s*senate|senate\s*&\s*house)\s*$", t)
    if sweep and sweep.group(1) in _P:
        return _P[sweep.group(1)], _P[sweep.group(1)]
    got = {}
    for party, chamber in re.findall(r"\b(\w+)[\s-]+(house|senate)\b", t):
        if party in _P:
            got[chamber] = _P[party]
    return (got["house"], got["senate"]) if len(got) == 2 else None


def _balance(e: Event, tags: Tags, out: Parsed) -> bool:
    """Congress balance-of-power events, on any venue: a joint control variable (house, senate)."""
    if not re.search(r"balance of power", e.title, re.I):
        return False
    year = re.search(r"\b(20\d\d)\b", e.title)
    year = int(year.group(1)) if year else tags.year
    if not year:
        return False
    comps = (f"control:United States|house|{year}", f"control:United States|senate|{year}")
    var = Var("joint", f"United States|congress|{year}", ";".join(comps))
    for m in e.markets:
        cell = balance_cell(m.outcome)
        if cell is None:
            out.unparsed[m.key] = "balance-of-power label not understood (or a catch-all option)"
            continue
        out.props.append(Prop(var, m.key, e.key, "balance_cell", values=frozenset({f"party:{cell[0]},party:{cell[1]}"}),
                              notes=("timing: when control is measured differs by venue",)))
    return True


# --- seat conjunctions: "Senate seats in S and House seats in H" ----------------------------------------------

CHAMBER_SEATS = {"senate": 100, "house": 435}  # the grid a seat box lives on (counts 0..size)
_SEAT_SENTENCE = re.compile(r"(?:(\d+)\s+or\s+(more|fewer)\s+seats\s+in\s+the|seat\s+count\s+of\s+(\d+)\s+or\s+(more|fewer)"
                            r"\s+in\s+the)\s+(house|senate)\b", re.I)
_SEAT_PARTY = {"democrats": "D", "democrat": "D", "dems": "D", "dem": "D", "republicans": "R", "republican": "R",
               "gop": "R"}


def seat_box(p: Prop) -> tuple[Span, Span] | None:
    """(senate span, house span) of a seat-conjunction cell, from its value "box:lo,hi;lo,hi" (half-open)."""
    v = next(iter(p.values), "")
    if not v.startswith("box:"):
        return None
    parts = [tuple(float(x) for x in c.split(",")) for c in v[4:].split(";")]
    return tuple(Span(lo, hi) for lo, hi in parts)


def _box_value(senate: tuple[float, float], house: tuple[float, float]) -> str:
    f = lambda x: "inf" if x == INF else f"{x:g}"  # noqa: E731
    return f"box:{f(senate[0])},{f(senate[1])};{f(house[0])},{f(house[1])}"


def _half_open(iv) -> tuple[float, float]:
    return (max(iv.lo, 0), INF if iv.hi == INF else iv.hi + 1)


def _seat_chambers(label: str) -> dict[str, tuple[float, float]] | None:
    """"≤47 and 218-232" -> {senate: (0, 48), house: (218, 233)}: the chamber of each count by its size (a count
    whose finite bounds all fit in the Senate's 100 seats is the Senate's; otherwise the House's)."""
    halves = re.split(r"\s+and\s+|\s*&\s*", label.strip(), flags=re.I)
    if len(halves) != 2:
        return None
    out = {}
    for h in halves:
        iv = count_interval(h)
        if iv is None:
            return None
        finite = [x for x in (iv.lo, iv.hi) if x not in (INF, -INF)]
        chamber = "senate" if finite and max(finite) <= CHAMBER_SEATS["senate"] else "house"
        if chamber in out:
            return None
        out[chamber] = _half_open(iv)
    return out


def _seat_sentence(text: str) -> dict[str, tuple[float, float]] | None:
    """"hold 218 or more seats in the House ... AND hold 49 or more seats in the Senate" (both required)."""
    got = {}
    for a, way, b, way2, chamber in _SEAT_SENTENCE.findall(text):
        n, way = int(a or b), (way or way2).lower()
        span = (n, INF) if way == "more" else (0, n + 1)
        if got.setdefault(chamber.lower(), span) != span:
            return None
    return got if len(got) == 2 else None


def _seat_combo(e: Event, tags: Tags, out: Parsed) -> bool:
    """Seat conjunctions, on any venue: a joint seats variable (Senate, House) whose values are boxes, one interval
    per chamber. Grids ("≤47 and 218-232", PredictIt and Polymarket) and single boxes ("Will Democrats hold 218 or
    more seats in the House AND 49 or more in the Senate?", Kalshi; Polymarket's "Blue wave" in its rules)."""
    text = " ".join([e.title] + [m.question for m in e.markets[:1]])
    head = text + " " + " ".join((m.rules or "")[:600] for m in e.markets[:1])  # yes/no markets state it in the rules
    if not re.search(r"\bsenate\b", head, re.I) or not re.search(r"\bhouse\b", head, re.I) or \
            not re.search(r"\bseats?\b|seat count", head, re.I):
        return False
    cells = []
    for m in e.markets:
        box = _seat_chambers(m.outcome) if m.outcome and re.search(r"\d", m.outcome) else None
        if box is None:
            box = _seat_sentence(m.question) or (_seat_sentence(m.rules) if re.search(
                r"\b(both|all) of the following|\bAND\b", m.rules or "") else None)
        if box is None:
            return False  # not a seat conjunction after all (or not every option is one): leave it to the others
        cells.append((m, box))
    words = re.findall(r"[a-z]+", _ascii(text + " " + (e.markets[0].rules[:400] if e.markets else "")))
    parties = {_SEAT_PARTY[w] for w in words if w in _SEAT_PARTY} or ({"D"} if re.search(r"blue", text, re.I) else set())
    if len(parties) != 1:
        for m, _ in cells:
            out.unparsed[m.key] = "seat conjunction: whose seats is not clear"
        return True
    party = parties.pop()
    # the date the seats are counted on, as the single-chamber seat variables read it: Kalshi counts seats held on
    # February 1 of the new Congress (year + 1); the others count the result of the election
    rules = " ".join(m.rules or "" for m in e.markets[:1])
    held_on = re.search(r"\bon\s+(?:january|february)\s+\d{1,2},\s+(20\d\d)", rules, re.I)
    year = re.search(r"\b(20\d\d)\b", text + " " + rules)
    if held_on:
        year = int(held_on.group(1))
    elif year:
        year = int(year.group(1))
    elif tags.year:
        year = int(tags.year)
    else:
        for m, _ in cells:
            out.unparsed[m.key] = "seat conjunction: no year"
        return True
    comps = [f"seats:United States|US|{c}|{year}|general#{party}/held" for c in ("senate", "house")]
    var = Var("joint", f"United States|congress|{year}|seats", ";".join(comps))
    for m, box in cells:
        out.props.append(Prop(var, m.key, e.key, "seat_box", values=frozenset({_box_value(box["senate"], box["house"])}),
                              notes=("timing: when seats are counted differs by venue",)))
    return True


def _combo(e: Event, tags: Tags, out: Parsed) -> None:
    """Governor-and-Senate combos: a joint winner variable (governor race, senate race)."""
    from pmpol.universe.outcomes import combo_cell

    if not tags.race_key or tags.office != "governor":
        for m in e.markets:
            out.unparsed[m.key] = "combo of something other than governor and senate"
        return
    gov = tags.race_key
    country, juris, _, year, stage = gov.split("|")
    sen = "|".join((country, juris, "senate", year, stage))
    var = Var("joint", f"{gov}+senate", f"winner:{gov};winner:{sen}")
    for m in e.markets:
        cell = combo_cell(m)
        if cell is None:
            out.unparsed[m.key] = "combo label not understood"
            continue
        out.props.append(Prop(var, m.key, e.key, "combo_cell", values=frozenset({f"party:{cell[0]},party:{cell[1]}"})))


def _control(e: Event, tags: Tags, out: Parsed) -> None:
    if tags.topic != "elections_us" or tags.office not in ("house", "senate"):
        for m in e.markets:
            out.unparsed[m.key] = "control of something other than a chamber"
        return
    subject = f"{tags.country}|{tags.office}|{tags.year}"
    for m in e.markets:
        lab = _ascii(m.outcome)
        if re.search(r"sweep|-house|-senate| and ", lab):
            out.unparsed[m.key] = "combination of two chambers (conjunction not in the prototype)"
            continue
        p = party_of(m) or ("D" if lab.startswith("democrat") else "R" if lab.startswith("republican") else None)
        if p:
            out.props.append(Prop(Var("control", subject), m.key, e.key, "control_party",
                                  values=frozenset({f"party:{p}"}),
                                  notes=("timing: when control is measured differs by venue",)))
        else:
            out.unparsed[m.key] = "control label is not a party"


def _margin(e: Event, tags: Tags, out: Parsed, parties: dict[str, str]) -> None:
    race = tags.race_key
    for m in e.markets:
        rung = kalshi_margin_rung(m)
        if rung:
            party, k = rung
            span = _kalshi_strike(m) or Span(k, INF, True, False)
            out.props.append(Prop(Var("margin", race, party), m.key, e.key, "margin_kalshi_rung", spans=(span,)))
            continue
        b = margin_bucket(m)
        lab = m.outcome.strip().replace("≥", ">=").replace("≤", "<=")
        if b is None:
            hit = re.match(r"^(.+?)\s*(>=|<)\s*(\d+(?:\.\d+)?)%?$", lab)
            if hit:
                who, op, k = hit.group(1), hit.group(2), float(hit.group(3))
                p = _party_word(who) or parties.get(surname(who) or "")
                if p:
                    span = Span(k, INF, True, False) if op == ">=" else Span(0, k, False, False)
                    out.props.append(Prop(Var("margin", race, p), m.key, e.key, "margin_open_bucket", spans=(span,),
                                          notes=_bounds_note(m)))
                    continue
            out.unparsed[m.key] = "margin label not understood"
            continue
        p = b.party or parties.get(b.who or "")
        if not p:
            out.unparsed[m.key] = "margin bucket names a person whose party is unknown"
            continue
        if b.lo == 0 and b.hi == INF:  # "Democrat Wins"
            span, rule = Span(0, INF, False, False), "margin_wins"
        else:
            span, rule = Span(b.lo, b.hi, True, False), "margin_bucket"
        out.props.append(Prop(Var("margin", race, p), m.key, e.key, rule, spans=(span,), notes=_bounds_note(m)))


def _party_word(text: str) -> str | None:
    t = _ascii(text).strip()
    return "D" if re.match(r"^dem", t) else "R" if re.match(r"^(rep|gop)", t) else None


def _subject_after_colon(title: str, tail: str) -> str | None:
    hit = re.search(rf":\s*(.+?)\s+{tail}", title, re.I)
    return hit.group(1) if hit else None


def _numeric(e: Event, tags: Tags, out: Parsed, kind: str, who: str = "") -> None:
    for m in e.markets:
        span = _kalshi_strike(m) or number_span(m.outcome)
        if span is None:
            out.unparsed[m.key] = f"{kind} label not understood"
            continue
        qualifier = who
        if kind == "turnout":  # the unit is part of the variable: a count of votes is not a percentage
            qualifier = "percent" if "%" in m.outcome else "votes"
        out.props.append(Prop(Var(kind, tags.race_key, qualifier), m.key, e.key, f"{kind}_range", spans=(span,),
                              notes=() if m.venue == "kalshi" else _bounds_note(m)))


def _vote_share(e: Event, tags: Tags, out: Parsed) -> None:
    who = _subject_after_colon(e.title, r"(vote percent|vote share)")
    # in a parliament the share is a party list's ("The Democrats", "Yisrael Beiteinu"), kept as written
    key = name_key(who) if who and tags.office != "parliament" else None
    key = key or (_ascii(who).strip() if who else None)
    if not key:
        for m in e.markets:
            out.unparsed[m.key] = "vote share: cannot tell whose share"
        return
    county = re.search(r"([A-Z][\w.'-]*(?: [A-Z][\w.'-]*)* County)", e.title)
    if county:  # a county's share is a different variable from the statewide share
        tags = Tags(**{**tags.to_dict(), "jurisdiction": f"{tags.jurisdiction}/{county.group(1)}"})
    _numeric(e, tags, out, "vote_share", key)


def _seats(e: Event, tags: Tags, out: Parsed) -> None:
    from pmpol.universe.relations import _count_basis

    basis = _count_basis(e)
    if basis:
        who = f"{basis[0]}/{basis[1]}"
    else:
        party = _subject_after_colon(e.title, r"(#|number) of seats")
        hit = None if party else re.search(r"\bhow many seats will (.+?) win\b", e.title, re.I)
        party = hit.group(1) if hit else party  # Kalshi: "...: how many seats will Likud win?"
        who = f"{_ascii(party).strip()}/won" if party else None
    if not who or not tags.race_key and not tags.jurisdiction:
        for m in e.markets:
            out.unparsed[m.key] = "seat count: cannot tell whose seats or where"
        return
    subject = tags.race_key or f"{tags.country}|{tags.jurisdiction}|{tags.office}|{tags.year}"
    subject = subject.removesuffix("/seat")  # a seat count is about the election itself, not "wins a seat"
    for m in e.markets:
        if " and " in m.outcome:
            out.unparsed[m.key] = "two chambers in one label (conjunction not in the prototype)"
            continue
        iv = count_interval(m.outcome)
        if iv is None:
            out.unparsed[m.key] = "seat count label not understood"
            continue
        span = Span(iv.lo, iv.hi + 1 if iv.hi != INF else INF, True, False)
        out.props.append(Prop(Var("seats", subject, who), m.key, e.key, "seats_interval", spans=(span,)))


_NOMINEE = re.compile(r"\b(democratic|republican|green|libertarian)\b.*\b(nominee|nomination)\b|"
                      r"\b(nominee|nomination)\b.*\b(democratic|republican|green|libertarian)\b", re.I)
_NOT_NOMINEE = re.compile(r"odds|leader on|back a primary|against|woman|age of|how many|margin|vote", re.I)


def _nominee(e: Event, tags: Tags, out: Parsed) -> None:
    hit = _NOMINEE.search(e.title)
    if not hit and tags.race_key and tags.jurisdiction not in (None, "US") and \
            re.search(r"\bprimary\b.*\bwinner\b|\bwins?\b.*\bprimary\b", e.title, re.I):
        _winner(e, tags, out)  # one state's primary ("South Carolina Democratic primary winner"): a contest
        return
    if not hit or _NOT_NOMINEE.search(e.title) or not tags.year:
        for m in e.markets:
            out.unparsed[m.key] = "not a plain 'who will be the nominee' question"
        return
    party = (hit.group(1) or hit.group(4)).lower()
    # The race key carries the stage and variant, so a vice-presidential nomination is its own variable.
    subject = f"{tags.race_key or f'{tags.country}|{tags.office}|{tags.year}|{tags.stage}'}|{party}"
    for m in e.markets:
        who = name_key(m.outcome)
        if who and not re.search(r"\bother\b|\bfield\b", m.outcome, re.I):
            out.props.append(Prop(Var("nominee", subject), m.key, e.key, "nominee_person",
                                  values=frozenset({f"person:{who}"})))
        else:
            out.unparsed[m.key] = "nominee label is not a person"


_TIME_NOTES = {
    "trump_term": "term end taken as 2029-01-20",
}


def window_start(m: Market) -> str:
    """When the counting window opens, as the rules state it. Venues differ ("visits that began before
    issuance do not count" vs no start at all), and two legs with different starts are not equivalent if the
    event already happened in between."""
    r = (m.rules or "").lower()
    if not r:
        return "window start: rules not held"
    if re.search(r"after (?:issuance|this market was (?:created|issued))|market creation|before (?:market )?issuance "
                 r"do not count|since (?:the )?market (?:was )?(?:created|opened)", r):
        return "window start: market creation"
    hit = re.search(r"(?:between|from) ((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.? \d{1,2},? 20\d\d),?"
                    r" (?:and|through|to|until)\b", r)
    if hit:
        return f"window start: {hit.group(1)}"
    return "window start: not stated in the rules"


def announcement_rule(m: Market) -> str | None:
    """Whether an announced departure counts, for "out" questions: venues differ (Polymarket: an announced
    resignation resolves Yes at once; Kalshi: an actual departure date is required)."""
    r = (m.rules or "").lower()
    if re.search(r"announce\w*[^.]{0,120}(?:resign|remov|leav|depart|step)[^.]{0,200}(?:immediately resolve|resolve "
                 r"(?:this market )?to .?yes|will count|counts? as)", r):
        return "announcement: counts"
    if re.search(r"actual departure|must (?:have an actual departure|vacate)|announcements? (?:alone )?(?:do|does|will) "
                 r"not (?:count|qualify)", r):
        return "announcement: does not count (actual departure required)"
    return None


def event_subject(title: str) -> str:
    """Standardised descriptor (action + argument bag) when the action is known, else the normalised title.
    Short bags are completed across the snapshot in derive.parse_universe."""
    d = describe(title)
    return d.key if d else _descriptor(title)


def _event_time_prop(e: Event, m, got: tuple[Span, str]) -> Prop:
    span, rule = got
    notes = ("time zone of the deadline not compared", window_start(m)) + \
        ((_TIME_NOTES[rule],) if rule in _TIME_NOTES else ()) + \
        ((a,) if (a := announcement_rule(m)) else ())
    return Prop(Var("event_time", event_subject(e.title)), m.key, e.key, f"time_{rule}", spans=(span,), notes=notes)


def _option_arguments(e: Event, out: Parsed) -> bool:
    """Questions whose options are the arguments ("Who will Trump meet in 2026?", "Which leaders will leave office
    in 2026?"): each option put back into the question is its own event_time proposition, so "Putin" in Kalshi's
    list and Polymarket's "Trump meets with Putin by...?" are one variable. Options that do not make a readable
    sentence with a deadline go to the generic forms."""
    if not re.match(r"^\s*(?:who|which|what)\b", e.title, re.I):
        return False
    done, rest = [], []
    for m in e.markets:
        sentence = option_sentence(e.title, m.outcome)
        d = describe(sentence) if sentence else None
        got = deadline_span("", sentence, m.rules, m.close_time) if d else None
        if got is None:
            rest.append(m)
            continue
        span, rule = got
        notes = ("time zone of the deadline not compared", window_start(m), "argument read from the option label") + \
            ((_TIME_NOTES[rule],) if rule in _TIME_NOTES else ()) + ((a,) if (a := announcement_rule(m)) else ())
        done.append(Prop(Var("event_time", d.key), m.key, e.key, f"time_option_{rule}", spans=(span,), notes=notes))
    if not done:
        return False
    out.props += done
    if rest:
        _generic(e, out, rest, "option not readable as an argument of the question")
    return True


def _event_time(e: Event, tags: Tags, out: Parsed) -> None:
    rest = []
    for m in e.markets:
        got = deadline_span(m.outcome, m.question or e.title, m.rules, m.close_time)
        if got is None:
            rest.append(m)
            continue
        out.props.append(_event_time_prop(e, m, got))
    if rest:  # the options are not dates (people, places): the generic forms
        _generic(e, out, rest, "deadline label not understood (or the options are not dates)")


_TITLE_STOP = {"will", "the", "a", "an", "be", "of", "who", "what", "which", "how", "many", "much", "next", "winner",
               "win", "wins", "won", "is", "to", "in", "on", "by", "for", "at", "and", "or", "s", "does", "do", "get",
               "become", "there"}
GENERIC_NOTE = "generic form: matched across venues by title words only; compare the rules before trusting"


def title_key(title: str) -> str:
    """The bag of a title's words, numbers and years kept, question words dropped: "2026 Nobel Peace Prize winner"
    and "Nobel Peace Prize Winner 2026" give the same key."""
    words = re.findall(r"[a-z0-9]+", _ascii(title))
    return " ".join(sorted({w for w in words if w not in _TITLE_STOP}))


def label_key(label: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", _ascii(label)))


def _generic(e: Event, out: Parsed, markets, reason: str) -> None:
    """Generic forms for markets no specific kind reads: a deadline (event_time), a number in a range (quantity)
    or one option of a mutually exclusive question (choice). Whatever none of them reads stays unparsed."""
    subject = title_key(e.title)
    for m in markets:
        lab = (m.outcome or "").strip()
        got = deadline_span(lab if lab.lower() not in ("yes",) else "", m.question or e.title, m.rules, m.close_time)
        if got is not None:
            out.props.append(_event_time_prop(e, m, got))
        elif lab.lower() in ("", "yes", "no"):
            out.unparsed[m.key] = f"{reason}; yes/no question without a readable deadline"
        elif (span := number_span(lab)) is not None and subject:
            out.props.append(Prop(Var("quantity", subject), m.key, e.key, "generic_quantity", spans=(span,),
                                  notes=(GENERIC_NOTE, "range boundaries as written in the label")))
        elif e.mutually_exclusive and subject and label_key(lab):
            out.props.append(Prop(Var("choice", subject), m.key, e.key, "generic_choice",
                                  values=frozenset({f"option:{label_key(lab)}"}), notes=(GENERIC_NOTE,)))
        elif subject and label_key(lab) and (got := deadline_span("", m.question or e.title, m.rules, m.close_time)):
            # options that are separate yes/no questions ("Which countries will recognize Palestine before 2027?":
            # France, Japan, ...): each is "this option happens before the question's deadline"
            span, rule = got
            out.props.append(Prop(Var("event_time", f"{subject} | {label_key(lab)}"), m.key, e.key,
                                  f"generic_time_{rule}", spans=(span,),
                                  notes=(GENERIC_NOTE, "time zone of the deadline not compared", window_start(m))))
        else:
            out.unparsed[m.key] = f"{reason}; options are separate questions without a readable deadline"


def parse_event(e: Event, tags: Tags, parties: dict[str, str] | None = None) -> Parsed:
    """Propositions for every active market of one event, plus the reasons for those left out."""
    out = Parsed()
    live = Event(e.venue, e.event_id, e.title, e.category, e.mutually_exclusive, [m for m in e.markets if m.active])
    measure = tags.measure
    if parse_cabinet(live, out):  # "Who will be a part of the next government of X?", tagged binary or winner
        return out
    if _balance(live, tags, out):  # tagged control, winner or binary depending on the venue's wording
        return out
    if _seat_combo(live, tags, out):  # tagged seat_count or by_date depending on the venue's wording
        return out
    if _option_arguments(live, out):  # "Who will Trump meet in 2026?": one event per option
        return out
    if parse_indicator(live, out):  # tagged binary, by_date or count depending on the venue's wording
        return out
    race_needed = measure in ("winner", "margin", "vote_share", "turnout")
    if race_needed and not tags.race_key:
        _generic(live, out, live.markets, "no contest identified (taxonomy)")
        return out
    if measure == "winner":
        _winner(live, tags, out)
    elif measure == "control":
        _control(live, tags, out)
    elif measure == "combo":
        _combo(live, tags, out)
    elif measure == "margin":
        _margin(live, tags, out, parties or {})
    elif measure == "vote_share":
        _vote_share(live, tags, out)
    elif measure == "turnout":
        _numeric(live, tags, out, "turnout")
    elif measure == "seat_count":
        _seats(live, tags, out)
    elif measure == "nomination":
        _nominee(live, tags, out)
    elif measure == "by_date":
        _event_time(live, tags, out)
    else:
        _generic(live, out, live.markets, f"measure '{measure}' not modelled")
    return out


def merged(props: list[Prop]) -> tuple[Span, ...]:
    return normalize(s for p in props for s in p.spans)
