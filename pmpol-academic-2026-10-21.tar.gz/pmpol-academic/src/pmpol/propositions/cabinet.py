"""Who will be in the next government: cabinet(<place>|next) (2026-10-06).

Two kinds of question ask about the same world variable, the set of parties in the next government formed:

  membership   "Who will be a part of the next government of Sweden?" (Kalshi), "Which parties will be in next
               Swedish Government?" (Polymarket): one market per party, "party p is in the government"
  coalition    "Which coalition will form the next Swedish government?" (Polymarket): mutually exclusive options,
               "the government is exactly these parties" ("S + MP + C")

A party counts only if it holds a ministerial post: every venue's rules must say so (a party that supports the
government from outside the cabinet is not in it); events whose rules do not are left unread.

Party names differ by venue ("Centre Party" / "Centre Party (C)" / "C"; "Greens" / "Green Party"; "NZF" / "New
Zealand First Party"). Within one place, a name resolves to a party when exactly one party matches: the same name
once "party", "the" and a trailing plural are dropped; the abbreviation a venue writes in parentheses or the
initials of a multi-word name; or all of its words are words of one party's name. A coalition option with a
member that does not resolve is left unread (precision first).
"""

from __future__ import annotations

import re
import unicodedata
from collections import defaultdict
from dataclasses import replace

from pmpol.models import Event
from pmpol.propositions import Parsed, Prop, Var

MEMBER = [r"^who will be (?:a )?part of the next government of (?P<c>.+?)\??$",
          r"^which parties will be (?:a )?part of the next government of (?P<c>.+?)\??$",
          r"^which parties will be in (?:the )?next (?P<c>.+?) government\??$"]
COALITION = [r"^which coalition will form the next (?P<c>.+?) government\??$",
             r"^which coalition will form the next government of (?P<c>.+?)\??$"]
MINISTER = re.compile(r"ministerial or cabinet-level position|cabinet minister|cabinet post")
PLACES = {"swedish": "sweden", "romanian": "romania", "israeli": "israel", "german": "germany", "dutch": "netherlands",
          "danish": "denmark", "norwegian": "norway", "belgian": "belgium", "austrian": "austria", "czech": "czechia",
          "portuguese": "portugal", "spanish": "spain", "japanese": "japan", "new zealand": "new zealand",
          "hungarian": "hungary", "bulgarian": "bulgaria", "irish": "ireland", "finnish": "finland"}
_OTHER = re.compile(r"^(?:other|others|none|no government|another|any other)\b", re.I)
_DROP = {"party", "the", "of", "and"}


def _ascii(text: str) -> str:
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().lower()


def place(name: str) -> str:
    p = re.sub(r"\s+", " ", _ascii(name)).strip()
    return PLACES.get(p, p)


def key(label: str) -> str:
    """"Centre Party (C)" -> "centre"; "Te Pāti Māori" -> "te pati maori"; "Hadash–Ta'al" -> "hadash taal"."""
    t = re.sub(r"\(.*?\)", " ", _ascii(re.sub(r"[\u2010-\u2015\-&/]", " ", label)))
    return " ".join(w for w in re.findall(r"[a-z0-9]+", t.replace("'", "").replace("\u2019", "")) if w not in _DROP)


def _plural(a: str, b: str) -> bool:
    """One-word names that differ by a plural s only: "greens" / "green" ("shas" has no "sha" to meet)."""
    return " " not in a and " " not in b and (a == b + "s" or b == a + "s")


def abbreviation(label: str) -> str:
    hit = re.search(r"\(([A-Za-z0-9\-]{1,8})\)\s*$", label.strip())
    return hit.group(1).lower() if hit else ""


def parse_cabinet(e: Event, out: Parsed) -> bool:
    """Membership or coalition propositions for a next-government event; False when the event is not one."""
    title = re.sub(r"\s+", " ", e.title).strip()
    for form, pats in (("member", MEMBER), ("coalition", COALITION)):
        hit = next((m for p in pats if (m := re.match(p, title, re.I))), None)
        if hit:
            break
    else:
        return False
    live = [m for m in e.markets if m.active]
    if not all(MINISTER.search((m.rules or "").lower()) for m in live):
        for m in live:
            out.unparsed[m.key] = "next government: the rules do not say a party must hold a ministerial post"
        return True
    var = Var("cabinet", f"{place(hit.group('c'))}|next")
    for m in live:
        label = re.sub(r"\s+", " ", m.outcome.replace("​", "")).strip()
        if not label or _OTHER.match(label):
            out.unparsed[m.key] = "next government: option is not a party or a coalition"
            continue
        if form == "member":
            values = frozenset({f"has:{label}"})
        else:
            values = frozenset({"is:" + " + ".join(x.strip() for x in re.split(r"\s*\+\s*", label))})
        out.props.append(Prop(var, m.key, e.key, f"cabinet_{form}", values=values, notes=_notes(m)))
    return True


def _notes(m) -> tuple[str, ...]:
    r = (m.rules or "").lower()
    out = ["ministers: " + ("any ministerial post, junior ministers included" if "junior minister" in r
                            else "at least one cabinet minister")]
    hit = re.search(r"before ((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{1,2}, \d{4})", r)
    out.append(f"window: a government formed before {hit.group(1)}" if hit else
               "window: the first government formed after the election or market creation")
    return tuple(out)


def resolve(props: list[Prop], unparsed: dict[str, str]) -> list[Prop]:
    """Party names to one id per party and place; membership values "has:<id>", coalitions "is:<id>+<id>"."""
    by_var: dict[Var, list[Prop]] = defaultdict(list)
    for p in props:
        if p.var.kind == "cabinet":
            by_var[p.var].append(p)
    if not by_var:
        return props
    new: dict[str, Prop | None] = {}
    for var, ps in by_var.items():
        names = [next(iter(p.values))[4:] for p in ps if next(iter(p.values)).startswith("has:")]
        parties = _parties(names)
        for p in ps:
            v = next(iter(p.values))
            if v.startswith("has:"):
                pid = _resolve(v[4:], parties)
                new[p.market] = replace(p, values=frozenset({f"has:{pid}"})) if pid else None
                if not pid:
                    unparsed[p.market] = f"next government: party name not identified ({v[4:]})"
                continue
            members = [_resolve(x, parties) for x in v[3:].split(" + ")]
            if not all(members) or len(set(members)) != len(members):
                new[p.market] = None
                unparsed[p.market] = f"next government: coalition member not identified ({v[3:]})"
                continue
            new[p.market] = replace(p, values=frozenset({"is:" + "+".join(sorted(members))}))
    out = []
    for p in props:
        if p.market in new:
            if new[p.market] is not None:
                out.append(new[p.market])
        else:
            out.append(p)
    return out


def _parties(names: list[str]) -> dict[str, dict]:
    """Party id -> {"words", "abbr"} from the membership labels of one place, across venues: names whose words are
    all words of exactly one longer name join it ("ACT" -> "act new zealand")."""
    keys = {}
    for n in names:
        k = key(n)
        if k:
            keys.setdefault(k, set())
            if abbreviation(n):
                keys[k].add(abbreviation(n))
    ids = sorted(keys, key=lambda k: (-len(k.split()), k))
    merged: dict[str, str] = {}
    for k in sorted(keys, key=lambda k: len(k.split())):
        plural = [b for b in ids if _plural(k, b) and len(b) < len(k)]  # "greens" joins "green"
        bigger = [b for b in ids if b != k and set(k.split()) <= set(b.split()) and len(b.split()) > len(k.split())]
        if len(plural) == 1:
            merged[k] = plural[0]
        elif len(bigger) == 1:
            merged[k] = merged.get(bigger[0], bigger[0])
    out: dict[str, dict] = {}
    for k, abbrs in keys.items():
        pid = merged.get(k, k)
        d = out.setdefault(pid, {"words": set(pid.split()), "abbr": set()})
        d["abbr"] |= abbrs
    for pid, d in out.items():
        if len(pid.split()) >= 2:
            d["abbr"].add("".join(w[0] for w in pid.split()))
    return out


def _resolve(name: str, parties: dict[str, dict]) -> str | None:
    k, a = key(name), _ascii(name).strip()
    if k in parties:
        return k
    plural = [pid for pid in parties if _plural(k, pid)]
    if len(plural) == 1:
        return plural[0]
    hits = [pid for pid, d in parties.items() if a in d["abbr"] or (abbreviation(name) and abbreviation(name) in d["abbr"])]
    if len(hits) == 1:
        return hits[0]
    words = set(k.split())
    hits = [pid for pid, d in parties.items() if words and words <= d["words"]]
    return hits[0] if len(hits) == 1 else None
