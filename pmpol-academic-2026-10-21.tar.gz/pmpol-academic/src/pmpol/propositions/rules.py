"""The inference rules of the proposition ontology, declared in config/inference_rules.toml.

Each derived relation names its rule (its `basis`), and each rule names its grounds: a probability axiom
("axiom:<id>"), a knowledge-base fact ("kb:<id>"), a registered key assumption ("assumption:<id>"), or an L1
record kept outside the knowledge base ("data:candidates:<race>", pmpol.entities.candidates).
A relation can add grounds of its own (`Relation.grounds`), e.g. the seat count of the chamber in question.
Proofs turn every ground into a step, so the reasoning never rests on a rule written only in code.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[3] / "config" / "inference_rules.toml"


@dataclass(frozen=True)
class Axiom:
    id: str
    statement: str
    source: str


@dataclass(frozen=True)
class Rule:
    id: str
    label: str
    kind: str  # "equivalent" or "implies"
    statement: str
    logic: str = ""  # what it means for prices, shown in proofs
    grounds: tuple[str, ...] = ()
    instance_grounds: str = ""


@dataclass
class RuleBook:
    axioms: dict[str, Axiom] = field(default_factory=dict)
    rules: dict[str, Rule] = field(default_factory=dict)

    def rule(self, basis: str) -> Rule | None:
        return self.rules.get(basis)

    def grounds(self, basis: str, extra: tuple[str, ...] = ()) -> list[str]:
        r = self.rules.get(basis)
        return list(dict.fromkeys((r.grounds if r else ()) + tuple(extra)))


@lru_cache(maxsize=1)
def load(path: Path = CONFIG) -> RuleBook:
    with open(path, "rb") as f:
        raw = tomllib.load(f)
    book = RuleBook()
    for a in raw.get("axiom", []):
        book.axioms[a["id"]] = Axiom(a["id"], a["statement"], a.get("source", ""))
    for r in raw.get("rule", []):
        book.rules[r["id"]] = Rule(r["id"], r["label"], r["kind"], r["statement"], r.get("logic", ""),
                                   tuple(r.get("grounds", [])), r.get("instance_grounds", ""))
    return book


def validate(book: RuleBook, kb=None, assumptions: dict | None = None) -> list[str]:
    """Problems: unknown ground kinds, axioms, facts or assumptions; rules without a ground."""
    if assumptions is None:
        from pmpol.assumptions import load as load_assumptions

        assumptions = load_assumptions()
    out = []
    for r in book.rules.values():
        if r.kind not in ("equivalent", "implies"):
            out.append(f"{r.id}: kind {r.kind}")
        if not r.grounds:
            out.append(f"{r.id}: no grounds")
        for g in r.grounds:
            out += check_ground(g, book, kb, assumptions, r.id)
    return out


def check_ground(g: str, book: RuleBook, kb, assumptions: dict, where: str = "") -> list[str]:
    kind, _, ref = g.partition(":")
    if kind == "axiom" and ref not in book.axioms:
        return [f"{where}: unknown axiom {ref}"]
    if kind == "kb" and kb is not None and ref not in kb.facts:
        return [f"{where}: unknown fact {ref}"]
    if kind == "assumption" and ref not in assumptions:
        return [f"{where}: unknown assumption {ref}"]
    if kind == "data" and not ref:
        return [f"{where}: empty data ground"]
    if kind not in ("axiom", "kb", "assumption", "data"):
        return [f"{where}: unknown ground {g}"]
    return []
