"""Official statistics and policy rates as propositions: indicator(series|period) ∈ set of grid steps.

These series are published on a fixed grid, so every label on every venue is a set of grid steps:

  US CPI, core CPI (MoM, YoY), U-3 unemployment rate   one decimal, step 0.1 (percent)
  Fed decision at one FOMC meeting                     change of the target range's upper bound, step 25 bp
  Fed upper bound at the end of a year                 step 0.25 (percent)

  Kalshi "Above 0.1%" (strike greater 0.1)   -> published value >= 0.2 -> steps [2, ∞)
  Polymarket "0.6%+"                         -> steps [6, ∞)
  Kalshi "Exactly 0.3%", Polymarket "0.3%"   -> step [3, 4)
  Kalshi "Cut >25bps", Polymarket "50+ bps decrease" -> steps (-∞, -1)

  US real GDP growth (quarterly, annualised)            one decimal, step 0.1 (percent)
  Brazil IPCA, 12-month change (IBGE)                   two decimals, step 0.01 (percent); a calendar year's
                                                        "annual inflation" is the 12 months ending December

Precision first: a series is recognised only from a known title pattern and, for agency series, rules that
name the agency (BLS, BEA) (other countries' CPI and "core goods" CPI are different series).
Which release is used (first print or revised) is a resolution detail and kept as a note.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from datetime import date

from pmpol.models import Event, Market
from pmpol.propositions import INF, Parsed, Prop, Span, Var

_MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
_MON = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?"


@dataclass(frozen=True)
class Series:
    key: str  # "us_cpi_mom", ...
    step: float  # grid step in the label's unit
    unit: str  # "pct" or "bp"
    source: str = ""  # regex the rules must match (the statistical agency), for venues other than Kalshi
    kalshi_too: bool = False  # the rules of Kalshi's markets must match `source` as well


_BLS = r"bureau of labor statistics|\bbls\b"
_BEA = r"bureau of economic analysis|\bbea\b"
SERIES = {
    "us_cpi_mom": Series("us_cpi_mom", 0.1, "pct", _BLS),
    "us_core_cpi_mom": Series("us_core_cpi_mom", 0.1, "pct", _BLS),
    "us_cpi_yoy": Series("us_cpi_yoy", 0.1, "pct", _BLS),
    "us_core_cpi_yoy": Series("us_core_cpi_yoy", 0.1, "pct", _BLS),
    "us_unemployment": Series("us_unemployment", 0.1, "pct", _BLS),
    "us_real_gdp_qoq_saar": Series("us_real_gdp_qoq_saar", 0.1, "pct", _BEA),
    # other countries (2026-10-06): only where both venues' rules name the same measure. Kalshi's Brazil rules say
    # "12-month" or "annual inflation rate in Brazil"; Polymarket's name IBGE's IPCA.
    "br_ipca_12m": Series("br_ipca_12m", 0.01, "pct",
                          r"\bipca\b[\s\S]*\bibge\b|\bibge\b[\s\S]*\bipca\b|(?:12-month|annual) inflation rate in brazil", True),
    "fed_change": Series("fed_change", 25, "bp"),
    "fed_upper_end_of_year": Series("fed_upper_end_of_year", 0.25, "pct"),
}
# Other central banks' decisions (2026-10-05), on the same 25 bp grid as the Fed's.
BANKS = {"european central bank": "ecb", "ecb": "ecb", "bank of england": "boe", "bank of japan": "boj",
         "bank of mexico": "banxico", "bank of canada": "boc", "swiss national bank": "snb",
         "reserve bank of australia": "rba", "central bank of brazil": "bcb"}
SERIES.update({f"{b}_change": Series(f"{b}_change", 25, "bp") for b in set(BANKS.values())})
_BANK = "|".join(sorted(BANKS, key=len, reverse=True))

# (series, title pattern); the period comes from the month (group 1) and "year", from "q" and "year", or "eoy".
TITLES: list[tuple[str, str]] = [
    ("us_core_cpi_mom", rf"^cpi core month-over-month in {_MON} (?P<year>20\d\d)\??$"),
    ("us_cpi_mom", rf"^cpi month-over-month in {_MON} (?P<year>20\d\d)\??$"),
    ("us_core_cpi_yoy", rf"^cpi core year-over-year in {_MON} (?P<year>20\d\d)\??$"),
    ("us_cpi_yoy", rf"^cpi year-over-year in {_MON} (?P<year>20\d\d)\??$"),
    ("us_core_cpi_mom", rf"^cpi core in {_MON}$"),
    ("us_cpi_mom", rf"^cpi in {_MON}$"),
    ("us_cpi_mom", rf"^{_MON} inflation us - monthly$"),
    ("us_cpi_yoy", rf"^{_MON} inflation us - annual$"),
    ("us_core_cpi_mom", rf"^core cpi mom - {_MON} (?P<year>20\d\d)$"),
    ("us_core_cpi_yoy", rf"^core cpi yoy - {_MON} (?P<year>20\d\d)$"),
    ("us_unemployment", rf"^unemployment in {_MON}$"),
    ("us_unemployment", rf"^unemployment rate in {_MON} (?P<year>20\d\d)\??$"),
    ("us_unemployment", rf"^{_MON} unemployment rate$"),
    ("us_real_gdp_qoq_saar", r"^us (?:real )?gdp growth in q(?P<q>[1-4]) (?P<year>20\d\d)\??$"),
    ("br_ipca_12m", rf"^what will inflation in brazil be in {_MON} (?P<year>20\d\d)\??$"),
    ("br_ipca_12m", rf"^will inflation in brazil be (?:above|below) \d+(?:\.\d+)?% in {_MON} (?P<year>20\d\d)\??$"),
    ("br_ipca_12m", rf"^brazil inflation rate in {_MON}$"),
    ("br_ipca_12m", r"^brazil annual inflation (?P<ann>20\d\d)$"),
    ("fed_change", rf"^fed decision in {_MON}(?: (?P<year>20\d\d))?\??$"),
    ("bank_change", rf"^(?P<bank>{_BANK})(?: rate)? decision in {_MON}(?: (?P<year>20\d\d))?\??$"),
    ("fed_upper_end_of_year", r"^fed funds rate at end of (?P<eoy>20\d\d)$"),
    ("fed_upper_end_of_year", r"^what will the fed rate be at the end of (?P<eoy>20\d\d)\??$"),
]
_TITLES = [(s, re.compile(p, re.I)) for s, p in TITLES]

# Central-bank decision labels -> steps of 25 bp (a set of consecutive steps as a half-open span). "Cut 1-25bps" is
# one step down: changes off the 25 bp grid are a resolution detail (noted, not compared).
FED_LABELS: list[tuple[str, Span]] = [
    (r"^cut >25 ?bps$|^50\+ bps decrease$|^cut more than 25 ?bps$", Span(-INF, -1)),
    (r"^cut more than 50 ?bps$", Span(-INF, -2)),
    (r"^cut 50 ?bps$|^50 bps decrease$", Span(-2, -1)),
    (r"^cut 25 ?bps$|^25 bps decrease$|^cut 1-25 ?bps$", Span(-1, 0)),
    (r"^fed maintains rate$|^no change$|^maintains? (?:current )?rate$", Span(0, 1)),
    (r"^hike 25 ?bps$|^25 bps increase$|^hike 1-25 ?bps$", Span(1, 2)),
    (r"^hike >25 ?bps$|^50\+ bps increase$|^hike more than 25 ?bps$", Span(2, INF)),
    (r"^hike 50 ?bps$|^50 bps increase$", Span(2, 3)),
    (r"^hike more than 50 ?bps$", Span(3, INF)),
    (r"^25\+ bps increase$", Span(1, INF)),
    (r"^25\+ bps decrease$", Span(-INF, 0)),
]


def identify(e: Event) -> tuple[Series, str] | None:
    """(series, period) for an event whose title is a known pattern, else None."""
    title = re.sub(r"\s+", " ", e.title.replace("​", "")).strip()
    for key, pat in _TITLES:
        hit = pat.match(title)
        if not hit:
            continue
        s = SERIES[f"{BANKS[hit.group('bank').lower()]}_change"] if key == "bank_change" else SERIES[key]
        live = [m for m in e.markets if m.active]
        if s.source and not all((m.venue == "kalshi" and not s.kalshi_too) or re.search(s.source, (m.rules or "").lower())
                                for m in live):
            return None  # rules must name the source; Kalshi's terse ladders are checked by the title alone
        if s.source and s.key.startswith("us_") and re.search(r"core goods|supercore|japan|china|canada|euro|germany|"
                                                              r"brazil|u\.?k\.?\b", title, re.I):
            return None
        if hit.groupdict().get("eoy"):
            return s, f"end of {hit.group('eoy')}"
        if hit.groupdict().get("ann"):  # a calendar year's inflation: the 12 months ending December
            if not all(re.search(r"12-month period ending december|ending december", (m.rules or "").lower())
                       for m in live):
                return None
            return s, f"{hit.group('ann')}-12"
        if hit.groupdict().get("q"):
            return s, f"{hit.group('year')}-Q{hit.group('q')}"
        month = _MONTHS[next(g for g in hit.groups() if g and g[:3].lower() in _MONTHS)[:3].lower()]
        year = int(hit.group("year")) if hit.groupdict().get("year") else _year_from_close(live, month)
        if year is None:
            return None
        return s, f"{year}-{month:02d}"
    return None


def _year_from_close(markets: list[Market], month: int) -> int | None:
    """Release or meeting month -> year, from the close time: data for a month is released after it, so a
    December period closes in January of the next year."""
    closes = {m.close_time[:10] for m in markets if m.close_time}
    if len(closes) != 1:
        return None
    c = date.fromisoformat(closes.pop())
    return c.year if month <= c.month else c.year - 1


def _k(x: float, step: float) -> int:
    k = x / step
    if abs(k - round(k)) > 1e-6:
        raise ValueError("off grid")
    return int(round(k))


def label_span(m: Market, s: Series) -> Span | None:
    """Grid steps for one market, from the venue's strike fields or its label. None if not understood."""
    lab = re.sub(r"\s+", " ", m.outcome.replace("​", "").replace("–", "-").replace("—", "-")).strip()
    try:
        if s.key.endswith("_change"):
            for pat, span in FED_LABELS:
                if re.match(pat, lab, re.I):
                    return span
            return None
        st = s.step
        if m.venue == "kalshi" and m.strike_type in ("greater", "greater_or_equal", "less", "less_or_equal", "between"):
            f, c = m.floor_strike, m.cap_strike
            if m.strike_type == "greater":
                return Span(_k(f, st) + 1, INF)
            if m.strike_type == "greater_or_equal":
                return Span(_k(f, st), INF)
            if m.strike_type == "less":
                return Span(-INF, _k(c, st))
            if m.strike_type == "less_or_equal":
                return Span(-INF, _k(c, st) + 1)
            return Span(_k(f, st), _k(c, st) + 1)
        n = r"(-?\d+(?:\.\d+)?)\s*%?"
        t = lab.lower()
        for pat, make in (
            (rf"^exactly {n}$", lambda a: Span(_k(a, st), _k(a, st) + 1)),
            (rf"^{n}$", lambda a: Span(_k(a, st), _k(a, st) + 1)),
            (rf"^(?:≤|<=) ?{n}$", lambda a: Span(-INF, _k(a, st) + 1)),
            (rf"^< ?{n}$", lambda a: Span(-INF, _k(a, st))),
            (rf"^{n} ?\+$", lambda a: Span(_k(a, st), INF)),
            (rf"^(?:≥|>=) ?{n}$", lambda a: Span(_k(a, st), INF)),
            (rf"^above {n}$", lambda a: Span(_k(a, st) + 1, INF)),
        ):
            hit = re.match(pat, t)
            if hit:
                return make(float(hit.group(1)))
        hit = re.match(rf"^{n} ?(?:-|to) ?{n}$", t)
        if hit and "higher range bracket" in (m.rules or "").lower():  # "0.5-1.0%", 1.0 belongs to "1.0-1.5%"
            return Span(_k(float(hit.group(1)), st), _k(float(hit.group(2)), st))
        if hit:  # "2.0-2.4%" on a 0.1 grid: both ends included
            return Span(_k(float(hit.group(1)), st), _k(float(hit.group(2)), st) + 1)
    except (ValueError, TypeError):
        return None
    return None


def _notes(m: Market, s: Series) -> tuple[str, ...]:
    r = (m.rules or "").lower()
    out = []
    if s.source:
        out.append("release: first print" if re.search(r"first (?:value )?(?:published|release|non-preliminary)|"
                                                       r"advance estimate", r)
                   else "release: first print or revision not stated")
    if s.key == "br_ipca_12m" and "ipca" not in r:
        out.append("index: the rules say the 12-month (annual) inflation rate in Brazil without naming IPCA")
    if s.key == "fed_upper_end_of_year":
        out.append("timing: in effect on December 31" if "december 31" in r
                   else "timing: after the December FOMC meeting" if "december" in r and "meeting" in r
                   else "timing: not stated")
    if s.key.endswith("_change"):
        out.append("changes off the 25 bp grid and cancelled meetings: rules differ by venue, not compared")
    return tuple(out)


def parse_indicator(e: Event, out: Parsed) -> bool:
    """Propositions for an indicator event; False when the event is not one."""
    got = identify(e)
    if got is None:
        return False
    s, period = got
    var = Var("indicator", f"{s.key}|{period}", f"{s.unit}, step {s.step:g}")
    for m in e.markets:
        if not m.active:
            continue
        span = label_span(m, s)
        if span is None or (math.isinf(span.lo) and math.isinf(span.hi)):
            out.unparsed[m.key] = f"indicator label not understood ({s.key})"
            continue
        if span.lo == -INF:
            span = Span(-INF, span.hi, False, False)
        out.props.append(Prop(var, m.key, e.key, f"indicator_{s.key}", spans=(span,), notes=_notes(m, s)))
    return True
