"""Proposition ontology (experimental prototype; design in docs/PROPOSITION_ONTOLOGY.md).

Every market is read as a proposition about one world variable: "variable X takes a value in set S".

  Variable     kind + subject + qualifier, e.g. margin(US|NY-02|house|2026|general, D)
  Value set    a union of intervals (numbers, counts, dates) or a set of categories (party, person)
  Resolution   what the rules say about boundaries, sources and timing, kept next to the proposition

Relations between markets are then set algebra instead of hand-written templates: equal sets are
equivalent, a subset implies its superset, disjoint pieces that tile a set add up to it. Relations
between different variables come from a short list of bridge rules (for example "a party wins the
race exactly when its margin is above 0").

Not wired into the pipeline: `pmpol propositions` runs it on a snapshot and reports coverage and how
its relations compare with the hand-written templates in pmpol.universe.relations.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

INF = math.inf

# kind -> domain type
KINDS = {
    "winner": "category",  # who wins a contest (a party or a person)
    "control": "category",  # which party controls a chamber
    "nominee": "category",  # who a party nominates
    "margin": "real",  # winner's vote share minus runner-up's, in points, signed by party
    "vote_share": "real",  # one candidate's or list's share of the vote, in percent
    "turnout": "real",  # total votes cast
    "seats": "integer",  # seats a party wins or holds
    "event_time": "date",  # when something happens (days since 0001-01-01)
    "indicator": "integer",  # an official statistic or policy rate, in steps of its publication grid
    # Conjunction of categorical variables: values are tuples ("party:D,party:R"); the components are named in
    # the qualifier ("control:US|house|2026;control:US|senate|2026"), so marginals can be bridged.
    "joint": "category",
    # Generic forms for questions no specific kind reads (2026-10-04): the subject is the bag of title words
    # (years kept), so cross-venue matches are by title and carry the "title" confidence (never used for consensus).
    "quantity": "real",  # a number in a range read from the option label ("Above 3%", "2.2M-2.4M")
    "choice": "category",  # one option of a mutually exclusive question ("Who will be ...?")
    # The set of parties in the next government formed (2026-10-06, pmpol.propositions.cabinet): "has:<party>" for
    # one party's membership, "is:<a>+<b>" for the exact coalition.
    "cabinet": "category",
}
GENERIC = ("quantity", "choice")


@dataclass(frozen=True)
class Var:
    kind: str
    subject: str  # contest key, chamber key, or a normalised description of the event
    qualifier: str = ""  # party for margin and seats, who for vote_share

    @property
    def id(self) -> str:
        return f"{self.kind}({self.subject}{', ' + self.qualifier if self.qualifier else ''})"


@dataclass(frozen=True, order=True)
class Span:
    """One interval of the real line. Integer and date values use half-open spans [a, b+1)."""
    lo: float
    hi: float
    lo_closed: bool = True
    hi_closed: bool = False

    def contains(self, o: "Span") -> bool:
        lo_ok = self.lo < o.lo or (self.lo == o.lo and (self.lo_closed or not o.lo_closed))
        hi_ok = o.hi < self.hi or (o.hi == self.hi and (self.hi_closed or not o.hi_closed))
        return lo_ok and hi_ok

    def overlaps(self, o: "Span") -> bool:
        if self.hi < o.lo or o.hi < self.lo:
            return False
        if self.hi == o.lo:
            return self.hi_closed and o.lo_closed
        if o.hi == self.lo:
            return o.hi_closed and self.lo_closed
        return True

    def __str__(self) -> str:
        def f(x):
            return "∞" if x == INF else "-∞" if x == -INF else f"{x:g}"
        return f"{'[' if self.lo_closed else '('}{f(self.lo)}, {f(self.hi)}{']' if self.hi_closed else ')'}"


def normalize(spans) -> tuple[Span, ...]:
    """Sorted, merged union of spans (touching spans merge when one side is closed at the joint)."""
    out: list[Span] = []
    for s in sorted(spans, key=lambda s: (s.lo, not s.lo_closed)):
        if out:
            p = out[-1]
            if s.lo < p.hi or (s.lo == p.hi and (p.hi_closed or s.lo_closed)):
                hi, hc = (p.hi, p.hi_closed) if (p.hi > s.hi or (p.hi == s.hi and p.hi_closed)) else (s.hi, s.hi_closed)
                out[-1] = Span(p.lo, hi, p.lo_closed, hc)
                continue
        out.append(s)
    return tuple(out)


def subset(a: tuple[Span, ...], b: tuple[Span, ...]) -> bool:
    return all(any(t.contains(s) for t in b) for s in a)


@dataclass(frozen=True)
class Prop:
    var: Var
    market: str  # market key
    event: str  # event key
    rule: str  # parser rule that produced it (for audit)
    spans: tuple[Span, ...] = ()  # numeric kinds
    values: frozenset = frozenset()  # categorical kinds: "party:D", "person:jd vance"
    notes: tuple[str, ...] = ()  # resolution details that matter for cross-venue equivalence
    person: str = ""  # who the label names, for winner and nominee props ("person:Q123"); set by derive.parse_universe

    @property
    def venue(self) -> str:
        return self.market.split(":", 1)[0]

    def text(self) -> str:
        if self.spans:
            return f"{self.var.id} ∈ {' ∪ '.join(map(str, self.spans))}"
        return f"{self.var.id} ∈ {{{', '.join(sorted(self.values))}}}"


@dataclass
class Parsed:
    props: list[Prop] = field(default_factory=list)
    unparsed: dict[str, str] = field(default_factory=dict)  # market key -> reason
