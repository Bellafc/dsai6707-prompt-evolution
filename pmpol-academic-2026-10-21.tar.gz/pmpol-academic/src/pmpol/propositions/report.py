"""Trial report: how much of the universe the proposition ontology can read, how its relations compare
with the hand-written templates, and which new relations it finds."""

from __future__ import annotations

import re

from collections import Counter, defaultdict

from pmpol.models import Relation
from pmpol.propositions import Prop
from pmpol.propositions.derive import Comparison, Derived, compare, derive, direct, parse_universe, violations
from pmpol.universe.index import Universe
from pmpol.venues import info

KIND_ZH = {"winner": "勝選", "control": "控制權", "nominee": "提名", "margin": "勝差", "vote_share": "得票率",
           "turnout": "投票數", "seats": "席次", "event_time": "發生時間", "joint": "組合", "quantity": "數值（通用）", "choice": "選項（通用）", "cabinet": "政府組成"}
BASIS_ZH = {"same_set": "集合相同（等價）", "subset": "子集合（蘊含）", "cover": "區間拼起來等於另一個（加總）",
            "bridge_margin_winner": "橋接：勝差 ≥ 0 ⇔ 勝選", "bridge_person_party": "橋接：候選人 ⇔ 政黨",
            "bridge_joint_marginal": "橋接：組合格子加總 = 單項"}


def _basis_zh(basis: str) -> str:
    from pmpol.propositions.rules import load

    r = load().rule(basis)
    return BASIS_ZH.get(basis) or (r.label if r else basis)


def run(u: Universe, templates: list[Relation], index=None, wd_people=(), candidacies=()):
    parsed = parse_universe(u, index, wd_people, candidacies)
    derived = derive(u, parsed.props)
    comp = compare(u, templates, parsed.props, derived)
    return parsed, derived, comp, violations(u, comp.new)


_NOTE_ZH = {"window start": "計算窗起點", "announcement": "宣布就算或要實際離職"}


def rule_differences(notes: list[str]) -> str:
    """Resolution attributes read on both sides with different values ("window start: market creation" on one
    leg, "window start: not stated in the rules" on the other)."""
    seen: dict[str, set[str]] = {}
    for n in notes:
        head, sep, value = n.partition(": ")
        if sep and head in _NOTE_ZH:
            seen.setdefault(head, set()).add(value)
    return "；".join(f"{_NOTE_ZH[h]}不同（{' / '.join(sorted(v))}）" for h, v in sorted(seen.items()) if len(v) > 1)


def _legs(u: Universe, keys: list[str]) -> str:
    shown = "、".join(f"{info(k.split(':', 1)[0]).code} {u.markets[k].outcome}" for k in keys[:3])
    return shown + (f" 等 {len(keys)} 個" if len(keys) > 3 else "")


_HOW_ZH = {"entity index": "實體索引（congress-legislators、OpenSanctions）",
           "Wikidata: holds or held this office": "Wikidata：擔任或擔任過這場選舉的職位",
           "Wikidata: the only living politician of this name in the country": "Wikidata：全國性選舉，該國唯一同名的政治人物",
           "local": "本地身分（這場選舉＋全名）"}


def people_section(u: Universe, parsed) -> list[str]:
    """How person labels got their identities (pmpol.propositions.people)."""
    how: Counter = Counter()
    labels_of: dict[str, set[str]] = defaultdict(set)
    for p in parsed.props:
        if not p.person:
            continue
        note = next((n[10:] for n in p.notes if n.startswith("identity: ")), "")
        how[next((k for k in _HOW_ZH if note.startswith(k)), "local")] += 1
        labels_of[p.person].add(u.markets[p.market].outcome)
    if not labels_of:
        return []
    qids = [k for k in labels_of if k.startswith("person:Q")]
    merged = sorted(((k, ls) for k, ls in labels_of.items() if len({_base(x) for x in ls}) > 1),
                    key=lambda t: -len(t[1]))
    unread = Counter(r for r in parsed.unparsed.values() if "one person" in r or "name" in r and "person" in r)
    L = ["## 1b. 人的身分（實體層）", "",
         f"人名選項 {sum(how.values()):,} 個，對應到 **{len(labels_of):,}** 個人；其中 **{len(qids):,}** 人有 Wikidata QID。"
         "規則見 `src/pmpol/propositions/people.py`：只有在證據夠強時才接 QID（名字相同不算證據），"
         "其餘用「這場選舉＋全名」；同一場選舉裡寫法不同的同一人（暱稱、縮寫、Jr.）會合併，"
         "但同一事件同時列出的兩個選項、中間名縮寫不同的名字、兩個不同的 QID 永遠不合併。", "",
         "| 身分來源 | 選項數 |", "|---|---|"]
    L += [f"| {_HOW_ZH[k]} | {n:,} |" for k, n in how.most_common()]
    L += ["", f"寫法不同、合併成同一人的：{len(merged):,} 人。例如：", ""]
    L += [f"- {' ／ '.join(sorted(ls)[:4])}（{k[7:] if k.startswith('person:Q') else '本地身分'}）" for k, ls in merged[:10]]
    if unread:
        L += ["", "因身分問題沒有讀的：" + "；".join(f"{r}（{n}）" for r, n in unread.most_common())]
    L.append("")
    return L


def _base(label: str) -> str:
    return re.sub(r"\s*\(.*?\)", "", label).strip()


def render(u: Universe, parsed, derived: list[Derived], comp: Comparison, viol: list[tuple[float, Derived]],
           generated_at: str, observed_at: str = "") -> str:
    prop_of: dict[str, Prop] = {p.market: p for p in parsed.props}
    L = [f"# 命題本體：覆蓋率與模板交叉驗證 — {generated_at}", "",
         "命題本體是主流程的關係來源（2026-10-03 起，設計見 `docs/PROPOSITION_ONTOLOGY.md`）；這份報告是覆蓋率、讀不懂的原因、"
         "和手寫模板交叉驗證的細節。"
         "每個市場讀成「某個世界變數落在某個集合」，關係用集合運算推出來，再和現有的 11 個手寫模板比對。"
         + (f" 報價時間：{observed_at}。" if observed_at else ""), ""]

    by_measure: dict[str, Counter] = defaultdict(Counter)
    reasons: dict[str, Counter] = defaultdict(Counter)
    for k, e in u.events.items():
        t = u.tags[k]
        for m in e.markets:
            if not m.active:
                continue
            key = f"{t.topic}／{t.measure}"
            by_measure[key]["markets"] += 1
            if m.key in prop_of:
                by_measure[key]["parsed"] += 1
            elif m.key in parsed.unparsed:
                reasons[key][parsed.unparsed[m.key]] += 1
    total = sum(c["markets"] for c in by_measure.values())
    done = sum(c["parsed"] for c in by_measure.values())
    L += ["## 1. 覆蓋率", "", f"有效市場 {total:,} 個，讀成命題的 {done:,} 個（{done / total:.0%}）。"
          "下表是市場數最多的 20 種（主題／問題類型）。", "",
          "| 主題／類型 | 市場 | 讀成命題 | 比例 | 最常見的未讀原因 |", "|---|---|---|---|---|"]
    for key, c in sorted(by_measure.items(), key=lambda t: -t[1]["markets"])[:20]:
        why = reasons[key].most_common(1)
        L.append(f"| {key} | {c['markets']:,} | {c['parsed']:,} | {c['parsed'] / c['markets']:.0%} | "
                 f"{why[0][0] + f'（{why[0][1]:,}）' if why else ''} |")
    kinds = Counter(p.var.kind for p in parsed.props)
    L += ["", "依變數種類：" + "、".join(f"{KIND_ZH.get(k, k)} {n:,}" for k, n in kinds.most_common()), ""]

    n_t = len(comp.agree) + len(comp.disagree) + len(comp.not_covered)
    L += people_section(u, parsed)

    L += ["## 2. 和手寫模板比對", "",
          f"現有模板產生 {n_t:,} 條關係。本體推出相同結論的 **{len(comp.agree):,}**（{len(comp.agree) / n_t:.1%}），"
          f"結論不同的 **{len(comp.disagree):,}**，本體還讀不懂的 {len(comp.not_covered):,}。", "",
          "| 模板 | 一致 | 不同 | 讀不懂 |", "|---|---|---|---|"]
    tpl = defaultdict(Counter)
    for r in comp.agree:
        tpl[r.template]["agree"] += 1
    for r, _ in comp.disagree:
        tpl[r.template]["disagree"] += 1
    for r, _ in comp.not_covered:
        tpl[r.template]["nc"] += 1
    for t, c in sorted(tpl.items(), key=lambda t: -sum(t[1].values())):
        L.append(f"| {t} | {c['agree']:,} | {c['disagree']:,} | {c['nc']:,} |")
    L += ["", "**結論不同的例子**（人工判斷誰對）：", ""]
    seen = set()
    for r, why in comp.disagree:
        sig = (u.markets[r.lhs[0]].outcome, u.markets[r.rhs[0]].outcome)
        if sig in seen:
            continue
        seen.add(sig)
        L.append(f"- `{r.template}`（配對：{r.confidence}）{r.group}：{_legs(u, r.lhs)} ＝ {_legs(u, r.rhs)} → 本體：{why}")
        if len(seen) >= 12:
            break
    nc = Counter(why.split(":")[0] for _, why in comp.not_covered)
    L += ["", "讀不懂的原因：" + "；".join(f"{w}（{n:,}）" for w, n in nc.most_common(5)), ""]

    short = direct(comp.new, parsed.props)
    cats = Counter((d.var.split("(")[0], d.basis, d.cross_venue) for d in comp.new)
    cats_direct = Counter((d.var.split("(")[0], d.basis, d.cross_venue) for d in short)
    L += ["## 3. 模板沒有、本體推出來的關係", "",
          f"共 {len(comp.new):,} 條；其中**直接關係 {len(short):,} 條**。其餘可以由更直接的關係加上同一事件內的階梯推得"
          "（例如「贏 20 點以上 ⇒ 勝選」可以由「贏 20 點以上 ⇒ 贏 10 點以上（同一事件）⇒ 勝選」推得；"
          "或某個勝差區間 ⇒ 勝選，而這個事件的區間加總已經等於勝選）。違反仍然檢查全部的關係，"
          "因為有買賣價差，推得的關係可能違反、它的每一段卻不違反。", "",
          "| 變數 | 推理方式 | 跨平台 | 條數 | 直接關係 |", "|---|---|---|---|---|"]
    for (k, b, x), n in cats.most_common(15):
        L.append(f"| {KIND_ZH.get(k, k)} | {_basis_zh(b)} | {'是' if x else '否'} | {n:,} | {cats_direct[(k, b, x)]:,} |")
    L += ["", f"### 扣費後按可執行價計算的違反：{len(viol):,} 條", "",
          "和模板用同一個檢查（`relations.check`）。**跨平台的結算規則還沒有比對，而且不同地區的平台通常無法兩邊交易**，"
          "所以這些是待人工確認的不一致，不是套利。", "",
          "「已讀出的規則差異」只列原型讀得出來的部分（目前是截止日題的計算窗起點、「宣布離職算不算」），沒列不代表規則相同。", "",
          "| 邊際（點） | 變數 | 推理 | 一邊 | 另一邊 | 已讀出的規則差異 |", "|---|---|---|---|---|---|"]
    for edge, d in viol[:20]:
        L.append(f"| {100 * edge:+.1f} | {d.var[:60]} | {_basis_zh(d.basis)} | {_legs(u, d.lhs)} | "
                 f"{_legs(u, d.rhs)} | {rule_differences(d.notes) or '—'} |")
    L.append("")
    return "\n".join(L)
