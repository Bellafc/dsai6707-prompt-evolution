"""Relations from propositions: set algebra within one variable, plus bridge rules across variables.

Within a variable (same kind, subject, qualifier):
  equal sets      -> equivalent
  A subset of B   -> A implies B
  disjoint pieces of one event that tile B exactly -> sum of the pieces equals B
Across variables (bridge rules, each a definition or an L0 rule):
  winner(c) = party p   <=>  margin(c, p) >= 0          (ties ignored)
  winner(c) = person x  <=>  winner(c) = party p        when x is p's only candidate (not a top-two state)
Only pairs from different events are emitted; ladders inside one event are pmpol.constraints' job.
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field, replace
from itertools import combinations

from pmpol.models import Relation
from pmpol.propositions import GENERIC, INF, KINDS, Prop, Span, Var, normalize, subset
from pmpol.propositions.describe import complete, describe
from pmpol.propositions.parse import Parsed, merged, parse_event
from pmpol.universe.index import Universe

WINS = (Span(0, INF, True, False),)  # margin of party p >= 0  <=>  p wins (ties ignored)


@dataclass
class Derived:
    kind: str  # "equivalent" or "implies"
    lhs: list[str]
    rhs: list[str]
    var: str  # variable id (lhs side)
    basis: str  # the inference rule (config/inference_rules.toml): "same_set", "subset", "bridge_margin_winner", ...
    cross_venue: bool
    notes: list[str] = field(default_factory=list)
    grounds: list[str] = field(default_factory=list)  # grounds of this relation beyond its rule's ("kb:us.house.majority")

    def key(self) -> tuple:
        if self.kind == "equivalent":
            return ("equivalent", frozenset({frozenset(self.lhs), frozenset(self.rhs)}))
        return ("implies", frozenset(self.lhs), frozenset(self.rhs))


def parse_universe(u: Universe, index=None, wd_people=(), candidacies=()) -> Parsed:
    """Propositions for every event, leaving out events whose labels look swapped (as the pipeline does).

    People get identities from pmpol.propositions.people: Wikidata QIDs with evidence from the entity `index`
    (pmpol.entities.graph.EntityIndex), `wd_people` (pmpol.entities.wd_peps) and `candidacies`
    (pmpol.entities.wikidata), else race + full name."""
    from pmpol.universe.quality import suspect_label_swaps

    suspects = suspect_label_swaps(u)
    out = Parsed()
    for k, e in u.events.items():
        if k in suspects:
            out.unparsed.update({m.key: "event excluded: labels look swapped (universe/quality.py)" for m in e.markets})
            continue
        t = u.tags[k]
        got = parse_event(e, t, u.candidate_parties(t.race_key) if t.race_key else {})
        out.props += got.props
        out.unparsed.update(got.unparsed)
    from pmpol.propositions.cabinet import resolve as resolve_cabinets

    out.props = resolve_cabinets(out.props, out.unparsed)  # party names across venues, coalition members
    out.props = _complete_descriptors(u, out.props, index)
    out.props = _identify_people(u, out, index, wd_people, candidacies)
    out.props = _drop_ambiguous_people(out)
    return out


def _identify_people(u: Universe, parsed: Parsed, index, wd_people, candidacies=()) -> list[Prop]:
    from pmpol.propositions.parse import name_key
    from pmpol.propositions.people import Label, identify, parse_name

    labels, unnamed = [], set()
    for p in parsed.props:
        if p.var.kind not in ("winner", "nominee"):
            continue
        label = u.markets[p.market].outcome
        v = next(iter(p.values))
        if not (v.startswith("person:") or (v.startswith("party:") and name_key(label))):
            continue
        n = parse_name(label)
        if n is None:
            if v.startswith("person:"):
                unnamed.add(p.market)
            continue
        t = u.tags[p.event]
        national = t.office in ("president", "head_of_government")
        labels.append(Label(p.market, p.event, p.var.subject, t.race_key, national, n, t.country, t.office,
                            t.jurisdiction))
    ids = identify(labels, index, wd_people, candidacies)
    out = []
    for p in parsed.props:
        if p.market in unnamed:
            parsed.unparsed[p.market] = "person label not understood as a name"
            continue
        if p.market in ids.unread:
            parsed.unparsed[p.market] = ids.unread[p.market]
            continue
        who = ids.of.get(p.market)
        if who is not None:
            person = f"person:{who}"
            note = (f"identity: {ids.how[p.market]}",)
            if next(iter(p.values)).startswith("person:"):
                p = replace(p, values=frozenset({person}), person=person, notes=p.notes + note)
            else:
                p = replace(p, person=person, notes=p.notes + note)
        out.append(p)
    return out


def _drop_ambiguous_people(parsed: Parsed) -> list[Prop]:
    """Two options of one event with the same person key are two people with one name (Alaska 2026: "Dan
    Sullivan" and "Daniel J. Sullivan"); that key then names nobody for sure anywhere in the race."""
    seen: dict[tuple[str, str, str], int] = defaultdict(int)
    for p in parsed.props:
        if p.var.kind == "winner":
            for v in p.values:
                if v.startswith("person:"):
                    seen[(p.var.subject, p.event, v)] += 1
    ambiguous = {(subj, v) for (subj, _, v), n in seen.items() if n > 1}
    keep = []
    for p in parsed.props:
        if p.var.kind == "winner" and any((p.var.subject, v) in ambiguous for v in p.values):
            parsed.unparsed[p.market] = "two people with one name key in this race"
            continue
        keep.append(p)
    return keep


def _complete_descriptors(u: Universe, props: list[Prop], index=None) -> list[Prop]:
    """Give event_time variables their standard descriptor: the people in it as entities (pmpol.entities: "Trump",
    "Donald Trump" and "President Trump" are one Wikidata QID) when the entity index identifies them, then the
    completed descriptor ("Warsh out" -> "Kevin Warsh out") when the completion is unique in the snapshot
    (pmpol.propositions.describe.complete). Descriptors are per market: a question whose options are the arguments
    has one descriptor per option."""
    from pmpol.propositions.describe import option_sentence

    descs, texts = {}, {}
    for p in props:
        if p.var.kind != "event_time":
            continue
        title = u.events[p.event].title
        text = option_sentence(title, u.markets[p.market].outcome) if p.rule.startswith("time_option_") else title
        if text and (d := describe(text)):
            descs[p.market], texts[p.market] = d, text
    who: dict[str, list[str]] = {}
    if index is not None:
        event_of = {p.market: p.event for p in props}
        names = people_names({k: (d, texts[k], u.tags[event_of[k]]) for k, d in descs.items()}, index)
        for k, d in descs.items():
            descs[k], who[k] = with_people(d, names, index)
    done = complete(descs)
    out = []
    for p in props:
        if p.market in done and p.var.kind == "event_time" and done[p.market] != p.var.subject:
            note = "descriptor with people as entities" if who.get(p.market) else "descriptor completed from a longer title"
            p = replace(p, var=Var("event_time", done[p.market]),
                        notes=p.notes + (note,) + tuple(f"identity: {w}" for w in who.get(p.market, ())))
        out.append(p)
    return out


def entity_token(e) -> str | None:
    """"q:<QID>" for an entity with a Wikidata id (OpenSanctions ids are QIDs too: "os:Q16194176"), else
    "e:<entity id>" for one from an official roster; None for a name seen only in market labels."""
    if not (e.sources - {"markets"}):
        return None
    qid = e.wikidata or (e.id[3:] if re.match(r"^os:Q\d+$", e.id) else None)
    return f"q:{qid}" if qid else f"e:{e.id}"


def _name_words(name: str) -> set[str]:
    """Words of a name as descriptors write them (ASCII, lower case, hyphens split: "ching-te" -> ching, te)."""
    from pmpol.propositions.describe import _clean

    return set(re.sub(r"[^a-z0-9 ]", " ", _clean(name).lower()).split())


def people_names(titled: dict[str, tuple], index) -> dict[frozenset, str]:
    """Words of a descriptor -> the entity they name, learned over the whole snapshot.

    Each title goes through the precision-first linker (pmpol.entities.graph.EntityIndex.link_text: a full name,
    or the surname of a single prominent person) with the verb in lower case ("Trump Impeached?" is not a first
    name followed by a surname). Only people from an official roster count (Congress, the Plum Book, world
    leaders, Wikidata's leaders; never a name seen only in market labels). Without a country on the event both
    contexts are tried. Words that name two different people anywhere in the snapshot are dropped, so one
    spelling never links in one title and stays apart in another."""
    from pmpol.propositions.describe import _ACTIONS

    seen: dict[frozenset, set[str]] = defaultdict(set)
    for d, title, tags in titled.values():
        act = next((p.search(title) for a, p in _ACTIONS if a == d.action), None)
        text = title[:act.start()] + title[act.start():act.end()].lower() + title[act.end():] if act else title
        contexts = [tags.country == "United States"] if tags.country else [True, False]
        state = tags.jurisdiction[:2] if tags.country == "United States" and tags.jurisdiction else None
        plain = {w.lstrip("@") for w in d.bag}
        for us in contexts:
            for m in index.link_text(text, "title", us, state):
                e = index.entities[m.entity]
                hit = frozenset(w for w in plain if w in set().union(*(_name_words(a) for a in e.aliases)))
                if hit and entity_token(e):
                    seen[hit].add(m.entity)
    return {words: next(iter(ids)) for words, ids in seen.items() if len(ids) == 1}


def with_people(d, names: dict[frozenset, str], index):
    """The descriptor with every name from `names` it contains replaced by the entity token, on the same side of
    the verb; longer names first ("kim jong un" before "kim")."""
    from pmpol.propositions.describe import Desc

    bag, given, how = set(d.bag), set(d.given), []
    for words in sorted(names, key=len, reverse=True):
        for side in ("@", ""):
            hit = {side + w for w in words}
            if hit <= bag:
                e = index.entities[names[words]]
                bag = (bag - hit) | {side + entity_token(e)}
                given -= hit
                how.append(f"{e.name} = {entity_token(e)[2:]} ({', '.join(sorted(e.sources))})")
    return Desc(d.action, frozenset(bag), frozenset(given)), how

def _venue(key: str) -> str:
    return key.split(":", 1)[0]


def _rel(kind, lhs: list[Prop], rhs: list[Prop], basis: str) -> Derived:
    keys = [p.market for p in lhs + rhs]
    notes = sorted({n for p in lhs + rhs for n in p.notes})
    cross = len({_venue(k) for k in keys}) > 1
    if cross:
        notes.append("resolution rules across venues not compared")
    return Derived(kind, [p.market for p in lhs], [p.market for p in rhs], lhs[0].var.id, basis, cross, notes)


def derive(u: Universe, props: list[Prop], kb=None, candidates: dict | None = None) -> list[Derived]:
    """Relations between markets, each from one rule of config/inference_rules.toml. `kb` supplies the facts some
    rules depend on (election methods, chamber sizes); the knowledge base on disk when not given. `candidates`
    (race -> L1 general-election candidate list, pmpol.entities.candidates) grounds the person-party bridge."""
    if kb is None:
        from pmpol.kb import KnowledgeBase

        kb = KnowledgeBase.load()
    by_var: dict[Var, list[Prop]] = defaultdict(list)
    for p in props:
        by_var[p.var].append(p)
    out: list[Derived] = []
    for var, ps in by_var.items():
        generic = var.kind in GENERIC or (var.kind == "event_time" and " | " in var.subject)
        ok = (lambda a, b: _generic_pair(u, a, b)) if generic else (lambda a, b: True)
        if KINDS[var.kind] == "category":
            for a, b in combinations(ps, 2):
                if a.event != b.event and a.values == b.values and ok(a, b):
                    out.append(_rel("equivalent", [a], [b], "same_set"))
            continue
        by_event: dict[str, list[Prop]] = defaultdict(list)
        for p in ps:
            by_event[p.event].append(p)
        for a, b in combinations(ps, 2):
            if a.event == b.event or not ok(a, b):
                continue
            if a.spans == b.spans:
                out.append(_rel("equivalent", [a], [b], "same_set"))
            elif subset(a.spans, b.spans):
                out.append(_rel("implies", [a], [b], "subset"))
            elif subset(b.spans, a.spans):
                out.append(_rel("implies", [b], [a], "subset"))
        for b in ps:
            for ev, parts in by_event.items():
                if ev == b.event:
                    continue
                inside = [p for p in parts if subset(p.spans, b.spans) and p.spans != b.spans and ok(p, b)]
                if len(inside) >= 2 and _disjoint(inside) and merged(inside) == b.spans:
                    out.append(_rel("equivalent", inside, [b], "cover"))
    out += _bridges(u, by_var, kb, candidates or {})
    out += _winner_nominee(by_var)
    out += _seats_control(by_var, kb)
    out += _seat_boxes(by_var, kb)
    out += _action_entailments(by_var)
    out += _defined_sets(u, by_var)
    out += _majority_wins(u, by_var, kb)
    out += _cabinet(by_var)
    return out


def _cabinet(by_var: dict[Var, list[Prop]]) -> list[Derived]:
    """Next-government variables: a coalition that includes a party implies that party is in the government; the
    options of one coalition event are mutually exclusive, so those that include the party add up to no more than
    its membership (coalitions_contain_party). Equal memberships and equal coalitions are same_set."""
    out: list[Derived] = []
    for var, ps in by_var.items():
        if var.kind != "cabinet":
            continue
        members = [p for p in ps if next(iter(p.values)).startswith("has:")]
        coalitions: dict[str, list[Prop]] = defaultdict(list)
        for p in ps:
            if next(iter(p.values)).startswith("is:"):
                coalitions[p.event].append(p)
        for m in members:
            party = next(iter(m.values))[4:]
            for ev, cs in coalitions.items():
                inside = [c for c in cs if party in next(iter(c.values))[3:].split("+")]
                if len(inside) == 1:
                    out.append(_rel("implies", inside, [m], "subset"))
                elif inside:
                    out.append(_rel("implies", inside, [m], "coalitions_contain_party"))
    return out


def direct(derived: list[Derived], props: list[Prop]) -> list[Derived]:
    """Drop implications that follow from a tighter one plus a ladder inside one event.

    If "R wins by 20+" and "R wins by 10+" are rungs of one event and both imply "R wins" elsewhere, only the
    looser rung's implication is direct: the tighter one follows through the ladder (which pmpol.constraints
    checks). Likewise on the right-hand side, only the tightest implied rung of an event is kept, and a piece
    whose event already adds up to the target ("buckets sum to R wins") needs no implication of its own.
    Equivalences and covers are all kept. This is for reading and counting; violations are still checked on every relation,
    because bid/ask spreads mean an implied relation can be violated when its links are not.
    """
    prop_of = {p.market: p for p in props}

    def within(a: str, b: str) -> bool:  # spans of a strictly inside spans of b
        pa, pb = prop_of[a], prop_of[b]
        return bool(pa.spans) and bool(pb.spans) and pa.spans != pb.spans and subset(pa.spans, pb.spans)

    summed = {(k, d.rhs[0]) for d in derived if d.kind == "equivalent" and len(d.lhs) > 1 and len(d.rhs) == 1
              for k in d.lhs}
    single = [d for d in derived if d.kind == "implies" and len(d.lhs) == 1 and len(d.rhs) == 1
              and (d.lhs[0], d.rhs[0]) not in summed]
    rest = [d for d in derived if not (d.kind == "implies" and len(d.lhs) == 1 and len(d.rhs) == 1)]
    by_target: dict[tuple, list[Derived]] = defaultdict(list)
    for d in single:
        by_target[(prop_of[d.lhs[0]].event, d.rhs[0], d.basis)].append(d)
    loosest = [d for ds in by_target.values() for d in ds
               if not any(within(d.lhs[0], o.lhs[0]) for o in ds)]
    by_source: dict[tuple, list[Derived]] = defaultdict(list)
    for d in loosest:
        by_source[(d.lhs[0], prop_of[d.rhs[0]].event, d.basis)].append(d)
    tightest = [d for ds in by_source.values() for d in ds
                if not any(within(o.rhs[0], d.rhs[0]) for o in ds)]
    return rest + tightest


def _disjoint(ps: list[Prop]) -> bool:
    spans = [s for p in ps for s in p.spans]
    return all(not x.overlaps(y) for x, y in combinations(spans, 2))


def components(var: Var) -> list[Var]:
    """Component variables of a joint variable, from its qualifier ("control:US|house|2026;...", or with the
    component's own qualifier after "#": "seats:United States|US|senate|2026|general#D/held")."""
    out = []
    for c in var.qualifier.split(";"):
        kind, rest = c.split(":", 1)
        subject, _, qualifier = rest.partition("#")
        out.append(Var(kind, subject, qualifier))
    return out


def _cell(p: Prop) -> list[str]:
    return next(iter(p.values)).split(",")


def _joint_marginals(by_var: dict[Var, list[Prop]]) -> list[Derived]:
    """In one event listing every cell of a joint variable, the cells whose i-th component is p add up to
    "component i is p" (on any venue)."""
    out = []
    for var, ps in by_var.items():
        if var.kind != "joint" or var.subject.endswith("|seats"):  # seat boxes: _seat_boxes
            continue
        comps = components(var)
        by_event: dict[str, list[Prop]] = defaultdict(list)
        for p in ps:
            by_event[p.event].append(p)
        for cells in by_event.values():
            values = {next(iter(c.values)) for c in cells}
            if len(values) != len(cells) or len(cells) != 2 ** len(comps):  # need the full product, once each
                continue
            for i, comp in enumerate(comps):
                for party in {_cell(c)[i] for c in cells}:
                    legs = [c for c in cells if _cell(c)[i] == party]
                    for target in by_var.get(comp, []):
                        if target.values == {party}:
                            d = _rel("equivalent", legs, [target], "bridge_joint_marginal")
                            out.append(d)
    return out


def _election_methods(kb) -> dict[str, tuple[str, set[str] | None]] | None:
    """State -> (fact id, offices not decided by plurality; None = every office), from the L0 facts
    us.election.method.<state>; None when the knowledge base has no plurality rule (then the margin-winner bridge
    has no ground and is not applied)."""
    if kb is None or "us.election.general_plurality" not in kb.facts:
        return None
    out = {}
    for fid, f in kb.facts.items():
        if fid.startswith("us.election.method.") and isinstance(f.value, dict):
            offices = f.value.get("offices")
            out[fid.rsplit(".", 1)[-1].upper()] = (fid, None if offices in (None, "all") else set(offices))
    return out


def _bridges(u: Universe, by_var: dict[Var, list[Prop]], kb=None, candidates: dict | None = None) -> list[Derived]:
    out = _joint_marginals(by_var)
    methods = _election_methods(kb)
    winners: dict[str, list[Prop]] = defaultdict(list)
    for var, ps in by_var.items():
        if var.kind == "winner":
            winners[var.subject] += ps
    for var, ps in by_var.items():
        if var.kind != "margin":
            continue
        country, juris, office = (var.subject.split("|") + ["", "", ""])[:3]
        if methods is None or country != "United States":
            continue  # "margin > 0 <=> wins" holds only where the most votes win (L0); runoffs and RCV differ
        method = methods.get(juris[:2])
        if method and (method[1] is None or office in method[1] or (office == "house" and "house" in method[1])):
            continue
        state_ground = [f"kb:{method[0]}"] if method else []  # e.g. Maine: ranked choice only for federal offices
        targets = [w for w in winners.get(var.subject, []) if w.values == {f"party:{var.qualifier}"}]
        if not targets:
            continue
        by_event: dict[str, list[Prop]] = defaultdict(list)
        for p in ps:
            by_event[p.event].append(p)
        for w in targets:
            for p in ps:
                if _same_as_wins(normalize(p.spans)):  # "Republican wins" read as margin > 0
                    d = _rel("equivalent", [p], [w], "bridge_margin_winner")
                    d.notes.append("ties ignored")
                    d.grounds += state_ground
                    out.append(d)
                elif subset(p.spans, WINS):
                    d = _rel("implies", [p], [w], "bridge_margin_winner")
                    d.grounds += state_ground
                    out.append(d)
            for parts in by_event.values():
                if len(parts) >= 2 and _disjoint(parts) and _same_as_wins(merged(parts)):
                    d = _rel("equivalent", parts, [w], "bridge_margin_winner")
                    d.notes.append("ties ignored: buckets start at 0")
                    d.grounds += state_ground
                    out.append(d)
    # person <-> party: from the L1 candidate list of the race when we have one, else learned from labels like
    # "George Latimer (D)" in the same race (a registered assumption)
    for subject, ps in winners.items():
        out += person_party(u, subject, ps, (candidates or {}).get(subject))[0]
    return out


def person_party(u: Universe, subject: str, ps: list[Prop], listed=None) -> tuple[list[Derived], list[str]]:
    """Person-party bridges of one race, and the conflicts between labels and the L1 list that stopped one.

    With a list (`listed`, the race's general-election candidates): the label must match exactly one listed
    person, of the party the labels give, and that party must have exactly one listed candidate. Otherwise the
    bridge is not derived and the conflict is reported (precision first; sources are not resolved by choosing)."""
    cands = candidate_parties(u, ps)
    parties = {p.market: p for p in ps if next(iter(p.values)).startswith("party:")}
    out, conflicts = [], []
    for p in ps:
        v = next(iter(p.values))
        if not v.startswith("person:"):
            continue
        party = party_of_person(cands, v)
        targets = [q for q in parties.values() if party and q.values == {f"party:{party}"} and q.event != p.event]
        if not targets:
            continue
        grounds = ["assumption:labels_identify_party_candidate"]
        if listed is not None:
            from pmpol.entities.candidates import same_person

            label = u.markets[p.market].outcome
            match = [c for c in listed if same_person(label, c.name)]
            if len(match) != 1:
                conflicts.append(f"{subject}: {label} is {'not' if not match else 'ambiguously'} on the "
                                 f"general-election list ({', '.join(f'{c.name} ({c.party})' for c in listed)})")
                continue
            if match[0].party != party:
                conflicts.append(f"{subject}: labels give {label} party {party}, the list {match[0].party}")
                continue
            if sum(c.party == party for c in listed) != 1:
                conflicts.append(f"{subject}: party {party} has {sum(c.party == party for c in listed)} listed candidates")
                continue
            grounds = [f"data:candidates:{subject}"]
        for q in targets:
            d = _rel("equivalent", [p], [q], "bridge_person_party")
            d.grounds += grounds
            d.notes.append("candidate's party and sole candidacy from the L1 general-election list"
                           if grounds[0].startswith("data:") else
                           "candidate's party learned from venue labels in the same race (L4), not an L1 fact")
            out.append(d)
    return out, conflicts


def person_party_conflicts(u: Universe, props: list[Prop], candidates: dict) -> list[str]:
    """Where the L1 candidate lists contradict the venues' labels (each stopped a person-party bridge)."""
    winners: dict[str, list[Prop]] = defaultdict(list)
    for p in props:
        if p.var.kind == "winner":
            winners[p.var.subject].append(p)
    return [c for subject, ps in winners.items() if subject in candidates
            for c in person_party(u, subject, ps, candidates[subject])[1]]


def candidate_parties(u: Universe, winner_props: list[Prop]) -> dict[str, str]:
    """person value -> party, from party-valued winner props whose label names a person ("Fiona Ma (D)"),
    using the identities from pmpol.propositions.people (so "Michael Bouchard Jr." and "Mike Bouchard (R)" are
    one person, and Alaska's two Sullivans are two). A person seen with two parties, or a party with two
    people (top-two finalists of one party), is left out."""
    seen: dict[str, set[str]] = defaultdict(set)
    for p in winner_props:
        v = next(iter(p.values))
        if v.startswith("party:") and p.person:
            seen[p.person].add(v[6:])
    single = {k: next(iter(v)) for k, v in seen.items() if len(v) == 1}
    count = Counter(single.values())
    return {k: v for k, v in single.items() if count[v] == 1}


def party_of_person(cands: dict[str, str], value: str) -> str | None:
    return cands.get(value)


def _same_as_wins(spans: tuple[Span, ...]) -> bool:
    return len(spans) == 1 and spans[0].lo == 0 and spans[0].hi == INF


# --- comparison with the hand-written templates --------------------------------------

@dataclass
class Comparison:
    agree: list[Relation] = field(default_factory=list)
    disagree: list[tuple[Relation, str]] = field(default_factory=list)
    not_covered: list[tuple[Relation, str]] = field(default_factory=list)
    new: list[Derived] = field(default_factory=list)  # derived here, absent from the templates


def _verdict(r: Relation, prop_of: dict[str, Prop], resolve: dict[str, str]) -> tuple[str, str]:
    legs = r.lhs + r.rhs
    missing = [k for k in legs if k not in prop_of]
    if missing:
        return "not_covered", f"{len(missing)} leg(s) not parsed: {prop_of and missing[0]}"
    lhs, rhs = [prop_of[k] for k in r.lhs], [prop_of[k] for k in r.rhs]
    lv, rv = {p.var for p in lhs}, {p.var for p in rhs}
    if len(lv) > 1 or len(rv) > 1:
        return "not_covered", "a side mixes variables (conjunction)"
    (a,), (b,) = lv, rv
    if a == b:
        if KINDS[a.kind] == "category":
            sa = frozenset(resolve.get(v, v) for p in lhs for v in p.values)
            sb = frozenset(resolve.get(v, v) for p in rhs for v in p.values)
            ok = sa == sb if r.kind == "equivalent" else sa <= sb
            if not ok and any(v.startswith("person:local:") for v in sa | sb) and not _surely_apart(sa, sb):
                # a local identity (race + name) proves difference only when the names cannot be one person
                # (John vs Robert); compatible names left apart (a nickname we do not know) stay open
                return "not_covered", f"identity not established: {sorted(sa)} vs {sorted(sb)}"
            if not ok and any(v.startswith("person:") for v in sa | sb) and any(v.startswith("party:") for v in sa | sb):
                return "not_covered", f"party of the person unknown: {sorted(sa)} vs {sorted(sb)}"
            if not ok and any(v.startswith("name:") for v in sa | sb):
                # a label kept as written can confirm sameness ("Likud" = "Likud") but not prove difference
                # ("NDP" vs "BC NDP", "Zema" vs "Romeu Zema")
                return "not_covered", f"label kept as written: {sorted(sa)} vs {sorted(sb)}"
            return ("agree", "") if ok else ("disagree", f"values {sorted(sa)} vs {sorted(sb)}")
        ua, ub = merged(lhs), merged(rhs)
        ok = ua == ub if r.kind == "equivalent" else subset(ua, ub)
        return ("agree", "") if ok else ("disagree", f"{' ∪ '.join(map(str, ua))} vs {' ∪ '.join(map(str, ub))}")
    kinds = {a.kind, b.kind}
    if "joint" in kinds and len(kinds) == 2:
        cells, other = (lhs, rhs) if a.kind == "joint" else (rhs, lhs)
        jv, ov = (a, b) if a.kind == "joint" else (b, a)
        if ov not in components(jv) or len(other) != 1:
            return "not_covered", f"joint {jv.id} and {ov.id} are not a marginal"
        i = components(jv).index(ov)
        target = resolve.get(next(iter(other[0].values)), next(iter(other[0].values)))
        got = {resolve.get(_cell(c)[i], _cell(c)[i]) for c in cells}
        n = len({next(iter(c.values)) for c in cells})
        ok = got == {target} and n == 2 ** (len(components(jv)) - 1)
        return ("agree", "") if ok else ("disagree", f"cells {sorted(got)} (x{n}) vs {target}")
    if kinds == {"margin", "winner"}:
        m_side, w_side = (lhs, rhs) if a.kind == "margin" else (rhs, lhs)
        party = (a if a.kind == "margin" else b).qualifier
        if w_side[0].values != {f"party:{party}"}:
            return "disagree", "margin party differs from winner party"
        um = merged(m_side)
        ok = _same_as_wins(um) if r.kind == "equivalent" else subset(um, WINS)
        return ("agree", "") if ok else ("disagree", f"margin {' ∪ '.join(map(str, um))}")
    return "not_covered", f"bridge {a.kind} <-> {b.kind} not in the prototype"


def _surely_apart(sa: frozenset, sb: frozenset) -> bool:
    """Two local identities whose names cannot be one person: different surnames, or first names that are not
    equal, an initial, a known nickname or a close spelling."""
    from pmpol.propositions.people import compatible_first, parse_name

    if len(sa) != 1 or len(sb) != 1:
        return False
    (a,), (b,) = sa, sb
    if not (a.startswith("person:local:") and b.startswith("person:local:")):
        return False
    na, nb = parse_name(a.rsplit("|", 1)[-1]), parse_name(b.rsplit("|", 1)[-1])
    return bool(na and nb) and (na.last != nb.last or not compatible_first(na.first, nb.first))


def compare(u: Universe, templates: list[Relation], props: list[Prop], derived: list[Derived]) -> Comparison:
    prop_of = {p.market: p for p in props}
    winners: dict[str, list[Prop]] = defaultdict(list)
    for p in props:
        if p.var.kind == "winner":
            winners[p.var.subject].append(p)
    c = Comparison()
    have = set()
    for r in templates:
        p0 = prop_of.get(r.lhs[0])
        race = winners.get(p0.var.subject, []) if p0 else []
        cands = candidate_parties(u, race)
        resolve = {v: f"party:{party}" for p in race for v in p.values
                   if v.startswith("person:") and (party := party_of_person(cands, v))}
        v, why = _verdict(r, prop_of, resolve)
        if v == "agree":
            c.agree.append(r)
        elif v == "disagree":
            c.disagree.append((r, why))
        else:
            c.not_covered.append((r, why))
        if r.kind == "equivalent":
            have.add(("equivalent", frozenset({frozenset(r.lhs), frozenset(r.rhs)})))
        else:
            have.add(("implies", frozenset(r.lhs), frozenset(r.rhs)))
    seen = set()
    for d in derived:
        k = d.key()
        if k not in have and k not in seen:
            seen.add(k)
            c.new.append(d)
    return c


def violations(u: Universe, ds: list[Derived], min_edge: float = 0.005) -> list[tuple[float, Derived]]:
    """Executable violations (net of fees) on derived relations, using the same check as the templates."""
    from pmpol.universe.relations import check

    out = []
    for d in ds:
        s = check(u, Relation(d.kind, d.lhs, d.rhs, f"onto_{d.basis}", d.var), min_edge)
        if s is not None:
            out.append((s.edge, d))
    return sorted(out, key=lambda t: -t[0])


def _who(p: Prop) -> str | None:
    """Who a single-person prop names: the QID, or the local identity, which is scoped to the contest (country,
    jurisdiction, office, year) and so the same in its primary and its general election."""
    if len(p.values) != 1:
        return None
    v = next(iter(p.values))
    return v[len("person:"):] if v.startswith("person:") else None


def _winner_nominee(by_var: dict[Var, list[Prop]]) -> list[Derived]:
    """Someone who appears in one party's nomination markets wins the general election only as that party's
    nominee: P(wins) <= P(nominated). Same country, jurisdiction, office and year; vice-presidential nominations
    and people listed by two parties are left out."""
    noms: dict[tuple, list[tuple[str, Prop]]] = defaultdict(list)
    for var, ps in by_var.items():
        if var.kind != "nominee":
            continue
        parts = var.subject.split("|")
        if len(parts) < 5 or "None" in parts[:4]:
            continue
        stage = parts[4].split("/")
        if stage[0] != "primary" or "vp" in stage or len(stage) < 2:
            continue
        for p in ps:
            who = _who(p)
            if who:
                noms[(*parts[:4], who)].append((stage[-1], p))
    out = []
    for var, ps in by_var.items():
        if var.kind != "winner":
            continue
        parts = var.subject.split("|")
        if len(parts) != 5 or parts[4] != "general":
            continue
        for w in ps:
            who = _who(w)
            got = noms.get((*parts[:4], who)) if who else None
            if not got or len({party for party, _ in got}) != 1:
                continue
            for _, n in got:
                if n.event != w.event:
                    out.append(_rel("implies", [w], [n], "winner_implies_nominee"))
    return out


def _seats_control(by_var: dict[Var, list[Prop]], kb=None) -> list[Derived]:
    """A party holding a majority of the whole chamber in the new Congress controls it under every venue's
    definition: Senate 51 of 100, House 218 of 435 (from the knowledge base). Seats held on a date in the new
    Congress (Kalshi: Feb 1 of the odd year) map to control after the election of the year before."""
    if kb is None:
        return []
    need, grounds = {}, {}
    if "us.senate.seats" in kb.facts:
        need["senate"] = int(kb.facts["us.senate.seats"].value) // 2 + 1
        grounds["senate"] = ["kb:us.senate.seats"]
    if "us.house.majority" in kb.facts:
        need["house"] = int(kb.facts["us.house.majority"].value)
        grounds["house"] = ["kb:us.house.voting_seats", "kb:us.house.majority"]
    controls = {var: ps for var, ps in by_var.items() if var.kind == "control"}
    out = []
    for var, ps in by_var.items():
        if var.kind != "seats" or not var.qualifier.endswith("/held"):
            continue
        parts = var.subject.split("|")
        if len(parts) != 5 or parts[:2] != ["United States", "US"] or parts[2] not in need or parts[4] != "general":
            continue
        year = int(parts[3])
        target = Var("control", f"United States|{parts[2]}|{year - 1 if year % 2 else year}")
        party = var.qualifier.split("/")[0]
        majority = (Span(need[parts[2]], INF),)
        for p in ps:
            if not p.spans or not subset(p.spans, majority):
                continue
            for c in controls.get(target, []):
                if c.values == {f"party:{party}"} and c.event != p.event:
                    d = _rel("implies", [p], [c], "seats_imply_control")
                    d.grounds += grounds[parts[2]]
                    out.append(d)
    return out


def _action_entailments(by_var: dict[Var, list[Prop]]) -> list[Derived]:
    """"A happens by d" implies "B happens by d'" when action A entails B for the same people and objects
    (pmpol.propositions.describe.ENTAILMENTS) and A's window lies inside B's (d <= d')."""
    from pmpol.propositions.describe import entails

    times = {v: ps for v, ps in by_var.items() if v.kind == "event_time" and " | " not in v.subject}
    out = []
    for va, pas in times.items():
        for vb, pbs in times.items():
            if va == vb or (hit := entails(va.subject, vb.subject)) is None:
                continue
            for a in pas:
                for b in pbs:
                    if a.event != b.event and a.spans and b.spans and subset(a.spans, b.spans):
                        d = _rel("implies", [a], [b], "action_entails")
                        d.notes.append(f"entailment: {hit[0]} ({hit[1]})")
                        out.append(d)
    return out


def _defined_sets(u: Universe, by_var: dict[Var, list[Prop]]) -> list[Derived]:
    """Events a market's rules define by listing members (describe.defined_members): "all" of them implies each
    member (capture all of Donetsk Oblast => capture Sloviansk, and all of Sloviansk); any one member implies "any"
    (invade Venezuela => invade a qualifying Latin American country). Same action and same actor, the member's
    name matched spelling-insensitively, and the windows nested."""
    from pmpol.propositions.describe import defined_members, parse_key, place_key

    times = {}
    for v, ps in by_var.items():
        if v.kind == "event_time" and " | " not in v.subject and (pk := parse_key(v.subject)):
            action, bag = pk
            actor = frozenset(t for t in bag if t.startswith("@"))
            times[v] = (action, actor, place_key(t for t in bag if not t.startswith("@") and t != "all"), "all" in bag)
    out = []
    for va, pas in by_var.items():
        if va not in times:
            continue
        action, actor, _, has_all = times[va]
        for a in pas:
            got = defined_members(u.markets[a.market].rules)
            if got is None or (got[0] == "all" and not has_all):
                continue
            mode, names = got
            members = {place_key(n): n for n in names}
            for vb, (b_action, b_actor, b_place, _) in times.items():
                if vb == va or b_action != action or b_actor != actor or b_place not in members:
                    continue
                for b in by_var[vb]:
                    lhs, rhs = (a, b) if mode == "all" else (b, a)
                    if lhs.event == rhs.event or not (lhs.spans and rhs.spans and subset(lhs.spans, rhs.spans)):
                        continue
                    d = _rel("implies", [lhs], [rhs], "defined_members")
                    d.grounds.append(f"data:rules:{a.market}")
                    d.notes.append(f"defined set ({mode}, from the rules of {a.market}): {', '.join(names)}; "
                                   f"member: {members[b_place]}")
                    out.append(d)
    return out


def _tiles(cells: list[Prop]) -> bool:
    """Every (Senate, House) seat count is in exactly one of the cells (the options of the event tile the grid)."""
    from pmpol.propositions.parse import CHAMBER_SEATS, seat_box

    boxes = [seat_box(c) for c in cells]
    n_house = CHAMBER_SEATS["house"] + 1
    for s in range(CHAMBER_SEATS["senate"] + 1):
        pos = 0
        for lo, hi in sorted((b[1].lo, min(b[1].hi, n_house)) for b in boxes if b[0].lo <= s < b[0].hi):
            if lo != pos:
                return False  # a gap or an overlap
            pos = hi
        if pos != n_house:
            return False
    return True


def _inside(box: tuple[Span, Span], other: tuple[Span, Span]) -> bool:
    return all(o.contains(b) for b, o in zip(box, other))


def _meets(box: tuple[Span, Span], other: tuple[Span, Span]) -> bool:
    return all(b.overlaps(o) for b, o in zip(box, other))


def _seat_boxes(by_var: dict[Var, list[Prop]], kb=None) -> list[Derived]:
    """Seat conjunctions (joint seats variables whose values are boxes: a Senate interval x a House interval).

      marginals   in an event whose options tile the grid, the cells whose Senate (House) interval lies inside a
                  seat range add up to that range of the single-chamber seat variable (bridge_joint_marginal),
                  when no cell straddles the range's edge
      boxes       cells of a tiling event lying inside another venue's box add up to no more than the box, and the
                  box is no more than the cells it meets (box_cells); a box inside another implies it (subset)
      control     a box at or above the majority of a chamber implies that party's control of it, and of both
                  chambers when both are (seats_imply_control; held seats in the new Congress, as _seats_control)
    """
    from pmpol.propositions.parse import seat_box

    out: list[Derived] = []
    need, grounds = {}, {}
    if kb is not None and "us.senate.seats" in kb.facts:
        need[0], grounds[0] = int(kb.facts["us.senate.seats"].value) // 2 + 1, ["kb:us.senate.seats"]
    if kb is not None and "us.house.majority" in kb.facts:
        need[1], grounds[1] = int(kb.facts["us.house.majority"].value), ["kb:us.house.voting_seats", "kb:us.house.majority"]
    for var, ps in by_var.items():
        if var.kind != "joint" or not var.subject.endswith("|seats"):
            continue
        comps = components(var)
        box = {p.market: seat_box(p) for p in ps}
        events: dict[str, list[Prop]] = defaultdict(list)
        for p in ps:
            events[p.event].append(p)
        grids = {ev: cells for ev, cells in events.items() if len(cells) > 1 and _tiles(cells)}
        # marginals: the single-chamber seat variables
        for ev, cells in grids.items():
            for i, comp in enumerate(comps):
                for target in by_var.get(comp, []):
                    if not target.spans:
                        continue
                    inside = [c for c in cells if subset((box[c.market][i],), target.spans)]
                    straddle = [c for c in cells if c not in inside
                                and any(box[c.market][i].overlaps(t) for t in target.spans)]
                    if inside and not straddle:
                        out.append(_rel("equivalent", inside, [target], "bridge_joint_marginal"))
        # boxes against boxes
        for a, b in combinations(ps, 2):
            if a.event == b.event or a.values == b.values:
                continue  # equal boxes: same_set
            if a.event not in grids and b.event not in grids:
                if _inside(box[a.market], box[b.market]):
                    out.append(_rel("implies", [a], [b], "subset"))
                elif _inside(box[b.market], box[a.market]):
                    out.append(_rel("implies", [b], [a], "subset"))
        for ev, cells in grids.items():
            for b in ps:
                if b.event == ev or b.event in grids:
                    continue
                inside = [c for c in cells if _inside(box[c.market], box[b.market])]
                meets = [c for c in cells if _meets(box[c.market], box[b.market])]
                if inside and len(inside) == len(meets):
                    out.append(_rel("equivalent", inside, [b], "cover"))
                    continue
                if inside:
                    out.append(_rel("implies", inside, [b], "box_cells"))
                if meets and len(meets) < len(cells):
                    out.append(_rel("implies", [b], meets, "box_cells"))
        # control
        party, year = comps[0].qualifier.split("/")[0], int(comps[0].subject.split("|")[3])
        cyear = year - 1 if year % 2 else year
        chambers = ("senate", "house")
        majority = {i: Span(need[i], INF) for i in need}
        targets = {i: [c for c in by_var.get(Var("control", f"United States|{chambers[i]}|{cyear}"), [])
                       if c.values == {f"party:{party}"}] for i in majority}
        sweep = [c for v, cs in by_var.items() if v.kind == "joint" and v.subject == f"United States|congress|{cyear}"
                 for c in cs if c.values == {f"party:{party},party:{party}"}]
        for ev, cells in events.items():
            for i in majority:
                legs = [c for c in cells if majority[i].contains(box[c.market][i])]
                for t in targets[i]:
                    if legs and t.event != ev:
                        d = _rel("implies", legs, [t], "seats_imply_control")
                        d.grounds += grounds[i]
                        out.append(d)
            if len(majority) == 2:
                legs = [c for c in cells if all(majority[i].contains(box[c.market][i]) for i in (0, 1))]
                for t in sweep:
                    if legs and t.event != ev:
                        d = _rel("implies", legs, [t], "seats_imply_control")
                        d.grounds += grounds[0] + grounds[1]
                        out.append(d)
    return out


def _generic_pair(u: Universe, a: Prop, b: Prop) -> bool:
    """Generic props (subject = title words) relate only across venues, and only for one occasion: close times
    within a week, or, with Kalshi (whose close time is a far backstop), a year or date in the title itself.
    Weekly questions repeated with the same title would otherwise be linked to the wrong week."""
    from datetime import datetime

    if a.venue == b.venue:
        return False
    if "kalshi" in (a.venue, b.venue):
        return bool(re.search(r"\b20\d\d\b", a.var.subject))
    ca, cb = u.markets[a.market].close_time, u.markets[b.market].close_time
    if not ca or not cb:
        return False
    try:
        da = datetime.fromisoformat(ca.replace("Z", "+00:00"))
        db = datetime.fromisoformat(cb.replace("Z", "+00:00"))
        if (da.tzinfo is None) != (db.tzinfo is None):
            da, db = da.replace(tzinfo=None), db.replace(tzinfo=None)
        return abs((da - db).total_seconds()) <= 7 * 86400
    except ValueError:
        return False


def _majority_wins(u: Universe, by_var: dict[Var, list[Prop]], kb=None) -> list[Derived]:
    """More than half the votes wins a directly elected office under plurality, majority-runoff and ranked-choice
    rules alike: P(share > 50%) <= P(wins). Race-level shares only (a county's share decides nothing); the person
    is the winner option whose label has the share's name key, and only when that key names one identity there."""
    from pmpol.propositions.parse import name_key

    methods = _election_methods(kb)
    if methods is None:
        return []
    winners: dict[str, list[Prop]] = defaultdict(list)
    for var, ps in by_var.items():
        if var.kind == "winner":
            winners[var.subject] += [p for p in ps if _who(p)]
    out = []
    for var, ps in by_var.items():
        if var.kind != "vote_share":
            continue
        parts = var.subject.split("|")
        if len(parts) != 5 or parts[0] != "United States" or "/" in parts[1] or parts[2] not in ("senate", "house",
                                                                                                  "governor"):
            continue
        targets = [w for w in winners.get(var.subject, []) if name_key(u.markets[w.market].outcome) == var.qualifier]
        if not targets or len({_who(w) for w in targets}) != 1:
            continue
        method = methods.get(parts[1][:2])
        for p in ps:
            if "two-party" in (u.markets[p.market].rules or "").lower() or not p.spans:
                continue
            if not all(s.lo > 50 or (s.lo == 50 and not s.lo_closed) for s in p.spans):
                continue
            for w in targets:
                if w.event != p.event:
                    d = _rel("implies", [p], [w], "majority_wins")
                    d.grounds += [f"kb:{method[0]}"] if method else []
                    out.append(d)
    return out
