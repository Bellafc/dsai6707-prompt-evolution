"""Event descriptors for event_time propositions: one action plus the bag of who and what it involves,
so that one happening written differently on several venues becomes one variable.

  "Will Trump be impeached by...?"       (Polymarket)    -> impeach(@trump)
  "Trump Impeached?"                     (Polymarket US) -> impeach(@trump)
  "Kevin Warsh out as Fed chair?"        (Kalshi)        -> leave_office(@kevin, @warsh, role:fed_chair)
  "Warsh out as Fed Chair by…?"          (Polymarket)    -> leave_office(@warsh, role:fed_chair) -> completed to the above
("@" marks words before the verb, for actions with a direction.)

The verb classes follow the spirit of CAMEO/PLOVER (the event codebooks behind GDELT and POLECAT): a
short list of political actions, each with the phrasings venues use. The vocabulary is ours (no code or
data is copied) and grows from the list of titles it could not read.

Precision first: every word that is not boilerplate stays in the bag, so "impeached" and "impeached and
removed from office" stay different variables. Without a known action the title is left unstandardised
(the old normalised-title descriptor), never guessed.
"""

from __future__ import annotations

import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass

# (action, phrasing). The first match wins, so specific phrasings come before general ones.
ACTIONS: list[tuple[str, str]] = [
    ("enter_into_force", r"\benters? into force\b"),
    ("normalize_relations", r"\bnormali[sz]e (?:diplomatic )?relations\b"),
    ("shake_hands", r"\bshake hands\b"),
    ("ceasefire", r"\bcease-?fire\b"),
    ("rate_cut", r"\brate cut\b"),
    ("rate_hike", r"\brate hike\b"),
    ("impeach", r"\bimpeach(?:es|ed)?\b"),
    ("resign", r"\bresign(?:s|ed)?\b"),
    ("confirm", r"\bconfirm(?:s|ed)?\b"),
    ("pardoned", r"\bpardoned\b"),
    ("arrest", r"\b(?:arrested|detained)\b"),
    ("charge", r"\b(?:charged|indicted)\b"),
    ("leave_office", r"\b(?:out|leaves? office|removed)\b(?: (?:as|from))?"),
    ("meet", r"\b(?:meets?|meeting)\b(?: with)?"),
    ("talk", r"\b(?:talks?|speaks?) (?:to|with)\b|\bspeak\b"),
    ("visit", r"\bvisits?\b"),
    ("default", r"\bdefaults?\b(?: on (?:its |the )?debt)?"),
    ("capture", r"\bcapture[sd]?\b"),
    ("invade", r"\b(?:invade[sd]?|invasion of)\b"),
    ("abolish", r"\b(?:abolish(?:es|ed)?|eliminate[sd]?)\b|\bends?\b(?= (?:the )?department\b)"),
    ("recession", r"\brecession\b"),
]
_ACTIONS = [(a, re.compile(p, re.I)) for a, p in ACTIONS]
# Actions whose arguments have no direction ("A and B meet" = "B meets A"). For every other action the words
# before the verb (the actor, or the subject of a passive: "Netanyahu arrested") are kept apart from the
# words after it, so "Russia invades Ukraine" and "Ukraine invades Russia" stay different variables.
SYMMETRIC = {"meet", "talk", "shake_hands", "normalize_relations", "ceasefire"}

# Argument roles (2026-10-05). "@" marks the agent (who does it; for actions without an object, who it happens to:
# "Trump resigns", "Lutnick out"); other words are the patient and the rest. For actions done to someone, the voice
# decides: "Russia invades Ukraine" (active) has agent Russia; "Trump impeached", "Will Netanyahu be arrested",
# "Kupiansk captured by Russia" (passive, a participle not after has/have) have the subject as patient and the
# "by ..." phrase as agent. So "Will the House impeach Trump?" and "Trump impeached?" are one variable.
TRANSITIVE = {"impeach", "confirm", "pardoned", "arrest", "charge", "capture", "invade", "abolish"}
# Agents fixed by the institution, so naming them adds nothing: only the House impeaches (U.S. Constitution, Art. I,
# sec. 2) and only the Senate confirms (Art. II, sec. 2; "Will Congress confirm a justice?" means the Senate, the
# House has no part in it). They are dropped when written.
IMPLICIT_AGENT = {"impeach": {"@house", "@representatives"}, "confirm": {"@senate", "@congress"}}

# Offices, so "Fed chair" and "chairman of the Federal Reserve" are one token.
ROLES: list[tuple[str, str]] = [
    ("fed_chair", r"\b(?:fed(?:eral reserve)? chair(?:man)?|chair(?:man)? of the (?:fed|federal reserve))\b"),
    ("fed_governor", r"\bfed(?:eral reserve)? (?:governor|board)\b"),
    ("fda_commissioner", r"\b(?:fda commissioner|commissioner of the (?:fda|food and drug administration))\b"),
    ("hhs_secretary", r"\b(?:hhs secretary|secretary of (?:hhs|health and human services))\b"),
    ("commerce_secretary", r"\b(?:commerce secretary|secretary of commerce)\b"),
    ("defense_secretary", r"\b(?:defense secretary|secretary of (?:defense|war))\b"),
    ("state_secretary", r"\bsecretary of state\b"),
    ("ecb_president", r"\b(?:ecb president|president of the ecb)\b"),
    ("de_chancellor", r"\bchancellor(?: of germany)?\b(?! of the exchequer)"),
    ("tw_president", r"\b(?:president of taiwan|taiwan(?:ese)? president)\b"),
    ("supreme_leader", r"\bsupreme leader\b"),
    ("prime_minister", r"\bprime minister\b|\bpm\b"),
]
_ROLES = [(r, re.compile(p, re.I)) for r, p in ROLES]

# Country names written in more than one way. Only names, not leaders or demonyms: "Netanyahu" must stay
# a person, not become "Israel".
COUNTRY = {"us": "united_states", "u s": "united_states", "usa": "united_states", "united states": "united_states",
           "america": "united_states", "uk": "united_kingdom", "u k": "united_kingdom",
           "united kingdom": "united_kingdom", "britain": "united_kingdom"}

# "new" is boilerplate ("a new Supreme Court justice") except in place names: New Mexico is not Mexico.
_NEW_PLACE = {"mexico", "york", "jersey", "hampshire", "zealand", "delhi", "caledonia", "orleans", "south", "brunswick",
              "guinea"}

_MONTH = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?"
# Deadline phrases at the end of a title; the deadline itself comes from the labels and rules.
_DEADLINE_TAIL = re.compile(
    rf"\s*\b(?:by|before|in|during|until|through)\b\s*(?:the end of |year-end |end of )?"
    rf"(?:\.\.\.|…|{_MONTH} \d{{1,2}}(?:,? 20\d\d)?|20\d\d|(?:his|trump s|the president s) term(?: ends| is up)?|"
    rf"this year)?\s*$", re.I)
_OPEN = re.compile(r"^\s*(?:who|which|where|what|how)\b", re.I)
_LEAD = re.compile(r"^\s*(?:will|when will|does|is|has|have|did)\b\s*", re.I)
STOP = {"the", "a", "an", "be", "will", "to", "of", "with", "and", "as", "by", "officially", "formally", "publicly",
        "president", "pres", "next", "another", "any", "new", "s", "have", "has"}


def _clean(text: str) -> str:
    t = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    t = t.replace("’", "'").replace("'", " ").replace("​", "")
    t = re.sub(r"[?!]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


@dataclass(frozen=True)
class Desc:
    action: str
    bag: frozenset  # every non-boilerplate word, plus role:… and c:… tokens; "@" marks the side before the verb
    given: frozenset = frozenset()  # first words of capitalised runs ("kevin" in "Kevin Warsh"): may be a given name

    @property
    def key(self) -> str:
        return key(self.action, self.bag)


def describe(title: str) -> Desc | None:
    """The action and argument bag of a title, or None when no known action is found."""
    if _OPEN.match(title):
        return None  # "Who will Trump meet?": the options are the arguments, one variable per option
    t = _clean(title)
    perfect = re.match(r"\s*(?:has|have|had)\b", t, re.I)  # "Has Russia invaded ...?" is active
    t = _LEAD.sub("", t)
    for _ in range(2):  # "... before his term ends?" can follow "... by..."
        t = _DEADLINE_TAIL.sub("", t)
    hits = [(a, p.search(t)) for a, p in _ACTIONS]
    hits = [(a, h) for a, h in hits if h]
    if not hits:
        return None
    action, h = hits[0]
    passive = action in TRANSITIVE and t[h.start():h.end()].lower().endswith("ed") and not perfect and \
        not re.search(r"\b(?:has|have|had)\s*$", t[:h.start()], re.I)
    t = t[:h.start()] + " zzverbzz " + t[h.end():]
    # before the verb: the agent (active) or the patient (passive); after it: the patient, or "by ..." the agent
    side = "" if action in SYMMETRIC or passive else "@"
    bag = []
    for role, p in _ROLES:
        if p.search(t):
            bag.append(f"role:{role}")
            t = p.sub(" ", t)
    t = re.sub(r"[^A-Za-z0-9 .\-]", " ", t).replace("-", " ")
    t = re.sub(r"\b([A-Za-z])\.", r"\1", t).replace(".", " ")  # "U.S." -> "US", "Jr." -> "Jr"
    raw = t.split()
    words = [w.lower() for w in raw]
    kept: list[tuple[str, bool]] = []  # (word, capitalised)
    i = 0
    while i < len(words):
        two = " ".join(words[i:i + 2])
        if two in COUNTRY:
            bag.append(f"{side}c:{COUNTRY[two]}")
            kept.append(("", False))
            i += 2
            continue
        w = words[i]
        if w == "zzverbzz":
            side = ""
            kept.append(("", False))
        elif passive and w == "by" and side == "" and "zzverbzz" in words[:i]:
            side = "@"  # "captured by Russia": the agent of a passive
            kept.append(("", False))
        elif w in COUNTRY:
            bag.append(f"{side}c:{COUNTRY[w]}")
            kept.append(("", False))
        elif w not in STOP or (w == "new" and i + 1 < len(words) and words[i + 1] in _NEW_PLACE):
            bag.append(side + w)
            kept.append((side + w, raw[i][:1].isupper()))
        else:
            kept.append(("", False))
        i += 1
    bag = [w for w in bag if w not in IMPLICIT_AGENT.get(action, ())]
    if not bag:
        return None
    given = {w for (w, cap), (nxt, ncap) in zip(kept, kept[1:]) if w and cap and nxt and ncap
             and w.lstrip("@") not in ("new", "north", "south", "west", "east", "saudi", "united")}  # place prefixes
    return Desc(action, frozenset(bag), frozenset(given))


# Entailments between actions (2026-10-05): "A happens" guarantees "B happens" at the same time or earlier, for the
# same people and objects. (id, from action, words that narrow the "from" side, to action, words that widen the
# "to" side, why). Only these pairs; an extra word in general may narrow ("all of Kupiansk") or widen ("Spain or
# France") a descriptor, so bags are never compared by inclusion. The table is a key assumption
# (config/assumptions.toml#action_entailments): a venue's rules can break a pair, which the cross-venue rule check
# reports (announcement against effective date).
ENTAILMENTS: list[tuple[str, str, frozenset, str, frozenset, str]] = [
    ("removed_is_impeached", "impeach", frozenset({"removed", "from", "office"}), "impeach", frozenset(),
     "被彈劾並免職的人，一定先被彈劾"),
    ("removed_is_out", "impeach", frozenset({"removed", "from", "office"}), "leave_office", frozenset(),
     "被免職就是離開職位（被彈劾的人就是離開職位的人）"),
    ("resign_is_out", "resign", frozenset(), "leave_office", frozenset(),
     "辭職就是離開職位（各平台算宣布或生效日可能不同，由結算條件比對標出）"),
    ("out_is_announced", "leave_office", frozenset(), "leave_office", frozenset({"announced"}),
     "已經離職，離職一定已經宣布"),
    ("emergency_cut_is_cut", "rate_cut", frozenset({"emergency"}), "rate_cut", frozenset(), "緊急降息也是降息"),
    ("all_is_captured", "capture", frozenset({"all"}), "capture", frozenset(), "攻下全部，就是攻下"),
]


def parse_key(k: str) -> tuple[str, frozenset] | None:
    """"leave_office(@q:Q1, role:x)" -> ("leave_office", {"@q:Q1", "role:x"}); None for other subjects."""
    m = re.fullmatch(r"([a-z_]+)\((.*)\)", k)
    if not m or m.group(1) not in {a for a, _ in ACTIONS}:
        return None
    return m.group(1), frozenset(t.strip() for t in m.group(2).split(",") if t.strip())


def _strip(bag: frozenset, words: frozenset) -> frozenset | None:
    """The bag without `words` (on either side of the verb); None unless every one of them is there."""
    plain = {w.lstrip("@") for w in bag}
    if not words <= plain:
        return None
    return frozenset(w for w in bag if w.lstrip("@") not in words)


def entails(a: str, b: str) -> tuple[str, str] | None:
    """(entailment id, why) when descriptor `a` guarantees descriptor `b` (ENTAILMENTS), else None."""
    pa, pb = parse_key(a), parse_key(b)
    if pa is None or pb is None:
        return None
    for eid, fa, narrow, ta, widen, why in ENTAILMENTS:
        if pa[0] != fa or pb[0] != ta:
            continue
        ra, rb = _strip(pa[1], narrow), _strip(pb[1], widen)
        if ra is not None and fa in TRANSITIVE and ta not in TRANSITIVE:
            ra = frozenset(w if w.startswith("@") else "@" + w for w in ra)  # the patient is who leaves
        if ra is not None and rb is not None and ra == rb and (narrow or widen or fa != ta):
            return eid, why
    if pa[0] == pb[0] and pa[0] in TRANSITIVE:
        agents = {w for w in pa[1] if w.startswith("@")}
        if agents and not any(w.startswith("@") for w in pb[1]) and pa[1] - agents == pb[1]:
            return "agent_unspecified", "指定了誰做的（例如俄羅斯攻下），就一定有人做了（攻下）"
    return None


# Sets a market's own rules define by listing their members (2026-10-05): "all" sets must all happen ("The relevant
# municipalities in Donetsk Oblast that must be simultaneously captured in their entirety are: Kramatorsk, ..."),
# "any" sets need one ("Qualifying Latin America countries: Belize, ..."). Geographic containment then rests on
# the resolving definition itself, not on a gazetteer: capturing "all of Donetsk Oblast" means these towns, not
# every village of the oblast.
_ALL_SET = re.compile(r"relevant municipalities in (.+?) that must be (?:simultaneously )?captured in their entirety "
                      r"are:\s*(.+?)\.(?:\s|$)", re.I | re.S)
_ANY_SET = re.compile(r"qualifying ([a-z ]+?) countries:\s*(.+?)(?:\s{2,}|\.\s|\.$|$)", re.I | re.S)


def defined_members(rules: str) -> tuple[str, list[str]] | None:
    """("all" | "any", member names) when the rules define the event by a list of members."""
    for mode, rx in (("all", _ALL_SET), ("any", _ANY_SET)):
        m = rx.search(rules or "")
        if m:
            names = [n.strip() for n in re.split(r",|\band\b", m.group(2)) if n.strip()]
            if names:
                return mode, names
    return None


def place_key(words) -> frozenset:
    """Spelling-insensitive key of a place name ("Kostyantynivka" = "Kostiantynivka", "Chasiv Yar"), from words or
    a name; country tokens ("c:united_states") are spelled out."""
    if isinstance(words, str):
        words = _clean(words).lower().replace("-", " ").split()
    out = []
    for w in words:
        w = w.lstrip("@")
        if w.startswith("c:"):
            out += w[2:].split("_")
            continue
        out.append(w.replace("y", "i").replace("'", ""))
    return frozenset(x for x in out if x and x not in STOP)


_WH = re.compile(r"^\s*(?:who|which|what)\b(?:\s+of\s+these)?(?P<noun>(?:\s+(?!will\b)[\w.'-]+){0,3})\s+will\s+(?P<rest>.+)$",
                 re.I)
_ORDER = re.compile(r"\b(?:next|first|last|how many|how much|most|least)\b", re.I)


def option_sentence(title: str, option: str) -> str | None:
    """A question whose options are the arguments, with the option put back in its place (2026-10-05):
    "Who will Donald Trump meet in 2026?" + "Vladimir Putin" -> "Will Donald Trump meet Vladimir Putin in 2026?";
    "Which leaders will leave office in 2026?" + "Mark Carney" -> "Will Mark Carney leave office in 2026?".
    None for counts and orderings ("next", "first", "how many"): those are not one event per option."""
    m = _WH.match(_clean(title))
    opt = _clean(option or "")
    if not m or not opt or _ORDER.search(title) or re.fullmatch(r"(?:yes|no|other|none|\d[\d,.\s%+-]*)", opt, re.I):
        return None
    rest = m.group("rest")
    hit = next((p.search(rest) for _, p in _ACTIONS if p.search(rest)), None)
    if hit is None or hit.group(0).lower() == "meeting":
        return None  # "dissent at the October Fed meeting": a noun, not the action
    before = rest[:hit.start()].strip()
    if all(w.lower() in {"be", "have", "get", "a", "an", "the"} for w in before.split()):
        return f"Will {opt} {rest}"  # the question asks for the subject: "Who will be arrested ...?"
    return f"Will {rest[:hit.end()]} {opt}{rest[hit.end():]}"  # ... for the object: "Who will Trump meet ...?"


def key(action: str, bag) -> str:
    return f"{action}({', '.join(sorted(bag))})"


def complete(descs: dict[str, Desc]) -> dict[str, str]:
    """Descriptor key for every id, completing short bags whose completion is unique.

    "Warsh out as Fed Chair" names one more-specific variable in the snapshot ("Kevin Warsh out as Fed
    chair"): its bag is a subset of exactly one larger bag that differs by one word (typically a first
    name, the first word of a capitalised run in the longer title). Then both are the same variable.
    With two or more candidates ("Khamenei" could be Ali or Mojtaba), or any longer bag containing the
    short one, the short bag stays as it is.
    """
    by_action: dict[str, dict[frozenset, frozenset]] = defaultdict(dict)  # bag -> given names seen with it
    for d in descs.values():
        by_action[d.action][d.bag] = by_action[d.action].get(d.bag, frozenset()) | d.given
    target: dict[tuple[str, frozenset], frozenset] = {}
    for action, bags in by_action.items():
        for b in bags:
            sup = [o for o in bags if b < o]
            if len(sup) == 1 and len(sup[0] - b) == 1 and next(iter(sup[0] - b)) in bags[sup[0]]:
                target[(action, b)] = sup[0]
    return {i: key(d.action, target.get((d.action, d.bag), d.bag)) for i, d in descs.items()}
