"""Resolution conditions read from the rules text, and how two venues' conditions compare.

Two markets can be the same proposition (same variable, same set) and still settle differently: one pays on
the media call, another on the swearing-in; one follows the party's nominee if the candidate is replaced,
another names a person; one counts a deadline from market creation, another from no stated start. Each market
gets a few attributes, each with a value or "not stated" (or "rules not held" when we have no rules text):

  elections   decided_by (media call / certification / sworn in / election authorities), runoff (included),
              candidate (party nominee, follows replacement / named person), independents (not a party)
  margins     denominator (total votes / valid votes / two-party), rounding, boundary
  deadlines   window start, announcement counts, time zone
  statistics  release (first print), timing

A cross-venue relation is then: rules equivalent (every material attribute read on every venue and equal),
unverified (no difference found, but a material attribute is not stated or the rules are not held somewhere),
minor differences only (the source or the rounding differs), or material differences (an attribute that can
change the payoff differs). "Not stated" is never read as a difference.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from pmpol.models import Market

NOT_STATED = "not stated"
NO_RULES = "rules not held"

# attribute -> material? (can the difference change who gets paid in a plausible scenario)
MATERIAL = {"candidate": True, "runoff": True, "decided_by": False, "independents": True, "denominator": True,
            "rounding": False, "boundary": False, "window start": True, "announcement": True, "time zone": False,
            "release": True, "timing": True,
            # next government (2026-10-06): a party with junior ministers only, or no government formed by a venue's
            # deadline (formation takes weeks; the deadlines seen are 4-15 months after the election)
            "ministers": False, "formation window": False}
ZH = {"decided_by": "判定依據", "runoff": "決選", "candidate": "候選人", "independents": "獨立候選人",
      "denominator": "分母", "rounding": "四捨五入", "boundary": "邊界", "window start": "計算窗起點",
      "announcement": "宣布算不算", "time zone": "時區", "release": "公布版本", "timing": "時間點",
      "ministers": "入閣的定義", "formation window": "組閣期限"}
ELECTION_KINDS = {"winner", "control", "nominee", "joint", "seats"}


def _decided_by(r: str) -> str:
    if re.search(r"sworn in|takes? office|assumes? office", r):
        return "sworn in"
    if re.search(r"associated press|\bap\b|fox news|\bnbc\b|consensus of media|media organizations project|"
                 r"decision desk|major networks", r):
        return "media call"
    if re.search(r"certif", r):
        return "certification"
    if re.search(r"government authorit|election authorit|official results|electoral commission", r):
        return "election authorities"
    return NOT_STATED


def _runoff(r: str) -> str:
    if re.search(r"(?:inclusive of|includ\w*|account for|regardless of) (?:any )?run-?offs?|any run-?off, tiebreak|"
                 r"run-?offs?,? (?:if any|will be included|are included)", r):
        return "included"
    if re.search(r"(?:not|excludes?|without) (?:include )?(?:any )?run-?off|first round only|before any run-?off", r):
        return "excluded"
    return NOT_STATED


def _candidate(r: str, label: str) -> str:
    if re.search(r"replaced as the nominee|replacement nominee|nominee of the party in question|party'?s? nominee|"
                 r"nominee of (?:the|their) (?:respective )?party|representative of the \w+ party", r):
        return "party nominee"
    from pmpol.universe.outcomes import name_key

    name = re.sub(r"\(.*?\)", "", label).strip()
    if name_key(name) and not re.search(r"\bparty\b|coalition|alliance", name, re.I) and \
            re.search(rf"^if {re.escape(name.lower())} wins", r):
        return "named person"
    return NOT_STATED


def _independents(r: str) -> str:
    if re.search(r"independents? (?:candidates? )?will not (?:be encompassed|represent)|run as independents will not",
                 r):
        return "not a party"
    return NOT_STATED


def _denominator(r: str) -> str:
    if re.search(r"two-party|two party", r):
        return "two-party vote"
    if re.search(r"valid votes", r):
        return "valid votes"
    if re.search(r"divided by total votes|total votes cast|of all votes", r):
        return "total votes"
    return NOT_STATED


def _rounding(r: str) -> str:
    hit = re.search(r"rounded to (one|two|three|\d) decimal", r)
    if hit:
        return f"{hit.group(1)} decimals"
    return "none" if re.search(r"no rounding (?:shall|will) be applied|without rounding|not be rounded", r) else NOT_STATED


def _boundary(r: str) -> str:
    # "goes to the higher bracket" and "the bracket for which it is the inclusive lower boundary" are both [lo, hi)
    if re.search(r"higher (?:range |margin )?bracket|inclusive lower bound|inclusive of its lower bound", r):
        return "[lo, hi)"
    if re.search(r"lower (?:range |margin )?bracket|inclusive upper bound|inclusive of its upper bound", r):
        return "(lo, hi]"
    return NOT_STATED


def _time_zone(r: str) -> str:
    if re.search(r"\bet\b|eastern time|\bedt\b|\best\b", r):
        return "ET"
    if re.search(r"\butc\b|\bgmt\b", r):
        return "UTC"
    return NOT_STATED


def attributes(m: Market, kind: str) -> dict[str, str]:
    """Resolution attributes of one market for a variable kind."""
    from pmpol.propositions.parse import announcement_rule, window_start

    r = (m.rules or "").lower()
    if kind == "nominee":  # "the party's nominee" is the question itself, not a replacement clause
        keys = ("decided_by",)
    elif kind in ELECTION_KINDS:
        keys = ("decided_by", "runoff", "candidate", "independents")
    elif kind in ("margin", "vote_share", "turnout"):
        keys = ("denominator", "rounding", "boundary") if kind != "turnout" else ("boundary",)
    elif kind == "event_time":
        keys = ("window start", "announcement", "time zone")
    elif kind == "indicator":
        keys = ("release", "timing")
    elif kind == "cabinet":
        keys = ("ministers", "formation window")
    else:
        return {}
    if not r.strip():
        return {k: NO_RULES for k in keys}
    out = {}
    for k in keys:
        if k == "decided_by":
            out[k] = _decided_by(r)
        elif k == "runoff":
            out[k] = _runoff(r)
            if out[k] == NOT_STATED and _decided_by(r) == "sworn in":
                out[k] = "included"  # whoever is sworn in won any runoff too
        elif k == "candidate":
            out[k] = _candidate(r, m.outcome)
        elif k == "independents":
            out[k] = _independents(r)
        elif k == "denominator":
            out[k] = _denominator(r)
        elif k == "rounding":
            out[k] = _rounding(r)
        elif k == "boundary":
            out[k] = _boundary(r)
        elif k == "window start":
            out[k] = window_start(m).split(": ", 1)[1]
            if out[k] == "not stated in the rules":
                out[k] = NOT_STATED
        elif k == "announcement":
            a = announcement_rule(m)
            out[k] = a.split(": ", 1)[1] if a else NOT_STATED
        elif k == "time zone":
            out[k] = _time_zone(r)
        elif k == "release":
            out[k] = "first print" if re.search(r"first (?:value )?(?:published|release|non-preliminary)|advance "
                                                r"estimate|initial release", r) else NOT_STATED
        elif k == "ministers":
            out[k] = ("any ministerial post" if "junior minister" in r else
                      "a cabinet minister" if re.search(r"cabinet minister|cabinet post", r) else NOT_STATED)
        elif k == "formation window":
            hit = re.search(r"before ((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{1,2}, \d{4})", r)
            out[k] = (f"before {hit.group(1)}" if hit else
                      "first government after the election" if re.search(r"first [a-z ]*government", r) else NOT_STATED)
        elif k == "timing":
            out[k] = ("in effect on December 31" if "december 31" in r else
                      "after the December FOMC meeting" if "december" in r and "meeting" in r else NOT_STATED)
    return out


@dataclass
class RuleCheck:
    status: str  # "equivalent", "unverified", "minor", "material", or "" (not cross-venue)
    same: list[str] = field(default_factory=list)
    differs: list[tuple[str, tuple[str, ...]]] = field(default_factory=list)  # (attribute, distinct values)
    unknown: list[str] = field(default_factory=list)

    def text(self) -> str:
        """Traditional Chinese summary for proofs and reports."""
        parts = []
        if self.differs:
            parts.append("不同：" + "；".join(f"{ZH.get(a, a)}（{' / '.join(v)}）" for a, v in self.differs))
        if self.same:
            parts.append("相同：" + "、".join(ZH.get(a, a) for a in self.same))
        if self.unknown:
            parts.append("未知：" + "、".join(ZH.get(a, a) for a in self.unknown))
        return "；".join(parts)


STATUS_ZH = {"equivalent": "規則一致", "unverified": "未發現差異（未完全驗證）", "minor": "只有細節差異",
             "material": "有實質差異", "": ""}


def compare(per_leg: list[tuple[str, dict[str, str]]]) -> RuleCheck:
    """Compare the attributes of a relation's legs across venues: [(venue, attributes)]. An attribute is compared
    only between venues whose legs have it (a margin leg and a winner leg share none)."""
    by_key: dict[str, dict[str, set[str]]] = {}
    for venue, attrs in per_leg:
        for k, v in attrs.items():
            by_key.setdefault(k, {}).setdefault(venue, set()).add(v)
    c = RuleCheck("")
    for k in sorted(by_key):
        venues = by_key[k]
        if len(venues) < 2:
            continue
        values = [v for vs in venues.values() for v in vs]
        stated = sorted({v for v in values if v not in (NOT_STATED, NO_RULES)})
        if len(stated) > 1:
            c.differs.append((k, tuple(stated)))
        elif stated and all(v not in (NOT_STATED, NO_RULES) for v in values):
            c.same.append(k)
        else:
            c.unknown.append(k)
    if any(MATERIAL.get(k, True) for k, _ in c.differs):
        c.status = "material"
    elif c.differs:
        c.status = "minor"
    elif any(MATERIAL.get(k, True) for k in c.unknown) or not c.same:  # nothing actually compared equal
        c.status = "unverified"
    else:
        c.status = "equivalent"
    return c
