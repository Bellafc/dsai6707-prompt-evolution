"""Who a person label is: the entity layer behind the ontology's person values.

Replaces the interim key (first initial + surname). Every person label in a winner or nominee proposition gets
an identity, in this order:

  1. A Wikidata QID, when the evidence is strong:
     - the entity index already has the person with a QID and links the label to the race (congress-
       legislators, OpenSanctions; incumbents of Congress, Cabinet members, world leaders);
     - or Wikidata (OpenSanctions' wd_peps extract) has exactly one person of that name who holds or held the
       very office the race is for ("Governor of Michigan" for a Michigan governor's race);
     - or, for national races only (a country's president or head of government, a U.S. presidential
       nomination), exactly one living politician of that name in the country;
     - or Wikidata records exactly one living person of that name as a candidate in this very election
       (P3602, queried directly; pmpol.entities.wikidata): same year, and the election's office contested is the
       race's office in the race's place ("Magistrate of Hualien County"; "United States senator" with
       jurisdiction Nebraska). This places newcomers who never held office.
     A name alone is not evidence: Wikidata's "Mike Bouchard" is a former sheriff, the MI-10 candidate is his
     son, who has no Wikidata item.
  2. Otherwise a local identity: the race plus the full name.

Then, within one race, labels that write one person differently are merged: the same surname and a compatible
first name (equal, an initial, a common nickname such as Mike/Michael, a short form such as Alex/Alexandra,
or for names of 5+ letters a spelling one letter apart such as Natalia/Nataliya), with Jr./II ignored. Never merged:
a label with Jr./Sr. and a person known by QID without it (Donald Trump Jr. is not Donald Trump; QIDs too are
matched only with the same suffix), two labels listed as separate options of one event (Alaska 2026 has Dan Sullivan and Daniel J. Sullivan),
names with different middle initials, a nickname match when either name has a middle initial, or two
different QIDs.
"""

from __future__ import annotations

import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass, field

from pmpol.universe.geo import US_STATES

# Common English nicknames -> formal first name (written for this project; extend as cases appear).
NICKNAMES = {
    "mike": "michael", "mick": "michael", "bob": "robert", "bobby": "robert", "rob": "robert", "robbie": "robert",
    "bill": "william", "billy": "william", "will": "william", "willie": "william", "jim": "james", "jimmy": "james",
    "dan": "daniel", "danny": "daniel", "tom": "thomas", "tommy": "thomas", "joe": "joseph", "joey": "joseph",
    "chris": "christopher", "matt": "matthew", "pat": "patrick", "steve": "steven", "stephen": "steven",
    "rick": "richard", "ricky": "richard", "dick": "richard", "rich": "richard", "ben": "benjamin",
    "tony": "anthony", "andy": "andrew", "drew": "andrew", "alex": "alexander", "kate": "katherine",
    "katie": "katherine", "kathy": "katherine", "kathleen": "katherine", "liz": "elizabeth", "beth": "elizabeth",
    "betsy": "elizabeth", "jen": "jennifer", "jenny": "jennifer", "sam": "samuel", "nick": "nicholas",
    "ed": "edward", "eddie": "edward", "ted": "edward", "greg": "gregory", "jeff": "jeffrey", "ron": "ronald",
    "don": "donald", "ken": "kenneth", "tim": "timothy", "larry": "lawrence", "jerry": "gerald",
    "charlie": "charles", "chuck": "charles", "dave": "david", "jon": "jonathan", "josh": "joshua",
    "fred": "frederick", "hank": "henry", "jack": "john", "johnny": "john", "sue": "susan", "peggy": "margaret",
    "maggie": "margaret", "abby": "abigail", "becky": "rebecca", "cindy": "cynthia", "debbie": "deborah",
    "deb": "deborah", "vicky": "victoria", "pete": "peter", "doug": "douglas", "jake": "jacob", "zach": "zachary",
    "nate": "nathan", "phil": "phillip", "philip": "phillip", "russ": "russell", "gus": "augustus",
    "marty": "martin", "nikki": "nicole", "jackie": "jacqueline", "terry": "terrence", "jerri": "geraldine",
    "patty": "patricia", "trish": "patricia", "sandy": "sandra", "mandy": "amanda", "kim": "kimberly",
    "lou": "louis", "randy": "randall", "rusty": "russell", "toni": "antonia", "connie": "constance",
}
_HONORIFICS = {"sen", "senator", "rep", "representative", "gov", "governor", "dr", "mr", "mrs", "ms", "president",
               "mayor", "judge", "gen", "general", "hon"}
_SUFFIX = {"jr", "sr", "ii", "iii", "iv"}


def _ascii(text: str) -> str:
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().lower()


@dataclass(frozen=True)
class Name:
    first: str
    middle: tuple[str, ...]
    last: str
    suffix: str = ""

    @property
    def full(self) -> str:
        return " ".join([self.first, *self.middle, self.last])



def parse_name(label: str) -> Name | None:
    """"Sen. Daniel J. Sullivan Jr. (R)" -> Name("daniel", ("j",), "sullivan", "jr"); None if not a name."""
    t = re.sub(r"\(.*?\)|\"[^\"]*\"|“[^”]*”", " ", label)  # party, and quoted nicknames: Eric A. "Rick" Crawford
    t = _ascii(t).replace(".", " ").replace(",", " ")
    words = [w for w in re.split(r"\s+", t) if w]
    while words and words[0] in _HONORIFICS:
        words = words[1:]
    suffix = ""
    if words and words[-1] in _SUFFIX:
        suffix = words.pop()
    if len(words) < 2 or not all(re.fullmatch(r"[a-z][a-z'\-]*", w) for w in words):
        return None
    # "J. D. Vance" / "J.D. Vance" -> "jd", as "JD Vance" is written
    while len(words) > 2 and len(words[0]) <= 2 and len(words[1]) == 1 and all(len(c) == 1 for c in words[0]):
        words = [words[0] + words[1], *words[2:]]
    first, last = words[0], words[-1]
    return Name(first, tuple(words[1:-1]), last, suffix)


def _formal(first: str) -> str:
    return NICKNAMES.get(first, first)


def _one_edit(a: str, b: str) -> bool:
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) == 1
    s, t = (a, b) if len(a) < len(b) else (b, a)
    return any(t[:i] + t[i + 1:] == s for i in range(len(t)))


def compatible_first(a: str, b: str) -> bool:
    if a == b or _formal(a) == _formal(b):
        return True
    if min(len(a), len(b)) >= 5 and a[0] == b[0] and _one_edit(a, b):  # transliterations: Natalia/Nataliya
        return True
    if min(len(a), len(b)) >= 3 and (a.startswith(b) or b.startswith(a)):  # short forms: Alex/Alexandra
        return True
    if len(a) == 1 or len(b) == 1:  # an initial
        return a[0] == b[0]
    if len(a) == 2 and len(b) == 2:  # "jd" vs "jb": initials written together
        return a == b
    return False


def _middle_conflict(a: Name, b: Name) -> bool:
    if a.middle and b.middle:
        return a.middle[0][0] != b.middle[0][0]
    return False


@dataclass
class Label:
    market: str
    event: str
    subject: str  # variable subject: the race (or the nomination)
    race: str | None  # the event's race key, as the entity index stores it
    national: bool  # a country's president or head of government, or a presidential nomination
    name: Name
    country: str | None
    office: str | None
    jurisdiction: str | None
    qid: str | None = None
    how: str = ""


@dataclass
class Identities:
    of: dict[str, str] = field(default_factory=dict)  # market -> "Q123" or "local:<country|juris|office|year>|<name>"
    how: dict[str, str] = field(default_factory=dict)  # market -> evidence
    unread: dict[str, str] = field(default_factory=dict)  # market -> why no identity


def _same_middle(label: Name, wd_name: str) -> bool:
    """A label with a middle initial matches only a Wikidata name with the same middle initial."""
    if not label.middle:
        return True
    n = parse_name(wd_name)
    return bool(n and n.middle and n.middle[0][0] == label.middle[0][0])


def _same_suffix(label: Name, other: str) -> bool:
    """Jr./Sr./II must agree: "Donald Trump Jr." is not "Donald Trump"."""
    n = parse_name(other)
    return bool(n) and n.suffix == label.suffix


def _suffix_fits(label: Name, official: str) -> bool:
    """For the entity index (which also requires the race): a label may omit a suffix the official name has
    ("Frank Pallone" for "Frank Pallone, Jr."), but a label's suffix must be in the official name ("Donald
    Trump Jr." is not "Donald Trump")."""
    if not label.suffix:
        return True
    n = parse_name(official)
    return bool(n) and n.suffix == label.suffix


def _office_patterns(office: str | None, jurisdiction: str | None, country: str | None) -> list[re.Pattern]:
    """Position names that are the race's office ("governor of michigan" for a Michigan governor's race)."""
    if not office:
        return []
    leaf = (jurisdiction or "").split("/")[-1].strip().lower()
    state = {v: k for k, v in US_STATES.items()}.get((jurisdiction or "")[:2]) if country == "United States" else None
    place = (state or leaf or "").lower()
    c = (country or "").lower()
    if office == "governor" and place:
        return [re.compile(rf"^governor of (?:the state of )?{re.escape(place)}$")]
    if office == "lt_governor" and place:
        return [re.compile(rf"^lieutenant governor of {re.escape(place)}$")]
    if office == "attorney_general" and place:
        return [re.compile(rf"^(?:{re.escape(place)} attorney general|attorney general of {re.escape(place)})$")]
    if office == "mayor" and leaf:
        return [re.compile(rf"^mayor of {re.escape(leaf)}(?: city)?$")]
    if office == "local" and leaf:  # Taiwan's county magistrates and other local heads ("Taiwan/Hualien")
        return [re.compile(rf"^(?:mayor|magistrate) of {re.escape(leaf)}(?: city| county)?$")]
    if office == "president" and c and c != "united states":
        return [re.compile(rf"^president of (?:the )?{re.escape(c)}$")]
    if office == "president" and c == "united states":
        return [re.compile(r"^president of the united states$")]
    if office == "head_of_government" and c:
        return [re.compile(rf"^(?:prime minister|chancellor|premier) of (?:the )?{re.escape(c)}$")]
    # No rule for the U.S. Congress: Wikidata's "United States representative" carries no state, so a namesake
    # from another state would pass (SC-06's John Peterson is not Pennsylvania's John E. Peterson). Members
    # of Congress get their QIDs from congress-legislators, which has the state.
    if office == "senate" and c == "brazil":
        return [re.compile(r"^member of the federal senate of brazil$")]
    return []


_ISO = {"united states": "us", "brazil": "br", "mexico": "mx", "france": "fr", "israel": "il", "argentina": "ar",
        "canada": "ca", "united kingdom": "gb", "bulgaria": "bg", "nigeria": "ng", "taiwan": "tw",
        "new zealand": "nz", "germany": "de", "colombia": "co", "peru": "pe", "chile": "cl", "japan": "jp"}


def _wd_qid(lab: Label, by_name: dict[str, list]) -> tuple[str | None, str]:
    people = by_name.get(f"{lab.name.first} {lab.name.last}", []) + \
        ([] if not lab.name.middle else by_name.get(lab.name.full, []))
    people = list({p.qid: p for p in people if not p.dead and _same_middle(lab.name, p.name)
                   and _same_suffix(lab.name, p.name)}.values())
    if not people:
        return None, ""
    pats = _office_patterns(lab.office, lab.jurisdiction, lab.country)
    if pats:
        held = [p for p in people if any(pat.match(_ascii(pos["name"])) for pos in p.positions for pat in pats)]
        if len(held) == 1:
            return held[0].qid, f"Wikidata: holds or held this office ({held[0].qid})"
        if len(held) > 1:
            return None, ""
    if lab.national:
        iso = _ISO.get((lab.country or "").lower())
        local = [p for p in people if iso and iso in p.countries]
        if len(local) == 1:
            return local[0].qid, f"Wikidata: the only living politician of this name in the country ({local[0].qid})"
    return None, ""


def _contests(lab: Label, c) -> bool:
    """The candidacy's election is the label's race: the same year, the race's office in the race's place."""
    year = (lab.race or "").split("|")[3:4]
    if not year or not year[0].isdigit() or int(year[0]) != c.year:
        return False
    offices = [_ascii(o) for o in c.offices]
    if lab.office == "senate" and lab.country == "United States":
        state = {v: k for k, v in US_STATES.items()}.get((lab.jurisdiction or "")[:2], "")
        return "united states senator" in offices and bool(state) and state.lower() in (_ascii(x) for x in c.places)
    pats = _office_patterns(lab.office, lab.jurisdiction, lab.country)
    return any(pat.match(o) for o in offices for pat in pats)


def _candidacy_qid(lab: Label, by_name: dict[str, list]) -> tuple[str | None, str]:
    found = by_name.get(f"{lab.name.first} {lab.name.last}", []) + \
        ([] if not lab.name.middle else by_name.get(lab.name.full, []))
    found = [c for c in found if _same_middle(lab.name, c.name) and _same_suffix(lab.name, c.name) and _contests(lab, c)]
    qids = {c.qid for c in found}
    if len(qids) == 1:
        c = found[0]
        return c.qid, f"Wikidata: candidate in this election ({c.label}, {c.election}; {c.qid})"
    return None, ""


def identify(labels: list[Label], index=None, wd_people=(), candidacies=()) -> Identities:
    """Identities for person labels (see the module docstring)."""
    out = Identities()
    by_cand: dict[str, list] = defaultdict(list)
    for c in candidacies:
        n = parse_name(c.name)
        if n:
            by_cand[f"{n.first} {n.last}"].append(c)
            if n.middle:
                by_cand[n.full].append(c)
    by_name: dict[str, list] = defaultdict(list)
    for p in wd_people:
        n = parse_name(p.name)
        if n:
            by_name[f"{n.first} {n.last}"].append(p)
            if n.middle:
                by_name[n.full].append(p)
    for lab in labels:
        if index is not None:
            lab.qid, lab.how = _index_qid(lab, index)
        if lab.qid is None and wd_people:
            lab.qid, lab.how = _wd_qid(lab, by_name)
        if lab.qid is None and by_cand:
            lab.qid, lab.how = _candidacy_qid(lab, by_cand)

    # Names that belong to a known person somewhere in this run ("donald j trump" -> Q22686): a label that
    # differs from such a name only by Jr./Sr. is somebody else, in every race.
    known = {(lab.name.first, lab.name.last, lab.name.suffix) for lab in labels if lab.qid}
    by_subject: dict[str, list[Label]] = defaultdict(list)
    for lab in labels:
        by_subject[lab.subject].append(lab)
    for subject, labs in by_subject.items():
        _unify(subject, labs, out, known)
    return out


def _index_qid(lab: Label, index) -> tuple[str | None, str]:
    from pmpol.entities.sources import name_variants

    # With a middle name, only that exact name: the index also holds "first last" variants, and "Daniel J.
    # Sullivan" must not become "Daniel Scott Sullivan" (Alaska's senator) through "daniel sullivan".
    variants = {lab.name.full} if lab.name.middle else name_variants(f"{lab.name.first} {lab.name.last}")
    ids = {i for v in variants for i in index.by_alias.get(v, ())}
    ents = [index.entities[i] for i in ids if _suffix_fits(lab.name, index.entities[i].name)]
    in_race = [e for e in ents if lab.race and lab.race in e.races]
    pick = in_race if in_race else []
    qids = {e.wikidata for e in pick if e.wikidata}
    if len(qids) == 1:
        q = qids.pop()
        return q, f"entity index: {', '.join(sorted(set().union(*(e.sources for e in pick))))} ({q})"
    return None, ""


def _unify(subject: str, labs: list[Label], out: Identities, known: set = frozenset()) -> None:
    """Union-find over labels of one race: exact names always, compatible names unless a cannot-link applies."""
    parent = list(range(len(labs)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    # Cannot-link: two different options of one event, or two different QIDs.
    options: dict[str, dict[str, set[int]]] = defaultdict(lambda: defaultdict(set))  # event -> market -> labels
    for i, lab in enumerate(labs):
        options[lab.event][lab.market].add(i)
    apart: set[frozenset] = set()
    for markets in options.values():
        groups = list(markets.values())
        for a in range(len(groups)):
            for b in range(a + 1, len(groups)):
                apart |= {frozenset((i, j)) for i in groups[a] for j in groups[b]}

    def members(r):
        return [i for i in range(len(labs)) if find(i) == r]

    def can_join(i, j) -> bool:
        ri, rj = find(i), find(j)
        if ri == rj:
            return True
        mi, mj = members(ri), members(rj)
        if any(frozenset((x, y)) in apart for x in mi for y in mj):
            return False
        qids = {labs[x].qid for x in mi + mj if labs[x].qid}
        if len(qids) > 1:
            return False
        names = [labs[x].name for x in mi + mj]
        if len({n.suffix for n in names}) > 1 and any((n.first, n.last, sfx) in known
                                                      for n in names for sfx in {m.suffix for m in names}):
            return False  # "Donald J. Trump" is a known person here, so "Donald J. Trump Jr." is not him
        if qids:  # a known person keeps their suffix: Donald Trump (Q22686) never absorbs "Donald Trump Jr."
            suffixes = {labs[x].name.suffix for x in mi + mj if labs[x].qid}
            if any(labs[x].name.suffix not in suffixes for x in mi + mj):
                return False
        return True

    def join(i, j):
        parent[find(i)] = find(j)

    by_last: dict[str, list[int]] = defaultdict(list)
    for i, lab in enumerate(labs):
        by_last[lab.name.last].append(i)
    for idx in by_last.values():
        # exact: same first, middle and suffix-insensitive name
        for a in idx:
            for b in idx:
                if a < b and labs[a].name.first == labs[b].name.first and labs[a].name.middle == labs[b].name.middle \
                        and can_join(a, b):
                    join(a, b)
        # compatible: nickname or initial; middle initials must not conflict, and a nickname match needs no middle
        for a in idx:
            for b in idx:
                if a >= b or find(a) == find(b):
                    continue
                na, nb = labs[a].name, labs[b].name
                if _middle_conflict(na, nb) or not compatible_first(na.first, nb.first):
                    continue
                if na.first != nb.first and (na.middle or nb.middle) and na.middle != nb.middle:
                    continue  # a nickname or initial with a middle name on one side only
                if can_join(a, b):
                    join(a, b)

    for r in {find(i) for i in range(len(labs))}:
        group = members(r)
        if any(frozenset((x, y)) in apart for x in group for y in group):
            for x in group:  # one identity cannot be two options of one event
                out.unread[labs[x].market] = "two options of one event resolve to one person"
            continue
        qids = {labs[x].qid for x in group if labs[x].qid}
        if qids:
            ident = qids.pop()
            how = next(labs[x].how for x in group if labs[x].qid)
        else:
            # the id carries the suffix: "Donald J. Trump" and "Donald J. Trump Jr." are two people
            first = min((labs[x] for x in group), key=lambda lab: (len(lab.name.middle), lab.name.full,
                                                                   lab.name.suffix))
            # scoped to the contest (country, jurisdiction, office, year), not the stage: the same person is one
            # identity in the primary and the general election of one contest
            scope = "|".join(subject.split("|")[:4])
            ident = f"local:{scope}|{first.name.full}" + (f" {first.name.suffix}" if first.name.suffix else "")
            how = "local: contest + full name"
        for x in group:
            out.of[labs[x].market] = ident
            out.how[labs[x].market] = how + ("" if len(group) == 1 else f"; {len(group)} labels in this race")
