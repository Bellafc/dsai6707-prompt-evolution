"""The proposition ontology as the main pipeline's source of relations.

The hand-written templates (pmpol.universe.relations) still run, as an independent cross-check: every
template relation is compared with what the ontology derives (agree / differ / not read), and template
violations the ontology does not reproduce are listed in the universe report.

Relations keep the pipeline's Relation shape:
  template    "onto:<variable kind>:<basis>", e.g. "onto:winner:same_set", "onto:margin:bridge_margin_winner"
  group       the variable, e.g. "winner(United States|TX|senate|2026|general)"
  confidence  how the legs were identified:
                rule        parties, numbers, dates, official series: read from labels and strike fields
                entity      people, every one resolved to a Wikidata item (pmpol.propositions.people)
                name        a person known only within the race (race + full name), or a person-party bridge
                label       a party list or single name kept as written
                descriptor  an event descriptor (action + arguments) for deadline questions
                title       an event's normalised title (no known action)
  note        resolution details read from the rules (boundaries, window start, announcement, ...)
  rules       for cross-venue relations, the comparison of the legs' resolution conditions
              (pmpol.propositions.resolution): equivalent / unverified / minor / material
"""

from __future__ import annotations

from dataclasses import dataclass, field

from pmpol.models import Relation
from pmpol.propositions import Prop
from pmpol.propositions.derive import Comparison, Derived, compare, derive, parse_universe
from pmpol.propositions.parse import Parsed
from pmpol.universe.index import Universe

KIND_ZH = {"winner": "勝選", "control": "控制權", "nominee": "提名", "margin": "勝差", "vote_share": "得票率",
           "turnout": "投票數", "seats": "席次", "event_time": "發生時間", "joint": "組合", "indicator": "官方統計", "quantity": "數值（通用）", "choice": "選項（通用）", "cabinet": "政府組成"}
# Rule labels and their logic live in config/inference_rules.toml (pmpol.propositions.rules).


def template_name(d: Derived) -> str:
    return f"onto:{d.var.split('(', 1)[0]}:{d.basis}"


def label(template: str) -> str | None:
    """Chinese label of an ontology template ("勝選・同一命題"), None for other templates."""
    if not template.startswith("onto:"):
        return None
    from pmpol.propositions.rules import load

    _, kind, basis = template.split(":", 2)
    r = load().rule(basis)
    return f"{KIND_ZH.get(kind, kind)}・{r.label if r else basis}"


def logic(template: str) -> str | None:
    if not template.startswith("onto:"):
        return None
    from pmpol.propositions.rules import load

    basis = template.rsplit(":", 1)[-1]
    r = load().rule(basis)
    return (r.logic or r.statement) if r else None


def confidence(d: Derived, prop_of: dict[str, Prop]) -> str:
    props = [prop_of[k] for k in d.lhs + d.rhs if k in prop_of]
    values = {v for p in props for v in p.values}
    if any(v.startswith("name:") for v in values):
        return "label"
    if d.basis == "bridge_person_party":
        return "name"
    if any(v.startswith("person:") for v in values):
        # every person resolved to a Wikidata item: the identity is the entity layer's, not a name key
        return "entity" if all(v.startswith("person:Q") for v in values) else "name"
    if props and props[0].var.kind in ("quantity", "choice"):
        return "title"  # generic forms: the subject is the bag of title words
    if props and props[0].var.kind == "event_time":
        return "descriptor" if "(" in props[0].var.subject and " | " not in props[0].var.subject else "title"
    return "rule"


def to_relation(d: Derived, prop_of: dict[str, Prop], u: Universe | None = None, cache: dict | None = None) -> Relation:
    r = Relation(d.kind, list(d.lhs), list(d.rhs), template_name(d), d.var, confidence(d, prop_of),
                 "; ".join(dict.fromkeys(d.notes)), grounds=tuple(d.grounds))
    if u is not None and r.cross_venue:
        check = rule_check(u, r, prop_of, cache if cache is not None else {})
        r.rules, r.rules_detail = check.status, check.text()
    return r


def rule_check(u: Universe, r: Relation, prop_of: dict[str, Prop], cache: dict):
    """Compare the resolution conditions of a relation's legs across venues (pmpol.propositions.resolution)."""
    from pmpol.propositions.resolution import attributes, compare

    legs = []
    for k in r.lhs + r.rhs:
        p = prop_of.get(k)
        kind = p.var.kind if p else r.template.split(":")[1]
        if (k, kind) not in cache:
            cache[(k, kind)] = attributes(u.markets[k], kind)
        legs.append((k.split(":", 1)[0], cache[(k, kind)]))
    return compare(legs)


@dataclass
class OntologyRun:
    parsed: Parsed
    derived: list[Derived]
    relations: list[Relation]
    crosscheck: Comparison | None = None
    template_relations: list[Relation] = field(default_factory=list)


def build(u: Universe, templates: list[Relation] | None = None, index=None, wd_people=(), kb=None,
          candidates: dict | None = None, candidacies=()) -> OntologyRun:
    """Relations from the ontology; with `templates`, also the cross-check against them. `index`, `wd_people`
    and `candidacies` give people Wikidata identities (pmpol.propositions.people)."""
    parsed = parse_universe(u, index, wd_people, candidacies)
    derived = derive(u, parsed.props, kb, candidates)
    prop_of = {p.market: p for p in parsed.props}
    cache: dict = {}
    run = OntologyRun(parsed, derived, [to_relation(d, prop_of, u, cache) for d in derived])
    if templates is not None:
        run.template_relations = templates
        run.crosscheck = compare(u, templates, parsed.props, derived)
    return run
