"""Election reference classes: the outside view (Kahneman & Lovallo 1993, "reference class forecasting";
Tetlock & Gardner 2015: start from the base rate, then adjust for the case).

The first class is the classic one for U.S. midterms: how many House seats the president's party gained or lost
in every midterm since 1946; the second is the same for the Senate (2026-10-05). They are built from four sources,
each kept as an L1 record in the knowledge base:

  House party divisions   history.house.gov, Office of the Historian (party seats at the start of each Congress;
                          U.S. government work, public domain)
  Senate party divisions  senate.gov, Senate Historical Office ("party division immediately following the
                          election, unless otherwise noted"; U.S. government work, public domain)
  presidents' terms       history.house.gov, "Presidents and Their Coinciding Congresses" (same licence)
  presidents' parties     the Miller Center (University of Virginia) president pages, "Political Party" (fact
                          only, quoted; the page text is not copied)

and the L2 base rate is derived from them (`derived_from`), all in the proposed state until a person reviews
them (`pmpol reference --write-kb` writes kb/L1/us_house_history.yaml, kb/L1/us_senate_history.yaml and
kb/L2/election_reference.yaml).

The outside view of a chamber control market sets the market next to that frequency: the share of past midterms in
which the president's party moved enough seats to change who holds the majority now. In the Senate the vice
president, of the president's party, breaks ties, so half the seats keep control; only a third of the Senate is
elected at a time, and which seats are up is something the class does not see. Both are shown side by side
and neither is a fact; the reference class itself is a key assumption (`midterm_reference_class`).
"""

from __future__ import annotations

import html as htmllib
import math
import re
import statistics
import time
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

DATA = Path("data/reference")
UA = "pmpol/0.1 (https://github.com/bellafc/polymarket_politics; research, read-only)"
HOUSE_URL = "https://history.house.gov/Institution/Party-Divisions/Party-Divisions/"
TERMS_URL = "https://history.house.gov/Institution/Presidents-Coinciding/Presidents-Coinciding/"
PARTY_URL = "https://millercenter.org/president/{slug}"
LICENCE = {"house": "public domain (U.S. government work)", "party": "Miller Center (fact and short quote only)"}
SINCE = 1945  # the post-war reference class (the 79th Congress onwards)
MAJORITY = 218  # of 435 seats
SENATE_URL = "https://www.senate.gov/history/partydiv.htm"
SENATE_FACT = "us.senate.party_divisions"
SENATE_MIDTERM_FACT = "us.senate.midterm_presidents_party_change"
# names as history.house.gov writes them -> Miller Center page
SLUG = {"Harry S. Truman": "truman", "Dwight D. Eisenhower": "eisenhower", "John F. Kennedy": "kennedy",
        "Lyndon B. Johnson": "lbjohnson", "Richard M. Nixon": "nixon", "Gerald R. Ford": "ford",
        "James Earl “Jimmy” Carter": "carter", "Ronald Reagan": "reagan", "George H.W. Bush": "bush",
        "William J. Clinton": "clinton", "George W. Bush": "gwbush", "Barack Obama": "obama",
        "Donald J. Trump": "trump", "Joseph R. Biden Jr.": "biden"}
PARTY = {"democrat": "D", "democratic": "D", "republican": "R"}
_MONTH = {m: i + 1 for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
                                          "dec"))}

HOUSE_FACT = "us.house.party_divisions"
TERMS_FACT = "us.president.terms"
PARTY_FACT = "us.president.party."  # + slug
MIDTERM_FACT = "us.house.midterm_presidents_party_change"


def _cells(row: str) -> list[str]:
    row = re.sub(r"<sup[^>]*>.*?</sup>", "", row, flags=re.S)  # footnote markers ("435<sup>5</sup>")
    return [re.sub(r"\s+", " ", htmllib.unescape(re.sub(r"<[^>]+>", "", c))).strip()
            for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)]


def parse_house(page: str, since: int = SINCE) -> dict[int, dict]:
    """Congress number -> {years, seats, D, R, other}, from the tables whose columns are Democrats, Republicans."""
    out, cols = {}, None
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", page, re.S):
        c = _cells(row)
        if "<th" in row:
            cols = c
            continue
        if not cols or len(c) < 5 or cols[2:4] != ["Democrats", "Republicans"]:
            continue
        m = re.match(r"(\d+)\w*\s*\((\d{4})\s*[–-]\s*(\d{4})\)", c[0])
        if not m or int(m.group(2)) < since:
            continue
        other = c[4] if c[4].isdigit() else sum(int(x) for x in re.findall(r"\((\d+)\)", c[4]))  # "Independent (2)"
        try:
            out[int(m.group(1))] = {"years": f"{m.group(2)}-{m.group(3)}", "seats": int(c[1]), "D": int(c[2]),
                                    "R": int(c[3]), "other": int(other)}
        except ValueError:
            continue
    return out


_SENATE_PARTY = {"democrats": "D", "democrat": "D", "republicans": "R", "republican": "R"}


def parse_senate(page: str, since: int = SINCE) -> dict[int, dict]:
    """Congress number -> {years, seats, D, R, other[, note]} from the Senate Historical Office's party division page
    (one block per Congress: "Majority Party: Democrats (57 seats)", "Other Parties: 1 Progressive", "Total Seats")."""
    text = htmllib.unescape(re.sub(r"<[^>]+>", " ", page))
    text = re.sub(r"\s+", " ", text)
    out = {}
    blocks = re.split(r"(?=\b\d+(?:st|nd|rd|th) Congress \(\d{4})", text)
    for b in blocks:
        m = re.match(r"(\d+)\w* Congress \((\d{4})\s*[–-]\s*(\d{4})\)", b)
        if not m or int(m.group(2)) < since:
            continue
        row = {"years": f"{m.group(2)}-{m.group(3)}"}
        for role in ("Majority", "Minority"):
            # the first entry is the division right after the election ("Majority Party (Jan 3-20, 2001): ...")
            hit = re.search(rf"{role} Party(?: \([^)]*\))?: (\w+) \((\d+) seats\)", b)
            if hit and hit.group(1).lower() in _SENATE_PARTY:
                row[_SENATE_PARTY[hit.group(1).lower()]] = int(hit.group(2))
        first = re.split(r" _{3,} ", b)[0]  # a Congress whose majority changed hands lists each period in turn
        total = re.search(r"Total Seats: (\d+)", first)
        other = re.search(r"Other Parties: (.*?)(?: Total Seats|$)", first)
        if "D" not in row or "R" not in row or not total:
            continue
        row["seats"] = int(total.group(1))
        row["other"] = sum(int(x) for x in re.findall(r"\b(\d+) [A-Z]", other.group(1))) if other else 0
        note = re.search(r"Note: (.*?)(?: -{10,}|$)", b)
        if note:
            row["note"] = note.group(1).strip()[:300]
        out[int(m.group(1))] = {k: row[k] for k in ("years", "seats", "D", "R", "other", "note") if k in row}
    return out


def _date(text: str) -> date | None:
    m = re.match(r"([A-Za-z]+)\.?\s+(\d{1,2}),\s*(\d{4})", text.strip())
    if not m or m.group(1)[:3].lower() not in _MONTH:
        return None
    return date(int(m.group(3)), _MONTH[m.group(1)[:3].lower()], int(m.group(2)))


def parse_terms(page: str, since: int = SINCE) -> list[dict]:
    """Presidents' periods of service: {president, start, end (None while in office), congresses}."""
    out = []
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", page, re.S):
        c = _cells(row)
        if "<th" in row or len(c) < 5:
            continue
        span = re.split(r"\s*[–-]\s*", c[3], maxsplit=1)
        start = _date(span[0])
        if start is None or start.year < since:
            continue
        end = _date(span[1]) if len(span) > 1 else None
        out.append({"president": c[1], "start": start.isoformat(), "end": end.isoformat() if end else None,
                    "congresses": [int(x) for x in re.findall(r"\d+", c[4])]})
    return out


def parse_party(page: str) -> tuple[str, str] | None:
    """("D" | "R", the quoted text) from a Miller Center president page."""
    text = re.sub(r"\s+", " ", htmllib.unescape(re.sub(r"<[^>]+>", " ", page)))
    m = re.search(r"Political Party (\w+)", text)
    if not m or m.group(1).lower() not in PARTY:
        return None
    return PARTY[m.group(1).lower()], m.group(0)


def election_day(year: int) -> date:
    """The Tuesday after the first Monday in November."""
    d = date(year, 11, 2)
    return d + timedelta(days=(1 - d.weekday()) % 7)


def president_on(terms: list[dict], day: date) -> str | None:
    for t in terms:
        if date.fromisoformat(t["start"]) <= day and (t["end"] is None or day < date.fromisoformat(t["end"])):
            return t["president"]
    return None


def congress_elected(year: int) -> int:
    """The Congress chosen at the November election of `year` (the 1st was elected in 1788)."""
    return (year - 1788) // 2 + 1


def midterms(house: dict[int, dict], terms: list[dict], parties: dict[str, str]) -> list[dict]:
    """The president's party's seat change in a chamber at every midterm the table covers (seats right after the
    election of the Congress elected, minus those of the one before); `house` is either chamber's table."""
    out = []
    for n in sorted(house):
        year = 1788 + 2 * (n - 1)
        if year % 4 != 2 or n - 1 not in house:
            continue
        who = president_on(terms, election_day(year))
        party = parties.get(who or "")
        if party is None:
            continue
        before, after = house[n - 1][party], house[n][party]
        out.append({"year": year, "president": who, "party": party, "before": before, "after": after,
                    "change": after - before})
    return out


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return 0.0, 1.0
    p = k / n
    centre, half = p + z * z / (2 * n), z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (centre - half) / (1 + z * z / n)), min(1.0, (centre + half) / (1 + z * z / n))


# --- fetching (one request per page, cached; a refusal stops the run) -------------------------------------------

def fetch(url: str, cache: Path = DATA, pause: float = 2.0, get=None) -> str:
    name = re.sub(r"[^A-Za-z0-9]+", "_", url.split("://", 1)[-1]).strip("_") + ".html"
    path = cache / name
    if path.exists():
        return path.read_text(encoding="utf-8")
    if get is None:
        import httpx

        def get(u: str) -> str:
            r = httpx.get(u, timeout=60, follow_redirects=True, headers={"User-Agent": UA})
            r.raise_for_status()
            return r.text
    text = get(url)
    cache.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    time.sleep(pause)
    return text


@dataclass
class Reference:
    house: dict[int, dict]
    terms: list[dict]
    parties: dict[str, tuple[str, str]]  # president -> (party, quoted text)
    house_quote: str
    terms_quote: str
    senate: dict[int, dict] | None = None
    senate_quote: str = ""

    @property
    def rows(self) -> list[dict]:
        return midterms(self.house, self.terms, {k: v[0] for k, v in self.parties.items()})

    @property
    def senate_rows(self) -> list[dict]:
        return midterms(self.senate or {}, self.terms, {k: v[0] for k, v in self.parties.items()})


def build(get=None, cache: Path = DATA, pause: float = 2.0) -> Reference:
    house_page, terms_page = fetch(HOUSE_URL, cache, pause, get), fetch(TERMS_URL, cache, pause, get)
    house, terms = parse_house(house_page), parse_terms(terms_page)
    parties = {}
    for who in dict.fromkeys(t["president"] for t in terms):
        slug = SLUG.get(who)
        got = parse_party(fetch(PARTY_URL.format(slug=slug), cache, pause, get)) if slug else None
        if got:
            parties[who] = got
    last = max(house)
    h = house[last]
    house_quote = f"{_ordinal(last)} ({h['years'].replace('-', '–')}) {h['seats']} {h['D']} {h['R']}"
    last_row = [c for c in (_cells(r) for r in re.findall(r"<tr[^>]*>(.*?)</tr>", terms_page, re.S)) if len(c) >= 5][-1]
    terms_quote = " ".join(last_row[1:4])
    senate_page = fetch(SENATE_URL, cache, pause, get)
    senate = parse_senate(senate_page)
    flat = re.sub(r"\s+", " ", htmllib.unescape(re.sub(r"<[^>]+>", " ", senate_page)))
    hit = re.search(rf"{_ordinal(max(senate))} Congress \(\d{{4}}–\d{{4}}\) Majority Party: \w+ \(\d+ seats\)",
                    flat) if senate else None
    senate_quote = hit.group(0) if hit else ""
    return Reference(house, terms, parties, house_quote, terms_quote, senate, senate_quote)


def _ordinal(n: int) -> str:
    return f"{n}{'th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"


def kb_yaml(ref: Reference, recorded: date) -> tuple[str, str]:
    """(kb/L1/us_house_history.yaml, kb/L2/election_reference.yaml)."""

    def dump(header: str, facts: list[dict]) -> str:
        return header + _yaml({"facts": facts})

    l1 = [{"id": HOUSE_FACT, "layer": "L1", "subject": "U.S. House of Representatives",
           "predicate": "party_seats_initial_election_results",
           "value": {n: ref.house[n] for n in sorted(ref.house)},
           "source": {"title": "Office of the Historian, U.S. House: Party Divisions of the House of Representatives",
                      "url": HOUSE_URL, "quote": ref.house_quote, "license": LICENCE["house"]},
           "admiralty": "A1", "status": "proposed", "recorded_at": recorded,
           "note": f"Congresses {min(ref.house)}-{max(ref.house)}: seats won by each party in the initial election "
                   "results of each Congress, as the source defines them (later deaths, resignations, special elections "
                   "and party switches are not included); footnote markers removed. Generated by `pmpol reference "
                   "--write-kb`."},
          {"id": TERMS_FACT, "layer": "L1", "subject": "U.S. presidency", "predicate": "periods_of_service",
           "value": ref.terms,
           "source": {"title": "Office of the Historian, U.S. House: Presidents and Their Coinciding Congresses",
                      "url": TERMS_URL, "quote": ref.terms_quote, "license": LICENCE["house"]},
           "admiralty": "A1", "status": "proposed", "recorded_at": recorded,
           "note": "One row per period of service (a new vice president starts a new row). "
                   "Generated by `pmpol reference --write-kb`."}]
    for who, (party, quote) in sorted(ref.parties.items(), key=lambda kv: SLUG[kv[0]]):
        l1.append({"id": PARTY_FACT + SLUG[who], "layer": "L1", "subject": who, "predicate": "political_party",
                   "value": party,
                   "source": {"title": f"Miller Center, University of Virginia: {who}",
                              "url": PARTY_URL.format(slug=SLUG[who]), "quote": quote, "license": LICENCE["party"]},
                   "admiralty": "B1", "status": "proposed", "recorded_at": recorded})
    rows = ref.rows
    changes = [r["change"] for r in rows]
    l2 = _senate_l2(ref, recorded) + [{"id": MIDTERM_FACT, "layer": "L2", "subject": "U.S. midterm elections",
           "predicate": "presidents_party_house_seat_change",
           "value": {"sample": f"{rows[0]['year']}-{rows[-1]['year']}, {len(rows)} midterms",
                     "lost": sum(c < 0 for c in changes), "gained": sum(c > 0 for c in changes),
                     "median": statistics.median(changes), "mean": round(statistics.mean(changes), 1),
                     "rows": rows},
           "source": {"title": "pmpol reference class, from the Office of the Historian tables and the Miller Center",
                      "url": "https://github.com/bellafc/polymarket_politics/blob/claude/gallant-ritchie-j6n5c8/"
                             "src/pmpol/reference.py"},
           "admiralty": "A2", "status": "proposed", "recorded_at": recorded,
           "derived_from": [HOUSE_FACT, TERMS_FACT] + sorted(PARTY_FACT + SLUG[w] for w in ref.parties),
           "note": "Change = the president's party's seats in the initial election results of the Congress elected "
                   "at the midterm, minus those of the previous Congress: election against election (special "
                   "elections and party switches in between are not counted). The president is the one in office "
                   "on election day."}]
    return (dump("# Generated by `pmpol reference --write-kb`; review before marking the facts reviewed.\n", l1),
            dump("# Generated by `pmpol reference --write-kb`; review before marking the facts reviewed.\n", l2))


def _senate_l2(ref: Reference, recorded: date) -> list[dict]:
    rows = ref.senate_rows
    if not rows:
        return []
    changes = [r["change"] for r in rows]
    return [{"id": SENATE_MIDTERM_FACT, "layer": "L2", "subject": "U.S. midterm elections",
             "predicate": "presidents_party_senate_seat_change",
             "value": {"sample": f"{rows[0]['year']}-{rows[-1]['year']}, {len(rows)} midterms",
                       "lost": sum(c < 0 for c in changes), "gained": sum(c > 0 for c in changes),
                       "median": statistics.median(changes), "mean": round(statistics.mean(changes), 1),
                       "rows": rows},
             "source": {"title": "pmpol reference class, from the Senate Historical Office and House historian tables "
                                 "and the Miller Center",
                        "url": "https://github.com/bellafc/polymarket_politics/blob/claude/gallant-ritchie-j6n5c8/"
                               "src/pmpol/reference.py"},
             "admiralty": "A2", "status": "proposed", "recorded_at": recorded,
             "derived_from": [SENATE_FACT, TERMS_FACT] + sorted(PARTY_FACT + SLUG[w] for w in ref.parties),
             "note": "Change = the president's party's Senate seats right after the midterm election, minus those right "
                     "after the previous election (the source's table; Democrats and Republicans only, independents who "
                     "caucus with a party are not added to it, and a few entries reflect later party switches, as the "
                     "source notes). Only a third of the Senate is elected at a time: which seats are up is not in the "
                     "class. The president is the one in office on election day."}]


def _yaml(data) -> str:
    """YAML without anchors (a shared date would otherwise become "&id001" / "*id001")."""
    import yaml

    class Dumper(yaml.SafeDumper):
        def ignore_aliases(self, data):
            return True

    return yaml.dump(data, Dumper=Dumper, allow_unicode=True, sort_keys=False, width=120, default_flow_style=None)


def senate_kb_yaml(ref: Reference, recorded: date) -> str:
    """kb/L1/us_senate_history.yaml: the Senate party divisions since 1945."""
    fact = {"id": SENATE_FACT, "layer": "L1", "subject": "U.S. Senate", "predicate": "party_seats_after_election",
            "value": {n: ref.senate[n] for n in sorted(ref.senate or {})},
            "source": {"title": "U.S. Senate Historical Office: Party Division", "url": SENATE_URL,
                       "quote": ref.senate_quote, "license": LICENCE["house"]},
            "admiralty": "A1", "status": "proposed", "recorded_at": recorded,
            "note": "Seats of each party immediately following the election, unless the source notes otherwise (its "
                    "notes are kept, shortened, under each Congress); \"other\" counts independents and third parties. "
                    "Generated by `pmpol reference --write-kb`."}
    return ("# Generated by `pmpol reference --write-kb`; review before marking the facts reviewed.\n"
            + _yaml({"facts": [fact]}))


# --- the outside view of a chamber control market -------------------------------------------------------------------

@dataclass
class OutsideView:
    year: int
    president_party: str
    seats: int  # the president's party's seats in the current Congress's initial election results
    needed: int  # seat change the president's party can absorb and still hold a majority (>= this keeps it)
    keeps: int  # past midterms with a change >= needed
    n: int
    rows: list[dict]
    facts: list[str]  # KB facts cited: [chamber table, terms, party, reference class]
    chamber: str = "house"
    total: int = 435  # seats in the chamber now

    @property
    def share(self) -> float:
        return self.keeps / self.n if self.n else float("nan")

    def probability(self, party: str) -> float:
        """Base-rate probability that `party` holds the chamber after the midterm."""
        return self.share if party == self.president_party else 1 - self.share


CHAMBERS = {"house": (HOUSE_FACT, MIDTERM_FACT), "senate": (SENATE_FACT, SENATE_MIDTERM_FACT)}


def outside_view(kb, year: int, chamber: str = "house") -> OutsideView | None:
    """For a midterm `year`: the share of past midterms after which the president's party would hold the
    chamber's majority, given its seats now. In the Senate the vice president (of the president's party) breaks a
    tie, so half the seats keep control. None when the knowledge base lacks the records."""
    table, cls = CHAMBERS[chamber]
    if year % 4 != 2 or kb is None or cls not in kb.facts or table not in kb.facts:
        return None
    house = {int(k): v for k, v in kb.facts[table].value.items()}
    terms = kb.facts[TERMS_FACT].value if TERMS_FACT in kb.facts else []
    now = congress_elected(year) - 1
    who = president_on(terms, election_day(year))
    slug = SLUG.get(who or "")
    pf = kb.facts.get(PARTY_FACT + slug) if slug else None
    if now not in house or pf is None:
        return None
    party = pf.value
    rows = [r for r in kb.facts[cls].value["rows"] if r["year"] < year]
    seats = house[now][party]
    total = int(house[now].get("seats", 435 if chamber == "house" else 100))
    needed = (MAJORITY if chamber == "house" else math.ceil(total / 2)) - seats
    keeps = sum(r["change"] >= needed for r in rows)
    return OutsideView(year, party, seats, needed, keeps, len(rows), rows, [table, TERMS_FACT, pf.id, cls],
                       chamber, total)
