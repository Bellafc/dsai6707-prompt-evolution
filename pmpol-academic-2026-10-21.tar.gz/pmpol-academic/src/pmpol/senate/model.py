"""Joint Senate outcome model: Gaussian (or Student t) factor copula + FFT seat-count convolution.

State space per scenario: (d, r, i) = races won by the Democratic nominee, by the
Republican nominee, and by independents who caucus with Democrats. Totals follow:

    d_total = d_holdover + d + i        (Kalshi-style, caucus members included)
    r_total = r_holdover + r
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from pmpol.copula import conditional_table, gauss_hermite_normal, student_scale_nodes
from pmpol.senate.config import SenateConfig
from pmpol.senate.races import CATEGORIES


@dataclass
class RaceInput:
    state: str
    probs: dict[str, float]  # D, I, R summing to 1
    caucus_d: float  # P(independent winner caucuses with Democrats)


class SeatModel:
    """`nu` None: Gaussian copula; a number: Student t copula with that many degrees of freedom (pmpol.copula)."""

    def __init__(self, cfg: SenateConfig, races: list[RaceInput], rho: float, n_nodes: int = 48,
                 nu: float | None = None, n_scale: int = 16):
        self.cfg = cfg
        self.races = races
        self.rho = rho
        self.nu = nu
        z, wz = gauss_hermite_normal(n_nodes if nu is None else max(24, n_nodes // 2))
        if nu is None:
            self.nodes, self.scales, self.weights = z, np.ones_like(z), wz
        else:
            s, ws = student_scale_nodes(nu, n_scale)
            self.nodes = np.repeat(z, len(s))
            self.scales = np.tile(s, len(z))
            self.weights = np.outer(wz, ws).ravel()
        self._by_state = {r.state: r for r in races}
        self._cond = self._conditional_tables()
        self.joint = self._joint_pmf()
        d, r, i = np.indices(self.joint.shape)
        self.d_won, self.r_won = d, r
        self.d_total = cfg.d_holdover + d + i
        self.r_total = cfg.r_holdover + r

    def _conditional_tables(self) -> np.ndarray:
        """[node, race, category] probabilities given the common factor(s)."""
        probs = np.array([[race.probs[c] for c in CATEGORIES] for race in self.races])
        return conditional_table(probs, self.rho, self.nodes, self.scales, self.nu)

    def _joint_pmf(self) -> np.ndarray:
        """Per node, races are independent and each adds a unit vector (D, R, caucusing I) or nothing, so the
        characteristic function of the total is a product of 4-term sums: one inverse FFT per node, no forward ones
        (pmpol.fourier.convolve_outcomes gives the same pmf)."""
        n = len(self.races)
        n_ind = sum(1 for r in self.races if r.probs["I"] > 0)
        shape = (n + 1, n + 1, n_ind + 1)
        e = [np.exp(-2j * np.pi * np.arange(m) / m) for m in shape]
        e0, e1, e2 = e[0][:, None, None], e[1][None, :, None], e[2][None, None, :]
        caucus = np.array([r.caucus_d for r in self.races])
        joint = np.zeros(shape)
        for k, w in enumerate(self.weights):
            pd, pi, pr = self._cond[k, :, 0], self._cond[k, :, 1], self._cond[k, :, 2]
            spectrum = np.ones(shape, dtype=np.complex128)
            for j in range(n):
                spectrum *= pd[j] * e0 + pr[j] * e1 + pi[j] * caucus[j] * e2 + pi[j] * (1 - caucus[j])
            total = np.fft.ifftn(spectrum).real
            total[total < 0] = 0.0
            joint += w * total
        return joint / joint.sum()

    def prob(self, mask: np.ndarray) -> float:
        return float(self.joint[mask].sum())

    def prob_control(self, party: str) -> float:
        if party == "D":
            return self.prob(self.d_total >= self.cfg.d_control_seats)
        return self.prob(self.r_total >= self.cfg.r_control_seats)

    def prob_all_of(self, states: list[str], party: str) -> float:
        """P(party's nominee wins every listed race), integrated over the factor."""
        idx = [self._index(s) for s in states]
        c = CATEGORIES.index(party)
        per_node = np.prod(self._cond[:, idx, c], axis=1)
        return float(np.dot(self.weights, per_node))

    def prob_any_loss(self, states: list[str], party: str) -> float:
        return 1.0 - self.prob_all_of(states, party)

    def count_pmf(self, variable: str) -> dict[int, float]:
        grid = getattr(self, variable)
        out: dict[int, float] = {}
        for v, p in zip(grid.ravel(), self.joint.ravel()):
            out[int(v)] = out.get(int(v), 0.0) + float(p)
        return dict(sorted(out.items()))

    def _index(self, state: str) -> int:
        for j, r in enumerate(self.races):
            if r.state == state:
                return j
        raise KeyError(state)



def census_divisions(path=None) -> dict[str, str]:
    """State postal code -> Census division (config/census_divisions.toml)."""
    import tomllib
    from pathlib import Path

    path = Path(path or Path(__file__).resolve().parents[3] / "config" / "census_divisions.toml")
    raw = tomllib.loads(path.read_text(encoding="utf-8"))
    return {st: div for div, states in raw["division"].items() for st in states}


class ClusterSeatModel(SeatModel):
    """Two factors (Gaussian): a national one shared by every race and one per pre-set group of states.

    Race j's latent is sqrt(rho_n) Z + sqrt(rho_c) W_g(j) + sqrt(1 - rho_n - rho_c) e_j, so two races in one group
    correlate at rho_n + rho_c and across groups at rho_n. Given Z the groups are independent; within a group the
    group factor is integrated out first, then the groups' characteristic functions multiply (one inverse FFT per
    national node). With rho_c = 0 it is the one-factor SeatModel."""

    def __init__(self, cfg: SenateConfig, races: list[RaceInput], rho_n: float, rho_c: float,
                 groups: dict[str, str], n_z: int = 32, n_w: int = 16):
        self.cfg, self.races, self.nu = cfg, races, None
        self.rho_n, self.rho_c, self.rho = rho_n, rho_c, rho_n + rho_c
        self.nodes, self.weights = gauss_hermite_normal(n_z)
        self.scales = np.ones_like(self.nodes)
        self.w_nodes, self.w_weights = gauss_hermite_normal(n_w)
        self._by_state = {r.state: r for r in races}
        names = [groups.get(r.state, f"_{r.state}") for r in races]  # a state outside the table is its own group
        self.group_index = {g: [j for j, x in enumerate(names) if x == g] for g in dict.fromkeys(names)}
        tot = rho_n + rho_c
        if tot <= 0:
            f = np.repeat(self.nodes[:, None], n_w, axis=1)
        else:
            f = (np.sqrt(rho_n) * self.nodes[:, None] + np.sqrt(rho_c) * self.w_nodes[None, :]) / np.sqrt(tot)
        probs = np.array([[race.probs[c] for c in CATEGORIES] for race in races])
        self._cond2 = conditional_table(probs, tot, f.ravel()).reshape(n_z, n_w, len(races), len(CATEGORIES))
        self.joint = self._joint_pmf()
        d, r, i = np.indices(self.joint.shape)
        self.d_won, self.r_won = d, r
        self.d_total = cfg.d_holdover + d + i
        self.r_total = cfg.r_holdover + r

    def _joint_pmf(self) -> np.ndarray:
        n = len(self.races)
        n_ind = sum(1 for r in self.races if r.probs["I"] > 0)
        shape = (n + 1, n + 1, n_ind + 1)
        e = [np.exp(-2j * np.pi * np.arange(m) / m) for m in shape]
        e0, e1, e2 = e[0][:, None, None], e[1][None, :, None], e[2][None, None, :]
        caucus = np.array([r.caucus_d for r in self.races])
        joint = np.zeros(shape)
        for k, wz in enumerate(self.weights):
            spectrum = np.ones(shape, dtype=np.complex128)
            for idx in self.group_index.values():
                group = np.zeros(shape, dtype=np.complex128)
                for l_, ww in enumerate(self.w_weights):
                    c = self._cond2[k, l_]
                    term = np.ones(shape, dtype=np.complex128)
                    for j in idx:
                        term *= c[j, 0] * e0 + c[j, 2] * e1 + c[j, 1] * caucus[j] * e2 + c[j, 1] * (1 - caucus[j])
                    group += ww * term
                spectrum *= group
            total = np.fft.ifftn(spectrum).real
            total[total < 0] = 0.0
            joint += wz * total
        return joint / joint.sum()

    def prob_all_of(self, states: list[str], party: str) -> float:
        c = CATEGORIES.index(party)
        want = {self._index(s) for s in states}
        per_z = np.ones(len(self.weights))
        for idx in self.group_index.values():
            js = [j for j in idx if j in want]
            if js:
                per_z *= np.prod(self._cond2[:, :, js, c], axis=2) @ self.w_weights
        return float(np.dot(self.weights, per_z))


class LoadingSeatModel(SeatModel):
    """Two factors (Gaussian): a national one, and one structural factor U every race loads on with its own
    pre-set loading s in [-1, 1]: X = sqrt(rho_n) Z + sqrt(rho_d) s U + sqrt(1 - rho_n - rho_d s^2) e, so two races
    correlate at rho_n + rho_d s_i s_j (states alike in the structure move together, unlike ones apart)."""

    def __init__(self, cfg: SenateConfig, races: list[RaceInput], rho_n: float, rho_d: float,
                 loading: dict[str, float], n_z: int = 24, n_u: int = 16):
        from scipy.stats import norm

        self.cfg, self.races, self.nu = cfg, races, None
        self.rho_n, self.rho_d, self.rho = rho_n, rho_d, rho_n + rho_d
        z, wz = gauss_hermite_normal(n_z)
        u, wu = gauss_hermite_normal(n_u)
        self.nodes = np.repeat(z, n_u)
        self.u_nodes = np.tile(u, n_z)
        self.weights = np.outer(wz, wu).ravel()
        self.scales = np.ones_like(self.nodes)
        self._by_state = {r.state: r for r in races}
        s = np.array([loading.get(r.state, 0.0) for r in races])
        probs = np.clip(np.array([[race.probs[c] for c in CATEGORIES] for race in races]), 0, None)
        probs = probs / probs.sum(axis=1, keepdims=True)
        thr = norm.ppf(np.clip(np.cumsum(probs, axis=1)[:, :-1], 1e-12, 1 - 1e-12))  # [race, 2]
        resid = np.sqrt(np.clip(1 - rho_n - rho_d * s ** 2, 1e-9, None))
        shift = np.sqrt(rho_n) * self.nodes[:, None] + np.sqrt(rho_d) * s[None, :] * self.u_nodes[:, None]
        cond = norm.cdf((thr[None, :, :] - shift[:, :, None]) / resid[None, :, None])  # [node, race, 2]
        zeros, ones = np.zeros((*cond.shape[:2], 1)), np.ones((*cond.shape[:2], 1))
        self._cond = np.diff(np.concatenate([zeros, cond, ones], axis=2), axis=2)
        self.joint = self._joint_pmf()
        d, r, i = np.indices(self.joint.shape)
        self.d_won, self.r_won = d, r
        self.d_total = cfg.d_holdover + d + i
        self.r_total = cfg.r_holdover + r
