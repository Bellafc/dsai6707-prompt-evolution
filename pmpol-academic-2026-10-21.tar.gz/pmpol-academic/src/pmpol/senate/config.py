from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_CONFIG = Path(__file__).resolve().parents[3] / "config" / "senate_2026.toml"


@dataclass
class RaceConfig:
    state: str
    name: str
    kalshi: str
    polymarket: str
    held_by: str
    pres_2024: str
    candidates: dict[str, str] = field(default_factory=dict)
    caucus_d: dict[str, float] = field(default_factory=dict)


@dataclass
class ObservableConfig:
    venue: str
    event: str
    variable: str
    party: str | None = None
    states: list[str] = field(default_factory=list)


@dataclass
class SenateConfig:
    as_of: str
    d_holdover: int
    r_holdover: int
    d_control_seats: int
    r_control_seats: int
    default_independent_caucus_d: float
    races: list[RaceConfig]
    observables: list[ObservableConfig]
    # Knowledge-base facts the thresholds and holdovers came from (empty when the config was used).
    provenance: dict[str, list[str]] = field(default_factory=dict)

    def race(self, state: str) -> RaceConfig:
        for r in self.races:
            if r.state == state:
                return r
        raise KeyError(state)


def load_config(path: Path | str = DEFAULT_CONFIG) -> SenateConfig:
    with open(path, "rb") as f:
        raw = tomllib.load(f)
    meta = raw["meta"]
    cfg = SenateConfig(
        as_of=meta["as_of"],
        d_holdover=meta["d_holdover"],
        r_holdover=meta["r_holdover"],
        d_control_seats=meta["d_control_seats"],
        r_control_seats=meta["r_control_seats"],
        default_independent_caucus_d=meta["default_independent_caucus_d"],
        races=[RaceConfig(**r) for r in raw["race"]],
        observables=[ObservableConfig(**o) for o in raw.get("observable", [])],
    )
    _apply_knowledge_base(cfg)
    states = [r.state for r in cfg.races]
    if len(set(states)) != len(states):
        raise ValueError("duplicate state in race registry")
    seats_up = len(cfg.races)
    if cfg.d_holdover + cfg.r_holdover + seats_up != 100:
        raise ValueError(f"holdover {cfg.d_holdover}+{cfg.r_holdover} plus {seats_up} races != 100 seats")
    return cfg


def control_thresholds(kb) -> tuple[int, int, list[str]]:
    """Seats each party needs to control the Senate, from L0 rules and the L1 Vice President fact."""
    seats = kb.value("us.senate.seats")
    vp_party = (kb.value("us.vice_president") or {}).get("party")
    if seats is None or vp_party not in ("D", "R"):
        raise KeyError("knowledge base lacks us.senate.seats or us.vice_president")
    majority, half = seats // 2 + 1, seats // 2
    d_needs = half if vp_party == "D" else majority
    r_needs = half if vp_party == "R" else majority
    return d_needs, r_needs, ["us.senate.seats", "us.senate.vp_tiebreak", "us.vice_president"]


def _apply_knowledge_base(cfg: SenateConfig) -> None:
    """Take control thresholds and holdovers from the knowledge base when it has them.

    The TOML values stay as a fallback and must agree, so a stale config is caught.
    """
    try:
        from pmpol.kb import KnowledgeBase

        kb = KnowledgeBase.load()
    except Exception:
        return
    try:
        d_needs, r_needs, facts = control_thresholds(kb)
    except KeyError:
        return
    if (d_needs, r_needs) != (cfg.d_control_seats, cfg.r_control_seats):
        raise ValueError(f"senate config control seats {cfg.d_control_seats}/{cfg.r_control_seats} disagree with "
                         f"knowledge base {d_needs}/{r_needs} ({', '.join(facts)})")
    cfg.provenance["control_seats"] = facts
    hold = kb.value("us.senate.2026_holdover")
    if hold:
        if (hold["D"], hold["R"]) != (cfg.d_holdover, cfg.r_holdover):
            raise ValueError(f"senate config holdover {cfg.d_holdover}/{cfg.r_holdover} disagrees with "
                             f"knowledge base {hold['D']}/{hold['R']} (us.senate.2026_holdover)")
        cfg.provenance["holdover"] = ["us.senate.2026_holdover"]
