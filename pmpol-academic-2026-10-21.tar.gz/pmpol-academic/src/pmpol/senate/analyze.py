"""End-to-end Senate pricing run: fetch, calibrate implied correlation, emit signals."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np
from scipy.optimize import minimize_scalar

from pmpol.models import Event, Market, Signal
from pmpol.senate.config import SenateConfig
from pmpol.senate.model import RaceInput, SeatModel
from pmpol.senate.observables import PricedMarket, bind
from pmpol.senate.races import CATEGORIES, RaceQuote, blend, race_quote
from pmpol.venues.kalshi import KalshiClient
from pmpol.venues.polymarket import PolymarketClient

MODULE = "senate_seats"


@dataclass
class Snapshot:
    race_events: dict[str, dict[str, Event]] = field(default_factory=dict)  # state -> venue -> event
    observable_events: dict[str, Event] = field(default_factory=dict)  # "venue:event" -> event
    errors: list[str] = field(default_factory=list)


def fetch_snapshot(cfg: SenateConfig) -> Snapshot:
    k, p = KalshiClient(), PolymarketClient()
    getters = {"kalshi": k.get_event, "polymarket": p.get_event}
    snap = Snapshot()
    for race in cfg.races:
        snap.race_events[race.state] = {}
        for venue, event_id in (("kalshi", race.kalshi), ("polymarket", race.polymarket)):
            try:
                snap.race_events[race.state][venue] = getters[venue](event_id)
            except Exception as e:  # keep going; report the gap
                snap.errors.append(f"{venue}:{event_id} ({race.state}): {e}")
    for obs in cfg.observables:
        try:
            snap.observable_events[f"{obs.venue}:{obs.event}"] = getters[obs.venue](obs.event)
        except Exception as e:
            snap.errors.append(f"{obs.venue}:{obs.event}: {e}")
    return snap


@dataclass
class RaceRow:
    state: str
    quotes: dict[str, RaceQuote]
    consensus: dict[str, float]
    caucus_d: float


def race_rows(cfg: SenateConfig, snap: Snapshot, caucus_override: float | None = None) -> list[RaceRow]:
    rows = []
    for race in cfg.races:
        quotes = {}
        for venue, ev in snap.race_events.get(race.state, {}).items():
            q = race_quote(ev, race)
            if q is not None:
                quotes[venue] = q
        if not quotes:
            raise RuntimeError(f"no quotes for {race.state}")
        caucus = race.caucus_d.get("I", cfg.default_independent_caucus_d)
        if caucus_override is not None:
            caucus = caucus_override
        rows.append(RaceRow(race.state, quotes, blend(list(quotes.values())), caucus))
    return rows


def build_model(cfg: SenateConfig, rows: list[RaceRow], rho: float, nu: float | None = None) -> SeatModel:
    inputs = [RaceInput(r.state, r.consensus, r.caucus_d) for r in rows]
    return SeatModel(cfg, inputs, rho, nu=nu)


def priced_markets(cfg: SenateConfig, snap: Snapshot) -> tuple[list[PricedMarket], list[Market]]:
    priced, unparsed = [], []
    for obs in cfg.observables:
        ev = snap.observable_events.get(f"{obs.venue}:{obs.event}")
        if ev is None:
            continue
        p, u = bind(obs, ev.markets)
        priced += p
        unparsed += u
    return priced, unparsed


def fit_rho(cfg: SenateConfig, rows: list[RaceRow], priced: list[PricedMarket],
            nu: float | None = None) -> tuple[float, float]:
    """Implied correlation: rho minimising spread-weighted squared pricing error."""
    usable = [pm for pm in priced if pm.market.mid is not None]

    def loss(rho: float) -> float:
        model = build_model(cfg, rows, rho, nu)
        err = 0.0
        for pm in usable:
            w = 1.0 / max(pm.market.spread or 0.0, 0.01)
            err += w * (pm.model_price(model) - pm.market.mid) ** 2
        return err

    res = minimize_scalar(loss, bounds=(0.0, 0.95), method="bounded", options={"xatol": 1e-3})
    return float(res.x), float(res.fun)


def market_signal(pm: PricedMarket, model_price: float, min_edge: float) -> Signal | None:
    """Edge net of taker fees. Positive: buy YES at the ask below model; negative: sell YES
    (buy NO) at the bid above model."""
    m = pm.market
    if m.bid is None or m.ask is None:
        return None
    buy = model_price - m.ask - m.taker_fee(m.ask)
    sell = m.bid - model_price - m.taker_fee(m.bid)
    if buy >= min_edge:
        edge = buy
    elif sell >= min_edge:
        edge = -sell
    else:
        return None
    return Signal(
        module=MODULE,
        kind="implied_price",
        subject=m.key,
        edge=round(edge, 4),
        payload={
            "event": m.event_id,
            "outcome": m.outcome,
            "variable": pm.observable.variable,
            "model": round(model_price, 4),
            "bid": m.bid,
            "ask": m.ask,
            "ask_size": m.ask_size,
            "bid_size": m.bid_size,
        },
    )


def cross_venue_race_signals(rows: list[RaceRow], min_edge: float) -> list[Signal]:
    """Same race outcome quoted on both venues with one bid above the other's ask."""
    out = []
    for row in rows:
        if len(row.quotes) < 2:
            continue
        for c in CATEGORIES:
            legs = {v: max(q.markets.get(c, []), key=lambda m: m.mid or 0, default=None) for v, q in row.quotes.items()}
            if any(m is None or m.bid is None or m.ask is None for m in legs.values()):
                continue
            a, b = legs.values()
            for buy, sell in ((a, b), (b, a)):
                gap = sell.bid - buy.ask - buy.taker_fee(buy.ask) - sell.taker_fee(sell.bid)
                if gap >= min_edge:
                    out.append(Signal(
                        module=MODULE,
                        kind="cross_venue_race",
                        subject=f"{row.state}:{c}",
                        edge=round(gap, 4),
                        payload={"buy": buy.key, "buy_ask": buy.ask, "sell": sell.key, "sell_bid": sell.bid,
                                 "note": "check that both venues resolve on the same definition"},
                    ))
    return out


RHO_GRID = np.round(np.arange(0.0, 0.96, 0.05), 2)


def implied_rhos(cfg: SenateConfig, rows: list[RaceRow], priced: list[PricedMarket],
                 nu: float | None = None) -> dict[str, float | None]:
    """Per-market implied correlation: the rho at which the model matches the market mid.

    The spread of these values across markets is the correlation skew: one rho cannot
    price every market, and the outliers are where a single-factor model (or the
    market) is wrong. None when no rho in the grid reaches the mid.
    """
    curves = np.array([[pm.model_price(m) for pm in priced]
                       for m in (build_model(cfg, rows, r, nu) for r in RHO_GRID)])
    out: dict[str, float | None] = {}
    for j, pm in enumerate(priced):
        mid, y = pm.market.mid, curves[:, j] - (pm.market.mid or 0.0)
        out[pm.market.key] = None
        if mid is None:
            continue
        for i in range(len(RHO_GRID) - 1):
            if y[i] == 0 or y[i] * y[i + 1] < 0:
                t = y[i] / (y[i] - y[i + 1]) if y[i] != y[i + 1] else 0.0
                out[pm.market.key] = float(RHO_GRID[i] + t * (RHO_GRID[i + 1] - RHO_GRID[i]))
                break
    return out


TAILS = (None, 30.0, 10.0, 5.0, 3.0)  # Gaussian, then Student t with fewer degrees of freedom (fatter joint tails)
SWEEPS = ("all_of", "any_loss")  # markets on joint outcomes of several named races


@dataclass
class TailFit:
    nu: float | None
    rho: float
    loss: float
    sweep_rho: float | None  # median implied rho of the sweep markets
    count_rho: float | None  # median implied rho of the control and seat-count markets

    @property
    def skew(self) -> float | None:
        return None if self.sweep_rho is None or self.count_rho is None else self.sweep_rho - self.count_rho


@dataclass
class SweepBound:
    """Where a sweep market sits between independence and lockstep, from the race marginals alone (no copula)."""
    key: str
    variable: str
    states: list[str]
    mid: float
    independent: float  # every race independent
    lockstep: float  # every race moves together (comonotone): the most dependence possible

    @property
    def position(self) -> float | None:
        span = self.lockstep - self.independent
        return None if abs(span) < 1e-9 else (self.mid - self.independent) / span


def sweep_bounds(rows: list[RaceRow], priced: list[PricedMarket]) -> list[SweepBound]:
    """all_of: P(party wins every race) runs from the product of the marginals (independent) to the smallest one
    (lockstep). any_loss: P(party loses at least one) runs from 1 - product (independent) down to the largest single
    loss probability (lockstep)."""
    by_state = {r.state: r.consensus for r in rows}
    out = []
    for pm in priced:
        obs, mid = pm.observable, pm.market.mid
        if obs.variable not in SWEEPS or mid is None or not all(st in by_state for st in obs.states):
            continue
        win = [by_state[st][obs.party] for st in obs.states]
        if obs.variable == "all_of":
            out.append(SweepBound(pm.market.key, obs.variable, obs.states, mid, float(np.prod(win)), min(win)))
        else:
            out.append(SweepBound(pm.market.key, obs.variable, obs.states, mid, 1 - float(np.prod(win)), 1 - min(win)))
    return out


def _median(xs: list[float]) -> float | None:
    xs = sorted(x for x in xs if x is not None)
    return None if not xs else (xs[len(xs) // 2] if len(xs) % 2 else (xs[len(xs) // 2 - 1] + xs[len(xs) // 2]) / 2)


def tail_fits(cfg: SenateConfig, rows: list[RaceRow], priced: list[PricedMarket], nus=TAILS) -> list[TailFit]:
    """Per copula: the fitted rho and its loss, and the correlation skew (sweep markets' implied rho minus the
    control and seat-count markets'). Fatter joint tails should shrink the skew if tail dependence explains it."""
    out = []
    for nu in nus:
        rho, loss = fit_rho(cfg, rows, priced, nu)
        imp = implied_rhos(cfg, rows, priced, nu)
        sweep = [imp[pm.market.key] for pm in priced if pm.observable.variable in SWEEPS]
        count = [imp[pm.market.key] for pm in priced if pm.observable.variable not in SWEEPS]
        out.append(TailFit(nu, rho, loss, _median(sweep), _median(count)))
    return out


@dataclass
class ClusterFit:
    """A two-factor copula with a pre-set structure against the one-factor one, on the same markets (2026-10-07)."""
    rho_n: float
    rho_c: float
    loss: float
    loss_one: float  # one-factor Gaussian at its own fitted rho
    sweep_err: float | None  # mean absolute pricing error of the sweep markets
    sweep_err_one: float | None
    count_err: float | None  # the same for the control and seat-count markets
    count_err_one: float | None
    rho_one: float = 0.0
    name: str = "Census divisions"


def _errors(model, priced: list[PricedMarket]) -> tuple[float | None, float | None]:
    sw = [abs(pm.model_price(model) - pm.market.mid) for pm in priced
          if pm.market.mid is not None and pm.observable.variable in SWEEPS]
    ct = [abs(pm.model_price(model) - pm.market.mid) for pm in priced
          if pm.market.mid is not None and pm.observable.variable not in SWEEPS]
    return (float(np.mean(sw)) if sw else None), (float(np.mean(ct)) if ct else None)


def structure_fit(cfg: SenateConfig, rows: list[RaceRow], priced: list[PricedMarket], make, name: str,
                  step: float = 0.05) -> ClusterFit:
    """Fit (rho_n, rho_2) of a two-factor model make(inputs, rho_n, rho_2) on a grid (sum <= 0.9), then refine;
    same loss as fit_rho."""
    from scipy.optimize import minimize

    inputs = [RaceInput(r.state, r.consensus, r.caucus_d) for r in rows]
    usable = [pm for pm in priced if pm.market.mid is not None]

    def loss(x) -> float:
        rn, rc = float(x[0]), float(x[1])
        if rn < 0 or rc < 0 or rn + rc > 0.95:
            return 1e9
        model = make(inputs, rn, rc)
        return sum((pm.model_price(model) - pm.market.mid) ** 2 / max(pm.market.spread or 0.0, 0.01) for pm in usable)

    grid = [(a, b) for a in np.arange(0, 0.9 + 1e-9, step) for b in np.arange(0, 0.9 - a + 1e-9, step)]
    best = min(grid, key=loss)
    res = minimize(loss, np.array(best), method="Nelder-Mead", options={"xatol": 2e-3, "fatol": 1e-6, "maxiter": 80})
    rn, rc = (float(res.x[0]), float(res.x[1])) if res.fun <= loss(best) else best
    rho1, loss1 = fit_rho(cfg, rows, priced)
    two, one = make(inputs, rn, rc), build_model(cfg, rows, rho1)
    (s2, c2), (s1, c1) = _errors(two, priced), _errors(one, priced)
    return ClusterFit(rn, rc, float(loss((rn, rc))), loss1, s2, s1, c2, c1, rho1, name)


def structure_fits(cfg: SenateConfig, rows: list[RaceRow], priced: list[PricedMarket]) -> list[ClusterFit]:
    """The pre-set structures: Census divisions (geography) and education (bachelor's share, ACS via FRED)."""
    from pmpol.senate import demographics
    from pmpol.senate.model import ClusterSeatModel, LoadingSeatModel, census_divisions

    groups = census_divisions()
    out = [structure_fit(cfg, rows, priced, lambda i, a, b: ClusterSeatModel(cfg, i, a, b, groups), "Census divisions")]
    try:
        load = demographics.loadings(demographics.fetch())
    except Exception:  # no data: the geographic structure alone
        return out
    out.append(structure_fit(cfg, rows, priced, lambda i, a, b: LoadingSeatModel(cfg, i, a, b, load),
                             "education (bachelor's share)"))
    return out


@dataclass
class RunResult:
    cfg: SenateConfig
    rows: list[RaceRow]
    rho: float
    loss: float
    model: SeatModel
    independent_model: SeatModel
    priced: list[PricedMarket]
    unparsed: list[Market]
    signals: list[Signal]
    caucus_sensitivity: dict[str, dict[str, float]]
    implied_rho: dict[str, float | None]
    errors: list[str]
    nu: float | None = None
    tails: list[TailFit] = field(default_factory=list)
    sweeps: list[SweepBound] = field(default_factory=list)
    clusters: list[ClusterFit] = field(default_factory=list)


def run(cfg: SenateConfig, snap: Snapshot, rho: float | None = None, min_edge: float = 0.01,
        nu: float | None = None, tails: bool = False, clusters: bool = False) -> RunResult:
    rows = race_rows(cfg, snap)
    priced, unparsed = priced_markets(cfg, snap)
    loss = float("nan")
    if rho is None:
        rho, loss = fit_rho(cfg, rows, priced, nu)
    model = build_model(cfg, rows, rho, nu)
    signals = [s for pm in priced if (s := market_signal(pm, pm.model_price(model), min_edge))]
    signals += cross_venue_race_signals(rows, min_edge)
    signals.sort(key=lambda s: -abs(s.edge))

    sensitivity = {}
    for q in (0.0, 1.0):
        alt = build_model(cfg, race_rows(cfg, snap, caucus_override=q), rho, nu)
        sensitivity[f"caucus_d={q:g}"] = {pm.market.key: pm.model_price(alt) for pm in priced}
    return RunResult(cfg, rows, rho, loss, model, build_model(cfg, rows, 0.0), priced, unparsed,
                     signals, sensitivity, implied_rhos(cfg, rows, priced, nu), snap.errors, nu,
                     tail_fits(cfg, rows, priced) if tails else [], sweep_bounds(rows, priced),
                     structure_fits(cfg, rows, priced) if clusters else [])


def save_snapshot(snap: Snapshot, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "race_events": {s: {v: asdict(e) for v, e in d.items()} for s, d in snap.race_events.items()},
        "observable_events": {k: asdict(e) for k, e in snap.observable_events.items()},
        "errors": snap.errors,
    }
    path.write_text(json.dumps(data, ensure_ascii=False))


def load_snapshot(path: Path) -> Snapshot:
    data = json.loads(path.read_text())

    def ev(d: dict) -> Event:
        return Event(**{**d, "markets": [Market(**m) for m in d["markets"]]})

    return Snapshot(
        race_events={s: {v: ev(e) for v, e in d.items()} for s, d in data["race_events"].items()},
        observable_events={k: ev(e) for k, e in data["observable_events"].items()},
        errors=data.get("errors", []),
    )


def _pct(x: float | None) -> str:
    return "—" if x is None else f"{100 * x:.1f}"


def _rho(x: float | None) -> str:
    return "—" if x is None else f"{x:.2f}"


def render_report(res: RunResult, generated_at: str) -> str:
    cfg, model = res.cfg, res.model
    L = [f"# Senate 2026 pricing report — {generated_at}", ""]
    copula = "Gaussian copula" if res.nu is None else f"Student t copula, ν = {res.nu:g}"
    L.append(f"- Implied correlation ρ = **{res.rho:.3f}** (one-factor {copula}, fit across "
             f"{len(res.priced)} seat/control/combo markets)")
    L.append(f"- Model P(D control) = **{_pct(model.prob_control('D'))}%**, P(R control) = "
             f"**{_pct(model.prob_control('R'))}%**, ambiguous = "
             f"{_pct(1 - model.prob_control('D') - model.prob_control('R'))}%")
    L.append(f"- Same races assuming independence (ρ = 0): P(D control) = "
             f"{_pct(res.independent_model.prob_control('D'))}%")
    L.append(f"- Holdover seats D {cfg.d_holdover} / R {cfg.r_holdover}; D needs {cfg.d_control_seats}, "
             f"R needs {cfg.r_control_seats}")
    if cfg.provenance:
        L.append("- Knowledge-base facts used: " + "; ".join(
            f"{k} ← {', '.join(v)}" for k, v in cfg.provenance.items()))
    L.append("")

    L += ["## Correlation skew (implied ρ by market group)", "",
          "A single ρ prices every group only if the one-factor model is right. Groups far from the "
          "fitted ρ are either mispriced or need a richer correlation structure.", "",
          "| event | variable | median implied ρ | range | markets |", "|---|---|---|---|---|"]
    groups: dict[str, list[float]] = {}
    variables: dict[str, str] = {}
    for pm in res.priced:
        key = f"{pm.market.venue}:{pm.market.event_id}"
        variables[key] = pm.observable.variable
        r = res.implied_rho.get(pm.market.key)
        groups.setdefault(key, [])
        if r is not None:
            groups[key].append(r)
    for key, vals in groups.items():
        if vals:
            L.append(f"| {key} | {variables[key]} | {np.median(vals):.2f} | {min(vals):.2f}–{max(vals):.2f} | "
                     f"{len(vals)} |")
        else:
            L.append(f"| {key} | {variables[key]} | — | not reachable | 0 |")
    L.append("")
    if res.sweeps:
        L += ["## Sweep markets between independence and lockstep (no model)", "",
              "From the race marginals alone: the price if the races were independent, the price if they moved in "
              "lockstep (the most dependence possible), and how far along that line the market sits. The control and "
              "seat-count markets fit a correlation of about the fitted ρ among the competitive races; a sweep far "
              "toward lockstep asks for much more between its own races.", "",
              "| market | races | independent | lockstep | market | position |", "|---|---|---|---|---|---|"]
        for b in res.sweeps:
            pos = "—" if b.position is None else f"{100 * b.position:.0f}%"
            L.append(f"| {b.key} | {', '.join(b.states) if len(b.states) <= 6 else f'{len(b.states)} states'} | "
                     f"{_pct(b.independent)} | {_pct(b.lockstep)} | {_pct(b.mid)} | {pos} |")
        L.append("")
    if res.tails:
        L += ["## Tail dependence: Gaussian vs. Student t copula", "",
              "The skew is the median implied ρ of the sweep markets (all of several races, any loss among them) minus "
              "that of the control and seat-count markets. Fatter joint tails (smaller ν) make sweeps likelier at the "
              "same ρ; if tail dependence explains the skew, it shrinks. Loss: the fit's spread-weighted squared error.",
              "", "| copula | fitted ρ | loss | sweep ρ | control/count ρ | skew |", "|---|---|---|---|---|---|"]
        for t in res.tails:
            name = "Gaussian" if t.nu is None else f"t, ν = {t.nu:g}"
            L.append(f"| {name} | {t.rho:.3f} | {t.loss:.4g} | {_rho(t.sweep_rho)} | {_rho(t.count_rho)} | "
                     f"{'—' if t.skew is None else f'{t.skew:+.2f}'} |")
        L.append("")

    if res.clusters:
        def e(x):
            return "—" if x is None else f"{100 * x:.1f} pts"
        c0 = res.clusters[0]
        L += ["## Pre-set structure: second factor", "",
              "A national factor plus a second one fixed in advance: Census divisions (two races in one division "
              "correlate at ρn + ρ2, across divisions at ρn; config/census_divisions.toml) or education (each state "
              "loads on one factor by its bachelor's-degree share, so two states correlate at ρn + ρ2·s_i·s_j; ACS via "
              "FRED GCT1502). Neither structure is chosen from the states the sweep markets name. Errors are mean "
              "absolute pricing errors.", "",
              "| model | ρ national | ρ second factor | loss | sweep error | control/count error |",
              "|---|---|---|---|---|---|",
              f"| one factor | {c0.rho_one:.3f} | — | {c0.loss_one:.4g} | {e(c0.sweep_err_one)} | {e(c0.count_err_one)} |"]
        for c in res.clusters:
            L.append(f"| national + {c.name} | {c.rho_n:.3f} | {c.rho_c:.3f} | {c.loss:.4g} | {e(c.sweep_err)} | "
                     f"{e(c.count_err)} |")
        L.append("")

    L += ["## Signals (model vs. executable quotes)", "",
          "edge > 0: model above the ask (YES looks cheap); edge < 0: model below the bid (YES looks rich). "
          "Edges are net of taker fees; depth is not yet checked.", "",
          "| kind | market | outcome | model | bid | ask | edge |", "|---|---|---|---|---|---|---|"]
    for s in res.signals:
        p = s.payload
        if s.kind == "implied_price":
            L.append(f"| {s.kind} | {s.subject} | {p['outcome']} | {_pct(p['model'])} | {_pct(p['bid'])} | "
                     f"{_pct(p['ask'])} | {100 * s.edge:+.1f} |")
        else:
            L.append(f"| {s.kind} | {s.subject} | buy {p['buy']} @ {_pct(p['buy_ask'])} | — | "
                     f"sell {p['sell']} @ {_pct(p['sell_bid'])} | | {100 * s.edge:+.1f} |")
    if not res.signals:
        L.append("| — | none above threshold | | | | | |")
    L.append("")

    L += ["## All observable markets", "",
          "| market | outcome | model | ρ=0 | bid | ask | implied ρ | caucus_d=0 | caucus_d=1 |",
          "|---|---|---|---|---|---|---|---|---|"]
    for pm in res.priced:
        m = pm.market
        L.append(f"| {m.key} | {m.outcome or m.question[:40]} | {_pct(pm.model_price(model))} | "
                 f"{_pct(pm.model_price(res.independent_model))} | {_pct(m.bid)} | {_pct(m.ask)} | "
                 f"{_rho(res.implied_rho.get(m.key))} | "
                 f"{_pct(res.caucus_sensitivity['caucus_d=0'][m.key])} | "
                 f"{_pct(res.caucus_sensitivity['caucus_d=1'][m.key])} |")
    L.append("")

    L += ["## Model seat distribution (D total, caucus included)", "", "| seats | P |", "|---|---|"]
    for k, p in model.count_pmf("d_total").items():
        if p >= 0.001:
            L.append(f"| {k} | {_pct(p)}% |")
    L.append("")

    L += ["## Race inputs", "",
          "| state | Kalshi D/I/R | Polymarket D/I/R | consensus D/I/R | caucus_d |", "|---|---|---|---|---|"]
    for r in res.rows:
        def fmt(q):
            return "/".join(_pct(q.probs[c]) for c in CATEGORIES) if q else "—"
        L.append(f"| {r.state} | {fmt(r.quotes.get('kalshi'))} | {fmt(r.quotes.get('polymarket'))} | "
                 f"{'/'.join(_pct(r.consensus[c]) for c in CATEGORIES)} | {r.caucus_d:g} |")
    L.append("")

    if res.unparsed or res.errors:
        L += ["## Data issues", ""]
        L += [f"- unparsed outcome: {m.key} “{m.outcome}”" for m in res.unparsed]
        L += [f"- fetch error: {e}" for e in res.errors]
        L.append("")
    return "\n".join(L)


def signals_to_jsonl(signals: list[Signal]) -> str:
    return "\n".join(json.dumps(s.to_dict(), ensure_ascii=False) for s in signals)

