"""A pre-set voter-structure loading per state for the Senate copula (2026-10-07).

Education is the single structural variable that has tracked state-level swings best since 2016, so it is fixed in
advance as the one demographic factor: the share of adults 25 and over with a bachelor's degree or higher (Census
Bureau, American Community Survey 5-year estimates, via FRED series GCT1502<state>; public domain). A state's loading
is its share minus the 50-state mean, divided by the largest absolute deviation, so loadings run from -1 to 1 (DC,
with no senators, is left out).
The Census API itself now needs a registered key; FRED serves the same ACS figures without one.
"""

from __future__ import annotations

import csv
import io
from datetime import date
from pathlib import Path

from pmpol import USER_AGENT

STATES = ("AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY",
          "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH",
          "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY")
URL = "https://fred.stlouisfed.org/graph/fredgraph.csv?id={ids}"
CACHE = Path("data/fundamentals")
LICENCE = "public domain (Census Bureau ACS via FRED)"


def parse(text: str) -> dict[str, float]:
    """state -> latest bachelor's-or-higher share (%) from a fredgraph CSV with GCT1502<ST> columns."""
    rows = list(csv.DictReader(io.StringIO(text)))
    out = {}
    for col in (rows[0].keys() if rows else []):
        if not col.startswith("GCT1502"):
            continue
        vals = [r[col] for r in rows if r.get(col) not in (None, "", ".")]
        if vals:
            out[col[-2:]] = float(vals[-1])
    return out


BATCH = 10  # fredgraph returns at most about a dozen series per request


def fetch(cache: Path = CACHE, get=None, today: date | None = None) -> dict[str, float]:
    """Every state's latest share, in batches of BATCH series (each batch cached for the day)."""
    if get is None:
        import httpx

        def get(url):
            r = httpx.get(url, timeout=90, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
            r.raise_for_status()  # a refusal stops here, never retried
            return r.text
    out: dict[str, float] = {}
    day = (today or date.today()).isoformat()
    for i in range(0, len(STATES), BATCH):
        batch = STATES[i:i + BATCH]
        path = cache / f"GCT1502_{day}_{batch[0]}{batch[-1]}.csv"
        if not path.exists():
            text = get(URL.format(ids=",".join(f"GCT1502{st}" for st in batch)))
            cache.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
        out.update(parse(path.read_text(encoding="utf-8")))
    missing = [st for st in STATES if st not in out]
    if missing:
        raise ValueError(f"no education share for {', '.join(missing)}")
    return out


def loadings(shares: dict[str, float]) -> dict[str, float]:
    """Centred and scaled over the 50 states (DC has no senators and, at about 65%, would squash every other loading)."""
    states = {st: v for st, v in shares.items() if st != "DC"}
    mean = sum(states.values()) / len(states)
    span = max(abs(v - mean) for v in states.values()) or 1.0
    return {st: (v - mean) / span for st, v in states.items()}
