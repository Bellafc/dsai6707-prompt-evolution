"""Map seat-count, control and combo markets onto model probabilities."""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass

import numpy as np

from pmpol.models import Market
from pmpol.senate.config import ObservableConfig
from pmpol.senate.model import SeatModel

_COUNT_LABELS: list[tuple[str, Callable[[int], Callable[[np.ndarray], np.ndarray]]]] = [
    (r"^(?:below|less than|fewer than)\s+(\d+)$", lambda n: lambda x: x < n),
    (r"^(?:above|more than)\s+(\d+)$", lambda n: lambda x: x > n),
    (r"^at least\s+(\d+)$", lambda n: lambda x: x >= n),
    (r"^(?:≤|<=)\s*(\d+)$", lambda n: lambda x: x <= n),
    (r"^(\d+)\s*\+$", lambda n: lambda x: x >= n),
    (r"^(\d+)$", lambda n: lambda x: x == n),
]


def parse_count_label(label: str) -> Callable[[np.ndarray], np.ndarray] | None:
    text = label.strip().lower()
    for pattern, make in _COUNT_LABELS:
        m = re.match(pattern, text)
        if m:
            return make(int(m.group(1)))
    return None


def _party_from_label(label: str) -> str | None:
    t = label.lower()
    if "democrat" in t:
        return "D"
    if "republican" in t:
        return "R"
    return None


@dataclass
class PricedMarket:
    observable: ObservableConfig
    market: Market
    price_fn: Callable[[SeatModel], float]

    def model_price(self, model: SeatModel) -> float:
        return self.price_fn(model)


def bind(obs: ObservableConfig, markets: list[Market]) -> tuple[list[PricedMarket], list[Market]]:
    """Attach a model-pricing function to each market of an observable event.

    Returns (priced, unparsed) so that unrecognised outcomes are surfaced, not dropped.
    """
    priced, unparsed = [], []
    for m in markets:
        if not m.active:
            continue
        fn = _price_fn(obs, m)
        if fn is None:
            unparsed.append(m)
        else:
            priced.append(PricedMarket(obs, m, fn))
    return priced, unparsed


def _price_fn(obs: ObservableConfig, m: Market) -> Callable[[SeatModel], float] | None:
    v = obs.variable
    if v in ("d_total", "r_total", "d_won", "r_won"):
        pred = parse_count_label(m.outcome)
        if pred is None:
            return None
        return lambda model: model.prob(pred(getattr(model, v)))
    if v == "control":
        party = _party_from_label(m.outcome) or _party_from_label(m.question)
        if party is None:
            return None
        return lambda model: model.prob_control(party)
    if v == "all_of":
        return lambda model: model.prob_all_of(obs.states, obs.party)
    if v == "any_loss":
        return lambda model: model.prob_any_loss(obs.states, obs.party)
    raise ValueError(f"unknown observable variable: {v}")
