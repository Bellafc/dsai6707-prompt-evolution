"""Per-race outcome probabilities from each venue, normalised to D / I / R."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from pmpol.models import Event, Market
from pmpol.senate.config import RaceConfig

CATEGORIES = ("D", "I", "R")  # ordered on one left-right axis for the copula


def classify(m: Market, race: RaceConfig) -> str:
    """Party class of a race outcome: D, R, I (independent) or O (unmapped/other)."""
    label = m.outcome.strip()
    for name, party in race.candidates.items():
        if name.lower() in label.lower():
            return party
    if m.venue == "kalshi":
        suffix = m.market_id.rsplit("-", 1)[-1]
        if suffix in ("D", "R"):
            return suffix
        # Any other Kalshi suffix is a named non-major-party candidate.
        return "I"
    if re.search(r"\(D\)$", label) or label == "Democrat" or "the Democrats" in m.question:
        return "D"
    if re.search(r"\(R\)\s*$", label) or label == "Republican" or "the Republicans" in m.question:
        return "R"
    if re.search(r"\(I\)$", label) or label.lower() == "independent" or "an independent" in m.question.lower():
        return "I"
    return "O"


@dataclass
class RaceQuote:
    state: str
    venue: str
    probs: dict[str, float]  # normalised over D, I, R
    overround: float  # sum of mids before normalising
    max_spread: float
    markets: dict[str, list[Market]] = field(default_factory=dict)  # by category
    dropped: float = 0.0  # mid mass on unmapped "O" outcomes


def race_quote(event: Event, race: RaceConfig) -> RaceQuote | None:
    mass = {c: 0.0 for c in CATEGORIES}
    by_cat: dict[str, list[Market]] = {}
    dropped, spreads = 0.0, []
    for m in event.markets:
        if not m.active or m.mid is None:
            continue
        cat = classify(m, race)
        if cat == "O":
            dropped += m.mid
            continue
        mass[cat] += m.mid
        by_cat.setdefault(cat, []).append(m)
        if m.spread is not None:
            spreads.append(m.spread)
    total = sum(mass.values())
    if total <= 0:
        return None
    return RaceQuote(
        state=race.state,
        venue=event.venue,
        probs={c: v / total for c, v in mass.items()},
        overround=total + dropped,
        max_spread=max(spreads, default=0.0),
        markets=by_cat,
        dropped=dropped,
    )


def blend(quotes: list[RaceQuote]) -> dict[str, float]:
    """Consensus race probabilities: spread-weighted average across venues."""
    weights = [1.0 / max(q.max_spread, 0.01) for q in quotes]
    total = sum(weights)
    return {c: sum(w * q.probs[c] for w, q in zip(weights, quotes)) / total for c in CATEGORIES}
