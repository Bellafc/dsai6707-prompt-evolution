"""House 2026 from its districts: factor copula + Fourier aggregation (layer 6; 2026-10-06).

The House has a market on almost every district (who wins), on the national seat count (how many seats each party
wins, Kalshi ladders), on each large state's delegation (how many seats Democrats win in Michigan, ...) and on
control (eight venues). The Senate model (pmpol.senate) shows how to join them: each district's market probability
is a marginal; a one-factor copula says how much districts move together; the seat count is a sum of dependent
Bernoulli trials, and given the common factor it is a sum of independent ones, i.e. a convolution, done in Fourier
space (one product of per-district characteristic functions, one inverse FFT per quadrature node).

Then every aggregate market has a model price, and the correlation can be read from them: fitted to the national
markets (control and the seat ladders), and implied separately by each state's delegation ladder. A state whose
delegation implies a very different correlation is either mispriced or a sign that districts in one state move
together more than districts across the country (the Senate's correlation skew, at state scale).

Precision first: a district enters only from winner markets that read as a party (pmpol.propositions), with the
book no wider than MAX_SPREAD on at least one venue; districts without one are listed, and the model runs only when
every one of the 435 seats has a probability. Model prices are L5 inferences, never facts; the proof cites the
majority rule (L0), the quotes (L4) and the copula assumption.
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import minimize_scalar

from pmpol.copula import conditional_table, gauss_hermite_normal

MAX_SPREAD = 0.20  # a district's quote counts when its book is at most this wide on some venue
SEATS, MAJORITY = 435, 218  # fallbacks; the knowledge base's us.house.voting_seats and us.house.majority are used
CATS = ("D", "O", "R")  # ordered on one axis for the copula: Democrat, other, Republican
RHO_GRID = np.round(np.arange(0.0, 0.96, 0.05), 2)


def district_key(jurisdiction: str) -> str | None:
    """"MI-07" -> "MI-07", "AK" / "AK-AL" / "AK-01" for a one-seat state -> "AK-AL"; None if not a district."""
    m = re.fullmatch(r"([A-Z]{2})(?:-(\d{1,2}|AL))?", jurisdiction or "")
    if not m:
        return None
    st, n = m.group(1), m.group(2)
    return f"{st}-{'AL' if n in (None, 'AL') else f'{int(n):02d}'}"


@dataclass
class District:
    key: str
    probs: dict[str, float]  # D, O, R summing to 1
    venues: list[str]
    quotes: list[str] = field(default_factory=list)  # market keys used
    weights: dict[str, float] = field(default_factory=dict)  # venue -> share of the blend


def district_probs(u, props, max_spread: float = MAX_SPREAD) -> tuple[dict[str, District], dict[str, str]]:
    """Per district, the parties' win probabilities from winner markets that read as a party, blended across venues
    by 1/spread and normalised. One-seat states written with and without "-AL" merge. (districts, left_out)."""
    quotes: dict[str, dict[tuple[str, str], list]] = defaultdict(lambda: defaultdict(list))  # dist -> (venue, event)
    for p in props:
        if p.var.kind != "winner":
            continue
        parts = p.var.subject.split("|")
        if len(parts) < 5 or parts[0] != "United States" or parts[2] != "house" or parts[3] != "2026" \
                or not parts[4].startswith("general"):
            continue
        key = district_key(parts[1])
        v = next(iter(p.values))
        m = u.markets.get(p.market)
        if key is None or not v.startswith("party:") or m is None or m.mid is None or m.spread is None:
            continue
        quotes[key][(p.venue, p.event)].append((v[6:], m))
    out, left = {}, {}
    # one-seat states: drop "XX-AL" when the state also has numbered districts (a statewide label, not a district)
    numbered = {k[:2] for k in quotes if not k.endswith("-AL")}
    for key, by_event in quotes.items():
        if key.endswith("-AL") and key[:2] in numbered:
            continue
        acc, wsum, venues, used, vw = defaultdict(float), 0.0, [], [], defaultdict(float)
        for (venue, _event), legs in by_event.items():
            major = [m for party, m in legs if party in ("D", "R")]
            if not major or not any(m.spread <= max_spread for m in major):
                continue
            mids = defaultdict(float)
            for party, m in legs:
                mids["D" if party == "D" else "R" if party == "R" else "O"] += m.mid
            if len(mids) == 1:  # a yes/no market on one party: the rest goes to the other major party
                (c, v), = mids.items()
                mids["R" if c == "D" else "D"] = max(0.0, 1 - v)
            total = sum(mids.values())
            if total <= 0:
                continue
            w = 1.0 / max(max(m.spread for m in major), 0.01)
            for c in CATS:
                acc[c] += w * mids.get(c, 0.0) / total
            wsum += w
            vw[venue] += w
            venues.append(venue)
            used += [m.key for _, m in legs]
        if wsum <= 0:
            left[key] = "no book narrower than the spread limit"
            continue
        probs = {c: acc[c] / wsum for c in CATS}
        s = sum(probs.values())
        out[key] = District(key, {c: probs[c] / s for c in CATS}, sorted(set(venues)), used,
                            {v: x / wsum for v, x in vw.items()})
    return out, left


def recalibrate(districts: dict[str, District], kb, horizon: int = 30) -> tuple[dict[str, District], list[str]]:
    """Each party's probability through the venues' calibration slope (L2 facts calibration.<venue>.politics.h<n>,
    from resolved markets; shrunk toward 1 as in the consensus), then renormalised. Thin district books put the
    underdog of a safe seat at a few percent; resolved markets say such prices are too high, and summed over a state
    those few percent widen the seat count. Returns (districts, facts used)."""
    from pmpol.universe.consensus import SHRINK_N0, _logit, _sigmoid

    used: set[str] = set()
    out = {}
    for key, d in districts.items():
        slope, wsum = 0.0, 0.0
        for venue, w in d.weights.items():
            f = kb.facts.get(f"calibration.{venue}.politics.h{horizon}") if kb is not None else None
            if f is None:
                continue
            k = f.value.get("n", 0) / (f.value.get("n", 0) + SHRINK_N0)
            slope += w * (1 + (f.value["slope_b"] - 1) * k)
            wsum += w
            used.add(f.id)
        if not wsum:
            out[key] = d
            continue
        slope /= wsum
        probs = {c: (_sigmoid(slope * _logit(p)) if p > 0 else 0.0) for c, p in d.probs.items()}
        s = sum(probs.values())
        out[key] = District(d.key, {c: probs[c] / s for c in CATS}, d.venues, d.quotes, d.weights)
    return out, sorted(used)


class HouseModel:
    """Distributions of seats won by D and by R under a one-factor Gaussian copula (pmpol.copula)."""

    def __init__(self, districts: list[District], rho: float, n_nodes: int = 48):
        self.districts, self.rho = districts, rho
        self.nodes, self.weights = gauss_hermite_normal(n_nodes)
        probs = np.array([[d.probs[c] for c in CATS] for d in districts])
        self.cond = conditional_table(probs, rho, self.nodes)  # [node, district, category]
        self.d_pmf = self._count_pmf(0, range(len(districts)))
        self.r_pmf = self._count_pmf(2, range(len(districts)))

    def _count_pmf(self, cat: int, idx) -> np.ndarray:
        idx = list(idx)
        n = len(idx) + 1
        e = np.exp(-2j * np.pi * np.arange(n) / n)
        out = np.zeros(n)
        for k, w in enumerate(self.weights):
            p = self.cond[k, idx, cat]
            spectrum = np.prod(1 - p[:, None] + p[:, None] * e[None, :], axis=0)
            pmf = np.fft.ifft(spectrum).real
            pmf[pmf < 0] = 0.0
            out += w * pmf
        return out / out.sum()

    def state_pmf(self, state: str, party: str = "D") -> np.ndarray:
        idx = [j for j, d in enumerate(self.districts) if d.key[:2] == state]
        return self._count_pmf(CATS.index(party), idx)

    @staticmethod
    def prob(pmf: np.ndarray, lo: float, hi: float) -> float:
        """P(count in [lo, hi)) from a pmf over 0..n."""
        k = np.arange(len(pmf))
        return float(pmf[(k >= lo) & (k < hi)].sum())


class TwoLevelModel:
    """National and state factors: X_i = sqrt(rho_n) Z + sqrt(rho_s) W_state + sqrt(1 - rho_n - rho_s) e_i. Two
    districts of one state correlate rho_n + rho_s, of different states rho_n. Given Z the states are independent and,
    given also W, so are a state's districts: per Z node, each state's characteristic function is averaged over W and
    the states' are multiplied (one inverse FFT per Z node)."""

    def __init__(self, districts: list[District], rho_n: float, rho_s: float | dict[str, float], n_z: int = 32,
                 n_w: int = 16, default_s: float | None = None):
        """rho_s: one state factor loading for every state, or a dict state -> rho_s (states missing from it use
        default_s)."""
        from scipy.stats import norm

        self.districts, self.rho_n, self.rho_s = districts, rho_n, rho_s
        z, wz = gauss_hermite_normal(n_z)
        w, ww = gauss_hermite_normal(n_w)
        a = np.sqrt(rho_n)

        def rs(st: str) -> float:
            return rho_s.get(st, default_s if default_s is not None else 0.0) if isinstance(rho_s, dict) else rho_s
        probs = np.array([[d.probs[k] for k in CATS] for d in districts])
        cum = np.clip(np.cumsum(probs, axis=1)[:, :-1], 1e-12, 1 - 1e-12)
        thr = norm.ppf(cum)  # [district, 2]: D | O | R
        states = sorted({d.key[:2] for d in districts})
        idx = {st: [j for j, d in enumerate(districts) if d.key[:2] == st] for st in states}
        n = len(districts) + 1
        e = np.exp(-2j * np.pi * np.arange(n) / n)
        self.d_pmf, self.r_pmf = np.zeros(n), np.zeros(n)
        self._state = {st: {"D": np.zeros(len(ix) + 1), "R": np.zeros(len(ix) + 1)} for st, ix in idx.items()}
        for zk, wzk in zip(z, wz):
            spec = {"D": np.ones(n, complex), "R": np.ones(n, complex)}
            for st, ix in idx.items():
                m = len(ix) + 1
                es = np.exp(-2j * np.pi * np.arange(m) / m)
                b, c = np.sqrt(rs(st)), np.sqrt(max(1 - rho_n - rs(st), 1e-9))
                shift = a * zk + b * w[:, None]  # [w node, 1]
                pd = norm.cdf((thr[ix, 0][None, :] - shift) / c)  # [w node, district]
                pr = 1 - norm.cdf((thr[ix, 1][None, :] - shift) / c)
                for party, p in (("D", pd), ("R", pr)):
                    # national grid: average over W of the product over the state's districts
                    prod = np.prod(1 - p[:, :, None] + p[:, :, None] * e[None, None, :], axis=1)
                    spec[party] *= ww @ prod
                    small = np.prod(1 - p[:, :, None] + p[:, :, None] * es[None, None, :], axis=1)
                    pmf = np.fft.ifft(ww @ small).real
                    self._state[st][party] += wzk * np.clip(pmf, 0, None)
            for party in ("D", "R"):
                pmf = np.clip(np.fft.ifft(spec[party]).real, 0, None)
                if party == "D":
                    self.d_pmf += wzk * pmf
                else:
                    self.r_pmf += wzk * pmf
        self.d_pmf /= self.d_pmf.sum()
        self.r_pmf /= self.r_pmf.sum()
        for st in self._state:
            for party in ("D", "R"):
                self._state[st][party] /= self._state[st][party].sum()

    def state_pmf(self, state: str, party: str = "D") -> np.ndarray:
        return self._state[state][party]


def _loss(model, tg: list[Target], majority: int) -> float:
    return sum((t.price(model, majority) - t.mid) ** 2 / max(t.spread, 0.01) for t in tg)


@dataclass
class LevelsFit:
    """One-factor and two-level fits to every aggregate market (national and state), with the losses split."""
    one: tuple[float, float, float]  # rho, national loss, state loss
    two: tuple[float, float, float, float]  # rho_n, rho_s, national loss, state loss
    p_d_control: tuple[float, float]  # one-factor, two-level
    model: object = None  # the fitted TwoLevelModel
    per_state: dict[str, float] = field(default_factory=dict)  # state -> its own rho_s, national rho_n held fixed
    three: tuple[float, float, float] | None = None  # per-state model: national loss, state loss, P(D control)


STATE_GRID = np.round(np.arange(0.0, 0.81, 0.02), 2)


def fit_state_rhos(districts: list[District], tg: list[Target], rho_n: float) -> dict[str, float]:
    """Each state's own rho_s (grid, rho_n held fixed), from its delegation markets alone: a state's delegation
    depends only on the national and its own factor, so a model of that state's districts is enough."""
    out = {}
    by_state: dict[str, list[Target]] = defaultdict(list)
    for t in tg:
        if t.state:
            by_state[t.state].append(t)
    for st, ts in by_state.items():
        ds = [d for d in districts if d.key[:2] == st]
        if not ds:
            continue
        grid = [r for r in STATE_GRID if rho_n + r <= 0.95]
        losses = [sum((t.price(TwoLevelModel(ds, rho_n, float(r), n_z=24, n_w=12), 0) - t.mid) ** 2
                      / max(t.spread, 0.01) for t in ts) for r in grid]
        out[st] = float(grid[int(np.argmin(losses))])
    return out


def fit_levels(districts: list[District], tg: list[Target], majority: int) -> LevelsFit:
    """Both models fitted to all aggregate markets: does a state factor price the delegations without hurting the
    national markets?"""
    from scipy.optimize import minimize

    nat = [t for t in tg if not t.state]
    sta = [t for t in tg if t.state]
    res1 = minimize_scalar(lambda r: _loss(HouseModel(districts, r, n_nodes=32), tg, majority), bounds=(0.0, 0.9),
                           method="bounded", options={"xatol": 5e-3})
    m1 = HouseModel(districts, float(res1.x))

    def loss2(x):
        rn, rs = float(x[0]), float(x[1])
        if rn < 0 or rs < 0 or rn + rs > 0.95:
            return 1e9
        return _loss(TwoLevelModel(districts, rn, rs, n_z=24, n_w=12), tg, majority)

    res2 = minimize(loss2, x0=[float(res1.x), 0.2], method="Nelder-Mead",
                    options={"xatol": 5e-3, "fatol": 1e-3, "maxfev": 60})
    m2 = TwoLevelModel(districts, float(res2.x[0]), float(res2.x[1]))
    per = fit_state_rhos(districts, tg, float(res2.x[0]))
    m3 = TwoLevelModel(districts, float(res2.x[0]), per, default_s=float(res2.x[1]))
    return LevelsFit((float(res1.x), _loss(m1, nat, majority), _loss(m1, sta, majority)),
                     (float(res2.x[0]), float(res2.x[1]), _loss(m2, nat, majority), _loss(m2, sta, majority)),
                     (HouseModel.prob(m1.d_pmf, majority, np.inf), HouseModel.prob(m2.d_pmf, majority, np.inf)), m2,
                     per, (_loss(m3, nat, majority), _loss(m3, sta, majority),
                           HouseModel.prob(m3.d_pmf, majority, np.inf)))


@dataclass
class Target:
    """An aggregate market the model prices: national control or seats won, or a state's delegation."""
    market: str
    label: str
    group: str  # "control", "national D/won", "MI D/won", ...
    party: str
    state: str  # "" for national
    lo: float
    hi: float
    mid: float
    spread: float

    def price(self, model: HouseModel, majority: int) -> float:
        if self.group == "control":
            return HouseModel.prob(model.d_pmf if self.party == "D" else model.r_pmf, majority, np.inf)
        pmf = (model.d_pmf if self.party == "D" else model.r_pmf) if not self.state else model.state_pmf(self.state,
                                                                                                         self.party)
        return HouseModel.prob(pmf, self.lo, self.hi)


def targets(u, props, max_spread: float = MAX_SPREAD) -> list[Target]:
    out = []
    for p in props:
        m = u.markets.get(p.market)
        if m is None or m.mid is None or m.spread is None or m.spread > max_spread:
            continue
        if p.var.kind == "control" and p.var.subject == "United States|house|2026":
            party = next(iter(p.values))[6:]
            if party in ("D", "R"):
                out.append(Target(p.market, m.outcome, "control", party, "", 0, 0, m.mid, m.spread))
        elif p.var.kind == "seats" and p.var.subject.startswith("United States|") and "|house|2026|general" in \
                p.var.subject and p.var.qualifier in ("D/won", "R/won") and len(p.spans) == 1:
            st = p.var.subject.split("|")[1]
            party = p.var.qualifier[0]
            lo, hi = p.spans[0].lo, p.spans[0].hi
            lo = lo if p.spans[0].lo_closed else np.floor(lo) + 1
            hi = hi + 1 if p.spans[0].hi_closed else hi
            out.append(Target(p.market, m.outcome, ("national" if st == "US" else st) + f" {party}/won", party,
                              "" if st == "US" else st, lo, hi, m.mid, m.spread))
    return out


def fit(districts: list[District], tg: list[Target], majority: int) -> tuple[float, float]:
    """rho minimising the spread-weighted squared error over the national markets (control and seat ladders)."""
    national = [t for t in tg if not t.state]

    def loss(rho):
        model = HouseModel(districts, rho)
        return sum((t.price(model, majority) - t.mid) ** 2 / max(t.spread, 0.01) for t in national)

    res = minimize_scalar(loss, bounds=(0.0, 0.9), method="bounded", options={"xatol": 2e-3})
    return float(res.x), float(res.fun)


def implied_by_group(districts: list[District], tg: list[Target], majority: int) -> dict[str, float | None]:
    """Per group of targets, the rho on the grid with the least spread-weighted squared error (None: no market)."""
    groups: dict[str, list[Target]] = defaultdict(list)
    for t in tg:
        groups[t.group].append(t)
    curves = {}
    for rho in RHO_GRID:
        model = HouseModel(districts, float(rho), n_nodes=32)
        for g, ts in groups.items():
            curves.setdefault(g, []).append(sum((t.price(model, majority) - t.mid) ** 2 / max(t.spread, 0.01)
                                                for t in ts))
    return {g: float(RHO_GRID[int(np.argmin(c))]) for g, c in curves.items()}


@dataclass
class Fit:
    label: str  # "market prices" or "calibrated"
    districts: list[District]
    rho: float
    loss: float
    model: HouseModel
    implied: dict[str, float]  # group -> best rho on the grid

    def state_rhos(self) -> dict[str, float]:
        return {g: r for g, r in self.implied.items() if g != "control" and not g.startswith("national")}

    def edge_groups(self) -> list[str]:
        """State groups whose best rho is at the grid's edge: no correlation reconciles them with the districts."""
        return sorted(g for g, r in self.state_rhos().items() if r in (RHO_GRID[0], RHO_GRID[-1]))


@dataclass
class HouseRun:
    districts: list[District]
    left_out: dict[str, str]
    targets: list[Target]
    fits: list[Fit] = field(default_factory=list)
    levels: LevelsFit | None = None  # one-factor vs national + state factors, both fitted to every aggregate market
    independent: HouseModel | None = None
    calibration: list[str] = field(default_factory=list)
    seats: int = SEATS
    majority: int = MAJORITY

    @property
    def complete(self) -> bool:
        return len(self.districts) == self.seats


def _fit(label: str, districts: list[District], tg: list[Target], majority: int) -> Fit:
    rho, loss = fit(districts, tg, majority)
    return Fit(label, districts, rho, loss, HouseModel(districts, rho), implied_by_group(districts, tg, majority))


def run(u, props, kb=None, levels: bool = True) -> HouseRun:
    seats, majority = SEATS, MAJORITY
    if kb is not None:
        if "us.house.voting_seats" in kb.facts:
            seats = int(kb.facts["us.house.voting_seats"].value)
        if "us.house.majority" in kb.facts:
            majority = int(kb.facts["us.house.majority"].value)
    ds, left = district_probs(u, props)
    tg = targets(u, props)
    res = HouseRun(sorted(ds.values(), key=lambda d: d.key), left, tg, seats=seats, majority=majority)
    if not res.complete or not any(not t.state for t in tg):
        return res
    res.independent = HouseModel(res.districts, 0.0)
    res.fits.append(_fit("market prices", res.districts, tg, majority))
    cal, res.calibration = recalibrate(ds, kb)
    if res.calibration:
        res.fits.append(_fit("calibrated", sorted(cal.values(), key=lambda d: d.key), tg, majority))
    if levels and any(t.state for t in tg):
        res.levels = fit_levels(res.fits[-1].districts, tg, majority)
    return res


def _mean(pmf: np.ndarray) -> float:
    return float((pmf * np.arange(len(pmf))).sum())


def _quantiles(pmf: np.ndarray, qs=(0.05, 0.95)) -> tuple[int, ...]:
    c = np.cumsum(pmf)
    return tuple(int(np.searchsorted(c, q)) for q in qs)


def proof(res: HouseRun, kb, observed_at: str):
    """The model's control probability next to the control markets; never a fact, never a correction of them."""
    from pmpol.assumptions import cite
    from pmpol.proof import Proof

    f = res.fits[-1]
    main = res.levels.model if res.levels is not None else f.model
    pd = HouseModel.prob(main.d_pmf, res.majority, np.inf)
    lo, hi = _quantiles(main.d_pmf)
    ctrl = [t for t in res.targets if t.group == "control" and t.party == "D"]
    how = (f"全國 ρ = {res.levels.two[0]:.2f}、州 ρ = {res.levels.two[1]:.2f}" if res.levels is not None
           else f"ρ = {f.rho:.2f}")
    head = (f"由 {len(res.districts)} 個選區的市場拼出：民主黨過半（≥ {res.majority} 席）{100 * pd:.1f}%，民主黨席次 90% 區間 "
            f"{lo}–{hi}（{how}，{'校準後的選區機率' if f.label == 'calibrated' else '選區市場價'}）；"
            f"控制權市場 {', '.join(f'{100 * t.mid:.0f}%' for t in ctrl)}——兩條證據線並列，不選邊")
    p = Proof("結構定價｜眾議院 2026", head,
              result={"p_d_control": round(pd, 4), "rho": round(f.rho, 3), "d_seats_90": [lo, hi],
                      "fits": [{"label": x.label, "rho": round(x.rho, 3), "loss": round(x.loss, 4),
                                "p_d_control": round(HouseModel.prob(x.model.d_pmf, res.majority, np.inf), 4),
                                "edge_groups": x.edge_groups()} for x in res.fits],
                      "districts": len(res.districts), "independent_p_d_control":
                          round(HouseModel.prob(res.independent.d_pmf, res.majority, np.inf), 4)})
    for fid in ("us.house.voting_seats", "us.house.majority"):
        if kb is not None and fid in kb.facts:
            x = kb.facts[fid]
            p.add("L0", f"{x.subject}：{x.predicate} = {x.value}", fid, str(x.valid_from or x.recorded_at), kind="rule",
                  id=f"kb:{fid}")
    venues = sorted({v for d in res.districts for v in d.venues})
    p.add("L4", f"{len(res.districts)} 個選區的勝選市場（{', '.join(venues)}），各平台依價差加權、正規化；價差超過 "
                f"{100 * MAX_SPREAD:.0f} 點的不用", "pmpol.house.district_probs", observed_at, kind="data", id="districts")
    ins = ["districts"]
    for fid in res.calibration:
        p.add("L2", f"校準（已結算市場）：{fid}", fid, kind="data", id=f"kb:{fid}")
        ins.append(f"kb:{fid}")
    if res.levels is not None:
        ins += cite(p, "house_two_level_copula")
        p.add("L5", f"兩層高斯 copula（全國因子＋州因子），用全部全國和州的席次、控制權市場擬合：全國 ρ = {res.levels.two[0]:.3f}、"
                    f"州 ρ = {res.levels.two[1]:.3f}；給定因子各選區獨立，席次分布是卷積（FFT）", kind="logic", id="model",
              inputs=tuple(ins))
    else:
        ins += cite(p, "house_one_factor_copula")
        p.add("L5", f"單因子高斯 copula，ρ 用全國的控制權和席次市場擬合 = {f.rho:.3f}；給定共同因子各選區獨立，席次分布是卷積（FFT）",
              kind="logic", id="model", inputs=tuple(ins))
    for t in ctrl:
        p.add("L4", f"控制權市場 {t.market.split(':')[0]}：中間價 {100 * t.mid:.1f}%（價差 {100 * t.spread:.1f} 點）",
              t.market, observed_at, kind="data", id=f"ctrl:{t.market}")
    p.caveats += ["模型價格是 L5 推論，市場是 L4 觀測；兩者不同不代表市場錯。",
                  "州的席次市場在兩層模型下仍有誤差，主要是選區市場和州的市場對平均席次的看法不同，不是相關性能解釋的。"]
    states = list(f.state_rhos().values())
    med = float(np.median(states)) if states else None
    lv = res.levels
    if lv is not None:
        rn, rs, nat2, sta2 = lv.two
        _, nat1, sta1 = lv.one
        good = rs > 0.1 and nat2 <= nat1
        p.add("L5", f"對照：單因子用同樣的全部市場擬合時 ρ = {lv.one[0]:.2f}、民主黨過半 {100 * lv.p_d_control[0]:.1f}%，"
                    f"全國誤差 {nat1:.2f}（兩層 {nat2:.2f}）", kind="logic", id="levels", inputs=("model",))
        p.alt("同一州的選區有共同的州因子（州內相關高於全國）", "supports" if good else "against",
              f"兩層模型的全國誤差 {nat2:.2f}（單因子 {nat1:.2f}）、州誤差 {sta2:.1f}（單因子 {sta1:.1f}）；州 ρ = {rs:.2f}"
              + ("" if med is None else f"；各州代表團市場自己隱含的 ρ 中位數 {med:.2f}"))
    else:
        p.alt("同一州的選區有共同的州因子（州內相關高於全國）",
              "unchecked" if med is None else "supports" if med > f.rho + 0.1 else "against",
              "沒有州代表團市場" if med is None else
              f"{len(states)} 州的代表團席次市場隱含的 ρ 中位數 {med:.2f}，全國擬合 {f.rho:.2f}")
    return p


def render(res: HouseRun, when: str) -> str:
    L = [f"# 眾議院 2026：由選區拼出的席次分布｜{when}", "",
         "每個選區的勝選市場是邊際機率；單因子高斯 copula 決定選區一起動的程度，給定共同因子後席次是獨立伯努利的和，用"
         "特徵函數相乘、反 FFT 得到分布（`pmpol.house`）。ρ 用全國的控制權和席次市場擬合；各州代表團的席次市場另外各自"
         "找最合的 ρ。模型價格是 L5 推論，不是事實，也不用來修正市場。", ""]
    L.append(f"- 選區：{len(res.districts)} / {res.seats}" + ("" if res.complete else
                                                           f"（不齊，不跑模型；缺 {res.seats - len(res.districts)} 個）"))
    if res.left_out:
        L.append("- 沒有用的選區：" + "、".join(f"{k}（{v}）" for k, v in sorted(res.left_out.items())))
    if not res.fits:
        return "\n".join(L + [""])
    pi = HouseModel.prob(res.independent.d_pmf, res.majority, np.inf)
    L += [f"- 各選區獨立（ρ = 0）時民主黨過半：{100 * pi:.2f}%", ""]
    L += ["## 全國擬合", "", "| 選區機率 | ρ | 誤差 | 民主黨過半 | 民主黨席次平均 | 90% 區間 | 隱含 ρ 卡在邊界的州 |",
          "|---|---|---|---|---|---|---|"]
    for f in res.fits:
        lo, hi = _quantiles(f.model.d_pmf)
        L.append(f"| {'市場中間價' if f.label == 'market prices' else '校準後'} | {f.rho:.3f} | {f.loss:.3g} | "
                 f"{100 * HouseModel.prob(f.model.d_pmf, res.majority, np.inf):.1f}% | {_mean(f.model.d_pmf):.1f} | "
                 f"{lo}–{hi} | {len(f.edge_groups())}：{'、'.join(g.split()[0] for g in f.edge_groups()) or '—'} |")
    if res.calibration:
        L += ["", "校準：" + "、".join(res.calibration) + "（已結算市場的校準斜率，冷門價格偏高；和跨平台共識用的相同）。"]
    if res.levels is not None:
        lv = res.levels
        L += ["", "## 全國＋州的兩層因子", "",
              "同州兩個選區的相關是全國 ρ 加州 ρ，不同州只有全國 ρ。兩個模型都用全部的全國和州市場擬合（校準後的選區機率），"
              "誤差分開列：如果州因子是真的，它應該同時對上州的席次市場，又不犧牲全國市場。", "",
              "| 模型 | 全國 ρ | 州 ρ | 全國誤差 | 州誤差 | 民主黨過半 |", "|---|---|---|---|---|---|"]
        L.append(f"| 單因子 | {lv.one[0]:.3f} | — | {lv.one[1]:.3g} | {lv.one[2]:.3g} | {100 * lv.p_d_control[0]:.1f}% |")
        L.append(f"| 兩層 | {lv.two[0]:.3f} | {lv.two[1]:.3f} | {lv.two[2]:.3g} | {lv.two[3]:.3g} | "
                 f"{100 * lv.p_d_control[1]:.1f}% |")
        if lv.three is not None and lv.per_state:
            rs = sorted(lv.per_state.values())
            L.append(f"| 兩層（各州自己的州 ρ） | {lv.two[0]:.3f} | {rs[0]:.2f}–{rs[-1]:.2f}（中位數 {rs[len(rs) // 2]:.2f}） | "
                     f"{lv.three[0]:.3g} | {lv.three[1]:.3g} | {100 * lv.three[2]:.1f}% |")
            L += ["", "各州的州 ρ 是全國 ρ 固定時，只用該州代表團市場找的格點最佳值；每州市場少，個別數字雜訊大，"
                  "州誤差下降一定會發生（每州多一個參數），要看的是全國誤差和控制權機率有沒有跟著變。"]
    f = res.fits[-1]
    L += ["", "## 全國市場：模型和市場", "", "| 市場 | 選項 | 中間價 | 模型 |", "|---|---|---|---|"]
    for t in sorted((t for t in res.targets if not t.state), key=lambda t: (t.group, t.market.split(":")[0], t.lo)):
        L.append(f"| {t.market.split(':')[0]} {t.group} | {t.label} | {100 * t.mid:.1f}% | "
                 f"{100 * t.price(f.model, res.majority):.1f}% |")
    L += ["", "## 各州代表團：隱含的相關性", "",
          "每州的代表團席次市場各自找最合的 ρ（0–0.95 的格點）。高於全國擬合的 ρ，表示同一州的選區一起動得比全國平均多；"
          "卡在邊界（0 或 0.95）表示任何 ρ 都對不上，是選區市場和州的席次市場對平均數的看法不同。", "",
          "| 州 | 選區 | 選區加總的民主黨席次 | 隱含 ρ | 州 ρ（兩層，全國 ρ 固定） | 市場數 |", "|---|---|---|---|---|---|"]
    groups = defaultdict(list)
    for t in res.targets:
        if t.state:
            groups[t.state].append(t)
    for st in sorted(groups):
        ds = [d for d in f.districts if d.key[:2] == st]
        rho = f.implied.get(f"{st} D/won")
        L.append(f"| {st} | {len(ds)} | {sum(d.probs['D'] for d in ds):.2f} | "
                 f"{'—' if rho is None else f'{rho:.2f}'}{'（邊界）' if rho in (RHO_GRID[0], RHO_GRID[-1]) else ''} | "
                 f"{'—' if res.levels is None or st not in res.levels.per_state else f'{res.levels.per_state[st]:.2f}'} | "
                 f"{len(groups[st])} |")
    return "\n".join(L + [""])


def export(res: HouseRun, kb, observed_at: str, path) -> int:
    import json
    from pathlib import Path

    if not res.fits:
        return 0
    p = proof(res, kb, observed_at)
    row = {"id": "house:2026", "group": "consensus", "kind": "structural_model", "subject": "control(United States|house|2026)",
           "edge": 0.0, "venues": [], "markets": [t.market for t in res.targets if t.group == "control"],
           "confidence": "rule", "title": p.title, "proof": {**p.to_dict(), "graph": p.graph()}}
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps({"signals": [row]}, ensure_ascii=False, default=str), encoding="utf-8")
    return 1
