"""Judgment log: what the system concluded, when, and why a conclusion changed (ICD 203 standard 7: "explains
change to or consistency of analytic judgments"; Good Judgment: every forecast recorded and scored later).

A judgment is a published proof: its value (a consensus probability, a violation's edge), its conclusion, its
analytic confidence and the L0-L4 steps it rests on. Every run records the value; the full inputs are stored
only when the judgment changes materially (the value by `MIN_DELTA` or more, the conclusion of a judgment
without a number, or the confidence),
which keeps the log small. A change is explained by comparing the inputs of the two full records: which quotes,
facts or assumptions differ, old against new.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field

MIN_DELTA = 0.02
VALUE_KEYS = ("recalibrated", "pooled", "edge", "probability", "value")
SCHEMA = """
CREATE TABLE IF NOT EXISTS judgments (
    id TEXT, ts TEXT, kind TEXT, subject TEXT, value REAL, confidence TEXT, conclusion TEXT, inputs TEXT,
    run_id TEXT, UNIQUE (id, ts)
);
CREATE INDEX IF NOT EXISTS judgments_id ON judgments (id, ts);
"""


def _value(result: dict) -> float | None:
    for k in VALUE_KEYS:
        v = result.get(k)
        if isinstance(v, (int, float)):
            return float(v)
    return None


def inputs_of(proof: dict) -> dict[str, str]:
    """The grounding steps (L0-L4) of a proof dict, keyed by step id or reference."""
    out = {}
    for i, s in enumerate(proof.get("steps", [])):
        if s.get("layer") in ("L0", "L1", "L2", "L3", "L4"):
            out[s.get("id") or s.get("ref") or f"s{i}"] = s.get("text", "")[:240]
    return out


def record(conn: sqlite3.Connection, items, ts: str, run_id: str = "", min_delta: float = MIN_DELTA) -> int:
    """items: (id, kind, subject, proof dict). Returns how many full (changed or new) records were stored."""
    conn.executescript(SCHEMA)
    full = 0
    for jid, kind, subject, proof in items:
        value = _value(proof.get("result", {}))
        conclusion, conf = proof.get("conclusion", ""), proof.get("analytic_confidence", "")
        last = conn.execute("SELECT value, conclusion, confidence FROM judgments WHERE id = ? AND inputs IS NOT NULL "
                            "AND ts < ? ORDER BY ts DESC LIMIT 1", (jid, ts)).fetchone()
        if last is None or last[2] != conf:
            changed = True
        elif value is not None and last[0] is not None:  # numeric judgments: the number decides (the wording follows it)
            changed = abs(value - last[0]) >= min_delta
        else:  # categorical judgments (a regime, a phase): the conclusion decides
            changed = last[1] != conclusion
        inputs = json.dumps(inputs_of(proof), ensure_ascii=False) if changed else None
        n = conn.execute("INSERT OR IGNORE INTO judgments VALUES (?,?,?,?,?,?,?,?,?)",
                         (jid, ts, kind, subject, value, conf, conclusion, inputs, run_id)).rowcount
        full += n if changed else 0
    conn.commit()
    return full


@dataclass
class Change:
    id: str
    kind: str
    subject: str
    old_ts: str
    new_ts: str
    old_value: float | None
    new_value: float | None
    old_conclusion: str
    new_conclusion: str
    old_confidence: str
    new_confidence: str
    changed: list[tuple[str, str, str]] = field(default_factory=list)  # (input, old text, new text)
    added: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)

    @property
    def delta(self) -> float:
        if self.old_value is None or self.new_value is None:
            return 0.0
        return self.new_value - self.old_value


def changes(conn: sqlite3.Connection, ts: str | None = None, kind: str | None = None) -> list[Change]:
    """Judgments that changed materially at `ts` (default: the latest time recorded), with the inputs that
    differ from the previous full record. New judgments (no earlier record) are not changes."""
    conn.executescript(SCHEMA)
    ts = ts or (conn.execute("SELECT MAX(ts) FROM judgments").fetchone() or [None])[0]
    if ts is None:
        return []
    q = "SELECT id, kind, subject, value, conclusion, confidence, inputs FROM judgments WHERE ts = ? AND inputs IS NOT NULL"
    args: list = [ts]
    if kind:
        q += " AND kind = ?"
        args.append(kind)
    out = []
    for jid, k, subject, value, concl, conf, inputs in conn.execute(q, args).fetchall():
        prev = conn.execute("SELECT ts, value, conclusion, confidence, inputs FROM judgments WHERE id = ? AND ts < ? "
                            "AND inputs IS NOT NULL ORDER BY ts DESC LIMIT 1", (jid, ts)).fetchone()
        if prev is None:
            continue
        a, b = json.loads(prev[4]), json.loads(inputs)
        out.append(Change(jid, k, subject, prev[0], ts, prev[1], value, prev[2], concl, prev[3], conf,
                          [(key, a[key], b[key]) for key in sorted(set(a) & set(b)) if a[key] != b[key]],
                          sorted(set(b) - set(a)), sorted(set(a) - set(b))))
    return sorted(out, key=lambda c: -abs(c.delta))
