"""Relationship graphs by theme (layer 4; 2026-10-06).

The viewer layout and the idea of grading every edge by how well it is known follow GEM (katarism/
geopolitical-elite-mapping, MIT; layout and interaction only, no code copied). The vocabulary is ours, and no edge is
written by hand: each comes from something the system can show (config/geo_themes.toml says what to collect).

  edge type     from -> to                  basis                                         confidence
  holds_office  person -> office            CIA World Leaders roster (via OpenSanctions)  confirmed
  office_of     office -> country           the same roster                               confirmed
  member_of     person -> body              a current Wikidata position (via OpenSanctions) reported
  measured_by   place -> series             IMF PortWatch / EIA data                      confirmed
  states        fact -> country | person    a knowledge-base fact (reviewed: confirmed; proposed: reported;
                                            disputed: reported, and the edge says so)
  bears_on      market -> node              the market's title or option names the node   inferred
  purge_status  person -> status            CSIS Database of Chinese Military Purges       reported
                                            (the ladder: under investigation, suspended or removed, dismissed,
                                            expelled from the party, with dates; "potentially purged" = missing)

So two nodes are connected only when a source connects them: "Hormuz" and "crude oil" meet in a market that names
both, not because the system believes they are related. People are merged across sources only when their names have
exactly the same words and the match is unique; otherwise both are kept. The graph is L1-L4 material arranged for a
person to read; it draws no conclusion.
"""

from __future__ import annotations

import json
import re
import tomllib
import unicodedata
from dataclasses import asdict, dataclass, field
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[2] / "config" / "geo_themes.toml"
CIA = Path("data/entities/os_us_cia_world_leaders.json")
WD_RAW = Path("data/entities/wd_peps.ftm.json")
CACHE = Path("data/geo")
CONFIDENCE = ("confirmed", "reported", "inferred")
COUNTRY_NAMES = {"ir": "Iran", "cn": "China", "us": "United States", "il": "Israel"}
SERIES_WORDS = {"WCSSTUS1": r"strategic petroleum|\bSPR\b|oil reserves|crude oil reserves",
                "WCESTUS1": r"commercial crude|crude (oil )?(stocks|inventories)"}
CSIS_URL = ("https://docs.google.com/spreadsheets/d/e/2PACX-1vTqDUe8PFC8Pcx-tsItuQQQtf8M49knq2dBlf4ZhbQwmWaj06TTh2Z5DRf1yni-gw/"
            "pub?output=csv")
CSIS_PAGE = "https://chinapower.csis.org/data/chinese-pla-military-purges/"
LADDER = (("Date Under Investigation", "調查"), ("Date Suspended/Removed ", "停職或免職"), ("Date Dismissed/Replaced", "撤換"),
          ("Date Expelled from CCP", "開除黨籍"), ("Date Potentially Purged", "可能被整肅（公開活動消失）"))
STATUS_ZH = {"Purged": "已整肅", "Potentially Purged": "可能被整肅"}
LICENCES = {"csis": "CSIS ChinaPower, Database of Chinese Military Purges (freely downloadable; cited, cached only, not "
                    "redistributed)",
            "cia": "CIA World Leaders (U.S. government work, public domain), via OpenSanctions (CC BY-NC 4.0)",
            "wd": "Wikidata (CC0) via OpenSanctions wd_peps (CC BY-NC 4.0)"}


@dataclass
class Node:
    id: str
    type: str  # country, office, person, body, place, series, fact, market
    label: str
    attrs: dict = field(default_factory=dict)


@dataclass
class Edge:
    source: str
    target: str
    type: str
    confidence: str
    basis: str  # URL, fact id or data reference
    as_of: str = ""
    note: str = ""


@dataclass
class Theme:
    id: str
    label: str
    countries: list[str] = field(default_factory=list)
    offices: str = ""
    bodies: str = ""
    chokepoints: list[str] = field(default_factory=list)
    eia: list[str] = field(default_factory=list)
    kb_subjects: str = ""
    markets: str = ""
    purges: str = ""  # "csis": the CSIS Database of Chinese Military Purges


def load_themes(path: Path = CONFIG) -> list[Theme]:
    with open(path, "rb") as f:
        return [Theme(**t) for t in tomllib.load(f)["theme"]]


class Graph:
    def __init__(self, theme: Theme):
        self.theme = theme
        self.nodes: dict[str, Node] = {}
        self.edges: list[Edge] = []

    def node(self, n: Node) -> str:
        if n.id in self.nodes:
            self.nodes[n.id].attrs.update({k: v for k, v in n.attrs.items() if k not in self.nodes[n.id].attrs})
        else:
            self.nodes[n.id] = n
        return n.id

    def edge(self, e: Edge) -> None:
        if e.source in self.nodes and e.target in self.nodes and not any(
                (x.source, x.target, x.type) == (e.source, e.target, e.type) for x in self.edges):
            self.edges.append(e)

    def to_dict(self) -> dict:
        return {"theme": self.theme.id, "label": self.theme.label, "nodes": [asdict(n) for n in self.nodes.values()],
                "edges": [asdict(e) for e in self.edges]}


def _words(name: str) -> frozenset[str]:
    t = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()
    return frozenset(w for w in re.findall(r"[a-z]+", t) if len(w) > 1)


def name_keys(name: str) -> set[str]:
    """Spellings of one name that differ only in spacing, hyphens, apostrophes, case, diacritics or the position of
    the surname: "Zhang Youxia", "ZHANG You-xia", "Zhang You Xia" and "Youxia Zhang" share a key (pinyin aliases)."""
    t = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()
    tokens = re.findall(r"[a-z]+", re.sub(r"['\u2019-]", "", t))
    if len(tokens) < 2:
        return set()
    return {"".join(tokens), "".join(tokens[1:] + tokens[:1]), "".join(tokens[-1:] + tokens[:-1])}


def _index(g: "Graph") -> dict[str, list[str]]:
    """name key -> person node ids."""
    out: dict[str, list[str]] = {}
    for n in g.nodes.values():
        if n.type == "person":
            for k in name_keys(n.label):
                if n.id not in out.setdefault(k, []):
                    out[k].append(n.id)
    return out


def _same(index: dict[str, list[str]], name: str) -> list[str]:
    """Person nodes whose name is a spelling of `name` (several when the keys disagree)."""
    return sorted({i for k in name_keys(name) for i in index.get(k, [])})


def mentions(name: str, text: str) -> bool:
    """`text` names `name` in some spelling: two to four consecutive words that join to one of its keys."""
    keys = name_keys(name)
    if not keys:
        return False
    t = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().lower()
    t = re.sub(r"['\u2019]s\b", "", t)  # "Xi Jinping's successor"
    tokens = re.findall(r"[a-z]+", re.sub(r"['\u2019-]", "", t))
    return any("".join(tokens[i:i + n]) in keys for n in (2, 3, 4) for i in range(len(tokens) - n + 1))


_NOT_A_NAME = {"will", "who", "when", "what", "which", "does", "did", "is", "are", "the", "a", "an", "and", "or", "by",
               "president", "prime", "minister", "general", "gen", "leader", "supreme", "ayatollah", "premier",
               "chairman", "vice", "sen", "rep", "gov", "mr", "mrs", "ms", "dr", "before", "after", "in", "out"}


def surname_ok(text: str, surname: str, label: str) -> bool:
    """The surname appears in `text` as this person: a capitalised word right next to it must agree with the
    person's given name in its first three letters ("Zhang Shengmin" is not ZHANG Guoqing; "Masoud Pezeshkian" is
    Masud PEZESHKIAN)."""
    given = {w.lower()[:3] for w in re.findall(r"[A-Za-z]+", unicodedata.normalize("NFKD", label)
                                               .encode("ascii", "ignore").decode()) if w.lower() != surname}
    plain = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    for m in re.finditer(rf"\b{re.escape(surname)}\b", plain, re.I):
        before = re.search(r"([A-Z][a-z]+)[\s-]*$", plain[:m.start()])
        after = re.match(r"[\s-]*([A-Z][a-z]+)", plain[m.end():])
        near = [x.group(1).lower()[:3] for x in (before, after) if x and x.group(1).lower() not in _NOT_A_NAME]
        if not near or any(n in given for n in near):
            return True
    return False


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")[:60]


# --- sources -------------------------------------------------------------------------------------------------------

def add_cia(g: Graph, path: Path = CIA) -> None:
    """Current officials of the theme's countries whose office matches `offices`."""
    if not path.exists() or not g.theme.countries:
        return
    rx = re.compile(g.theme.offices or ".", re.I)
    for line in path.read_text(encoding="utf-8").splitlines():
        r = json.loads(line)
        p = r.get("properties", {})
        cc = [c for c in p.get("citizenship", []) if c in g.theme.countries]
        if r.get("schema") != "Person" or not cc:
            continue
        offices = [o for o in p.get("position", []) if rx.search(o) and "Hong Kong" not in o and "Macau" not in o]
        if not offices:
            continue
        name = p.get("name", [""])[0]
        pid = g.node(Node(f"person:cia:{r['id']}", "person", name,
                          {"source": (p.get("sourceUrl") or [""])[0], "licence": LICENCES["cia"],
                           "surname": " ".join(w for w in name.split() if w.isupper() and len(w) > 1).lower()}))
        country = g.node(Node(f"country:{cc[0]}", "country", COUNTRY_NAMES.get(cc[0], cc[0].upper())))
        for o in offices:
            oid = g.node(Node(f"office:{cc[0]}:{_slug(o)}", "office", o))
            g.edge(Edge(pid, oid, "holds_office", "confirmed", (p.get("sourceUrl") or [""])[0], r.get("last_seen", "")[:10]))
            g.edge(Edge(oid, country, "office_of", "confirmed", (p.get("sourceUrl") or [""])[0]))


def wd_bodies(theme: Theme, raw: Path = WD_RAW, cache: Path = CACHE) -> list[dict]:
    """Current holders of the positions matching `bodies` in the theme's first country: [{qid, name, body, start}].
    Three passes over the Wikidata extract; the result is cached per theme and extract."""
    if not theme.bodies or not raw.exists():
        return []
    key = cache / f"wd_{theme.id}_{int(raw.stat().st_mtime)}.json"
    if key.exists():
        return json.loads(key.read_text(encoding="utf-8"))
    rx, cc = re.compile(theme.bodies, re.I), theme.countries[0]
    posts, holds, names = {}, [], {}
    with open(raw, encoding="utf-8") as f:
        for line in f:
            if '"schema":"Position"' in line:
                r = json.loads(line)
                p = r["properties"]
                name = (p.get("name") or [""])[0]
                if rx.search(name) and cc in p.get("country", []):
                    posts[r["id"]] = name
    with open(raw, encoding="utf-8") as f:
        for line in f:
            if '"schema":"Occupancy"' in line:
                r = json.loads(line)
                p = r["properties"]
                post = next((x for x in p.get("post", []) if x in posts), None)
                current = "current" in p.get("status", []) or (p.get("startDate") and not p.get("endDate"))
                if post and current:
                    for h in p.get("holder", []):
                        holds.append({"qid": h, "body": posts[post], "start": min(p.get("startDate", [""]))})
    wanted = {h["qid"] for h in holds}
    with open(raw, encoding="utf-8") as f:
        for line in f:
            if '"schema":"Person"' in line:
                r = json.loads(line)
                if r["id"] in wanted and not r["properties"].get("deathDate"):
                    names[r["id"]] = (r["properties"].get("name") or [""])[0]
    out = [{**h, "name": names[h["qid"]]} for h in holds if h["qid"] in names]
    cache.mkdir(parents=True, exist_ok=True)
    key.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    return out


def add_wd(g: Graph, rows: list[dict]) -> None:
    cia = _index(g)
    for r in rows:
        same = _same(cia, r["name"])
        pid = same[0] if len(same) == 1 else g.node(Node(f"person:q:{r['qid']}", "person", r["name"],
                                                         {"source": f"https://www.wikidata.org/wiki/{r['qid']}",
                                                          "licence": LICENCES["wd"]}))
        if len(same) == 1:
            g.nodes[pid].attrs["wikidata"] = r["qid"]
        bid = g.node(Node(f"body:{_slug(r['body'])}", "body", r["body"]))
        g.edge(Edge(pid, bid, "member_of", "reported", f"https://www.wikidata.org/wiki/{r['qid']}", r["start"]))


def add_chokepoints(g: Graph, cache: Path = Path("data/osint/portwatch")) -> None:
    from pmpol.osint.portwatch import CHOKEPOINTS, LICENCE

    for key in g.theme.chokepoints:
        pid = g.node(Node(f"place:{key}", "place", CHOKEPOINTS.get(key, key)))
        files = sorted(cache.glob(f"*_{key}_*.json"))
        if not files:
            continue
        rows = json.loads(files[-1].read_text(encoding="utf-8"))
        last = rows[-7:]
        avg = sum(r["total"] for r in last) / max(len(last), 1)
        sid = g.node(Node(f"series:portwatch:{key}", "series", f"PortWatch {CHOKEPOINTS.get(key, key)} 每日通行數",
                          {"latest": f"{last[-1]['day']} 前 7 天平均 {avg:.1f} 艘" if last else "", "licence": LICENCE}))
        g.edge(Edge(pid, sid, "measured_by", "confirmed", "IMF PortWatch", last[-1]["day"] if last else ""))


def add_eia(g: Graph, cache: Path = Path("data/macro/eia")) -> None:
    from pmpol.macro.eia import LICENCE, SERIES

    for code in g.theme.eia:
        files = sorted(cache.glob(f"*_{code}.json"))
        latest = ""
        if files:
            d = json.loads(files[-1].read_text(encoding="utf-8"))
            day = max(d)
            latest = f"{day}：{d[day] / 1000:,.1f} 百萬桶"
        g.node(Node(f"series:eia:{code}", "series", SERIES.get(code, code), {"latest": latest, "licence": LICENCE}))


def add_kb(g: Graph, kb) -> None:
    if not g.theme.kb_subjects or kb is None:
        return
    rx = re.compile(g.theme.kb_subjects)
    people = {n.id: _words(n.label) for n in g.nodes.values() if n.type == "person"}
    for f in kb.facts.values():
        if not (rx.search(f.id) or rx.search(f.subject)):
            continue
        conf = "confirmed" if f.status == "reviewed" else "reported"
        fid = g.node(Node(f"fact:{f.id}", "fact", f"{f.subject}：{f.predicate}",
                          {"value": f.value if isinstance(f.value, (str, int, float)) else json.dumps(f.value, ensure_ascii=False, default=str)[:300],
                           "status": f.status, "layer": f.layer, "source": f.source.url}))
        cc = f.id.split(".", 1)[0]
        if f"country:{cc}" in g.nodes:
            g.edge(Edge(fid, f"country:{cc}", "states", conf, f.id, str(f.recorded_at),
                        "有爭議" if f.status == "disputed" else ""))
        text = _words(str(f.value))
        for pid, w in people.items():  # a fact that names a person in full
            if w and w <= text:
                g.edge(Edge(fid, pid, "states", conf, f.id, str(f.recorded_at), "有爭議" if f.status == "disputed" else ""))


def add_markets(g: Graph, events) -> None:
    """Live events whose title matches the theme, linked to every node they name."""
    if not g.theme.markets:
        return
    rx = re.compile(g.theme.markets, re.I)
    people = [n for n in g.nodes.values() if n.type == "person"]
    surnames: dict[str, list[str]] = {}
    for n in people:
        s = n.attrs.get("surname", "")
        if len(s) >= 5:
            surnames.setdefault(s, []).append(n.id)
    for e in events:
        if not rx.search(e.title):
            continue
        live = [m for m in e.markets if m.active and m.bid is not None and m.ask is not None]
        if not live:
            continue
        top = max(live, key=lambda m: (m.bid + m.ask) / 2)
        mid = g.node(Node(f"market:{e.venue}:{e.event_id}", "market", e.title,
                          {"venue": e.venue, "top": f"{top.outcome or 'Yes'} {50 * (top.bid + top.ask):.0f}%"}))
        text = " ".join([e.title] + [m.outcome or "" for m in e.markets])
        for n in people:
            s = n.attrs.get("surname", "")
            cn = n.attrs.get("name_cn", "")
            # consecutive words only: "Li Qiang ... Dong Jun" in one list of options does not name "Li Jun"
            if (mentions(n.label, text) or (cn and len(cn) >= 2 and cn in text)
                    or (s and len(surnames.get(s, [])) == 1 and surname_ok(text, s, n.label))):
                g.edge(Edge(mid, n.id, "bears_on", "inferred", e.title))
        for cc, name in COUNTRY_NAMES.items():
            if f"country:{cc}" in g.nodes and re.search(rf"\b{name}", text, re.I):
                g.edge(Edge(mid, f"country:{cc}", "bears_on", "inferred", e.title))
        for n in [n for n in g.nodes.values() if n.type == "place"]:
            key = n.label.split()[-1] if n.label.startswith("Strait") else n.label.split(" Strait")[0]
            if re.search(re.escape(key), text, re.I):
                g.edge(Edge(mid, n.id, "bears_on", "inferred", e.title))
        for code, pat in SERIES_WORDS.items():
            if f"series:eia:{code}" in g.nodes and re.search(pat, text, re.I):
                g.edge(Edge(mid, f"series:eia:{code}", "bears_on", "inferred", e.title))


def fetch_csis(cache: Path = CACHE, get=None, today=None) -> Path | None:
    """The CSIS purge database as CSV, cached per day; on failure the latest cached copy (None without one)."""
    from datetime import date

    from pmpol import USER_AGENT

    path = cache / f"csis_pla_purges_{(today or date.today()).isoformat()}.csv"
    if path.exists():
        return path
    try:
        if get is None:
            import httpx

            r = httpx.get(CSIS_URL, timeout=60, follow_redirects=True, headers={"User-Agent": USER_AGENT})
            r.raise_for_status()  # a refusal stops here, never retried
            text = r.text
        else:
            text = get(CSIS_URL)
    except Exception:
        older = sorted(cache.glob("csis_pla_purges_*.csv"))
        return older[-1] if older else None
    cache.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def _date(text: str) -> str:
    """"1/24/26" -> "2026-01-24"; anything else as written."""
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{2})", text.strip())
    return f"20{m.group(3)}-{int(m.group(1)):02d}-{int(m.group(2)):02d}" if m else text.strip()


def add_csis(g: Graph, path: Path | None) -> None:
    import csv

    if path is None or not path.exists():
        return
    known = _index(g)
    rows = list(csv.DictReader(path.read_text(encoding="utf-8").splitlines()))
    count: dict[str, int] = {}
    for x in rows:
        count[(x.get("Name") or "").strip()] = count.get((x.get("Name") or "").strip(), 0) + 1
    for r in rows:
        name = (r.get("Name") or "").strip()
        if not name:
            continue
        ladder = [f"{zh} {_date(r[col])}" for col, zh in LADDER if (r.get(col) or "").strip()]
        attrs = {"name_cn": r.get("Name_CN", ""), "rank": r.get("Rank", ""), "csis_position": r.get("Position", ""),
                 "csis_status": STATUS_ZH.get(r.get("Status", ""), r.get("Status", "")),
                 "csis_detail": r.get("Status_Detail", ""), "csis_confidence": r.get("Status Confidence", ""),
                 "ladder": " → ".join(ladder), "csis_source": CSIS_PAGE}
        same = _same(known, name)
        if count[name] > 1:  # two officers with one name (two Li Jun): never merged, one node each
            nid = f"person:csis:{_slug(name)}:{_slug(r.get('Position', ''))[:30]}"
            pid = g.node(Node(nid, "person", f"{name}（{r.get('Name_CN', '')}，{r.get('Position', '')[:40]}）",
                              {"licence": LICENCES["csis"], "ambiguous_name": True}))
        else:
            pid = same[0] if len(same) == 1 else g.node(Node(f"person:csis:{_slug(name)}", "person", name,
                                                             {"licence": LICENCES["csis"]}))
        g.nodes[pid].attrs.update({k: v for k, v in attrs.items() if v})
        status = r.get("Status", "")
        sid = g.node(Node(f"status:{_slug(status)}", "status", f"CSIS：{STATUS_ZH.get(status, status)}"))
        latest = (r.get("Latest Recorded Event") or "").strip()
        conflict = any(e.source == pid and e.type == "member_of" for e in g.edges)
        g.edge(Edge(pid, sid, "purge_status", "reported", CSIS_PAGE, latest,
                    ("；Wikidata 仍列為現任，兩邊並列" if conflict else "") + (f"（{attrs['ladder']}）" if ladder else "")))


def build(theme: Theme, events=(), kb=None, cia: Path = CIA, raw: Path = WD_RAW, csis: Path | None = None) -> Graph:
    g = Graph(theme)
    for cc in theme.countries:
        g.node(Node(f"country:{cc}", "country", COUNTRY_NAMES.get(cc, cc.upper())))
    add_cia(g, cia)
    add_wd(g, wd_bodies(theme, raw))
    if theme.purges == "csis":
        add_csis(g, csis if csis is not None else fetch_csis())
    add_chokepoints(g)
    add_eia(g)
    add_kb(g, kb)
    add_markets(g, events)
    # a market that names nothing in the graph is noise here
    linked = {e.source for e in g.edges}
    for nid in [n.id for n in g.nodes.values() if n.type == "market" and n.id not in linked]:
        del g.nodes[nid]
    return g


def latest_events(folder: Path = Path("data/snapshots")):
    from pmpol.universe.pipeline import load_snapshot

    snaps = sorted(folder.glob("universe_*.json.gz"))
    return load_snapshot(snaps[-1]) if snaps else []


def write(graphs: list[Graph], out: Path = CACHE / "graphs.json") -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps([g.to_dict() for g in graphs], ensure_ascii=False, default=str), encoding="utf-8")


def page(graphs: list[Graph], out: Path = Path("data/viewer/geo.html"), generated_at: str = "") -> Path:
    """One self-contained HTML file (Cytoscape.js from cdnjs) with the graphs embedded."""
    template = Path(__file__).with_name("viewer") / "geo.html"
    blob = json.dumps({"generated_at": generated_at, "graphs": [g.to_dict() for g in graphs]}, ensure_ascii=False,
                      default=str).replace("</", "<\\/")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(template.read_text(encoding="utf-8").replace("/*DATA*/", blob), encoding="utf-8")
    return out

