"""Reverse engine, first layer: price moves between two snapshots, checked against the news.

  diff        markets present in both snapshots, with a tight book both times, ranked by |Δ mid|
  confirm     did logically equivalent markets on other venues move the same way? (universe relations)
  news        GDELT DOC 2.0 article search over the window between the snapshots
  explain     a Proof per move; "silent move" when nothing in the news explains it

A silent move is a lead for a human, never a conclusion that someone traded on inside information:
the competing hypotheses (thin book, news in other languages, scheduled releases, one large trader)
are listed with every flag.
"""
