"""Price moves between two universe snapshots."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path

from pmpol.models import Event, Market


@dataclass
class Move:
    key: str  # market key
    event_key: str
    venue: str
    title: str
    outcome: str
    question: str
    mid_a: float
    mid_b: float
    spread_a: float
    spread_b: float
    ts_a: str
    ts_b: str
    lane: str = ""  # pmpol.movers.explain.LANES; set by the report, never used to drop a move

    @property
    def delta(self) -> float:
        return self.mid_b - self.mid_a

    @property
    def logit_delta(self) -> float:
        def lg(p):
            p = min(max(p, 0.01), 0.99)
            return math.log(p / (1 - p))
        return lg(self.mid_b) - lg(self.mid_a)


def snapshot_time(path: Path) -> str:
    m = re.search(r"(\d{8})T(\d{4})Z", path.name)
    if not m:
        return ""
    d, t = m.groups()
    return f"{d[:4]}-{d[4:6]}-{d[6:]}T{t[:2]}:{t[2:]}:00+00:00"


def _quotes(events: list[Event], max_spread: float) -> dict[str, tuple[Market, Event]]:
    out = {}
    for e in events:
        for m in e.markets:
            if m.active and m.bid is not None and m.ask is not None and 0 < m.ask and m.ask - m.bid <= max_spread:
                out[m.key] = (m, e)
    return out


def diff(a: list[Event], b: list[Event], ts_a: str, ts_b: str, min_move: float = 0.05,
         max_spread: float = 0.10) -> list[Move]:
    """Markets quoted with a tight book in both snapshots whose mid moved by at least `min_move`,
    largest first; one move per event (its biggest)."""
    qa, qb = _quotes(a, max_spread), _quotes(b, max_spread)
    best: dict[str, Move] = {}
    for key in qa.keys() & qb.keys():
        (ma, _), (mb, eb) = qa[key], qb[key]
        mv = Move(key, eb.key, mb.venue, eb.title, mb.outcome, mb.question, ma.mid, mb.mid, ma.spread, mb.spread,
                  ts_a, ts_b)
        if abs(mv.delta) >= min_move and (eb.key not in best or abs(mv.delta) > abs(best[eb.key].delta)):
            best[eb.key] = mv
    return sorted(best.values(), key=lambda m: -abs(m.delta))
