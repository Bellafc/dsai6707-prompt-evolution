"""Confirmation across venues, and the proof for each move."""

from __future__ import annotations

from datetime import datetime, timezone

from pmpol.assumptions import cite
from pmpol.models import Event
from pmpol.movers.diff import Move
from pmpol.movers.news import NewsResult
from pmpol.proof import Proof
from pmpol.universe.index import Universe
from pmpol.venues import info, source_url

POLITICAL_TOPICS = ("elections_us", "elections_intl", "us_government", "geopolitics")


def _mid(m) -> float | None:
    return m.mid if m is not None and m.bid is not None and m.ask is not None and m.ask > 0 else None


def equivalents(u_b: Universe, u_a: Universe, moves: list[Move]) -> dict[str, list[dict]]:
    """For each moved market, the other side of every cross-venue equivalence it is a single leg of,
    with that side's mid in both snapshots."""
    wanted = {m.key for m in moves}
    out: dict[str, list[dict]] = {k: [] for k in wanted}
    from pmpol.propositions.relations import build

    for r in build(u_b).relations:  # the proposition ontology is the source of relations
        if r.kind != "equivalent" or not r.cross_venue:
            continue
        for mine, other in ((r.lhs, r.rhs), (r.rhs, r.lhs)):
            if len(mine) == 1 and mine[0] in wanted:
                mb = [_mid(u_b.markets.get(k)) for k in other]
                ma = [_mid(u_a.markets.get(k)) for k in other]
                if None in mb or None in ma:
                    continue
                out[mine[0]].append({"keys": other, "venue": other[0].split(":", 1)[0], "template": r.template,
                                     "confidence": r.confidence, "mid_a": sum(ma), "mid_b": sum(mb),
                                     "url": source_url(u_b.markets[other[0]])})
    return out


def _days_to_close(m, ts_b: str) -> float | None:
    if not m or not m.close_time:
        return None
    try:
        close = datetime.fromisoformat(m.close_time.replace("Z", "+00:00"))
        now = datetime.fromisoformat(ts_b)
    except ValueError:
        return None
    # Date-only or naive times are taken as UTC, as elsewhere in the system.
    close, now = (d if d.tzinfo else d.replace(tzinfo=timezone.utc) for d in (close, now))
    return (close - now).total_seconds() / 86400


def explain_move(mv: Move, news: NewsResult | None, confirms: list[dict], market_b=None,
                 unobserved: tuple[str, ...] = (), lane_: str = "political") -> Proof:
    """`unobserved`: venues missing from either snapshot. "Not observed" is not "did not move": a lead is
    only called silent when every venue was seen in both snapshots (three-state evidence)."""
    code = info(mv.venue).code
    same_dir = [c for c in confirms if (c["mid_b"] - c["mid_a"]) * mv.delta > 0 and abs(c["mid_b"] - c["mid_a"]) >= 0.02]
    count = None if news is None else news.count
    if count == 0 and not same_dir and unobserved:
        verdict = ("查不到新聞，已觀測的平台也沒有跟著動；但 " + "、".join(info(v).code for v in unobserved)
                   + " 這段期間沒有資料，不能確定是沉默異動")
    elif count == 0 and not same_dir:
        verdict = "沉默異動：價格明顯變動，查不到相關新聞，其他平台也沒有跟著動"
    elif count == 0:
        verdict = "價格變動查不到新聞，但其他平台同一合約也同向變動（資訊可能已經公開，只是新聞還沒寫）"
    elif count:
        verdict = f"有 {count} 篇新聞可能解釋這次變動"
    else:
        verdict = "新聞查詢失敗，無法判斷"
    p = Proof(f"價格異動｜{mv.title}", f"{verdict}（{mv.outcome or 'Yes'} {100 * mv.mid_a:.1f}% → {100 * mv.mid_b:.1f}%）",
              result={"delta": round(mv.delta, 4), "logit_delta": round(mv.logit_delta, 3), "news": count,
                      "confirmed_elsewhere": len(same_dir), "silent": count == 0 and not same_dir and not unobserved,
                      "unobserved_venues": list(unobserved), "lane": lane_})
    if lane_ == "unclassified":
        p.caveats.append("分類系統認不出這個市場的主題（未分類），照樣檢查：分類只用來標註和排序，不用來過濾。")
    url = source_url(market_b) if market_b is not None else ""
    p.add("L4", f"{code} {mv.outcome or 'Yes'}：中間價 {100 * mv.mid_a:.1f}%（價差 {100 * mv.spread_a:.1f} 點）", url, mv.ts_a,
          kind="data", id="quote_a")
    p.add("L4", f"{code} {mv.outcome or 'Yes'}：中間價 {100 * mv.mid_b:.1f}%（價差 {100 * mv.spread_b:.1f} 點）", url, mv.ts_b,
          kind="data", id="quote_b")
    p.add("L5", f"變動 {100 * mv.delta:+.1f} 個百分點（logit {mv.logit_delta:+.2f}），兩個時間點盤口都夠緊（價差 ≤ 10 點）",
          kind="logic", id="move", inputs=("quote_a", "quote_b"))
    conf_ids = []
    for i, c in enumerate(confirms):
        d = c["mid_b"] - c["mid_a"]
        cid = f"other{i}"
        p.add("L4", f"{info(c['venue']).code} 同一合約（{c['template']}，配對：{c['confidence']}）："
                    f"{100 * c['mid_a']:.1f}% → {100 * c['mid_b']:.1f}%（{100 * d:+.1f} 點）", c["url"],
              f"{mv.ts_a} → {mv.ts_b}", kind="data", id=cid)
        conf_ids.append(cid)
    if confirms:
        p.add("L5", f"其他平台：{len(same_dir)} / {len(confirms)} 個等價合約同向變動 2 點以上", kind="logic",
              id="confirm", inputs=tuple(conf_ids))
    if news is not None:
        from pmpol.evidence import from_news, summary

        heads = "；".join(f"{a['domain']}：{a['title'][:80]}" for a in news.articles[:3])
        src_name = {"gdelt": "GDELT", "google_news": "Google News"}.get(news.source, "新聞")
        items = from_news(f"market:{mv.key}", news.articles, news.source)
        when = summary(items, mv.ts_a, mv.ts_b)
        timing = (f"；以變動期間 {mv.ts_a[:16]} 到 {mv.ts_b[:16]} 來看：變動前就已公開 {when['before']} 篇、"
                  f"變動期間 {when['during']} 篇" + (f"、時間不明 {when['unknown']} 篇" if when["unknown"] else "")
                  if items else "")
        text = (f"{src_name} 搜尋「{news.query}」，{news.start[:16]} 到 {news.end[:16]}："
                + (f"{news.count} 篇" + (f"（{heads}）" if heads else "") + timing if news.count is not None
                   else f"查詢失敗（{news.error}）"))
        p.add("L1", text, news.url, news.end[:16], kind="data", id="news")
        p.result["evidence"] = [e.to_dict() for e in items]
        p.result["evidence_timing"] = when
        if items and when["before"] == len(items):
            p.alt("新聞在變動開始前就已公開（市場是在反應已知消息）", "supports",
                  f"{len(items)} 篇都早於第一個快照 {mv.ts_a[:16]}")
        if news.count == 0:  # "no news found" leans on the search being good enough
            cite(p, "news_search_coverage")
    days = _days_to_close(market_b, mv.ts_b)
    p.alt("報價太薄，一筆小單就能推動", "supports" if max(mv.spread_a, mv.spread_b) > 0.05 else "against",
          f"價差 {100 * mv.spread_a:.1f} → {100 * mv.spread_b:.1f} 點")
    p.alt("接近到期，價格只是往 0 或 1 收斂", "supports" if days is not None and days < 7 else
          "against" if days is not None else "unchecked",
          f"距離截止 {days:.1f} 天" if days is not None else "沒有截止時間")
    p.alt("資訊已經公開（其他平台也動了）", "supports" if same_dir else
          ("unchecked" if unobserved else "against" if confirms else "unchecked"),
          (f"{len(same_dir)} / {len(confirms)} 個等價合約同向變動" if confirms else "其他平台沒有等價合約")
          + (f"；{'、'.join(info(v).label for v in unobserved)} 沒有資料（未觀測，不等於沒動）" if unobserved else ""))
    p.alt("有新聞，只是用的字詞不同或語言不同", "supports" if count else "unchecked",
          "GDELT 涵蓋多語言並翻譯，但關鍵字由標題自動產生，可能漏掉" if not count else f"找到 {count} 篇")
    p.alt("單一大戶下單或做市商調整報價", "unchecked", "需要逐筆成交資料（下一步：鏈上與成交紀錄）")
    p.alt("有人比市場先知道（知情交易）", "unchecked",
          "只有在其他解釋都被排除、而且之後真的有新聞證實時才考慮；系統不據此點名任何人")
    p.caveats.append("這只是供人工追查的線索，不是「有人內線交易」的結論。")
    if news is not None and news.count == 25 and news.source == "gdelt":
        p.caveats.append("新聞數達到查詢上限 25 篇，實際更多。")
    if news is not None and news.source == "google_news":
        p.caveats.append("GDELT 限流，改用 Google News RSS：以英文新聞為主，非英文報導可能漏掉。")
    return p


# Lanes label a move; they never remove it (ontology principle: classification is a lens, not a wall).
# Political and unclassified moves get news checks first: a market the taxonomy cannot place may be the
# newest kind of political question. Counting markets move as counts are published, so they go last.
LANES = ("political", "unclassified", "economy_media", "count")
LANE_ZH = {"political": "政治", "unclassified": "未分類", "economy_media": "經濟／媒體", "count": "計數題"}


def lane(u: Universe, mv: Move) -> str:
    t = u.tags.get(mv.event_key)
    if t is None or t.topic == "other":
        return "count" if t is not None and t.measure == "count" else "unclassified"
    if t.measure == "count":
        return "count"
    return "political" if t.topic in POLITICAL_TOPICS else "economy_media"


def political(u: Universe, mv: Move) -> bool:
    """Political topics only, and not counting markets ("how many … this week"), which move as the
    count is published rather than on news."""
    t = u.tags.get(mv.event_key)
    return t is not None and t.topic in POLITICAL_TOPICS and t.measure not in ("count",)


def universes(a: list[Event], b: list[Event]) -> tuple[Universe, Universe]:
    return Universe.build(a), Universe.build(b)
