"""Run the movers pipeline over two snapshots and render the report."""

from __future__ import annotations

import json
from pathlib import Path

from pmpol.movers.diff import diff, snapshot_time
from pmpol.movers.explain import LANE_ZH, LANES, equivalents, explain_move, lane, universes
from pmpol.movers.news import query_for, search
from pmpol.universe import pipeline
from pmpol.venues import info


def pick_snapshots(folder: Path = Path("data/snapshots"), min_hours: float = 1.0) -> tuple[Path, Path] | None:
    """The latest universe snapshot and the latest one at least `min_hours` older."""
    from datetime import datetime

    snaps = sorted(folder.glob("universe_*.json.gz"))
    if len(snaps) < 2:
        return None
    b = snaps[-1]
    tb = datetime.fromisoformat(snapshot_time(b))
    for a in reversed(snaps[:-1]):
        if (tb - datetime.fromisoformat(snapshot_time(a))).total_seconds() >= min_hours * 3600:
            return a, b
    return None


def run(a_path: Path, b_path: Path, top: int = 20, min_move: float = 0.05, news: bool = True, fetch=None,
        flow: bool = False, flow_client=None):
    ea, eb = pipeline.load_snapshot(a_path), pipeline.load_snapshot(b_path)
    ts_a, ts_b = snapshot_time(a_path), snapshot_time(b_path)
    ua, ub = universes(ea, eb)
    from pmpol.movers.explain import _days_to_close

    # Every move is kept and labelled with a lane; only markets settling within 2 days are set aside (they
    # converge to 0/1 on schedule, not on news). News checks go to the political and unclassified lanes first.
    near_close = []
    moves = []
    for m in diff(ea, eb, ts_a, ts_b, min_move=min_move):
        d = _days_to_close(ub.markets.get(m.key), ts_b)
        (near_close if d is not None and d < 2 else moves).append(m)
    for m in moves:
        m.lane = lane(ub, m)
    checked = [m for m in moves if m.lane in ("political", "unclassified")][:top]
    conf = equivalents(ub, ua, checked)
    from pmpol.venues import VENUES

    unobserved = tuple(v for v in VENUES if v not in {e.venue for e in ea} & {e.venue for e in eb})
    rows = []
    for mv in checked:
        res = search(query_for(mv.title, mv.outcome), ts_a, ts_b, fetch=fetch) if news else None
        p = explain_move(mv, res, conf.get(mv.key, []), ub.markets.get(mv.key), unobserved, mv.lane)
        if flow and p.result.get("silent") and mv.venue == "polymarket":
            from pmpol.movers import flow as fl

            slug = mv.key.split(":", 1)[1]
            try:
                f = fl.for_move(slug, ts_a, ts_b, client=flow_client)
            except Exception as e:  # a refusal stops this lookup only; the move keeps its proof
                p.caveats.append(f"成交紀錄查不到：{str(e)[:120]}")
                f = None
            if f is not None:
                fl.add_to_proof(p, f, slug, ts_b)
        rows.append((mv, p))
    return moves, rows, ts_a, ts_b, len(near_close)


def goal_rows(a_path: Path, b_path: Path, news: bool = True, fetch=None) -> list:
    """Shared goals whose markets moved together between the snapshots (pmpol.goals), with a news check each."""
    from pmpol.goals import comovement, comovement_proof, load_goals

    ea, eb = pipeline.load_snapshot(a_path), pipeline.load_snapshot(b_path)
    ts_a, ts_b = snapshot_time(a_path), snapshot_time(b_path)
    out = []
    for g in load_goals():
        cm = comovement(g, ea, eb)
        if cm.direction == 0:
            continue
        res = search(g.news, ts_a, ts_b, fetch=fetch) if news and g.news else None
        out.append((cm, comovement_proof(cm, res, ts_a, ts_b)))
    return out


def render(moves, rows, ts_a: str, ts_b: str, near_close: int = 0, goals: list | None = None) -> str:
    from collections import Counter

    silent = [(m, p) for m, p in rows if p.result.get("silent")]
    by_lane = Counter(m.lane or "political" for m in moves)
    L = [f"# 價格異動報告 — {ts_a[:16]} → {ts_b[:16]}", "",
         "逆向引擎的第一層：兩個快照之間價格明顯變動（盤口夠緊）的市場，逐一查新聞、比對其他平台。"
         "「沉默異動」是給人工追查的線索，不是內線交易的結論；系統不點名任何錢包或個人。", "",
         "**分類只用來標註和排序，不用來過濾**：分類系統認不出主題的市場（未分類）和政治市場一樣優先查新聞；"
         "經濟、媒體和計數題的異動全部列出，只是不查新聞。", "",
         f"- 變動 ≥ 5 個百分點的事件：**{len(moves)}** 個（"
         + "、".join(f"{LANE_ZH[k]} {by_lane[k]}" for k in LANES if by_lane[k]) + "）；"
         f"另有 {near_close} 個在 2 天內到期、價格本來就會往 0 或 1 收斂，不列入",
         f"- 查了新聞的前 **{len(rows)}** 個（政治和未分類），沉默異動（沒有新聞、其他平台也沒動）：**{len(silent)}** 個", "",
         "## 1. 查了新聞的異動", "",
         "| 變動 | 平台 | 分類 | 市場 | 選項 | 前 → 後 | 新聞數 | 其他平台同向 | 判斷 |", "|---|---|---|---|---|---|---|---|---|"]
    for mv, p in rows:
        r = p.result
        news = "—" if r["news"] is None else r["news"]
        flag = "**沉默**" if r["silent"] else ("有新聞" if r["news"] else ("同向" if r["confirmed_elsewhere"] else "未知"))
        L.append(f"| {100 * mv.delta:+.1f} | {info(mv.venue).code} | {LANE_ZH[r.get('lane', 'political')]} | "
                 f"{mv.title[:70]} | {mv.outcome[:30]} | "
                 f"{100 * mv.mid_a:.1f}% → {100 * mv.mid_b:.1f}% | {news} | {r['confirmed_elsewhere']} | {flag} |")
    rest = [m for m in moves if m.lane in ("economy_media", "count")]
    if rest:
        L += ["", f"## 1b. 其他主題的異動（{len(rest)} 個，列出但沒有查新聞）", "",
              "| 變動 | 平台 | 分類 | 市場 | 選項 | 前 → 後 |", "|---|---|---|---|---|---|"]
        for mv in rest[:40]:
            L.append(f"| {100 * mv.delta:+.1f} | {info(mv.venue).code} | {LANE_ZH[mv.lane]} | {mv.title[:70]} | "
                     f"{mv.outcome[:30]} | {100 * mv.mid_a:.1f}% → {100 * mv.mid_b:.1f}% |")
        if len(rest) > 40:
            L.append(f"| … | | | 另外 {len(rest) - 40} 個 | | |")
    L += ["", "## 2. 沉默異動的推理證明", ""]
    for _, p in silent:
        L += p.markdown()
    if not silent:
        L.append("- 這段期間沒有沉默異動。")
    if goals:
        L += ["", f"## 3. 共同目的的市場一起動（{len(goals)} 個）", "",
              "同一個共同目的（`config/goals.toml`）底下至少 3 個市場往同一方向移動 2 點以上、反方向的不到三分之一。"
              "交給逆向引擎查新聞；是線索，不是結論。", ""]
        for _, p in goals:
            L += p.markdown()
    L += ["", "資料來源：各平台公開 API；新聞來自 GDELT DOC 2.0 API（The GDELT Project，可自由使用，需註明出處）。", ""]
    return "\n".join(L)


def export(rows, path: Path, goals: list | None = None) -> int:
    out = [{"id": f"goal_move:{cm.goal.id}", "group": "mover", "kind": "goal_comovement", "subject": cm.goal.id,
            "edge": float(len(cm.moves)), "venues": sorted({info(e.venue).code for e, *_ in cm.moves}),
            "markets": [m.key for _, m, *_ in cm.moves], "confidence": "rule", "title": p.title,
            "proof": {**p.to_dict(), "graph": p.graph()}} for cm, p in (goals or [])] + [{"id": f"mover:{mv.key}", "group": "mover", "kind": "silent_move" if p.result.get("silent") else "move",
            "subject": mv.event_key, "edge": round(mv.delta, 4), "venues": [info(mv.venue).code],
            "confidence": "rule", "title": p.title, "proof": {**p.to_dict(), "graph": p.graph()}} for mv, p in rows]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"signals": out}, ensure_ascii=False, default=str))
    return len(out)
