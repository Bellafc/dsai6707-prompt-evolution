"""Order flow behind a Polymarket move (reverse engine, layer 3; 2026-10-06).

A silent move (the price moved, the news did not) is a lead. The next question is who traded: many small wallets
or a few large ones, old accounts or new ones, wallets that trade everywhere or only this event, buying long shots
or favourites, before or after the first article. Polymarket's public data API lists every trade with the trading
wallet; the features below are computed from it for the window between the two snapshots.

Privacy (team rule: never name a wallet or a person): a wallet address is replaced by a salted hash the moment it is
read, and names, pseudonyms, biographies and images in the API's answer are dropped before anything is stored. The
output is aggregate shares only; no address, hash or profile appears in a report or a proof.

Features (aggregate, for the market's trades in the window):
  trades, volume_usd, wallets       how much traded, by how many wallets
  top_share, hhi                    concentration of the volume (largest wallet's share; Herfindahl index)
  new_wallet_share                  volume from wallets whose first trade on Polymarket is under NEW_DAYS old
  single_event_share                volume from wallets that traded no other event (in their last PROFILE_LIMIT trades)
  longshot_buy_share                volume bought at a price under LONGSHOT
  before_news_share                 volume traded before the first article in the window (when there is one)
  dormant_share                     volume from wallets that had traded before but not in the DORMANT_DAYS before the
                                    window (reactivated wallets; 2026-10-07)
  skilled_share                     volume from wallets with at least MIN_CLOSED closed positions of which at least
                                    SKILLED made a realized profit (closed-positions endpoint; 2026-10-07)
Only the TOP_WALLETS largest wallets are profiled (one or two requests each), so the wallet-history shares are lower
bounds. Thresholds are fixed here, before looking at any move. A lead for a person, never a conclusion that anyone traded on inside information.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path

from pmpol import USER_AGENT

GAMMA = "https://gamma-api.polymarket.com"
DATA_API = "https://data-api.polymarket.com"
CACHE = Path("data/flow")
SALT = "pmpol-flow-v1"  # hashes are for joining within this cache, not for publication
NEW_DAYS = 30
LONGSHOT = 0.15
TOP_WALLETS = 5
PROFILE_LIMIT = 500
PAGE = 500
MAX_PAGES = 4
KEEP = ("side", "price", "size", "timestamp", "outcomeIndex", "eventSlug")
DORMANT_DAYS = 60
MIN_CLOSED = 20
SKILLED = 0.7
CLOSED_LIMIT = 500


def _hash(addr: str) -> str:
    return hashlib.sha256((SALT + (addr or "").lower()).encode()).hexdigest()[:16]


def _clean(t: dict) -> dict:
    """Drop everything personal; keep the trade and a salted hash of its wallet."""
    out = {k: t.get(k) for k in KEEP}
    out["wallet"] = _hash(t.get("proxyWallet", ""))
    return out


def _get(url: str, params: dict) -> list | dict:
    import httpx

    r = httpx.get(url, params=params, timeout=60, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
    r.raise_for_status()  # a refusal or a rate limit (403, 429) stops here, never retried
    return r.json()


class Client:
    def __init__(self, get=None, cache: Path = CACHE, pause: float = 0.5):
        self.get, self.cache, self.pause = get or _get, cache, pause
        self.addresses: dict[str, str] = {}  # hash -> address, in memory only (needed for profile requests)

    def _call(self, url, params):
        out = self.get(url, params)
        time.sleep(self.pause)
        return out

    def condition_id(self, slug: str) -> str | None:
        rows = self._call(f"{GAMMA}/markets", {"slug": slug})
        rows = rows if isinstance(rows, list) else []
        return rows[0].get("conditionId") if rows else None

    def trades(self, condition_id: str, start: int, end: int) -> list[dict]:
        """Cleaned trades of a market with start <= timestamp <= end (newest first pages until past start)."""
        path = self.cache / f"trades_{condition_id[:18]}_{start}_{end}.json"
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
        out = []
        for page in range(MAX_PAGES):
            rows = self._call(f"{DATA_API}/trades", {"market": condition_id, "limit": PAGE, "offset": page * PAGE})
            if not rows:
                break
            for t in rows:
                if start <= int(t.get("timestamp", 0)) <= end:
                    out.append(_clean(t))
                    self.addresses[out[-1]["wallet"]] = t.get("proxyWallet", "")
            if min(int(t.get("timestamp", 0)) for t in rows) < start or len(rows) < PAGE:
                break
        self.cache.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(out), encoding="utf-8")
        return out

    def profile(self, addr_hash: str, addr: str) -> dict:
        """{trades, events, first_ts} from the wallet's latest PROFILE_LIMIT trades (cached by hash)."""
        path = self.cache / f"wallet_{addr_hash}.json"
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
        rows = self._call(f"{DATA_API}/trades", {"user": addr, "limit": PROFILE_LIMIT})
        rows = rows if isinstance(rows, list) else []
        prof = {"trades": len(rows), "events": len({r.get("eventSlug") for r in rows}),
                "first_ts": min((int(r.get("timestamp", 0)) for r in rows), default=0), "complete": len(rows) < PROFILE_LIMIT,
                "ts": sorted(int(r.get("timestamp", 0)) for r in rows)}
        self.cache.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(prof), encoding="utf-8")
        return prof


    def record(self, addr_hash: str, addr: str) -> dict:
        """{closed, wins, complete}: the wallet's closed positions and how many made a realized profit (cached)."""
        path = self.cache / f"wallet_{addr_hash}_closed.json"
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
        rows = self._call(f"{DATA_API}/closed-positions", {"user": addr, "limit": CLOSED_LIMIT})
        rows = rows if isinstance(rows, list) else []
        rec = {"closed": len(rows), "wins": sum(float(r.get("realizedPnl") or 0) > 0 for r in rows),
               "complete": len(rows) < CLOSED_LIMIT}
        self.cache.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(rec), encoding="utf-8")
        return rec


def dormant(profile: dict, start: int, days: int = DORMANT_DAYS) -> bool | None:
    """The wallet traded before, but not in the `days` before `start`; None when the history cannot tell."""
    before = [t for t in profile.get("ts", []) if t < start]
    if "ts" not in profile:
        return None
    if not before:
        return False if profile.get("complete") else None  # a new wallet is not a reactivated one
    return start - before[-1] >= days * 86400


def skilled(rec: dict | None) -> bool:
    return bool(rec) and rec["closed"] >= MIN_CLOSED and rec["wins"] / rec["closed"] >= SKILLED


@dataclass
class Features:
    trades: int
    volume_usd: float
    wallets: int
    top_share: float
    hhi: float
    new_wallet_share: float
    single_event_share: float
    longshot_buy_share: float
    before_news_share: float | None
    profiled: int
    dormant_share: float | None = None
    skilled_share: float | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def features(trades: list[dict], profiles: dict[str, dict], end: int, news_first: int | None = None,
             start: int | None = None, records: dict[str, dict] | None = None) -> Features | None:
    if not trades:
        return None
    vol: dict[str, float] = {}
    for t in trades:
        vol[t["wallet"]] = vol.get(t["wallet"], 0.0) + float(t["size"]) * float(t["price"])
    total = sum(vol.values()) or 1.0
    shares = sorted((v / total for v in vol.values()), reverse=True)
    new = sum(vol[w] for w, p in profiles.items() if p["complete"] and end - p["first_ts"] < NEW_DAYS * 86400)
    single = sum(vol[w] for w, p in profiles.items() if p["events"] <= 1)
    longshot = sum(float(t["size"]) * float(t["price"]) for t in trades
                   if t.get("side") == "BUY" and float(t["price"]) < LONGSHOT)
    before = None if news_first is None else sum(float(t["size"]) * float(t["price"]) for t in trades
                                                 if int(t["timestamp"]) < news_first) / total
    dorm = None if start is None else sum(vol[w] for w, p in profiles.items() if dormant(p, start)) / total
    skill = None if records is None else sum(vol[w] for w, r in records.items() if skilled(r)) / total
    return Features(len(trades), round(total, 2), len(vol), round(shares[0], 4), round(sum(s * s for s in shares), 4),
                    round(new / total, 4), round(single / total, 4), round(longshot / total, 4),
                    None if before is None else round(before, 4), len(profiles),
                    None if dorm is None else round(dorm, 4), None if skill is None else round(skill, 4))


def for_move(slug: str, ts_a: str, ts_b: str, news_first: str | None = None, client: Client | None = None,
             top: int = TOP_WALLETS) -> Features | None:
    """Features of a Polymarket market's trades between two snapshot times (ISO)."""
    client = client or Client()
    start, end = int(datetime.fromisoformat(ts_a).timestamp()), int(datetime.fromisoformat(ts_b).timestamp())
    cid = client.condition_id(slug)
    if not cid:
        return None
    raw = client.trades(cid, start, end)
    if not raw:
        return None
    # profile the largest wallets; their addresses are needed for the request but are never stored or shown
    vol: dict[str, float] = {}
    for t in raw:
        vol[t["wallet"]] = vol.get(t["wallet"], 0.0) + float(t["size"]) * float(t["price"])
    wanted = sorted(vol, key=vol.get, reverse=True)[:top]
    if any(h not in client.addresses for h in wanted):  # trades came from the cache: read the addresses again
        client.addresses.update(_addresses(client, cid, set(wanted)))
    profiles = {h: client.profile(h, client.addresses[h]) for h in wanted if h in client.addresses}
    records = {h: client.record(h, client.addresses[h]) for h in wanted if h in client.addresses}
    nf = int(datetime.fromisoformat(news_first).timestamp()) if news_first else None
    return features(raw, profiles, end, nf, start, records)


def _addresses(client: Client, cid: str, wanted: set[str]) -> dict[str, str]:
    """hash -> address for the wanted wallets, read again from the API (the cache holds hashes only)."""
    found: dict[str, str] = {}
    for page in range(MAX_PAGES):
        rows = client._call(f"{DATA_API}/trades", {"market": cid, "limit": PAGE, "offset": page * PAGE})
        for t in rows or []:
            h = _hash(t.get("proxyWallet", ""))
            if h in wanted:
                found[h] = t.get("proxyWallet", "")
        if len(found) == len(wanted) or not rows or len(rows) < PAGE:
            break
    return found


def add_to_proof(p, f: Features, slug: str, ts_b: str) -> None:
    """Aggregate order-flow steps and the hypotheses they bear on; no wallet is named."""
    p.add("L4", f"Polymarket 成交（data-api，兩個快照之間）：{f.trades:,} 筆、約 {f.volume_usd:,.0f} 美元、{f.wallets:,} 個錢包；"
                f"最大錢包占 {100 * f.top_share:.0f}%（HHI {f.hhi:.2f}）；買價低於 {100 * LONGSHOT:.0f}% 的買單占 "
                f"{100 * f.longshot_buy_share:.0f}%", f"{DATA_API}/trades?market={slug}", ts_b, kind="data", id="flow")
    p.add("L4", f"成交量最大的 {f.profiled} 個錢包：首筆交易在 {NEW_DAYS} 天內的占全部成交量 {100 * f.new_wallet_share:.0f}%、"
                f"只交易過這一個事件的占 {100 * f.single_event_share:.0f}%（只查前幾大錢包，是下限）"
                + ("" if f.before_news_share is None else f"；第一篇報導之前成交的占 {100 * f.before_news_share:.0f}%"),
          f"{DATA_API}/trades", ts_b, kind="data", id="flow_wallets")
    if f.dormant_share is not None or f.skilled_share is not None:
        p.add("L4", f"同一批錢包：沉睡 {DORMANT_DAYS} 天以上後重新交易的占成交量 "
                    f"{'—' if f.dormant_share is None else f'{100 * f.dormant_share:.0f}%'}；過去至少 {MIN_CLOSED} 個已結算部位、"
                    f"{100 * SKILLED:.0f}% 以上有實現獲利的占 "
                    f"{'—' if f.skilled_share is None else f'{100 * f.skilled_share:.0f}%'}（門檻事先固定）",
              f"{DATA_API}/closed-positions", ts_b, kind="data", id="flow_history")
    p.result["flow"] = f.to_dict()
    p.alt("少數錢包推動了這次變動（一個大戶或少數人）", "supports" if f.top_share >= 0.5 else "against",
          f"最大錢包占成交量 {100 * f.top_share:.0f}%，{f.wallets} 個錢包")
    p.alt("新開的錢包集中下單（常見於有特定資訊或新進場的交易者）", "supports" if f.new_wallet_share >= 0.3 else "unchecked",
          f"前幾大錢包中，首筆交易在 {NEW_DAYS} 天內的占 {100 * f.new_wallet_share:.0f}%；這不是內線交易的證據")
    if f.dormant_share is not None:
        p.alt("沉睡的錢包被重新啟用來下單", "supports" if f.dormant_share >= 0.3 else "unchecked",
              f"前幾大錢包中，沉睡 {DORMANT_DAYS} 天以上後重新交易的占 {100 * f.dormant_share:.0f}%；這不是內線交易的證據")
    if f.skilled_share is not None:
        p.alt("過去常賺錢的錢包在這次變動中下單", "supports" if f.skilled_share >= 0.3 else "unchecked",
              f"已結算部位多數獲利的錢包占 {100 * f.skilled_share:.0f}%；勝率包括提前賣出獲利、做市，不代表有資訊優勢")
    p.caveats.append("成交特徵是彙總數字：系統不點名、不保存任何錢包地址或個人資料（地址只在記憶體裡轉成雜湊）。")
