"""News search for a move.

Primary: GDELT DOC 2.0 (keyless; one request every 5 seconds per IP). GDELT monitors news in about
65 languages and translates them, so an English query also finds non-English coverage.
Fallback when GDELT rate-limits the (shared) IP: Google News RSS search, which supports date bounds
(day precision) and returns each item's publication time; items are then filtered to the window.
Google News RSS is offered for personal, non-commercial use, which fits this research-only project.
Results are cached under data/news/ by source, query and window.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

DOC_API = "https://api.gdeltproject.org/api/v2/doc/doc"
RSS_API = "https://news.google.com/rss/search"
CACHE = Path("data/news")
_last_call = [0.0]

_GENERIC = {"will", "who", "what", "which", "when", "the", "election", "elections", "winner", "win", "wins", "house",
            "senate", "governor", "gubernatorial", "mayoral", "mayor", "primary", "race", "party", "general", "next",
            "district", "margin", "victory", "of", "in", "by", "before", "after", "be", "a", "an", "and", "or", "for",
            "to", "on", "u.s", "us", "2025", "2026", "2027", "2028", "yes", "no", "democratic", "republican",
            "nominee", "nomination", "midterm", "midterms", "how", "many", "seats", "control", "special", "runoff",
            "round", "first", "second", "presidential", "president", "prime", "minister", "leader", "out", "announced",
            "generic", "vote", "percent", "this", "week", "month", "year", "end", "publicly", "praise", "visit",
            "january", "february", "march", "april", "may", "june", "july", "august", "september", "october",
            "november", "december", "jan", "feb", "mar", "apr", "jun", "jul", "aug", "sep", "sept", "oct", "nov",
            "dec", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "today", "tomorrow"}
_NOT_A_NAME = re.compile(r"\d|%|\$|^(at least|above|below|over|under|before|after|by|yes|no|other)\b", re.I)


@dataclass
class NewsResult:
    query: str
    start: str
    end: str
    count: int | None  # None when the search failed
    articles: list[dict] = field(default_factory=list)  # {title, url, domain, seendate, language}
    url: str = ""
    error: str = ""
    source: str = ""  # "gdelt" or "google_news"


_INSTITUTION = re.compile(r"\bWhite House\b|\bHouse of (?:Commons|Lords|Representatives)\b|\bSenate Majority\b", re.I)


def _strip_generic(phrase: str) -> str:
    inst = _INSTITUTION.search(phrase)
    if not inst:
        return " ".join(t for t in phrase.split() if t.lower() not in _GENERIC)
    head = " ".join(t for t in phrase[:inst.start()].split() if t.lower() not in _GENERIC)
    return (head + " " + phrase[inst.start():]).strip()


def query_for(title: str, outcome: str) -> str:
    """A GDELT query: the outcome when it names a person or party, plus the proper nouns of the title."""
    from pmpol.universe.outcomes import party_of, surname
    from pmpol.models import Market

    words = re.findall(r"[A-Z][\w'’.-]+(?:\s+[A-Z][\w'’.-]+)*", re.sub(r"['’]s\b", "", title))
    phrases = [w for w in words if w.lower() not in _GENERIC and not re.fullmatch(r"[A-Z]{2}-\d+", w)]
    # Generic words are dropped from a name, except inside fixed institutional names ("White House").
    phrases = [_strip_generic(p) for p in phrases]
    phrases = [p for p in phrases if len(p) > 2]
    lab = re.sub(r"\s*\((?:[DRI])\)\s*$", "", outcome).strip()
    m = Market("x", "x", "x", title, lab)
    if lab and not _NOT_A_NAME.search(lab) and surname(lab) and party_of(m) is None and len(lab.split()) >= 2:
        phrases = [lab] + phrases
    seen, out = set(), []
    for p in phrases:
        if p.lower() not in seen:
            seen.add(p.lower())
            out.append(f'"{p}"' if " " in p else p)
    return " ".join(out[:3])


def _stamp(iso: str) -> str:
    return datetime.fromisoformat(iso).strftime("%Y%m%d%H%M%S")


def local_search(query: str, lang: str, country: str, start_iso: str, end_iso: str, cache: Path = CACHE,
                 rss_fetch=None, edition: str = "") -> NewsResult:
    """The same window in another language's edition of Google News (Hebrew in Israel, Persian in Iran, ...)."""
    if not query:
        return NewsResult(query, start_iso, end_iso, None, error="no searchable terms")
    return _google_news(query, start_iso, end_iso, rss_fetch, cache, lang, country, edition)


def relevance(title: str, query: str) -> float:
    """Share of the query's terms found in a headline (case-insensitive; quoted phrases count as one term; works
    for scripts without spaces between words as a plain substring test)."""
    terms = re.findall(r'"([^"]+)"|(\S+)', query)
    # generic words and short Latin function words ("of", "the") do not make a headline relevant
    terms = [a or b for a, b in terms if (a or b).lower() not in _GENERIC and not re.fullmatch(r"[a-z]{1,3}", (a or b).lower())]
    if not terms:
        return 0.0
    t = title.casefold()
    return sum(term.casefold() in t for term in terms) / len(terms)


def search(query: str, start_iso: str, end_iso: str, fetch=None, cache: Path = CACHE, max_records: int = 25,
           pad_hours: int = 24, rss_fetch=None) -> NewsResult:
    """Articles matching `query` seen from `pad_hours` before the window start to its end:
    GDELT first, Google News RSS when GDELT fails."""
    start = (datetime.fromisoformat(start_iso) - timedelta(hours=pad_hours)).isoformat()
    if not query:
        return NewsResult(query, start, end_iso, None, error="no searchable terms")
    res = _gdelt(query, start, end_iso, fetch, cache, max_records)
    if res.count is None:
        rss = _google_news(query, start, end_iso, rss_fetch, cache)
        if rss.count is not None:
            rss.error = f"GDELT failed ({res.error[:60]}); used Google News RSS"
            return rss
    return res


def _cached_text(cache: Path, url: str, get, check) -> str:
    path = cache / f"{hashlib.sha1(url.encode()).hexdigest()[:16]}.txt"
    if path.exists():
        return path.read_text(encoding="utf-8")
    text = get()
    check(text)  # only cache responses that parse
    cache.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return text


def _gdelt(query, start, end_iso, fetch, cache, max_records) -> NewsResult:
    params = {"query": query, "mode": "artlist", "format": "json", "maxrecords": str(max_records),
              "startdatetime": _stamp(start), "enddatetime": _stamp(end_iso), "sort": "datedesc"}
    url = DOC_API + "?" + "&".join(f"{k}={v}" for k, v in params.items())
    res = NewsResult(query, start, end_iso, None, url=url, source="gdelt")
    try:
        d = json.loads(_cached_text(cache, url, lambda: (fetch or _gdelt_fetch)(params), lambda t: json.loads(t or "{}"))
                       or "{}")
    except Exception as e:  # rate-limit notices come back as plain text
        res.error = str(e)[:200]
        return res
    res.articles = [{k: a.get(k, "") for k in ("title", "url", "domain", "seendate", "language")}
                    for a in d.get("articles") or []]
    res.count = len(res.articles)
    return res


def _google_news(query, start, end_iso, rss_fetch, cache, lang: str = "en", country: str = "US",
                 edition: str = "") -> NewsResult:
    import xml.etree.ElementTree as ET
    from email.utils import parsedate_to_datetime

    d0, d1 = datetime.fromisoformat(start), datetime.fromisoformat(end_iso)
    q = f"{query} after:{(d0 - timedelta(days=1)).date()} before:{(d1 + timedelta(days=1)).date()}"
    hl = "en-US" if lang == "en" else lang
    params = {"q": q, "hl": hl, "gl": country, "ceid": f"{country}:{edition or lang.split('-')[0]}"}
    url = RSS_API + "?" + "&".join(f"{k}={v}" for k, v in params.items())
    res = NewsResult(query, start, end_iso, None, url=url, source="google_news")
    try:
        root = ET.fromstring(_cached_text(cache, url, lambda: (rss_fetch or _rss_fetch)(params), ET.fromstring))
    except Exception as e:
        res.error = str(e)[:200]
        return res
    for item in root.iter("item"):
        try:
            when = parsedate_to_datetime(item.findtext("pubDate") or "")
        except (TypeError, ValueError):
            continue
        if d0 <= when <= d1:  # the search operators are day-precise; keep the exact window
            src = item.find("source")
            res.articles.append({"title": item.findtext("title") or "", "url": item.findtext("link") or "",
                                 "domain": src.text if src is not None else "", "seendate": when.isoformat(),
                                 "language": lang})
    res.count = len(res.articles)
    return res


def _rss_fetch(params: dict) -> str:
    import httpx

    r = httpx.get(RSS_API, params=params, timeout=60, follow_redirects=True,
                  headers={"User-Agent": USER_AGENT})
    r.raise_for_status()
    return r.text


def _gdelt_fetch(params: dict) -> str:
    """One request, spaced 5.5 s from the last (GDELT's documented rate). A 429 is a refusal: it is raised, not
    retried (the project's rule), and the search falls back to Google News."""
    import httpx

    wait = 5.5 - (time.time() - _last_call[0])
    if wait > 0:
        time.sleep(wait)
    _last_call[0] = time.time()
    r = httpx.get(DOC_API, params=params, timeout=60, headers={"User-Agent": USER_AGENT})
    r.raise_for_status()
    return r.text
