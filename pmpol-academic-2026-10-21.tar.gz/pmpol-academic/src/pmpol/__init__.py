"""pmpol: research system for political prediction markets (read-only, no trading)."""

# Every request names the project and says it is research and read-only. A refused request (403, 429) stops;
# the client is never disguised as a browser.
USER_AGENT = "pmpol/0.1 (https://github.com/bellafc/polymarket_politics; research, read-only)"
