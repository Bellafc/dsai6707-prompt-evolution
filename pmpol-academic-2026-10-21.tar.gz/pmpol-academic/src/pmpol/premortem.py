"""Structured challenge: a pre-mortem of the judgments that matter most (Klein 2007, "Performing a project
premortem"; CIA Tradecraft Primer 2009, devil's advocacy and "what if?" analysis).

"Suppose that three months from now this judgment has turned out wrong. What is the most likely reason?" The
question is put to every judgment the stated requirements depend on (the headline answer of each question in
config/requirements.toml) and to the largest consistency violations. The system answers first, from the proof
itself, so that the team's session starts from a complete list of weak points rather than a blank page:

  - a cited key assumption whose signpost has triggered, that has no basis, or that is caveated (its own
    "falsified if" is the failure story; its check is the first sign to watch);
  - a knowledge-base fact that is disputed, proposed, or marked reviewed with no second reader;
  - resolution rules that differ or were not fully verified; legs matched by label, title or text;
  - for a consensus: venues that disagree after fees, one venue carrying most of the weight, an error all
    venues share (which pooling cannot see), a long time to resolution;
  - a reference class with a small sample;
  - competing hypotheses in the proof that the data support or that were never checked.

Failure points are ranked by how likely they are to be the reason (level: high, medium, low) and each names
the step it attacks, so the proof graph shows where the judgment would break. The team adds what the system
cannot know (context, intent, news) in the session; nothing here changes a judgment.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

LEVELS = ("high", "medium", "low")
SELF = ("真的定價不一致",)  # competing hypotheses that are the judgment itself, not a way for it to fail
SHARED = 100  # cited by this many published proofs: a model-wide weak point, folded into one line
ZH = {"high": "高", "medium": "中", "low": "低"}
_MATCH = {"label": "high", "title": "high", "text": "high", "entity": "medium", "name": "medium", "descriptor": "medium"}
_MATCH_ZH = {"label": "標籤", "title": "標題", "text": "文字相似", "entity": "人物的 Wikidata 身分", "name": "人名",
             "descriptor": "事件描述詞"}
_RULES = {"material": ("high", "兩邊的結算條件有實質差異：同一個結果，兩邊可能判得不一樣"),
          "minor": ("medium", "結算條件有細節差異（例如以宣誓或媒體宣布為準），邊界情況可能判得不一樣"),
          "unverified": ("medium", "結算條件沒有完全比對（規則文字讀不到的屬性），可能有沒讀到的差異")}


@dataclass
class Failure:
    level: str
    reason: str
    attacks: str  # step id or reference the failure would break
    watch: str = ""  # what would show it first


@dataclass
class Premortem:
    id: str
    title: str
    conclusion: str
    confidence: str
    why: str  # why this judgment was chosen
    failures: list[Failure] = field(default_factory=list)


@dataclass
class Context:
    assumptions: dict  # id -> pmpol.assumptions.Assumption
    facts: dict  # fact id -> status bucket from pmpol.review ("reviewed", "legacy", "proposed", "disputed", ...)
    triggered: dict = field(default_factory=dict)  # assumption id -> triggered signpost detail
    shared: set = field(default_factory=set)  # assumption and fact ids most proofs rest on (model-wide, not case-specific)


def challenge(row: dict, ctx: Context, why: str) -> Premortem:
    p = row.get("proof", {})
    res = p.get("result", {}) or {}
    steps = p.get("steps", [])
    pm = Premortem(row.get("id", ""), p.get("title", row.get("title", "")), p.get("conclusion", ""),
                   p.get("analytic_confidence", ""), why)
    model: list[Failure] = []  # weak points shared by most published proofs: reported once, folded

    def add(f: Failure) -> None:
        key = f.attacks.removeprefix("assumption:")
        (model if key in ctx.shared else pm.failures).append(f)

    for aid in res.get("assumptions", []) or []:
        a = ctx.assumptions.get(aid)
        if a is None:
            continue
        if aid in ctx.triggered:
            add(Failure("high", f"假設「{aid}」的路標已經觸發：{ctx.triggered[aid]}", f"assumption:{aid}",
                        "`pmpol signposts`"))
        elif a.status != "solid":
            add(Failure("high" if a.status == "unsupported" else "medium",
                        f"假設「{aid}」{'沒有根據' if a.status == 'unsupported' else '有保留'}，而它失效的情況是：{a.falsified_if}",
                        f"assumption:{aid}", a.check))
    seen = set()
    for s in steps:
        ref = s.get("ref", "")
        bucket = ctx.facts.get(ref)
        if bucket is None or ref in seen:
            continue
        seen.add(ref)
        if bucket in ("disputed", "stale"):
            add(Failure("high", f"事實「{ref}」{'有爭議' if bucket == 'disputed' else '審核後內容又改了'}", ref,
                        "並列的其他來源；`pmpol review`"))
        elif bucket in ("proposed", "rejected"):
            add(Failure("medium", f"事實「{ref}」還在提議中，沒有人審核過：如果它錯了，這一步就不成立", ref,
                        "`pmpol review` 的待審佇列"))
        elif bucket == "legacy":
            add(Failure("low", f"事實「{ref}」標成已審核，但沒有第二個人的審核紀錄", ref, "`pmpol review`"))
    if res.get("rules") in _RULES:
        level, text = _RULES[res["rules"]]
        add(Failure(level, text, "rules", "比對兩邊的規則原文（L1 步驟）"))
    if res.get("confidence") in _MATCH:
        m = res["confidence"]
        add(Failure(_MATCH[m], f"各腿只靠{_MATCH_ZH[m]}配對，可能根本不是同一件事", "match", "逐腿讀題目和選項文字"))
    if row.get("kind") == "consensus":
        _consensus(res, steps, add)
    if row.get("kind") == "outside_view" and isinstance(res.get("n"), int) and res["n"] < 30:
        add(Failure("medium", f"參考類別只有 {res['n']} 次，基準率的區間很寬；這次的條件也可能和過去不同", "base",
                    "分段樣本（例如 1994 年以後）的基準率"))
    for alt in p.get("alternatives", []):
        verdict = alt.get("verdict")
        if verdict in ("supports", "unchecked") and not any(x in alt.get("hypothesis", "") for x in SELF):
            add(Failure("medium" if verdict == "supports" else "low",
                        f"競爭假設{'有資料支持' if verdict == 'supports' else '還沒查'}：{alt.get('hypothesis', '')}"
                        + (f"（{alt['evidence']}）" if alt.get("evidence") else ""), "alternatives", ""))
    if model:
        model.sort(key=lambda f: LEVELS.index(f.level))
        ids = [f.attacks.removeprefix("assumption:") for f in model]
        fired = [i for i in ids if i in ctx.triggered]
        pm.failures.append(Failure(model[0].level, "共用的模型弱點（大部分推理證明都依賴，不是這個判斷特有的）："
                                   + "、".join(f"「{i}」" for i in ids)
                                   + (f"；其中路標已觸發的：{'、'.join(fired)}" if fired else ""),
                                   "model", "`pmpol signposts`、`pmpol review`、`pmpol assumptions`"))
    pm.failures.sort(key=lambda f: (LEVELS.index(f.level), f.attacks == "model"))
    return pm


def _consensus(res: dict, steps: list[dict], add) -> None:
    if res.get("disagree"):
        add(Failure("high", "各平台扣掉手續費後的區間沒有交集：平台之間真的不一致，共識只是參考值，任何一邊都可能是對的",
                    "band", "下一個快照各平台是否收斂、往哪一邊收斂"))
    weights = [int(m.group(1)) for s in steps if s.get("layer") == "L4"
               for m in [re.search(r"權重 (\d+)%", s.get("text", ""))] if m]
    if weights and max(weights) >= 60:
        add(Failure("medium", f"一個平台占了 {max(weights)}% 的權重：共識幾乎就是那個平台的報價", "pool",
                    "其他平台的報價和掛單深度"))
    add(Failure("medium", "所有平台一起錯：合併只能平均掉各平台各自的誤差，同一批交易者共同的錯誤（例如都相信同一份民調）"
                          "看不到", "pool", "獨立的證據線：民調、基本面、專家評級、參考類別"))
    days = res.get("horizon_days")
    if isinstance(days, (int, float)) and days > 180:
        add(Failure("low", f"離結算還有約 {days:.0f} 天，之後的新資訊可能讓今天的價格完全失準", "pool", ""))


def select(rows: list[dict], headline_ids: dict[str, str], top: int = 5) -> list[tuple[dict, str]]:
    """The judgments to challenge: the headline answer of each stated question, then the largest violations."""
    by_id = {r.get("id"): r for r in rows}
    out = [(by_id[i], f"需求清單「{q}」目前的答案") for q, i in headline_ids.items() if i in by_id]
    taken = {r.get("id") for r, _ in out}
    viol = sorted((r for r in rows if str(r.get("kind", "")).startswith("onto:") and r.get("id") not in taken),
                  key=lambda r: -abs(r.get("edge") or 0))
    out += [(r, f"扣費後邊際最大的一致性違反（{100 * abs(r.get('edge') or 0):.1f} 點）") for r in viol[:top]]
    return out


def render(pms: list[Premortem], when: str) -> str:
    from pmpol.confidence import ZH as CONF

    L = [f"# 事前驗屍（結構化挑戰）｜{when}", "",
         "**假設三個月後這個判斷錯了，最可能的原因是什麼？** 對需求清單每個問題目前的答案、和扣費後邊際最大的違反各做一次。"
         "系統先從推理證明本身列出失敗點（由最可能到最不可能，每個標明它會打斷哪一步、最先會在哪裡看到），"
         "團隊再補系統不知道的（背景、意圖、新聞）。這不改變任何判斷。", ""]
    for i, pm in enumerate(pms, 1):
        L += [f"## {i}. {pm.title}", "", f"- 為什麼挑這個：{pm.why}", f"- 判斷：{pm.conclusion}",
              f"- 分析信心：{CONF.get(pm.confidence, pm.confidence or '—')}", "",
              "| # | 可能性 | 最可能錯在哪裡 | 打斷的步驟 | 最先在哪裡看到 |", "|---|---|---|---|---|"]
        for j, f in enumerate(pm.failures, 1):
            L.append(f"| {j} | {ZH[f.level]} | {f.reason} | `{f.attacks}` | {f.watch or '—'} |".replace("\n", " "))
        if not pm.failures:
            L.append("| — | — | 推理證明裡找不到結構性的弱點：只靠機率公理、已審核的事實和結構配對 | — | — |")
        L.append("")
    return "\n".join(L)
