"""External forecasts as a fair-value benchmark (layer 5; 2026-10-06).

A market price is one crowd's estimate. Other forecasters answer the same or nearby questions: Manifold (a
play-money market with a public API) and ViEWS (Uppsala/PRIO's statistical forecasts of armed conflict, public
API). Their numbers are L3 opinions: shown next to the market, with the definitional differences, never used to
correct the price and never called a mispricing.

Manifold: each pair in config/external.toml joins one Manifold question to one market of the latest snapshot.
Pairs are written by hand after reading both rule texts (an automatic text match would pair questions that only
sound alike). The proof shows both rule texts (L0), Manifold's probability (L3), the market's quote (L4) and the gap
(L5), and checks one hypothesis mechanically: when one side's YES is broader by the rules, it should be priced at
least as high, so a gap in that direction is what the definitions predict.

ViEWS: country-month probabilities of at least 25 battle-related deaths in state-based armed conflict (UCDP
definition) and the predicted number of deaths, from the latest monthly run. No market settles on this; it is
context for a question.

Not used: Metaculus (the API answers 403 without a token since 2025; not retried), ACLED CAST (needs an
institutional account), Early Warning Project (annual mass-killing risk; no market asks it).
"""

from __future__ import annotations

import json
import re
import tomllib
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path

from pmpol import USER_AGENT

CONFIG = Path(__file__).resolve().parents[2] / "config" / "external.toml"
CACHE = Path("data/external")
MANIFOLD = "https://api.manifold.markets/v0/slug/{slug}"
VIEWS = "https://api.viewsforecasting.org"
MIN_BETTORS = 30  # fewer distinct traders: the Manifold price is shown but flagged as thin
MIN_GAP = 0.02  # a smaller gap says nothing about its direction (spreads and noise)
STALE_DAYS = 7  # no Manifold trade for this long: the price may be old
VIEWS_MONTHS = 3
LICENCE = {"manifold": "Manifold Markets public API (ToS: non-commercial research permitted); cited, creator data dropped",
           "views": "VIEWS (Uppsala University, PRIO) public API; licence not stated; cited, not redistributed"}
# Manifold fields kept; the creator's id, name, username and avatar are dropped on read (team rule: no personal data)
KEEP = ("id", "slug", "question", "outcomeType", "probability", "uniqueBettorCount", "volume", "closeTime",
        "lastBetTime", "isResolved", "resolution", "token", "resolutionTime", "createdTime")


@dataclass
class Pair:
    id: str
    requirement: str
    slug: str
    market: str
    differences: str
    broader: str = ""
    answer: str = ""


@dataclass
class ViewsCountry:
    iso: str
    requirement: str
    why: str = ""


@dataclass
class Config:
    pairs: list[Pair] = field(default_factory=list)
    views: list[ViewsCountry] = field(default_factory=list)


def load(path: Path = CONFIG) -> Config:
    raw = tomllib.loads(path.read_text(encoding="utf-8"))
    pairs = [Pair(**p) for p in raw.get("manifold", [])]
    for p in pairs:
        if p.broader not in ("", "market", "external"):
            raise ValueError(f"pair {p.id}: broader must be market, external or empty")
        if ":" not in p.market:
            raise ValueError(f"pair {p.id}: market must be <venue>:<market_id>")
    return Config(pairs, [ViewsCountry(**v) for v in raw.get("views", [])])


def _http(url: str) -> str:
    import httpx

    r = httpx.get(url, timeout=60, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
    r.raise_for_status()  # a refusal or a rate limit (403, 429) stops here, never retried
    return r.text


def _cached(name: str, url: str, today: date, get, cache: Path) -> dict:
    path = cache / f"{today:%Y%m%d}_{name}.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    d = json.loads((get or _http)(url))
    cache.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    return d


def clean_manifold(m: dict) -> dict:
    """Keep the market, drop the creator; the rule text is cut to its first 600 characters."""
    out = {k: m.get(k) for k in KEEP}
    out["rules"] = re.sub(r"\s+", " ", m.get("textDescription") or "").strip()[:600]
    out["answers"] = [{"text": a.get("text"), "probability": a.get("probability")} for a in m.get("answers") or []]
    return out


def manifold(slug: str, today: date | None = None, get=None, cache: Path = CACHE) -> dict:
    today = today or datetime.now(timezone.utc).date()
    path = cache / f"{today:%Y%m%d}_manifold_{slug}.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    out = clean_manifold(json.loads((get or _http)(MANIFOLD.format(slug=slug))))
    cache.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    return out


def latest_run(runs: list[str]) -> str | None:
    """The newest monthly fatalities run, e.g. fatalities003_2026_08_t01."""
    found = [(int(m[2]), int(m[3]), int(m[1]), r) for r in runs
             if (m := re.fullmatch(r"fatalities(\d+)_(\d{4})_(\d{2})_t01", r))]
    return max(found)[3] if found else None


def views(isos: list[str], today: date | None = None, get=None, cache: Path = CACHE) -> tuple[str | None, dict]:
    """(run, {iso: [rows]}) from the latest ViEWS fatalities run; one request per country, cached per day."""
    today = today or datetime.now(timezone.utc).date()
    run = latest_run(_cached("views_runs", f"{VIEWS}/", today, get, cache).get("runs", []))
    if not run:
        return None, {}
    out = {}
    for iso in isos:
        d = _cached(f"views_{run}_{iso}", f"{VIEWS}/{run}/cm?iso={iso}&pagesize=1000", today, get, cache)
        out[iso] = sorted(d.get("data") or [], key=lambda r: (r["year"], r["month"]))
    return run, out


def manifold_p(m: dict, answer: str = "") -> float | None:
    if answer:
        return next((a["probability"] for a in m.get("answers", []) if a["text"] == answer), None)
    return m.get("probability")


def find_market(events: list[dict], key: str):
    """(event, market) of a '<venue>:<market_id>' key in a snapshot's events, or (None, None)."""
    venue, mid = key.split(":", 1)
    for e in events:
        if e["venue"] != venue:
            continue
        for m in e["markets"]:
            if m["market_id"] == mid:
                return e, m
    return None, None


def consensus_for(rows: list[dict], key: str) -> dict | None:
    """The published cross-venue consensus row that includes this market, if any."""
    return next((r for r in rows if r.get("kind") == "consensus" and key in r.get("markets", [])), None)


def _day(ms) -> str:
    return datetime.fromtimestamp(int(ms) / 1000, timezone.utc).strftime("%Y-%m-%d") if ms else ""


def calibration_check(kb, horizon: int = 7, venue: str | None = None) -> tuple[str, str, str | None]:
    """(verdict, evidence, fact id) for "play money is systematically biased", from Manifold's resolved questions
    (kb/L2/external_calibration.yaml). The comparison is with the paired real-money venue's slope at the same horizon
    (kb/L2/market_calibration.yaml) when there is one, else with 1: real-money venues are not perfectly calibrated
    either, so a bias of play money is a difference from them."""
    f = kb.facts.get(f"calibration.manifold.politics.h{horizon}") if kb is not None else None
    if f is None or not isinstance(f.value, dict):
        return "unchecked", "需要用已結算的題目檢查 Manifold 的校準，知識庫還沒有這筆事實", None
    v = f.value
    b, se, n = float(v["slope_b"]), float(v["slope_b_se"]), int(v["n"])
    ref = kb.facts.get(f"calibration.{venue}.politics.h{horizon}") if venue else None
    if ref is not None and isinstance(ref.value, dict):
        rb, rse = float(ref.value["slope_b"]), float(ref.value["slope_b_se"])
        off = abs(b - rb) > 2 * (se ** 2 + rse ** 2) ** 0.5
        against = f"{venue} 的 {rb:.2f}（標準誤 {rse:.2f}）"
    else:
        rb, off, against = 1.0, abs(b - 1) > 2 * se, "1（完美校準）"
    shape = "比較不夠自信（機率太靠中間）" if b > rb else "比較過度自信（機率太極端）"
    return ("supports" if off else "against",
            f"Manifold 已結算的美國政治題 {n:,} 題（截止前 {horizon} 天）：校準斜率 b = {b:.2f}（標準誤 {se:.2f}），"
            f"對照 {against}：" + (f"差超過兩個標準誤，{shape}" if off else "分不開") + f"；Brier {float(v['brier']):.3f}",
            f.id)


def pair_proof(pair: Pair, m: dict, event: dict | None, market: dict | None, cons: dict | None, observed_at: str,
               now: datetime | None = None, kb=None):
    from pmpol.proof import Proof

    now = now or datetime.now(timezone.utc)
    ext = manifold_p(m, pair.answer)
    mid = (None if not market or market.get("bid") is None or market.get("ask") is None
           else (market["bid"] + market["ask"]) / 2)
    bettors = int(m.get("uniqueBettorCount") or 0)
    label = f"{m.get('question', pair.slug)}" + (f"｜{pair.answer}" if pair.answer else "")
    venue = pair.market.split(":", 1)[0]
    if ext is None or mid is None:
        head = "比不了：" + ("Manifold 沒有這個答案的機率" if ext is None else "快照裡沒有這個市場的報價")
        gap = None
    else:
        gap = ext - mid
        head = (f"Manifold {100 * ext:.1f}%（遊戲幣，{bettors:,} 人交易）；{venue} 中間價 {100 * mid:.1f}%；"
                f"差 {100 * gap:+.1f} 點" + ("" if pair.broader else "（定義相同）") + "——外部意見，不據此修正市場價格")
    p = Proof(f"外部預測｜{pair.id}｜{label}", head,
              result={"pair": pair.id, "requirement": pair.requirement, "external": ext, "market": mid,
                      "gap": None if gap is None else round(gap, 4), "bettors": bettors, "broader": pair.broader,
                      "source": "manifold", "slug": pair.slug, "market_key": pair.market,
                      # analytic confidence (pmpol.confidence): differing definitions are material; even the same
                      # definition differs in resolution sources and timing
                      "rules": "material" if pair.broader else "minor"})
    p.add("L0", f"Manifold 結算條件（原文節錄）：{m.get('rules', '')[:300]}", MANIFOLD.format(slug=pair.slug),
          kind="rule", id="rule_ext")
    if market:
        rules = re.sub(r"\s+", " ", market.get("rules") or "").strip()
        p.add("L0", f"{venue} 結算規則（原文節錄）：{rules[:300]}", pair.market, kind="rule", id="rule_mkt")
    p.add("L5", f"配對（人工，讀過兩邊規則）：{pair.differences}", "config/external.toml", kind="match", id="pair",
          inputs=tuple(i for i in ("rule_ext", "rule_mkt") if market or i == "rule_ext"))
    if ext is not None:
        p.add("L3", f"Manifold 機率 {100 * ext:.1f}%（{bettors:,} 個不同交易者、成交量 {int(m.get('volume') or 0):,} 遊戲幣；"
                    f"最後交易 {_day(m.get('lastBetTime'))}）", MANIFOLD.format(slug=pair.slug),
              observed_at, kind="data", id="ext")
    if mid is not None:
        p.add("L4", f"{venue} 買 {100 * market['bid']:.1f}／賣 {100 * market['ask']:.1f}（中間價 {100 * mid:.1f}%）",
              pair.market, observed_at, kind="data", id="quote")
    if cons:
        p.add("L5", f"本系統的跨平台共識：{cons['proof'].get('conclusion', '')}", cons["id"], observed_at,
              kind="logic", id="consensus")
    if gap is not None:
        p.add("L5", f"差距 = Manifold − 市場中間價 = {100 * gap:+.1f} 點", "", kind="logic", id="gap",
              inputs=("ext", "quote", "pair"))
        # the side whose YES is broader by the rules should be priced at least as high
        if pair.broader and abs(gap) < MIN_GAP:
            p.alt("差距來自定義不同", "unchecked", f"差距 {100 * gap:+.1f} 點小於 {100 * MIN_GAP:.0f} 點，看不出方向")
        elif pair.broader:
            expected = gap < 0 if pair.broader == "market" else gap > 0
            wide = "市場" if pair.broader == "market" else "Manifold"
            p.alt("差距來自定義不同", "supports" if expected else "against",
                  f"依規則原文，{wide}的 YES 範圍較寬，應該不低於另一邊；實際差 {100 * gap:+.1f} 點"
                  + ("，方向一致" if expected else "，方向相反（範圍較窄的一邊反而較高）"))
        last = m.get("lastBetTime")
        stale = bool(last) and (now - datetime.fromtimestamp(int(last) / 1000, timezone.utc)).days >= STALE_DAYS
        p.alt("Manifold 價格太舊或交易者太少", "supports" if stale or bettors < MIN_BETTORS else "against",
              f"{bettors:,} 個交易者（門檻 {MIN_BETTORS}）；最後交易 {_day(last)}")
        verdict, evidence, fid = calibration_check(kb, venue=venue)
        if fid:
            f = kb.facts[fid]
            p.add("L2", evidence, fid, str(f.recorded_at), kind="data", id="ext_calibration")
        p.alt("遊戲幣市場的系統性偏誤（沒有真錢、長期題目缺少套利）", verdict, evidence)
    p.caveats += ["Manifold 是遊戲幣市場（Mana 不能兌現），價格是外部意見（L3），不是市場事實，也不是本系統的修正值。",
                  "兩題的定義不完全相同時，差距有一部分是定義造成的；配對時寫下的差異見「配對」步驟。"]
    if bettors and bettors < MIN_BETTORS:
        p.caveats.append(f"交易者少於 {MIN_BETTORS} 人，價格很容易被少數人推動。")
    return p


def _span(xs: list[float], scale: float, unit: str) -> str:
    lo, hi = f"{scale * min(xs):,.0f}", f"{scale * max(xs):,.0f}"
    return f"{lo}{unit}" if lo == hi else f"{lo}–{hi}{unit}"


def views_proof(c: ViewsCountry, run: str, rows: list[dict], today: date):
    from pmpol.proof import Proof

    ahead = [r for r in rows if (r["year"], r["month"]) >= (today.year, today.month)][:VIEWS_MONTHS]
    name = (rows[0].get("name") if rows else "") or c.iso
    if not ahead:
        head = f"ViEWS（{run}）沒有 {name} 的未來月份"
    else:
        ps, ns = [r["main_dich"] for r in ahead], [r["main_mean"] for r in ahead]
        head = (f"ViEWS（{run}）：{name} 未來 {len(ahead)} 個月，每月至少 25 名戰鬥死亡的國家層級武裝衝突機率 "
                f"{_span(ps, 100, '%')}，預測每月死亡 {_span(ns, 1, ' 人')}")
    p = Proof(f"外部預測｜ViEWS｜{name}", head,
              result={"iso": c.iso, "requirement": c.requirement, "run": run, "source": "views",
                      "months": [{"month": f"{r['year']}-{r['month']:02d}", "p_conflict": r["main_dich"],
                                  "deaths": r["main_mean"]} for r in ahead]})
    p.add("L3", "ViEWS 定義：main_dich＝每國每月至少 25 名戰鬥死亡（UCDP 國家層級武裝衝突，政府是其中一方）的預測機率；"
                "main_mean＝預測死亡人數（集成模型）", f"{VIEWS}/{run}/codebook", kind="rule", id="def")
    p.add("L3", f"為什麼看這個國家：{c.why}", "config/external.toml", kind="rule", id="why")
    for i, r in enumerate(ahead):
        p.add("L3", f"{r['year']}-{r['month']:02d}：機率 {100 * r['main_dich']:.0f}%、預測死亡 {r['main_mean']:,.1f} 人",
              f"{VIEWS}/{run}/cm?iso={c.iso}", f"{r['year']}-{r['month']:02d}", kind="data", id=f"m{i}",
              inputs=("def",))
    p.caveats += ["ViEWS 是統計模型的預測（L3 外部意見），只算政府參與的武裝衝突；沒有市場用這個定義結算，只當背景。",
                  f"這一輪（{run}）用到上個月為止的資料；之後發生的事件不在模型裡。"]
    return p


def export(proofs: list[tuple[str, str, object]], path: Path = Path("data/external.json")) -> int:
    """proofs: (id, requirement, proof). Rows carry subject external:<requirement> for the requirements report."""
    out = [{"id": f"external:{i}", "group": "external", "kind": f"external_{p.result.get('source', '')}",
            "subject": f"external:{req}", "edge": abs(p.result.get("gap") or 0.0), "venues": [],
            "markets": [p.result["market_key"]] if p.result.get("market_key") else [], "confidence": "rule",
            "title": p.title, "proof": {**p.to_dict(), "graph": p.graph()}} for i, req, p in proofs]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"signals": out}, ensure_ascii=False, default=str), encoding="utf-8")
    return len(out)


def _pct(x) -> str:
    return "—" if x is None else f"{100 * x:.1f}%"


def render(proofs: list[tuple[str, str, object]], when: str) -> str:
    L = [f"# 外部預測｜{when}", "",
         "外部預測（Manifold 遊戲幣市場、ViEWS 衝突模型）放在市場價格旁邊比對。它們是 L3 外部意見，不是事實，"
         "也不用來修正市場價格；差距只是觀察，不判斷哪邊對（`config/external.toml`）。", "",
         "| 配對 | 問題 | Manifold | 市場 | 差距 | 定義 |", "|---|---|---|---|---|---|"]
    for i, req, p in proofs:
        r = p.result
        if r.get("source") != "manifold":
            continue
        wide = {"market": "市場較寬", "external": "Manifold 較寬", "": "相同"}[r.get("broader", "")]
        gap = "—" if r["gap"] is None else f"{100 * r['gap']:+.1f}"
        L.append(f"| {i} | {req} | {_pct(r['external'])}（{r['bettors']} 人） | {_pct(r['market'])} | {gap} | {wide} |")
    L += ["", "## ViEWS 衝突預測（背景）", ""]
    for i, req, p in proofs:
        if p.result.get("source") == "views":
            L.append(f"- {p.conclusion}（問題：{req}）")
    L.append("")
    for _, _, p in proofs:
        L += p.markdown()
    return "\n".join(L)
