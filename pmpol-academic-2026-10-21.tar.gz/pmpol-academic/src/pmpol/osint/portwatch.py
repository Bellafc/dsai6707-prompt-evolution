"""IMF PortWatch: daily transit calls through maritime chokepoints (AIS-based).

Source: IMF PortWatch (IMF and University of Oxford), ArcGIS feature service "Daily_Chokepoints_Data".
Terms: IMF copyright and usage (imf.org/en/About/copyright-and-terms): data may be reused with the
attribution "Source: International Monetary Fund"; commercial reuse needs permission.
Kalshi's Strait of Hormuz and Bab el-Mandeb traffic markets settle on this series, so it is both an L1
observation and the settlement source for those markets.

Published with a lag of several days; the latest date present is returned with the data.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import json
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.parse import urlencode

URL = ("https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services/Daily_Chokepoints_Data/"
       "FeatureServer/0/query")
CACHE = Path("data/osint/portwatch")
CHOKEPOINTS = {"hormuz": "Strait of Hormuz", "bab_el_mandeb": "Bab el-Mandeb Strait", "suez": "Suez Canal",
               "panama": "Panama Canal", "malacca": "Malacca Strait", "bosporus": "Bosporus Strait"}
LICENCE = "IMF PortWatch; Source: International Monetary Fund (reuse with attribution; commercial use needs permission)"


@dataclass(frozen=True)
class Transits:
    chokepoint: str  # key of CHOKEPOINTS
    day: date
    total: int
    tanker: int | None = None


def query_url(name: str, since: date, offset: int = 0) -> str:
    q = {"where": f"portname = '{name}' AND date >= DATE '{since.isoformat()}'",
         "outFields": "date,portname,n_total,n_tanker", "orderByFields": "date ASC",
         "resultOffset": offset, "resultRecordCount": 1000, "f": "json"}
    return URL + "?" + urlencode(q)


def parse(text: str, chokepoint: str) -> list[Transits]:
    data = json.loads(text)
    if "error" in data:
        raise ValueError(f"PortWatch error: {data['error']}")
    out = []
    for f in data.get("features", []):
        a = f["attributes"]
        d = a["date"]
        day = (datetime.fromtimestamp(d / 1000, tz=timezone.utc).date() if isinstance(d, (int, float))
               else date.fromisoformat(str(d)[:10]))
        if a.get("n_total") is not None:
            out.append(Transits(chokepoint, day, int(a["n_total"]), a.get("n_tanker")))
    return out


def _default_fetch(url: str) -> str:
    import httpx

    r = httpx.get(url, timeout=60, headers={"User-Agent": USER_AGENT})
    r.raise_for_status()
    return r.text


def fetch(chokepoint: str, since: date, fetch_text=None, cache: Path = CACHE,
          today: date | None = None) -> list[Transits]:
    """Daily transits since `since`, cached for the day (only responses that parse are cached)."""
    fetch_text = fetch_text or _default_fetch
    today = today or datetime.now(timezone.utc).date()
    cache.mkdir(parents=True, exist_ok=True)
    path = cache / f"{today:%Y%m%d}_{chokepoint}_{since:%Y%m%d}.json"
    if path.exists():
        return [Transits(chokepoint, date.fromisoformat(r["day"]), r["total"], r.get("tanker"))
                for r in json.loads(path.read_text())]
    rows, offset = [], 0
    while True:
        got = parse(fetch_text(query_url(CHOKEPOINTS[chokepoint], since, offset)), chokepoint)
        rows += got
        if len(got) < 1000:
            break
        offset += len(got)
    path.write_text(json.dumps([{"day": r.day.isoformat(), "total": r.total, "tanker": r.tanker} for r in rows]))
    return rows
