"""Open-source observations of the physical world (L1): ship transits through chokepoints, and later
flights, outages and fires (docs/ARCHITECTURE.md roadmap, layer 5)."""
