"""GDELT 2.0 event files, every 15 minutes, as a conflict baseline for the requirements (2026-10-07).

The GDELT search API often refuses this host (429). The raw files do not go through it: every 15 minutes GDELT
publishes the events it machine-coded from the news of that quarter hour (data.gdeltproject.org/gdeltv2/
<YYYYMMDDHHMMSS>.export.CSV.zip, 61 tab-separated columns, CAMEO codes; lastupdate.txt names the newest file and
its MD5). For each topic of config/gdelt.toml this keeps, per file:

  total      all events in the file (news volume changes by the hour and the weekday, so counts are divided by it)
  verbal     events between the topic's country pairs in quad class 3 (verbal conflict)
  material   the same in quad class 4 (material conflict)
  examples   the material-conflict events with the most articles (CAMEO code, actors, source URL, DATEADDED)

in SQLite (gdelt_counts, gdelt_examples), so history accumulates over runs; files already stored are not fetched
again. The comparison: the share of material-conflict events in the last RECENT_HOURS against the same share in
earlier non-overlapping blocks of the same length. A topic is "elevated" only when the recent share is at least
twice the pooled baseline and above every earlier block, with at least MIN_EVENTS recent events and MIN_BLOCKS
blocks of history.

What this is: an observation of what the news reported, coded by a machine (L1 evidence of coverage, graded like
other news until a person judges it). Not a fact about the world; event dates in the files can be old (an
article about last year), so time is DATEADDED, when GDELT first saw the report. GDELT data: free and open for
any use, with citation (gdeltproject.org/about.html#termsofuse).
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import time
import tomllib
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from pmpol import USER_AGENT

BASE = "https://data.gdeltproject.org/gdeltv2/"
LAST = BASE + "lastupdate.txt"
CONFIG = Path("config/gdelt.toml")
LICENCE = "GDELT Project: free and open, cite gdeltproject.org"
RECENT_HOURS = 4
MIN_BLOCKS = 12  # two days of 4-hour blocks before "elevated" can be said
MIN_EVENTS = 10  # events cluster (one article, several events): fewer recent events say nothing
EXAMPLES = 3
QUADS = {"3": "verbal", "4": "material"}
ROOT_ZH = {"14": "抗議", "15": "展示武力", "16": "降低關係", "17": "脅迫", "18": "攻擊", "19": "交戰", "20": "大規模暴力"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS gdelt_files (stamp TEXT PRIMARY KEY, total INTEGER, md5 TEXT, fetched_at TEXT);
CREATE TABLE IF NOT EXISTS gdelt_counts (stamp TEXT, topic TEXT, verbal INTEGER, material INTEGER,
    PRIMARY KEY (stamp, topic));
CREATE TABLE IF NOT EXISTS gdelt_examples (stamp TEXT, topic TEXT, event_id TEXT, code TEXT, actor1 TEXT,
    actor2 TEXT, articles INTEGER, url TEXT, PRIMARY KEY (stamp, topic, event_id));
"""


@dataclass
class Topic:
    id: str
    requirement: str
    label: str
    dyads: list[frozenset]


def load_topics(path: Path = CONFIG) -> list[Topic]:
    raw = tomllib.loads(path.read_text(encoding="utf-8"))
    return [Topic(t["id"], t.get("requirement", ""), t.get("label", t["id"]), [frozenset(d) for d in t["dyads"]])
            for t in raw.get("topic", [])]


def stamps(end: datetime, hours: float) -> list[str]:
    """The 15-minute file stamps covering `hours` up to `end` (UTC), oldest first."""
    end = end.replace(minute=end.minute - end.minute % 15, second=0, microsecond=0)
    n = int(hours * 4)
    return [(end - timedelta(minutes=15 * i)).strftime("%Y%m%d%H%M%S") for i in range(n - 1, -1, -1)]


def _get(url: str) -> bytes:
    import httpx

    r = httpx.get(url, timeout=60, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
    r.raise_for_status()  # a refusal or a rate limit stops here, never retried
    return r.content


def latest(get=None) -> tuple[str, str]:
    """(stamp, md5) of the newest export file, from lastupdate.txt."""
    text = (get or _get)(LAST).decode("utf-8")
    for line in text.splitlines():
        parts = line.split()
        if len(parts) == 3 and parts[2].endswith(".export.CSV.zip"):
            return parts[2].rsplit("/", 1)[-1][:14], parts[1]
    raise ValueError("no export file in lastupdate.txt")


@dataclass
class FileCounts:
    stamp: str
    total: int
    counts: dict[str, dict[str, int]] = field(default_factory=dict)  # topic -> {"verbal", "material"}
    examples: dict[str, list[dict]] = field(default_factory=dict)  # topic -> top material events


def parse(stamp: str, data: bytes, topics: list[Topic]) -> FileCounts:
    """Count one export file (zip) for the topics."""
    z = zipfile.ZipFile(io.BytesIO(data))
    rows = list(csv.reader(io.TextIOWrapper(z.open(z.namelist()[0]), "utf-8", errors="replace"), delimiter="\t"))
    fc = FileCounts(stamp, len(rows), {t.id: {"verbal": 0, "material": 0} for t in topics},
                    {t.id: [] for t in topics})
    for r in rows:
        if len(r) < 61 or r[29] not in QUADS:
            continue
        pair = frozenset((r[7], r[17]))
        for t in topics:
            if pair in t.dyads:
                fc.counts[t.id][QUADS[r[29]]] += 1
                if r[29] == "4":
                    fc.examples[t.id].append({"event_id": r[0], "code": r[26], "actor1": r[6] or r[7],
                                              "actor2": r[16] or r[17], "articles": int(r[33] or 0),
                                              "url": r[60]})
    for t in topics:
        fc.examples[t.id] = sorted(fc.examples[t.id], key=lambda e: -e["articles"])[:EXAMPLES]
    return fc


def save(conn, fc: FileCounts, md5: str = "") -> None:
    conn.executescript(SCHEMA)
    conn.execute("INSERT OR REPLACE INTO gdelt_files VALUES (?,?,?,?)",
                 (fc.stamp, fc.total, md5, datetime.now(timezone.utc).isoformat(timespec="seconds")))
    for tid, c in fc.counts.items():
        conn.execute("INSERT OR REPLACE INTO gdelt_counts VALUES (?,?,?,?)", (fc.stamp, tid, c["verbal"], c["material"]))
    for tid, ex in fc.examples.items():
        for e in ex:
            conn.execute("INSERT OR REPLACE INTO gdelt_examples VALUES (?,?,?,?,?,?,?,?)",
                         (fc.stamp, tid, e["event_id"], e["code"], e["actor1"], e["actor2"], e["articles"], e["url"]))
    conn.commit()


def stored(conn) -> set[str]:
    conn.executescript(SCHEMA)
    return {r[0] for r in conn.execute("SELECT stamp FROM gdelt_files")}


def ingest(conn, topics: list[Topic], hours: float, now: datetime | None = None, get=None,
           pause: float = 0.3) -> dict:
    """Fetch the export files of the last `hours` not yet stored. A file that does not exist (GDELT skips some
    quarter hours) is recorded as missing; any other failure stops the run."""
    import httpx

    get = get or _get
    newest, md5 = latest(get)
    end = datetime.strptime(newest, "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    if now is not None:
        end = min(end, now)
    have = stored(conn)
    todo = [s for s in stamps(end, hours) if s not in have]
    out = {"newest": newest, "fetched": 0, "missing": [], "stored_before": len(have)}
    for s in todo:
        try:
            data = get(f"{BASE}{s}.export.CSV.zip")
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                out["missing"].append(s)
                continue
            raise
        digest = hashlib.md5(data).hexdigest()
        if s == newest and digest != md5:
            raise ValueError(f"{s}: MD5 differs from lastupdate.txt")
        save(conn, parse(s, data, topics), digest)
        out["fetched"] += 1
        time.sleep(pause)
    return out


# --- comparison ---------------------------------------------------------------------------------------------------

@dataclass
class Reading:
    topic: Topic
    recent: tuple[str, str]  # first and last stamp of the recent window
    recent_total: int
    recent_material: int
    recent_verbal: int
    base_total: int
    base_material: int
    blocks: list[float]  # material share (per 1,000 events) of each earlier block
    examples: list[dict]

    @property
    def recent_rate(self) -> float:
        return 1000 * self.recent_material / self.recent_total if self.recent_total else float("nan")

    @property
    def base_rate(self) -> float:
        return 1000 * self.base_material / self.base_total if self.base_total else float("nan")

    @property
    def ratio(self) -> float | None:
        return self.recent_rate / self.base_rate if self.base_material and self.recent_total else None

    @property
    def rank(self) -> int:
        """How many earlier blocks had a higher share than the recent window."""
        return sum(b > self.recent_rate for b in self.blocks)

    @property
    def elevated(self) -> bool | None:
        if len(self.blocks) < MIN_BLOCKS or self.ratio is None:
            return None
        return self.ratio >= 2 and self.rank == 0 and self.recent_material >= MIN_EVENTS


def reading(conn, topic: Topic, hours: float = RECENT_HOURS, lookback_days: int = 14) -> Reading | None:
    conn.executescript(SCHEMA)
    rows = conn.execute("SELECT f.stamp, f.total, c.verbal, c.material FROM gdelt_files f JOIN gdelt_counts c "
                        "ON f.stamp = c.stamp AND c.topic = ? ORDER BY f.stamp", (topic.id,)).fetchall()
    if not rows:
        return None
    end = datetime.strptime(rows[-1][0], "%Y%m%d%H%M%S")
    start = (end - timedelta(days=lookback_days)).strftime("%Y%m%d%H%M%S")
    rows = [r for r in rows if r[0] >= start]
    per = int(hours * 4)  # files per block
    cut = (end - timedelta(minutes=15 * (per - 1))).strftime("%Y%m%d%H%M%S")
    recent = [r for r in rows if r[0] >= cut]
    base = [r for r in rows if r[0] < cut]
    blocks = []
    b_end = datetime.strptime(cut, "%Y%m%d%H%M%S")
    while True:
        b_start = b_end - timedelta(hours=hours)
        sel = [r for r in base if b_start.strftime("%Y%m%d%H%M%S") <= r[0] < b_end.strftime("%Y%m%d%H%M%S")]
        if len(sel) < per * 0.75:  # a block with many missing files is not comparable
            break
        tot = sum(r[1] for r in sel)
        blocks.append(1000 * sum(r[3] for r in sel) / tot if tot else 0.0)
        b_end = b_start
    ex = [dict(zip(("stamp", "event_id", "code", "actor1", "actor2", "articles", "url"), r)) for r in conn.execute(
        "SELECT stamp, event_id, code, actor1, actor2, articles, url FROM gdelt_examples WHERE topic = ? AND stamp >= ? "
        "ORDER BY articles DESC, stamp DESC LIMIT ?", (topic.id, cut, EXAMPLES))]
    return Reading(topic, (recent[0][0], recent[-1][0]), sum(r[1] for r in recent), sum(r[3] for r in recent),
                   sum(r[2] for r in recent), sum(r[1] for r in base), sum(r[3] for r in base), blocks, ex)


def _ts(stamp: str) -> str:
    return f"{stamp[:4]}-{stamp[4:6]}-{stamp[6:8]}T{stamp[8:10]}:{stamp[10:12]}Z"


def proof(r: Reading):
    from pmpol.proof import Proof

    state = {None: "歷史還不夠（少於 2 天），只列數字", True: "升高", False: "沒有升高"}[r.elevated]
    ratio = "—" if r.ratio is None else f"{r.ratio:.2f} 倍"
    p = Proof(f"事件資料｜{r.topic.label}",
              f"最近 {RECENT_HOURS} 小時，{r.topic.label}的實質衝突事件占全部事件的 {r.recent_rate:.2f}‰"
              f"（{r.recent_material} / {r.recent_total:,}），過去平均 {r.base_rate:.2f}‰，{ratio}：{state}",
              result={"topic": r.topic.id, "requirement": r.topic.requirement, "recent_per_mille": round(r.recent_rate, 3),
                      "base_per_mille": round(r.base_rate, 3), "ratio": None if r.ratio is None else round(r.ratio, 3),
                      "blocks": len(r.blocks), "higher_blocks": r.rank, "elevated": r.elevated})
    p.add("L1", f"GDELT 事件檔 {_ts(r.recent[0])} 到 {_ts(r.recent[1])}：全部 {r.recent_total:,} 件，"
                f"{'、'.join('—'.join(sorted(d)) for d in r.topic.dyads)} 之間的口頭衝突 {r.recent_verbal}、實質衝突 "
                f"{r.recent_material}", BASE + "lastupdate.txt", _ts(r.recent[1]), kind="data", id="recent")
    p.add("L1", f"之前 {len(r.blocks)} 個 {RECENT_HOURS} 小時區塊：實質衝突合計 {r.base_material} / {r.base_total:,}"
                f"（{r.base_rate:.2f}‰）；比最近更高的區塊 {r.rank} 個", BASE, kind="data", id="base")
    for i, e in enumerate(r.examples):
        p.add("L1", f"{ROOT_ZH.get(e['code'][:2], e['code'])}（CAMEO {e['code']}）：{e['actor1']} → {e['actor2']}，"
                    f"{e['articles']} 篇報導", e["url"], _ts(e["stamp"]), kind="data", id=f"ex{i}")
    p.add("L5", f"比例 {ratio}；「升高」要至少 2 倍、高於之前每一個區塊（至少 {MIN_BLOCKS} 個），而且最近至少 "
                f"{MIN_EVENTS} 件", kind="logic",
          id="compare", inputs=("recent", "base"))
    p.caveats += ["事件是機器從新聞標題和內文編碼的：一篇文章可能產生好幾個事件，行為者是猜的，報導的事件也可能是舊的；"
                  "這是「新聞報導了什麼」的觀測，不是事實。",
                  "比例會受到其他新聞多寡影響（分母是同一批檔案的全部事件）；方向（誰對誰）和真假要人工看例子。"]
    return p


def export(readings: list[Reading], path: Path = Path("data/gdelt.json")) -> int:
    out = []
    for r in readings:
        p = proof(r)
        out.append({"id": f"gdelt:{r.topic.id}", "group": "evidence", "kind": "event_data",
                    "subject": f"news:{r.topic.requirement}", "edge": round(r.ratio or 0.0, 4), "venues": [],
                    "confidence": "rule", "title": p.title, "proof": {**p.to_dict(), "graph": p.graph()}})
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"signals": out}, ensure_ascii=False, default=str), encoding="utf-8")
    return len(out)


def render(readings: list[Reading], run: dict) -> str:
    L = ["# GDELT 事件檔：衝突事件的比例", "",
         f"每 15 分鐘的事件檔（最新 {_ts(run.get('newest', '')) if run.get('newest') else '—'}；這次抓了 "
         f"{run.get('fetched', 0)} 個檔、缺 {len(run.get('missing', []))} 個）。實質衝突（CAMEO 14–20）事件占同一批檔案"
         f"全部事件的千分比；最近 {RECENT_HOURS} 小時和之前的區塊比。機器編碼、雜訊大，只當新聞覆蓋的觀測。", "",
         "| 主題 | 最近（‰） | 之前（‰） | 比例 | 之前的區塊 | 更高的區塊 | 判斷 |", "|---|---|---|---|---|---|---|"]
    for r in readings:
        state = {None: "歷史不足", True: "升高", False: "—"}[r.elevated]
        L.append(f"| {r.topic.label} | {r.recent_rate:.2f}（{r.recent_material}） | {r.base_rate:.2f} | "
                 f"{'—' if r.ratio is None else f'{r.ratio:.2f}'} | {len(r.blocks)} | {r.rank} | {state} |")
    for r in readings:
        if r.examples:
            L += ["", f"**{r.topic.label}：最近報導最多的實質衝突事件**", ""]
            L += [f"- {ROOT_ZH.get(e['code'][:2], e['code'])}（{e['code']}）{e['actor1']} → {e['actor2']}，{e['articles']} 篇："
                  f"{e['url']}" for e in r.examples]
    return "\n".join(L + [""])
