"""Internet connectivity from IODA, as a proxy beside blackout markets (2026-10-06).

Polymarket's "Total Internet Blackout in Iran" settles on Cloudflare Radar (total bytes at or below 1% of the
last four weeks' maximum for six consecutive hours), which needs an API token we do not have. IODA (Georgia Tech's
Internet Outage Detection and Analysis, public API, no key) measures the same country from other angles: BGP
(routed prefixes), active probing (responsive /24 blocks), a network telescope (unsolicited traffic) and Google
traffic. None of them is the settlement source, so the result is a proxy (L1 evidence of connectivity), shown next
to the market and never used to decide it.

For each signal: the latest value as a share of its 28-day maximum, and the lowest level held for six hours (the
highest value inside the quietest six-hour window, over the maximum). The market's threshold is 1%; a proxy far
above it says the country is connected by that measure, not that the market is mispriced.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path

from pmpol import USER_AGENT

API = "https://api.ioda.inetintel.cc.gatech.edu/v2/signals/raw/country/{cc}?from={start}&until={end}"
CACHE = Path("data/osint/ioda")
SIGNALS = {"gtr": "Google 流量", "bgp": "BGP 路由前綴", "ping-slash24": "主動探測（回應的 /24 網段）",
           "merit-nt": "網路望遠鏡"}
DAYS = 28
WINDOW_HOURS = 6
LICENCE = "IODA (Georgia Tech Internet Intelligence Lab), public API; cited"


def fetch(cc: str, today: date | None = None, get=None, cache: Path = CACHE) -> dict:
    """The raw signals of a country for the last DAYS days (cached per day)."""
    today = today or datetime.now(timezone.utc).date()
    path = cache / f"{today:%Y%m%d}_{cc}.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    end = int(time.time()) if get is None else int(datetime(today.year, today.month, today.day, tzinfo=timezone.utc).timestamp())
    url = API.format(cc=cc.upper(), start=end - DAYS * 86400, end=end)
    if get is None:
        import httpx

        r = httpx.get(url, timeout=90, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
        r.raise_for_status()  # a refusal or a rate limit stops here, never retried
        text = r.text
    else:
        text = get(url)
    d = json.loads(text)
    cache.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(d), encoding="utf-8")
    return d


@dataclass
class Level:
    signal: str
    latest: float  # share of the 28-day maximum
    floor6h: float  # lowest level held for six hours
    at: str  # time of the latest value (UTC)


def levels(raw: dict) -> list[Level]:
    out = []
    groups = raw.get("data") or []
    for s in (groups[0] if groups and isinstance(groups[0], list) else groups):
        name = s.get("datasource")
        if name not in SIGNALS:
            continue
        vals = s.get("values") or []
        step = int(s.get("step") or 0)
        pts = [(i, v) for i, v in enumerate(vals) if isinstance(v, (int, float))]
        if not pts or step <= 0:
            continue
        top = max(v for _, v in pts)
        if top <= 0:
            continue
        n = max(1, WINDOW_HOURS * 3600 // step)
        windows = [max(v for v in vals[i:i + n] if isinstance(v, (int, float)))
                   for i in range(0, len(vals) - n + 1) if any(isinstance(v, (int, float)) for v in vals[i:i + n])]
        i_last, last = pts[-1]
        at = datetime.fromtimestamp(int(s["from"]) + i_last * step, timezone.utc).strftime("%Y-%m-%d %H:%M")
        out.append(Level(name, last / top, (min(windows) / top) if windows else last / top, at))
    return out


def proof(market, event_title: str, cc: str, lv: list[Level], observed_at: str, threshold: float = 0.01):
    from pmpol.proof import Proof
    from pmpol.venues import info, source_url

    lowest = min(lv, key=lambda x: x.floor6h) if lv else None
    head = ("IODA 沒有資料" if lowest is None else
            f"旁證（不是結算來源）：過去 {DAYS} 天最低的連續 {WINDOW_HOURS} 小時水準，{SIGNALS[lowest.signal]} "
            f"{100 * lowest.floor6h:.0f}%（門檻 {100 * threshold:.0f}%）")
    p = Proof(f"斷網旁證｜{event_title}｜{market.outcome}", head,
              result={"country": cc, "levels": [x.__dict__ for x in lv], "threshold": threshold, "proxy": True})
    p.add("L0", f"結算規則（平台規則原文）：{(market.rules or '')[:240]}", source_url(market), kind="rule", id="rule")
    for i, x in enumerate(lv):
        p.add("L1", f"IODA {SIGNALS[x.signal]}：最新 {100 * x.latest:.0f}%、最低連續 {WINDOW_HOURS} 小時 {100 * x.floor6h:.0f}%"
                    f"（相對過去 {DAYS} 天最高點）", f"https://ioda.inetintel.cc.gatech.edu/country/{cc.upper()}", x.at,
              kind="data", id=f"s{i}")
    if market.bid is not None and market.ask is not None:
        p.add("L4", f"{info(market.venue).code} 中間價 {50 * (market.bid + market.ask):.1f}%", source_url(market),
              observed_at, kind="data", id="quote")
    p.caveats += ["結算來源是 Cloudflare Radar 的總流量（需要權杖，系統讀不到）；IODA 量的是路由、探測和 Google 流量，和結算的定義不同，"
                  "只能當旁證，不能判定市場。",
                  "IODA 的最近幾個資料點常是空值（還沒處理完），「最新」取最後一個有值的點。"]
    p.alt("斷網只在結算來源看得到（例如只擋國際流量、路由還在）", "unchecked", "IODA 的 BGP 和探測在國際斷線時可能仍正常")
    return p
