"""Proofs as W3C PROV (PROV-JSON, https://www.w3.org/submissions/prov-json/), 2026-10-06.

The proof objects (pmpol.proof) already have the PROV shape: steps derived from other steps (`inputs`), each step
from a source (`ref`: a knowledge-base fact, a data series, a file or a URL), and a conclusion derived from the steps
nobody else uses. This writes them in the standard vocabulary so that tools outside this repository can follow a
conclusion back to its sources:

  entity      pmpol:proof/<n>            the conclusion (prov:label = title; pmpol:conclusion, layer, confidence)
              pmpol:step/<n>/<step>      one step (pmpol:layer L0-L5, pmpol:kind, pmpol:asOf)
              kb:<fact id>               a knowledge-base fact; src:<hash> any other source (prov:location)
  activity    pmpol:inference/<n>        the run that produced the proof (prov:endTime = observation time)
  agent       pmpol:system               the software (prov:SoftwareAgent; the git commit when known)
  relations   wasDerivedFrom (step <- input step, step <- source, proof <- steps feeding it),
              wasGeneratedBy (proof <- inference), used (inference -> steps), wasAssociatedWith, wasAttributedTo

Market observations (L4) keep their observation time. Nothing here adds to or interprets a proof: it is the same
graph in another vocabulary, and `check` confirms every relation points at a declared node and every proof still
reaches an L0-L4 step.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

NS = {"prov": "http://www.w3.org/ns/prov#", "xsd": "http://www.w3.org/2001/XMLSchema#",
      "pmpol": "https://github.com/bellafc/polymarket_politics/ns#",
      "kb": "https://github.com/bellafc/polymarket_politics/blob/claude/gallant-ritchie-j6n5c8/kb#",
      "src": "https://github.com/bellafc/polymarket_politics/ns/source#"}
GROUNDING = ("L0", "L1", "L2", "L3", "L4")


def _source_id(ref: str, facts: set[str]) -> tuple[str, dict]:
    if ref in facts:
        return f"kb:{ref}", {"prov:type": "pmpol:Fact", "prov:label": ref}
    h = hashlib.sha1(ref.encode()).hexdigest()[:12]
    kind = "pmpol:WebSource" if ref.startswith("http") else "pmpol:LocalSource"
    return f"src:{h}", {"prov:type": kind, "prov:location": ref}


def document(rows: list[dict], facts: set[str] = frozenset(), commit: str = "") -> dict:
    """rows: published proofs as in data/proofs.json ({"id", "title", "proof": Proof.to_dict()}) or bare
    Proof.to_dict() rows (data/macro/regimes.json)."""
    doc: dict = {"prefix": NS, "entity": {}, "activity": {}, "agent": {}, "wasDerivedFrom": {}, "wasGeneratedBy": {},
                 "used": {}, "wasAssociatedWith": {}, "wasAttributedTo": {}}
    agent = "pmpol:system"
    doc["agent"][agent] = {"prov:type": "prov:SoftwareAgent", "prov:label": "pmpol",
                           **({"pmpol:commit": commit} if commit else {})}
    n_rel = 0

    def rel(kind: str, body: dict) -> None:
        nonlocal n_rel
        n_rel += 1
        doc[kind][f"_:r{n_rel}"] = body

    for n, row in enumerate(rows):
        p = row.get("proof", row)
        pid, act = f"pmpol:proof/{n}", f"pmpol:inference/{n}"
        observed = (p.get("meta") or {}).get("generated_at") or row.get("observed_at") or ""
        doc["entity"][pid] = {"prov:type": "pmpol:Proof", "prov:label": p.get("title", ""),
                              "pmpol:conclusion": p.get("conclusion", ""), "pmpol:layer": p.get("layer", "L5"),
                              "pmpol:analyticConfidence": p.get("analytic_confidence", ""),
                              "pmpol:grounded": bool(p.get("grounded")),
                              **({"pmpol:signal": row["id"]} if "id" in row else {})}
        doc["activity"][act] = {"prov:type": "pmpol:Inference", **({"prov:endTime": observed} if observed else {})}
        rel("wasGeneratedBy", {"prov:entity": pid, "prov:activity": act})
        rel("wasAssociatedWith", {"prov:activity": act, "prov:agent": agent})
        rel("wasAttributedTo", {"prov:entity": pid, "prov:agent": agent})
        steps = p.get("steps", [])
        ids = {}
        for i, s in enumerate(steps):
            sid = f"pmpol:step/{n}/{s.get('id') or f's{i}'}"
            ids[s.get("id") or f"s{i}"] = sid
            doc["entity"][sid] = {"prov:type": "pmpol:Step", "prov:label": s.get("text", ""),
                                  "pmpol:layer": s.get("layer", ""), "pmpol:kind": s.get("kind", ""),
                                  **({"pmpol:asOf": s["as_of"]} if s.get("as_of") else {})}
            if s.get("ref"):
                src, attrs = _source_id(s["ref"], facts)
                doc["entity"].setdefault(src, attrs)
                rel("wasDerivedFrom", {"prov:generatedEntity": sid, "prov:usedEntity": src})
        used = set()
        for i, s in enumerate(steps):
            sid = ids[s.get("id") or f"s{i}"]
            for inp in s.get("inputs", ()):
                if inp in ids:
                    used.add(inp)
                    rel("wasDerivedFrom", {"prov:generatedEntity": sid, "prov:usedEntity": ids[inp]})
        for key, sid in ids.items():
            if key not in used:  # steps nobody else uses feed the conclusion (as in Proof.graph)
                rel("wasDerivedFrom", {"prov:generatedEntity": pid, "prov:usedEntity": sid})
                rel("used", {"prov:activity": act, "prov:entity": sid})
    return {k: v for k, v in doc.items() if v}


def check(doc: dict) -> list[str]:
    """Relations pointing at undeclared nodes, and proofs that no longer reach an L0-L4 step."""
    nodes = set(doc.get("entity", {})) | set(doc.get("activity", {})) | set(doc.get("agent", {}))
    problems = []
    parents: dict[str, list[str]] = {}
    for kind in ("wasDerivedFrom", "wasGeneratedBy", "used", "wasAssociatedWith", "wasAttributedTo"):
        for rid, body in doc.get(kind, {}).items():
            for end in body.values():
                if end not in nodes:
                    problems.append(f"{kind} {rid}: unknown node {end}")
            if kind == "wasDerivedFrom":
                parents.setdefault(body["prov:generatedEntity"], []).append(body["prov:usedEntity"])
    for eid, e in doc.get("entity", {}).items():
        if e.get("prov:type") != "pmpol:Proof" or not e.get("pmpol:grounded"):
            continue
        seen, stack = set(), [eid]
        while stack:
            for q in parents.get(stack.pop(), []):
                if q not in seen:
                    seen.add(q)
                    stack.append(q)
        if not any(doc["entity"].get(q, {}).get("pmpol:layer") in GROUNDING for q in seen):
            problems.append(f"{eid}: marked grounded but reaches no L0-L4 step")
    return problems


def load_rows(paths: list[Path]) -> list[dict]:
    rows = []
    for path in paths:
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        items = raw.get("signals", []) if isinstance(raw, dict) else raw
        observed = raw.get("observed_at", "") if isinstance(raw, dict) else ""
        for r in items:
            if isinstance(r, dict) and ("proof" in r or "steps" in r):
                rows.append({**r, "observed_at": observed} if observed and "proof" in r else r)
    return rows
