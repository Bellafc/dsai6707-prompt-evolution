"""Presidential elections: the incumbent party's record and the economy (2026-10-07).

The midterm reference class (pmpol.reference) and its fundamentals (pmpol.fundamentals) cover the House and the
Senate. This adds the presidency, for markets on which party wins the White House:

  L1 popular vote   the Democratic and Republican candidates' national popular vote in every election since 1952,
                    each candidate's total over all the ballot lines that carried them:
                      1952-2008  Census Bureau, Statistical Abstract of the United States 2012, Table 402 ("Vote
                                 Cast for President by Major Political Party"; thousands; from the Clerk of the House)
                      2012-2020  FEC, "Federal Elections 20xx", presidential popular vote summary
                      2024       FEC, "Official 2024 Presidential General Election Results"
                    (U.S. government works, public domain). The Clerk's own statistics before 2000 are scanned
                    images without text, and from 2000 split a candidate's votes by ballot line, so they are not used.
  L2 record         for every election: the president's party on election day (the incumbent party), whether the
                    president was on the ballot, how many terms the party had held the White House (one, or two and
                    more), its share of the two-party vote, and whether it kept the White House (the party of the
                    president in office on the next 21 January; presidents' terms and parties are the L1 records of
                    pmpol.reference)
  L2 fundamentals   incumbent two-party share = a + b * x, with x the same income measure as the midterm model
                    (A229RX0, January-August of the election year over the same months a year earlier), fixed before
                    fitting; 1960-2024, the years the series covers

The outside view of a "which party wins" market sets it next to the share of elections the incumbent party won,
with the two pre-stated subclasses (the party's first term in the White House or not; the president on the ballot
or an open seat) side by side, not chosen between. The record counts the Electoral College, which the markets
settle on; the vote share is popular vote, and the two differed in 2000 and 2016. L2 history and L5 inferences,
never facts.
"""

from __future__ import annotations

import math
import re
import statistics
import time
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

from pmpol import USER_AGENT
from pmpol.reference import PARTY_FACT, SLUG, TERMS_FACT, election_day, president_on, wilson

DATA = Path("data/reference/president")
CENSUS_URL = "https://www2.census.gov/library/publications/2011/compendia/statab/131ed/tables/election.pdf"
FEC_URL = {2012: "https://www.fec.gov/resources/cms-content/documents/federalelections2012.pdf",
           2016: "https://www.fec.gov/resources/cms-content/documents/federalelections2016.pdf",
           2020: "https://www.fec.gov/resources/cms-content/documents/federalelections2020.pdf",
           2024: "https://www.fec.gov/documents/5644/2024presgeresults.pdf"}
CENSUS_FACT = "us.president.popular_vote.census"
FEC_FACT = "us.president.popular_vote.fec"  # + year
RECORD_FACT = "us.president.incumbent_party_record"
MODEL_FACT = "us.president.fundamentals_model"
TERM_LIMIT_FACT = "us.president.term_limit"
LICENCE = "public domain (U.S. government work)"
OTHER = {"D": "R", "R": "D"}


def pdf_layout(data: bytes) -> str:
    """Text of a PDF with its column layout kept (pdftotext -layout, run as a separate program)."""
    import shutil
    import subprocess

    exe = shutil.which("pdftotext")
    if exe is None:
        raise ValueError("pdftotext is not installed")
    out = subprocess.run([exe, "-q", "-layout", "-", "-"], input=data, capture_output=True, timeout=120)
    if out.returncode != 0:
        raise ValueError(f"pdftotext failed ({out.returncode})")
    return out.stdout.decode("utf-8", "replace")


def fetch(url: str, cache: Path = DATA, pause: float = 2.0, get=None) -> str:
    """The layout text of a PDF, downloaded once (the PDF is cached; a refusal stops here, never retried)."""
    path = cache / url.rsplit("/", 1)[-1]
    if not path.exists():
        if get is None:
            import httpx

            def get(u: str) -> bytes:
                r = httpx.get(u, timeout=180, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
                r.raise_for_status()
                return r.content
        data = get(url)
        if not data.startswith(b"%PDF"):
            raise ValueError(f"{url}: not a PDF")
        cache.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        time.sleep(pause)
    return pdf_layout(path.read_bytes())


def _int(text: str) -> int:
    return int(text.replace(",", ""))


_STATAB_ROW = re.compile(r"^(\d{4})[ .]+([A-Za-z][A-Za-z' ]*?)[ .]+([A-Za-z][A-Za-z' ]*?)[ .]+([\d,]+)\s+([\d,]+)\s+"
                         r"([\d.]+)\s+(\d+)\s+([\d,]+)\s+([\d.]+)\s+(\d+)\s*$")


def parse_census(text: str) -> dict[int, dict]:
    """Statistical Abstract Table 402: year -> {D, R (votes), D_candidate, R_candidate, D_ev, R_ev, total}."""
    start = text.find("Vote Cast for President by Major Political Party")
    if start < 0:
        raise ValueError("Table 402 not found")
    out = {}
    for line in text[start:].splitlines():
        m = _STATAB_ROW.match(line.strip())
        if m:
            y = int(m.group(1))
            out[y] = {"D": _int(m.group(5)) * 1000, "R": _int(m.group(8)) * 1000,
                      "D_candidate": m.group(2).strip(), "R_candidate": m.group(3).strip(),
                      "D_ev": int(m.group(7)), "R_ev": int(m.group(10)), "total": _int(m.group(4)) * 1000}
        elif out and line.strip().startswith("Table "):
            break
    return out


_FEC_ROW = re.compile(r"^\s*(.+?)\s+\(([^)]*)\)\s+([\d,]+)\s+[\d.]+%\s*$")


def parse_fec_summary(text: str) -> dict:
    """The 'presidential popular vote summary' of a Federal Elections volume: the candidates whose ballot lines
    start with Democrat and Republican."""
    i = text.find("PRESIDENTIAL POPULAR VOTE SUMMARY")
    if i < 0:
        raise ValueError("popular vote summary not found")
    out = {}
    for line in text[i:].splitlines()[1:60]:
        m = _FEC_ROW.match(line)
        if not m:
            continue
        party = {"democrat": "D", "republican": "R"}.get(m.group(2).split(",")[0].strip().lower())
        if party and party not in out:
            out[party] = _int(m.group(3))
            out[f"{party}_candidate"] = m.group(1).strip()
    if "D" not in out or "R" not in out:
        raise ValueError("Democratic or Republican candidate missing")
    return out


def parse_fec_results(text: str) -> dict:
    """The FEC's official results table (2024 layout): candidates are columns, headed by surname, totals in a
    'Total:' row; party from the electoral-vote header ('DONALD J. TRUMP (R)')."""
    named = re.findall(r"([A-Z][A-Z.]*(?: [A-Z][A-Z.]*)*) \((D|R)\)", text[:3000])
    party = {}
    for name, p in named:
        party.setdefault(p, name.strip())
    if set(party) != {"D", "R"}:
        raise ValueError("electoral-vote header without both parties")
    surname = {p: n.split()[-1] for p, n in party.items()}
    head: list[str] | None = None
    out = {f"{p}_candidate": n.title() for p, n in party.items()}
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("STATE"):
            head = re.split(r"\s{2,}", s)[1:]
        elif s.startswith("Total:") and head:
            nums = re.findall(r"[\d,]+", s[len("Total:"):])
            if len(nums) == len(head):
                for h, n in zip(head, nums):
                    for p, sn in surname.items():
                        if h == sn:
                            out[p] = _int(n)
            head = None
    if "D" not in out or "R" not in out:
        raise ValueError("candidate totals not found")
    return out


@dataclass
class Votes:
    census: dict[int, dict] = field(default_factory=dict)
    fec: dict[int, dict] = field(default_factory=dict)

    def all(self) -> dict[int, dict]:
        return {**self.census, **self.fec}


def collect(cache: Path = DATA, get=None, pause: float = 2.0) -> Votes:
    v = Votes(census=parse_census(fetch(CENSUS_URL, cache, pause, get)))
    for y, url in FEC_URL.items():
        text = fetch(url, cache, pause, get)
        v.fec[y] = parse_fec_results(text) if "OFFICIAL" in text[:500] else parse_fec_summary(text)
    return v


def parties(kb) -> dict[str, str]:
    """President's name (as history.house.gov writes it) -> party, from the knowledge base's L1 records."""
    return {name: kb.facts[PARTY_FACT + slug].value for name, slug in SLUG.items() if PARTY_FACT + slug in kb.facts}


def _surname(candidate: str) -> str:
    return re.sub(r"\s+(jr|sr|ii|iii)\.?$", "", candidate.strip().lower()).split()[-1]


def record(votes: dict[int, dict], terms: list[dict], party_of: dict[str, str]) -> list[dict]:
    """One row per election: the incumbent party, on the ballot or not, terms held, two-party share, kept or not."""
    out = []
    for y in sorted(votes):
        who = president_on(terms, election_day(y))
        party = party_of.get(who or "")
        nxt = party_of.get(president_on(terms, date(y + 1, 1, 21)) or "")
        if party is None or nxt is None:
            continue
        v = votes[y]
        before = party_of.get(president_on(terms, date(y - 7, 1, 21)) or "")
        out.append({"year": y, "president": who, "party": party,
                    "running": _surname(v[f"{party}_candidate"]) in (who or "").lower(),
                    "terms_held": None if before is None else (1 if before != party else 2),
                    "share": round(100 * v[party] / (v[party] + v[OTHER[party]]), 2),
                    "kept": nxt == party})
    return out


def _rate(rows: list[dict]) -> dict:
    k, n = sum(r["kept"] for r in rows), len(rows)
    lo, hi = wilson(k, n)
    return {"kept": k, "n": n, "share": round(k / n, 3) if n else None, "wilson95": [round(lo, 3), round(hi, 3)]}


def base_rates(rows: list[dict]) -> dict:
    return {"all": _rate(rows),
            "first_term": _rate([r for r in rows if r["terms_held"] == 1]),
            "two_terms_or_more": _rate([r for r in rows if r["terms_held"] == 2]),
            "president_running": _rate([r for r in rows if r["running"]]),
            "open_seat": _rate([r for r in rows if not r["running"]])}


@dataclass
class Model:
    years: list[int]
    x: list[float]
    y: list[float]
    a: float
    b: float
    se_b: float
    sigma: float
    r2: float

    @property
    def n(self) -> int:
        return len(self.x)

    def predict(self, x0: float) -> tuple[float, float]:
        mx = statistics.mean(self.x)
        sxx = sum((xi - mx) ** 2 for xi in self.x)
        return self.a + self.b * x0, self.sigma * math.sqrt(1 + 1 / self.n + (x0 - mx) ** 2 / sxx)

    def p_above_half(self, x0: float) -> float:
        """P(incumbent two-party share > 50%) under the t predictive distribution."""
        from scipy.stats import t

        m, se = self.predict(x0)
        return float(1 - t.cdf((50 - m) / se, self.n - 2))


def fit(rows: list[dict], monthly: dict[str, float]) -> Model:
    from pmpol.fundamentals import income_growth

    pts = [(r["year"], g, r["share"]) for r in rows if (g := income_growth(monthly, r["year"])) is not None]
    years, x, y = [p[0] for p in pts], [p[1] for p in pts], [p[2] for p in pts]
    mx, my = statistics.mean(x), statistics.mean(y)
    sxx = sum((xi - mx) ** 2 for xi in x)
    b = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y)) / sxx
    a = my - b * mx
    resid = [yi - (a + b * xi) for xi, yi in zip(x, y)]
    sigma = math.sqrt(sum(e * e for e in resid) / (len(x) - 2))
    sst = sum((yi - my) ** 2 for yi in y)
    return Model(years, x, y, a, b, sigma / math.sqrt(sxx), sigma, 1 - sum(e * e for e in resid) / sst)


SCENARIOS = (-2.0, 0.0, 2.0, 4.0)  # income growth (%) for the conditional table


# --- the outside view of a "which party wins the White House" market -------------------------------------------

@dataclass
class PresidentialView:
    year: int
    party: str  # the incumbent party
    president: str
    eligible: bool  # the sitting president may be elected again (two elections at most)
    first_term: bool | None  # the party has held the White House for one term
    rates: dict
    rows: list[dict]
    facts: list[str]
    model: dict | None = None

    @property
    def share(self) -> float:
        return self.rates["all"]["share"]


def elected_times(terms: list[dict], who: str, before: date) -> int:
    """How many terms `who` began on an inauguration day (20 January) before `before`: elections won."""
    return sum(t["president"] == who and t["start"][5:] == "01-20" and date.fromisoformat(t["start"]) < before
               for t in terms)


def outside_view(kb, year: int) -> PresidentialView | None:
    if year % 4 or kb is None or RECORD_FACT not in kb.facts or TERMS_FACT not in kb.facts:
        return None
    terms = kb.facts[TERMS_FACT].value
    who = president_on(terms, election_day(year))
    slug = SLUG.get(who or "")
    pf = kb.facts.get(PARTY_FACT + slug) if slug else None
    if pf is None:
        return None
    party_of = parties(kb)
    before = party_of.get(president_on(terms, date(year - 7, 1, 21)) or "")
    rows = [r for r in kb.facts[RECORD_FACT].value["rows"] if r["year"] < year]
    model = kb.facts[MODEL_FACT].value if MODEL_FACT in kb.facts else None
    facts = [TERMS_FACT, pf.id, RECORD_FACT] + ([TERM_LIMIT_FACT] if TERM_LIMIT_FACT in kb.facts else [])
    return PresidentialView(year, pf.value, who, elected_times(terms, who, election_day(year)) < 2,
                            None if before is None else before != pf.value, base_rates(rows), rows, facts, model)


# --- knowledge-base YAML ------------------------------------------------------------------------------------------

def _yaml(header: str, facts: list[dict]) -> str:
    from pmpol.reference import _yaml as dump

    return header + dump({"facts": facts})


def kb_l1(v: Votes, recorded: date) -> list[dict]:
    out = [{"id": CENSUS_FACT, "layer": "L1", "subject": "U.S. presidential elections 1952-2008",
            "predicate": "major_party_popular_vote",
            "value": {y: v.census[y] for y in sorted(v.census)},
            "source": {"title": "U.S. Census Bureau, Statistical Abstract of the United States: 2012, Table 402",
                       "url": CENSUS_URL, "quote": "Vote Cast for President by Major Political Party: 1952 to 2008",
                       "license": LICENCE},
            "admiralty": "A1", "status": "proposed", "recorded_at": recorded,
            "note": "Votes in the table are thousands (multiplied out here); they include the votes of minor parties "
                    "cast for the major-party candidates. Source of the table: Clerk of the House."}]
    for y in sorted(v.fec):
        quote = ("OFFICIAL 2024 PRESIDENTIAL GENERAL ELECTION RESULTS" if y == 2024
                 else f"{y} PRESIDENTIAL POPULAR VOTE SUMMARY")
        out.append({"id": f"{FEC_FACT}{y}", "layer": "L1", "subject": f"U.S. presidential election {y}",
                    "predicate": "major_party_popular_vote", "value": {y: v.fec[y]},
                    "source": {"title": f"Federal Election Commission, {'official results' if y == 2024 else 'Federal Elections'} {y}",
                               "url": FEC_URL[y], "quote": quote, "license": LICENCE},
                    "admiralty": "A1", "status": "proposed", "recorded_at": recorded,
                    "note": "Each candidate's total over every ballot line that carried them."})
    return out


def kb_l2(rows: list[dict], model: Model | None, recorded: date, l1: list[str], last_month: str = "") -> list[dict]:
    facts = [{"id": RECORD_FACT, "layer": "L2", "subject": "U.S. presidential elections",
              "predicate": "incumbent_party_record",
              "value": {"sample": f"{rows[0]['year']}-{rows[-1]['year']}, {len(rows)} elections",
                        "base_rates": base_rates(rows), "rows": rows},
              "source": {"title": "Computed from the popular-vote records and presidents' terms and parties",
                         "url": "https://history.house.gov/Institution/Presidents-Coinciding/Presidents-Coinciding/",
                         "license": LICENCE},
              "admiralty": "B1", "status": "proposed", "recorded_at": recorded,
              "derived_from": [*l1, TERMS_FACT, *[PARTY_FACT + s for s in sorted(set(SLUG.values()))]],
              "note": "kept = the party of the president in office on the next 21 January (Electoral College); share "
                      "= incumbent party's share of the two-party popular vote; terms_held 1 or 2 (two or more), "
                      "null where the party four years earlier is not in the records. Generated by "
                      "`pmpol presidential --write-kb`."}]
    if model is not None:
        facts.append({
            "id": MODEL_FACT, "layer": "L2", "subject": "U.S. presidential elections",
            "predicate": "incumbent_share_given_income_growth",
            "value": {"model": "incumbent two-party share = a + b * income growth (fixed before fitting)",
                      "sample": f"{model.years[0]}-{model.years[-1]}, {model.n} elections", "a": round(model.a, 2),
                      "b": round(model.b, 2), "b_se": round(model.se_b, 2), "b_t": round(model.b / model.se_b, 2),
                      "residual_sd": round(model.sigma, 2), "r2": round(model.r2, 3),
                      "scenarios": {x: {"share": round(model.predict(x)[0], 1), "p_above_50": round(model.p_above_half(x), 3)}
                                    for x in SCENARIOS},
                      "points": [{"year": yr, "income_growth": round(xi, 2), "share": yi}
                                 for yr, xi, yi in zip(model.years, model.x, model.y)]},
            "source": {"title": "BEA real disposable personal income per capita (FRED A229RX0), with the incumbent "
                                "party record", "url": "https://fred.stlouisfed.org/series/A229RX0",
                       "license": "public domain (U.S. government data via FRED)"},
            "admiralty": "B2", "status": "proposed", "recorded_at": recorded, "derived_from": [RECORD_FACT],
            "note": f"Income growth is January-August of the election year over the same months a year earlier (data "
                    f"through {last_month}); the same measure as the midterm model, not chosen for its fit. Popular "
                    "vote, not the Electoral College."})
    return facts


# --- report -------------------------------------------------------------------------------------------------------

def _r(d: dict) -> str:
    return "—" if not d["n"] else (f"{d['kept']}/{d['n']}（{100 * d['share']:.0f}%；95% 區間 "
                                   f"{100 * d['wilson95'][0]:.0f}–{100 * d['wilson95'][1]:.0f}%）")


def render(rows: list[dict], model: Model | None) -> str:
    r = base_rates(rows)
    L = ["# 總統選舉：執政黨的紀錄和經濟（參考類別）", "",
         "每次總統選舉，選舉日在任總統的政黨（執政黨）有沒有守住白宮（隔年 1 月 21 日在任總統的政黨，也就是選舉人團的結果），"
         "和它在兩黨普選票裡的得票率。普選票 1952–2008 年來自人口普查局《統計摘要》表 402，2012 年以後來自 FEC。", "",
         f"- 全部：{_r(r['all'])}",
         f"- 執政黨只執政一任：{_r(r['first_term'])}；兩任以上：{_r(r['two_terms_or_more'])}",
         f"- 總統本人參選：{_r(r['president_running'])}；開放席次：{_r(r['open_seat'])}", "",
         "| 年 | 執政黨 | 總統參選 | 已執政 | 兩黨得票率 | 守住白宮 |", "|---|---|---|---|---|---|"]
    for x in rows:
        held = "—" if x["terms_held"] is None else ("一任" if x["terms_held"] == 1 else "兩任以上")
        L.append(f"| {x['year']} | {x['party']} | {'是' if x['running'] else '否'} | {held} | {x['share']:.1f}% | "
                 f"{'是' if x['kept'] else '否'} |")
    if model is not None:
        L += ["", "## 基本面：執政黨得票率對選舉年 1–8 月實質可支配所得成長", "",
              f"{model.years[0]}–{model.years[-1]} 年 {model.n} 次：得票率 = {model.a:.1f} + {model.b:.2f} × 所得成長"
              f"（斜率的 t = {model.b / model.se_b:.2f}，R² = {model.r2:.2f}，殘差標準差 {model.sigma:.1f} 點）。"
              "解釋變數和期中選舉模型相同，事先固定，不為了配適換變數。", "",
              "| 所得成長 | 預測得票率 | 得票率過半的機率 |", "|---|---|---|"]
        for x in SCENARIOS:
            L.append(f"| {x:+.0f}% | {model.predict(x)[0]:.1f}% | {100 * model.p_above_half(x):.0f}% |")
        L += ["", "普選票過半不等於贏得選舉人團（2000、2016 年）。"]
    return "\n".join(L + [""])
