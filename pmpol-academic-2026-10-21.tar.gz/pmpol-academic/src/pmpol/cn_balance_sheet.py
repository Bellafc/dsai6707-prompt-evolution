"""RMB balance-sheet repair monitor: Chinese households (2026-10-08).

Three lights (config/cn_balance_sheet.toml), each the condition that would show households turning from paying
debt down to borrowing again: the mortgage early-repayment rate at or below a threshold, household short-term
loans up on the same month a year earlier, and the rental yield at or above the mortgage rate.

Household loans come from the People's Bank of China's monthly financial statistics reports, which give
year-to-date flows ("住户贷款减少1.03万亿元，其中，短期贷款减少1.05万亿元，中长期贷款增加188亿元"). A month's flow is
this month's year-to-date figure minus last month's, and the year-on-year change is that flow minus the same
month's a year earlier. Figures in 万亿 carry two decimals, so a flow derived from them is uncertain by up to 50亿
per term; the uncertainty is carried and a light within it of its threshold reads "at the threshold". Older
months fall off the Chinese list page; the English report of the same month is read instead.

The other readings were supplied by the user and are shown as such, never as official facts. Market prices on
Chinese macro questions are listed beside the lights (L4), with no direction assigned: the monitor is about the
balance sheet, not about any market.
"""

from __future__ import annotations

import html as htmllib
import json
import re
import time
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

from pmpol import USER_AGENT

CONFIG = Path("config/cn_balance_sheet.toml")
CACHE = Path("data/macro/pbc")
LIST = "http://www.pbc.gov.cn/diaochatongjisi/116219/116225/index.html"
BASE = "http://www.pbc.gov.cn"
# months whose Chinese report has dropped off the list page: the English release of the same month
EXTRA = {(2025, 7): "https://camlmac.pbc.gov.cn/en/3688247/3688978/3709137/5810171/index.html"}
LICENCE = "People's Bank of China statistical release (official government data, cited)"
MARKETS = re.compile(r"\b(yuan|renminbi|CNY|China'?s? (GDP|economy|property|housing)|People's Bank of China|PBOC)\b",
                     re.I)


def _get(url: str) -> str:
    import httpx

    r = httpx.get(url, timeout=60, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
    r.raise_for_status()  # a refusal stops here, never retried
    r.encoding = r.encoding or "utf-8"
    return r.text


def _text(page: str) -> str:
    page = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", page, flags=re.S)
    return re.sub(r"\s+", " ", htmllib.unescape(re.sub(r"<[^>]+>", " ", page)))


_PERIODS = {"一季度": 3, "上半年": 6, "前三季度": 9}


def discover(list_page: str) -> dict[tuple[int, int], str]:
    """(year, month) -> report URL, from the PBOC statistics list page."""
    out = {}
    for href, title in re.findall(r'href="([^"]+)"[^>]*>\s*([^<]{4,40})<', list_page):
        m = re.fullmatch(r"\s*(\d{4})年(\d{1,2}月|一季度|上半年|前三季度|)金融统计数据报告\s*", title)
        if not m:
            continue
        y, p = int(m.group(1)), m.group(2)
        month = 12 if not p else _PERIODS.get(p) or int(p[:-1])
        out[(y, month)] = href if href.startswith("http") else BASE + href
    return out


@dataclass
class Amount:
    value: float  # 億元
    unc: float  # half a unit of the last published digit, 億元

    def __sub__(self, other: "Amount") -> "Amount":
        return Amount(self.value - other.value, self.unc + other.unc)


def _amount(sign: str, num: str, unit: str) -> Amount:
    neg = sign in ("减少", "decreased", "falling", "fell")
    decimals = len(num.split(".")[1]) if "." in num else 0
    scale = {"万亿": 10000, "亿": 1, "trillion": 10000, "billion": 10}[unit]
    v = float(num) * scale
    return Amount(-v if neg else v, 0.5 * scale * 10 ** -decimals)


_ZH = re.compile(r"住户贷款(增加|减少)([\d.]+)(万亿|亿)元，其中，短期贷款(增加|减少)([\d.]+)(万亿|亿)元，"
                 r"中长期贷款(增加|减少)([\d.]+)(万亿|亿)元")
_EN = re.compile(r"household loans (increased|decreased) by RMB([\d.]+) (trillion|billion), with short-term loans "
                 r"(falling|rising) by RMB([\d.]+) (trillion|billion) and medium and long-term \(MLT\) loans "
                 r"(rising|falling) by RMB([\d.]+) (trillion|billion)", re.I)


def parse_household(page: str) -> dict[str, Amount] | None:
    """Year-to-date household loan flows: {"total", "short", "long"} in 億元."""
    t = _text(page)
    m = _ZH.search(t) or _EN.search(t)
    if not m:
        return None
    g = m.groups()
    return {"total": _amount(*g[0:3]), "short": _amount(*g[3:6]), "long": _amount(*g[6:9])}


def latest(get=None, cache: Path = CACHE) -> tuple[int, int]:
    """The newest month with a report on the list page."""
    return max(discover((get or _get)(LIST)))


def needed(y: int, m: int) -> list[tuple[int, int]]:
    """Reports for a month's flow and its year-on-year change."""
    return sorted({(y, m), (y - 1, m)} | ({(y, m - 1), (y - 1, m - 1)} if m > 1 else set()))


def fetch_ytd(months: list[tuple[int, int]], get=None, cache: Path = CACHE, pause: float = 1.0) -> dict:
    """(year, month) -> year-to-date flows, for the months asked (each report cached once)."""
    get = get or _get
    cache.mkdir(parents=True, exist_ok=True)
    index = None
    out = {}
    for ym in months:
        path = cache / f"report_{ym[0]}_{ym[1]:02d}.html"
        if not path.exists():
            if index is None:
                index = {**EXTRA, **discover(get(LIST))}
                time.sleep(pause)
            url = index.get(ym)
            if url is None:
                continue
            path.write_text(get(url), encoding="utf-8")
            time.sleep(pause)
        parsed = parse_household(path.read_text(encoding="utf-8"))
        if parsed:
            out[ym] = parsed
    return out


def month_flow(ytd: dict, y: int, m: int) -> dict[str, Amount] | None:
    if (y, m) not in ytd:
        return None
    if m == 1:
        return ytd[(y, 1)]
    if (y, m - 1) not in ytd:
        return None
    return {k: ytd[(y, m)][k] - ytd[(y, m - 1)][k] for k in ytd[(y, m)]}


# --- readings and lights --------------------------------------------------------------------------------------

@dataclass
class Reading:
    id: str
    label: str
    value: float | None
    unit: str
    period: str
    source: str  # "pbc" (official, computed), "reported" (official, via media), "user" (supplied, unverified)
    note: str = ""
    low: float | None = None
    high: float | None = None
    unc: float = 0.0
    url: str = ""

    def shown(self) -> str:
        if self.low is not None:
            return f"{self.low:g}–{self.high:g}{self.unit}"
        v = f"{self.value:+,.0f}" if float(self.value).is_integer() else f"{self.value:+,.2f}"
        return f"{v}{self.unit}" + (f"（±{self.unc:,.0f}）" if self.unc else "")


@dataclass
class Light:
    id: str
    label: str
    reading: str
    op: str
    threshold: float
    unit: str
    meaning: str
    threshold_note: str = ""


@dataclass
class Config:
    lights: list[Light]
    readings: dict[str, Reading] = field(default_factory=dict)


def load(path: Path = CONFIG) -> Config:
    raw = tomllib.loads(path.read_text(encoding="utf-8"))
    lights = [Light(**{k: v for k, v in x.items()}) for x in raw.get("light", [])]
    readings = {}
    for r in raw.get("reading", []):
        readings[r["id"]] = Reading(r["id"], r["label"], r.get("value"), r.get("unit", ""), r.get("period", ""),
                                    r.get("source", "user"), r.get("note", ""), r.get("low"), r.get("high"),
                                    url=r.get("url", ""))
    return Config(lights, readings)


def pbc_readings(ytd: dict, y: int, m: int) -> dict[str, Reading]:
    """The month's household loan flows and the short-term year-on-year change (None when a report is missing)."""
    now, before = month_flow(ytd, y, m), month_flow(ytd, y - 1, m)
    out = {}
    if now:
        for k, label in (("total", "住户贷款合计"), ("short", "住户短期贷款"), ("long", "住户中长期贷款")):
            out[f"household_{k}"] = Reading(f"household_{k}", f"{label}（當月）", now[k].value, "億元", f"{y}-{m:02d}",
                                            "pbc", "年初至今的累計相減", unc=now[k].unc)
    if now and before:
        d = now["short"] - before["short"]
        out["household_short_loans_yoy"] = Reading(
            "household_short_loans_yoy", "居民短贷同比（當月比去年同月）", d.value, "億元", f"{y}-{m:02d}", "pbc",
            f"{y} 年 {m} 月 {now['short'].value:+,.0f} 億，{y - 1} 年 {m} 月 {before['short'].value:+,.0f} 億", unc=d.unc)
    return out


def derived(readings: dict[str, Reading]) -> None:
    """The rent-mortgage spread from its two parts (both as supplied)."""
    r, k = readings.get("rent_price_ratio"), readings.get("mortgage_rate")
    if r and k and r.value is not None and k.value is not None:
        readings["rent_mortgage_spread"] = Reading(
            "rent_mortgage_spread", "租贷利差（租金回報率 − 房貸利率）", round(r.value - k.value, 2), "pct",
            f"{r.period}／{k.period}", "user", "由兩個使用者提供的讀數相減；兩者期間不同")


def status(light: Light, r: Reading | None) -> str:
    """"met", "not met", "at the threshold" (within the reading's uncertainty or a range across it) or "no reading"."""
    if r is None:
        return "no reading"
    lo, hi = (r.low, r.high) if r.low is not None else (r.value - r.unc, r.value + r.unc)
    if light.op in ("<=", "<"):
        ok_all, ok_none = (hi <= light.threshold, lo > light.threshold) if light.op == "<=" else \
            (hi < light.threshold, lo >= light.threshold)
    else:
        ok_all, ok_none = (lo >= light.threshold, hi < light.threshold) if light.op == ">=" else \
            (lo > light.threshold, hi <= light.threshold)
    return "met" if ok_all else "not met" if ok_none else "at the threshold"


STATUS_ZH = {"met": "🟢 轉向", "not met": "🔴 未轉向", "at the threshold": "🟡 在門檻上", "no reading": "⚪ 沒有讀數"}
SOURCE_ZH = {"pbc": "人行月報（官方，程式計算）", "reported": "官方報告（媒體轉載）", "user": "使用者提供（未核對）"}


def proof(cfg: Config, readings: dict[str, Reading], markets: list = (), observed_at: str = ""):
    from pmpol.proof import Proof

    states = {lt.id: status(lt, readings.get(lt.reading)) for lt in cfg.lights}
    met = sum(s == "met" for s in states.values())
    head = (f"{len(cfg.lights)} 個條件中 {met} 個轉向：" + "；".join(f"{lt.label} {STATUS_ZH[states[lt.id]]}"
                                                               for lt in cfg.lights))
    p = Proof("人民幣資產負債表修復監測", head, result={"met": met, "lights": states})
    for lt in cfg.lights:
        r = readings.get(lt.reading)
        if r is None:
            continue
        layer = "L1" if r.source in ("pbc", "reported") else "L3"
        ref = {"pbc": LIST, "reported": r.url}.get(r.source) or "config/cn_balance_sheet.toml"
        p.add(layer, f"{r.label}：{r.shown()}（{r.period}；{SOURCE_ZH[r.source]}{'；' + r.note if r.note else ''}）",
              ref, r.period, kind="data", id=f"r:{lt.id}")
        p.add("L3", f"門檻（使用者提出）：{lt.label} {lt.op} {lt.threshold:g}{lt.unit}——{lt.meaning}"
                    + (f"（{lt.threshold_note}）" if lt.threshold_note else ""), "config/cn_balance_sheet.toml",
              kind="rule", id=f"t:{lt.id}")
        p.add("L5", f"{lt.label}：{STATUS_ZH[states[lt.id]]}", kind="logic", id=f"s:{lt.id}",
              inputs=(f"r:{lt.id}", f"t:{lt.id}"))
    for key in ("household_total", "household_long", "mortgage_balance_yoy", "six_banks_mortgage_change_h1",
                "secondhand_price_mom", "passenger_car_retail_yoy"):
        r = readings.get(key)
        if r is not None:
            layer = "L1" if r.source in ("pbc", "reported") else "L3"
            ref = {"pbc": LIST, "reported": r.url}.get(r.source) or "config/cn_balance_sheet.toml"
            p.add(layer, f"{r.label}：{r.shown()}（{r.period}；{SOURCE_ZH[r.source]}{'；' + r.note if r.note else ''}）",
                  ref, r.period, kind="data", id=f"x:{key}")
    for i, (title, top, url) in enumerate(markets):
        p.add("L4", f"相關市場：{title}（{top}）——只並列，不指定方向", url, observed_at, kind="data", id=f"m{i}")
    p.alt("修復已經開始，只是還沒反映在這三個讀數", "unchecked",
          "三個條件都是落後或同步的；存款搬家、理財規模、新增房貸利率等領先指標還沒接")
    p.alt("讀數口徑不一致造成的假象", "unchecked",
          "租貸利差的兩個成分期間不同（6 月租金、8 月利率），房貸利率是存量還是新發放待確認")
    p.caveats += ["使用者提供的讀數標成 L3（未核對的觀點），補上來源並核對後才算 L1。",
                  "人行月報只公布年初至今的累計，萬億元只到小數兩位，相減得到的當月數字最多有 ±50 億的誤差。"]
    return p


def related_markets(events) -> list[tuple[str, str, str]]:
    from pmpol.universe.explain import source_url

    out = []
    for e in events:
        if not MARKETS.search(e.title):
            continue
        live = [m for m in e.markets if m.active and m.bid is not None and m.ask is not None]
        if live:
            top = max(live, key=lambda m: m.bid + m.ask)
            out.append((e.title, f"{top.outcome or 'Yes'} {50 * (top.bid + top.ask):.0f}%", source_url(top)))
    return out


def render(cfg: Config, readings: dict[str, Reading], p, when: str) -> str:
    L = ["# 人民幣資產負債表修復監測", "", f"產生時間：{when}。三個條件都轉向，才算居民從「還債」轉回「借錢」。", "",
         "## 三燈快照", "", "| 燈 | 讀數 | 門檻 | 狀態 | 來源 |", "|---|---|---|---|---|"]
    for lt in cfg.lights:
        r = readings.get(lt.reading)
        L.append(f"| {lt.label} | {'—' if r is None else r.shown()} | {lt.op} {lt.threshold:g}{lt.unit}"
                 + ("＊" if lt.threshold_note else "") + f" | {STATUS_ZH[p.result['lights'][lt.id]]} | "
                 f"{'—' if r is None else SOURCE_ZH[r.source]} |")
    notes = [f"＊{lt.label}：{lt.threshold_note}" for lt in cfg.lights if lt.threshold_note]
    L += [""] + notes + ["", "## 關鍵讀數", "", "| 指標 | 讀數 | 期間 | 來源 | 說明 |", "|---|---|---|---|---|"]
    for r in readings.values():
        L.append(f"| {r.label} | {r.shown()} | {r.period} | {SOURCE_ZH[r.source]} | {r.note} |")
    L += ["", "## 本月判讀", "", p.conclusion, ""]
    L += [f"- 競爭假設：{a['hypothesis']}（{a['evidence']}）" for a in p.alternatives]
    L += [f"- 限制：{c}" for c in p.caveats]
    mk = [s for s in p.steps if s.layer == "L4"]
    if mk:
        L += ["", "## 相關預測市場（只並列）", ""] + [f"- {s.text}" for s in mk]
    return "\n".join(L + [""])


def export(p, path: Path = Path("data/cn_balance_sheet.json")) -> None:
    row = {"id": "cn_balance_sheet", "group": "evidence", "kind": "macro_monitor", "subject": "cn_balance_sheet",
           "edge": 0.0, "venues": [], "confidence": "rule", "title": p.title, "proof": {**p.to_dict(), "graph": p.graph()}}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"signals": [row]}, ensure_ascii=False, default=str), encoding="utf-8")
