"""Layered proof viewer: one self-contained HTML file (Cytoscape.js from cdnjs) with the data embedded.

Market signals come from data/proofs.json (pmpol universe), data/movers.json, data/settlement.json and
data/external.json, data/house.json, data/news.json and data/gdelt.json; macro judgments from data/macro/regimes.json (pmpol macro); the knowledge base from kb/; and
the "system" tab shows
the status page, key assumptions, track record, residual monitor and settlement checks as Markdown. The output goes to data/ (not version-controlled), because
it embeds venue quotes that some venues' terms do not allow us to redistribute.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from pmpol.kb import KnowledgeBase
from pmpol.proof import Proof, Step

TEMPLATE = Path(__file__).with_name("template.html")


def _macro_with_graphs(rows: list[dict]) -> list[dict]:
    """regimes.json stores Proof.to_dict(); rebuild each Proof to add its graph."""
    out = []
    for d in rows:
        steps = [Step(**{k: (tuple(v) if k == "inputs" else v) for k, v in s.items()}) for s in d.get("steps", [])]
        p = Proof(d["title"], d["conclusion"], steps, d.get("caveats", []), d.get("result", {}), d.get("layer", "L5"))
        out.append({**p.to_dict(), "graph": p.graph()})
    return out


def kb_rows(kb: KnowledgeBase) -> list[dict]:
    return [{"id": f.id, "layer": f.layer, "subject": f.subject, "predicate": f.predicate,
             "value": f.value if isinstance(f.value, (str, int, float)) else json.dumps(f.value, ensure_ascii=False,
                                                                                       default=str),
             "status": f.status, "admiralty": f.admiralty, "source_title": f.source.title, "source_url": f.source.url,
             "quote": f.source.quote or "", "note": f.note}
            for f in sorted(kb.facts.values(), key=lambda f: (f.layer, f.id))]


HISTORY_POINTS = 48  # per market, evenly thinned


def price_history(keys: set[str], db: Path | None = None, points: int = HISTORY_POINTS) -> dict[str, list]:
    """market key ("venue:market_id") -> [[ts, mid], ...] from the stored quotes (mid of a two-sided book, else the
    last trade), thinned to `points`, for the viewer's sparklines. Empty without a database."""
    if not keys:
        return {}
    from pmpol import store

    try:
        conn = store.connect(db) if db else store.connect()
    except Exception:  # the page must still build without a database
        return {}
    with conn:
        conn.execute("CREATE TEMP TABLE IF NOT EXISTS want (venue TEXT, market_id TEXT)")
        conn.execute("DELETE FROM want")
        conn.executemany("INSERT INTO want VALUES (?, ?)", [tuple(k.split(":", 1)) for k in keys if ":" in k])
        rows = conn.execute("SELECT q.venue, q.market_id, q.ts, q.bid, q.ask, q.last FROM quotes q JOIN want w "
                            "ON q.venue = w.venue AND q.market_id = w.market_id ORDER BY q.venue, q.market_id, q.ts")
        out: dict[str, list] = {}
        for venue, mid_id, ts, bid, ask, last in rows:
            mid = (bid + ask) / 2 if bid is not None and ask is not None and ask >= bid else last
            if mid is not None:
                out.setdefault(f"{venue}:{mid_id}", []).append([ts[:16], round(mid, 4)])
    for k, series in out.items():
        if len(series) > points:
            step = (len(series) - 1) / (points - 1)
            out[k] = [series[round(i * step)] for i in range(points)]
    return out


def _latest(pattern: str, reports: Path) -> Path | None:
    files = sorted(reports.glob(pattern))
    return files[-1] if files else None


def system_pages(reports: Path = Path("reports"), db: Path | None = None) -> list[dict]:
    """Markdown pages for the "system" tab: status, assumptions, track record, residual monitor, settlement."""
    from datetime import date

    from pmpol import assumptions, runs, store

    pages = []
    try:
        with (store.connect(db) if db else store.connect()) as conn:
            pages.append({"title": "系統狀態", "md": runs.render_status(conn)})
    except Exception as e:  # the page must still build without a database
        pages.append({"title": "系統狀態", "md": f"讀不到執行紀錄：{e}"})
    rows = assumptions.load_proof_rows([Path("data/proofs.json"), Path("data/movers.json"),
                                        Path("data/macro/regimes.json")])
    pages.append({"title": "關鍵假設", "md": assumptions.render(rows, date.today())})
    for title, pattern in (("訊號成績單", "*_track.md"), ("結算資料檢查", "*_settlement.md")):
        if f := _latest(pattern, reports):
            pages.append({"title": title, "md": f.read_text(encoding="utf-8")})
    if f := _latest("*_universe.md", reports):
        text = f.read_text(encoding="utf-8")
        i = text.find("## 8. 殘差監測")
        if i >= 0:
            j = text.find("### 8d", i)
            pages.append({"title": "殘差監測", "md": text[i:j if j > 0 else None]})
    return pages


def build(out: Path = Path("data/viewer/index.html"), proofs: Path = Path("data/proofs.json"),
          macro: Path = Path("data/macro/regimes.json"), kb: KnowledgeBase | None = None,
          movers: Path = Path("data/movers.json"), settlement: Path = Path("data/settlement.json"),
          pages: list[dict] | None = None, history: dict | None = None,
          external: Path = Path("data/external.json"), house: Path = Path("data/house.json"),
          news: tuple[Path, ...] = (Path("data/news.json"), Path("data/gdelt.json"))) -> dict:
    kb = kb or KnowledgeBase.load()
    data = {"generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), "observed_at": "",
            "signals": [], "macro": [], "kb": kb_rows(kb),
            "pages": system_pages() if pages is None else pages}
    if proofs.exists():
        d = json.loads(proofs.read_text(encoding="utf-8"))
        data["signals"] = sorted(d["signals"], key=lambda s: -s["edge"])
        data["observed_at"] = d.get("observed_at", "")
    if movers.exists():  # reverse engine: price moves with news checks
        data["signals"] += json.loads(movers.read_text(encoding="utf-8"))["signals"]
    if settlement.exists():  # markets checked against their settlement data
        data["signals"] += json.loads(settlement.read_text(encoding="utf-8"))["signals"]
    if external.exists():  # external forecasts beside the markets (L3 opinions)
        data["signals"] += json.loads(external.read_text(encoding="utf-8"))["signals"]
    if house.exists():  # the House from its districts (structural model, L5)
        data["signals"] += json.loads(house.read_text(encoding="utf-8"))["signals"]
    for path in news:  # news watch and GDELT event data for the requirements (L1 observations of coverage)
        if path.exists():
            data["signals"] += json.loads(path.read_text(encoding="utf-8"))["signals"]
    if macro.exists():
        data["macro"] = _macro_with_graphs(json.loads(macro.read_text(encoding="utf-8")))
    if history is None:
        history = price_history({k for s in data["signals"] for k in s.get("markets", [])})
    data["history"] = history
    blob = json.dumps(data, ensure_ascii=False, default=str).replace("</", "<\\/")  # cannot close the script tag
    html = TEMPLATE.read_text(encoding="utf-8").replace("/*DATA*/", blob)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    return {"signals": len(data["signals"]), "macro": len(data["macro"]), "kb": len(data["kb"]),
            "history": len(data["history"]),
            "pages": len(data["pages"]), "bytes": len(html)}
