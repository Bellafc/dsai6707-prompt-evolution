"""Settlement-data checks: when a market settles on a public series we can read, evaluate it on the data
already published. A market whose outcome the published data has already decided, but whose price says
otherwise, is the cleanest inconsistency there is (an L1 fact against an L4 price).

Each market is read as a proposition about one statistic of one daily series:

  sum(window) / max(window) / min(window)          daily counts over [start, end]
  ma7(day)                                         7-day moving average reported for one day
  max_ma7(window) / min_ma7(window)                the moving average reaching a level on any day

and a condition (a threshold, or a bucket). With data published up to day L, a condition can already be
decided (the known part of a sum is past the threshold, the maximum so far is past it, or the window is
complete) or still open.

Precision rules:
  - Windows that start at "market creation" have an unknown start. They are never decided YES (data
    from before the market existed could satisfy the condition; Hormuz traffic was normal in January),
    and decided NO only when the whole of the published year never satisfies it and the window is over.
  - Days within PROVISIONAL_DAYS of the latest published day may still be revised; decisions that
    depend on them are marked provisional.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from pmpol.models import Market
from pmpol.osint.portwatch import CHOKEPOINTS
from pmpol.universe.outcomes import count_interval

PROVISIONAL_DAYS = 7
INF = float("inf")


@dataclass(frozen=True)
class Condition:
    """Statistic of a daily series over a window, and the set its value must fall in."""
    series: str  # "portwatch:hormuz"
    stat: str  # sum, max, min, ma7, max_ma7, min_ma7
    start: date | None  # None: from market creation (unknown)
    end: date
    lo: float = -INF  # value must be in [lo, hi] (closedness below)
    hi: float = INF
    lo_open: bool = False
    hi_open: bool = False
    rule: str = ""  # which reading rule matched

    def holds(self, v: float) -> bool:
        above = v > self.lo if self.lo_open else v >= self.lo
        below = v < self.hi if self.hi_open else v <= self.hi
        return above and below

    def text(self) -> str:
        win = (f"{self.start:%Y-%m-%d}" if self.start else "建立日") + f" → {self.end:%Y-%m-%d}"
        lo = "" if self.lo == -INF else f"{'>' if self.lo_open else '≥'} {self.lo:g}"
        hi = "" if self.hi == INF else f"{'<' if self.hi_open else '≤'} {self.hi:g}"
        return f"{self.stat}({self.series}, {win}) {' 且 '.join(x for x in (lo, hi) if x)}"


@dataclass
class Decision:
    state: str  # "yes", "no", "open"
    value: float | None  # the statistic over the published part of the window
    known_until: date | None
    complete: bool
    provisional: bool = False
    detail: str = ""


# --- reading markets ---------------------------------------------------------------------

_DATE = r"((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.? \d{1,2},? \d{4})"


def _d(text: str) -> date:
    t = re.sub(r"[.,]", "", text.strip())
    for fmt in ("%b %d %Y", "%B %d %Y"):
        try:
            return datetime.strptime(t, fmt).date()
        except ValueError:
            continue
    raise ValueError(text)


def _chokepoint(text: str) -> str | None:
    for key, name in CHOKEPOINTS.items():
        if name.lower() in text.lower():
            return key
    return None


def _label_date(label: str, year: int) -> date | None:
    try:
        return _d(f"{label.strip()} {year}") if not re.search(r"\d{4}", label) else _d(label)
    except ValueError:
        return None


def _bucket(label: str, integer: bool) -> tuple[float, float, bool, bool] | None:
    """Bucket label -> (lo, hi, lo_open, hi_open). Integer sums use inclusive ranges ("20-24");
    moving averages use [lo, hi) (Polymarket: a value on an edge goes to the higher bracket)."""
    if integer:
        iv = count_interval(label)
        return (iv.lo, iv.hi, False, False) if iv else None
    from pmpol.propositions.parse import number_span

    s = number_span(label)
    return (s.lo, s.hi, not s.lo_closed, not s.hi_closed) if s else None


def _read_eia(m: Market, r: str) -> Condition | None:
    # Kalshi: commercial crude inventories for one week, strictly above N million barrels (first publication)
    hit = re.search(rf"commercial crude oil inventories for the week ending {_DATE} are strictly above\s+([\d.]+) "
                    r"million barrels", r, re.I)
    if hit:
        week = _d(hit.group(1))
        return Condition("eia:WCESTUS1", "value", week, week, lo=float(hit.group(2)) * 1000, lo_open=True,
                         rule="kalshi_crude_week")
    # Polymarket: SPR at or below a level for any week from market creation to a date
    hit = re.search(rf"Ending Stocks of Crude Oil in the Strategic Petroleum Reserve less than or equal to the specified "
                    rf"value after market creation for any week ending on or before {_DATE}", r, re.I)
    if hit:
        lv = re.match(r"^\s*([\d.]+)\s*M\s*$", m.outcome or "", re.I)
        if lv:
            return Condition("eia:WCSSTUS1", "min", None, _d(hit.group(1)), hi=float(lv.group(1)) * 1000,
                             rule="pm_spr_touch")
    return None


_MONTH = r"(January|February|March|April|May|June|July|August|September|October|November|December) (\d{4})"


# Units of FRED series used in annual-total markets: a threshold in dollars or people is divided by this.
FRED_SCALE = {"IMPCH": 1e6, "EXPCH": 1e6, "JTU540099LDL": 1e3}
_NUM = r"\$?([\d,]+(?:\.\d+)?)\s*(billion|million|thousand|%)?"
_CMP = {"below": "lt", "less than": "lt", "above": "gt", "greater than": "gt", "at least": "ge", "at most": "le"}


def _bounds(op: str, x: float) -> dict:
    return {"lt": {"hi": x, "hi_open": True}, "le": {"hi": x}, "gt": {"lo": x, "lo_open": True}, "ge": {"lo": x}}[op]


def _amount(num: str, unit: str | None) -> float:
    return float(num.replace(",", "")) * {"billion": 1e9, "million": 1e6, "thousand": 1e3}.get((unit or "").lower(), 1.0)


def _read_fred_transformed(m: Market, r: str, code: str) -> Condition | None:
    """Annual totals, year-over-year growth for one month, and touches over the months after issuance (2026-10-06).
    Each needs the threshold's unit to match the series (FRED_SCALE) or a percentage."""
    cmp = r"(below|above|greater than|less than|at least|at most)"
    # "imports ... (FRED series IMPCH) in calendar year 2026 are below $220 billion"; "... during calendar year 2026
    # is greater than 5,497,000"
    hit = re.search(rf"calendar year (\d{{4}}) (?:are|is) {cmp} {_NUM}", r, re.I)
    if hit and code in FRED_SCALE and not re.search(r"any of the remaining", r, re.I):
        year = int(hit.group(1))
        x = _amount(hit.group(3), hit.group(4)) / FRED_SCALE[code]
        return Condition(f"fred:{code}", "sum", date(year, 1, 1), date(year, 12, 1), **_bounds(_CMP[hit.group(2).lower()], x),
                         rule="kalshi_fred_calendar_sum")
    # "M2 money-supply growth for December 2026 is below 5.0% ... the year-over-year percent change"
    hit = re.search(rf"growth for {_MONTH} is {cmp} ([\d.]+)%", r, re.I)
    if hit and re.search(r"year-over-year percent change", r, re.I):
        day = _d(f"{hit.group(1)} 1 {hit.group(2)}")
        return Condition(f"fred:{code}|yoy", "value", day, day, **_bounds(_CMP[hit.group(3).lower()], float(hit.group(4))),
                         rule="kalshi_fred_yoy_month")
    # "... growth for December 2026 is between 5.0% and 5.4%" (the published change is rounded to 0.1: inclusive)
    hit = re.search(rf"growth for {_MONTH} is between ([\d.]+)% and ([\d.]+)%", r, re.I)
    if hit and re.search(r"year-over-year percent change", r, re.I):
        day = _d(f"{hit.group(1)} 1 {hit.group(2)}")
        return Condition(f"fred:{code}|yoy", "value", day, day, lo=float(hit.group(3)), hi=float(hit.group(4)),
                         rule="kalshi_fred_yoy_month")
    # "for any monthly observation from Issuance through December 2026 is At least 0.50"
    hit = re.search(rf"any monthly observation from Issuance through {_MONTH} is {cmp} ([\d.]+)", r, re.I)
    if hit:
        end = _d(f"{hit.group(1)} 1 {hit.group(2)}")
        stat = "max" if _CMP[hit.group(3).lower()] in ("gt", "ge") else "min"
        return Condition(f"fred:{code}", stat, None, end, **_bounds(_CMP[hit.group(3).lower()], float(hit.group(4))),
                         rule="kalshi_fred_touch")
    # "in any of the remaining Employment Situation releases published after Issuance in calendar year 2026, the
    # unemployment rate ... is below 7.5%" (the release in January reports December and is excluded)
    hit = re.search(rf"any of the remaining .*? releases published after Issuance in calendar year (\d{{4}}).*? is {cmp} ([\d.]+)%",
                    r, re.I)
    if hit:
        year = int(hit.group(1))
        end = date(year, 11, 1) if re.search(r"does not include the release scheduled for January", r, re.I) else date(year, 12, 1)
        stat = "max" if _CMP[hit.group(2).lower()] in ("gt", "ge") else "min"
        return Condition(f"fred:{code}", stat, None, end, **_bounds(_CMP[hit.group(2).lower()], float(hit.group(3))),
                         rule="kalshi_fred_release_touch")
    return None


def _read_fred(m: Market, r: str) -> Condition | None:
    """Kalshi markets on one month's value of a FRED series: "<statistic> for September 2026 is above X ...
    FRED series CODE"; annual totals, growth rates and touches go to _read_fred_transformed."""
    code = re.search(r"FRED series ([A-Z0-9]+)", r)
    if not code:
        return None
    if re.search(r"growth|year-over-year|calendar year|any monthly observation|any of the remaining", r, re.I):
        return _read_fred_transformed(m, r, code.group(1))
    month = re.search(rf"for {_MONTH}\b", r)
    if not month:
        return None
    from pmpol.propositions.parse import _kalshi_strike

    span = _kalshi_strike(m)
    if span is None:
        return None
    day = _d(f"{month.group(1)} 1 {month.group(2)}")
    return Condition(f"fred:{code.group(1)}", "value", day, day, lo=span.lo, hi=span.hi, lo_open=not span.lo_closed,
                     hi_open=not span.hi_closed, rule="kalshi_fred_month")


def read(m: Market, year: int = 2026) -> Condition | None:
    """The settlement condition of a market, when its rules name a series we can read; else None."""
    r = re.sub(r"\s+", " ", m.rules or "")
    if "fred series" in r.lower() and m.venue == "kalshi":
        return _read_fred(m, r)
    if "energy information administration" in r.lower():
        return _read_eia(m, r)
    if "portwatch" not in r.lower():
        return None
    cp = _chokepoint(r)
    if cp is None:
        return None
    s = f"portwatch:{cp}"
    lab = (m.outcome or "").strip()
    low = r.lower()

    # Kalshi: sum over a week, above x
    hit = re.search(rf"number of transit calls through the .+? is above ([\d.]+) from {_DATE} to {_DATE}", r, re.I)
    if hit and "highest" not in low:
        return Condition(s, "sum", _d(hit.group(2)), _d(hit.group(3)), lo=float(hit.group(1)), lo_open=True,
                         rule="kalshi_sum")
    # Kalshi: highest single day in a week, above x
    hit = re.search(rf"highest single-day number of transit calls .+? is above ([\d.]+) from {_DATE} to {_DATE}", r, re.I)
    if hit:
        return Condition(s, "max", _d(hit.group(2)), _d(hit.group(3)), lo=float(hit.group(1)), lo_open=True,
                         rule="kalshi_peak")
    # Kalshi: highest day in a month, at least x
    hit = re.search(r"highest daily number of transit calls .+? is at least ([\d.]+) in (\w{3}) (\d{4})", r, re.I)
    if hit:
        first = _d(f"{hit.group(2)} 1 {hit.group(3)}")
        last = (first.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
        return Condition(s, "max", first, last, lo=float(hit.group(1)), rule="kalshi_month_high")
    # Kalshi: 7-day average above x on some day (after A and) before B
    hit = re.search(rf"7-day moving average of transit calls through the .+? is above ([\d.]+) "
                    rf"(?:after {_DATE} and )?before {_DATE}", r, re.I)
    if hit:
        start = _d(hit.group(2)) + timedelta(days=1) if hit.group(2) else None
        return Condition(s, "max_ma7", start, _d(hit.group(3)) - timedelta(days=1), lo=float(hit.group(1)),
                         lo_open=True, rule="kalshi_ma_touch")
    # Polymarket: weekly total, bucket
    hit = re.search(rf"total number of transit calls that IMF Portwatch reports for the .+? for all days from "
                    rf"{_DATE},? through {_DATE}", r, re.I)
    if hit:
        b = _bucket(lab, integer=True)
        return Condition(s, "sum", _d(hit.group(1)), _d(hit.group(2)), *b, rule="pm_week_total") if b else None
    # Polymarket: 7-day average reported for one day, bucket
    hit = re.search(rf"7-day moving average of transit calls .{{0,40}}for the .+? that IMF Portwatch reports for {_DATE}", r, re.I)
    if hit:
        b = _bucket(lab, integer=False)
        day = _d(hit.group(1))
        return Condition(s, "ma7", day, day, *b, rule="pm_ma_on_day") if b else None
    # Polymarket: some day at or above N between market creation and B
    hit = re.search(rf"daily number of transit calls .+? is equal to or above the listed value for any date between "
                    rf"market creation and {_DATE}", r, re.I)
    if hit:
        iv = count_interval(lab)
        return Condition(s, "max", None, _d(hit.group(1)), lo=iv.lo, rule="pm_any_day_at_least") if iv else None
    # Polymarket: a day with 0 transits between (June 26 | market creation) and the listed date
    hit = re.search(r"daily number of transit calls .+? equal to 0 for any date between (market creation|\w+ \d{1,2}) "
                    r"and the specified date", r, re.I)
    if hit:
        end = _label_date(lab, year)
        if end is None:
            return None
        start = None if hit.group(1).lower() == "market creation" else _d(f"{hit.group(1)} {year}")
        return Condition(s, "min", start, end, hi=0, rule="pm_zero_day")
    # Polymarket / Limitless: 7-day average at or above / at or below a level on any day, from creation
    hit = re.search(r"7-day moving average of transit calls .{0,60}?(equal to or above|less than or equal to) "
                    r"([\d.]+) for any date between market creation and (the listed date|" + _DATE + ")", r, re.I)
    if hit:
        end = _label_date(lab, year) if hit.group(3).lower() == "the listed date" else _d(hit.group(3))
        if end is None:
            return None
        v = float(hit.group(2))
        if hit.group(1).lower().startswith("equal to or above"):
            return Condition(s, "max_ma7", None, end, lo=v, rule="pm_ma_touch_up")
        return Condition(s, "min_ma7", None, end, hi=v, rule="pm_ma_touch_down")
    return None


# --- evaluating ---------------------------------------------------------------------------

def _ma7(daily: dict[date, int], day: date) -> float | None:
    vals = [daily.get(day - timedelta(days=i)) for i in range(7)]
    return None if any(v is None for v in vals) else sum(vals) / 7


def decide(c: Condition, daily: dict[date, int]) -> Decision:
    if not daily:
        return Decision("open", None, None, False, detail="沒有資料")
    latest, first = max(daily), min(daily)
    start = c.start or first  # creation-bounded: the whole published year is a superset of the window
    end_known = min(c.end, latest)
    complete = c.end <= latest
    days = [start + timedelta(days=i) for i in range((end_known - start).days + 1)] if end_known >= start else []
    prov = any(d > latest - timedelta(days=PROVISIONAL_DAYS) for d in days)
    if c.stat == "value":  # one published observation (EIA weekly)
        v = daily.get(c.end)
        if v is None:
            return Decision("open", None, latest, False, detail=f"資料只到 {latest}")
        return Decision("yes" if c.holds(v) else "no", v, latest, True, c.end > latest - timedelta(days=PROVISIONAL_DAYS))
    if c.stat == "ma7":
        v = _ma7(daily, c.end) if complete else None
        if v is None:
            return Decision("open", None, latest, False, detail=f"資料只到 {latest}")
        return Decision("yes" if c.holds(v) else "no", v, latest, True, prov)
    if c.stat in ("max_ma7", "min_ma7"):
        series = [v for d in days if (v := _ma7(daily, d)) is not None]
    else:
        series = [daily[d] for d in days if d in daily]
    if not series:
        return Decision("open", None, latest, complete, detail=f"資料只到 {latest}")
    agg = {"sum": sum, "max": max, "max_ma7": max, "min": min, "min_ma7": min}[c.stat](series)
    unknown_start = c.start is None
    if complete and not unknown_start:
        return Decision("yes" if c.holds(agg) else "no", agg, latest, True, prov)
    if c.stat in ("sum", "max", "max_ma7"):  # can only grow as days are added
        if c.holds(agg) and c.hi == INF and not unknown_start:
            return Decision("yes", agg, latest, complete, prov, "已公布的部分已經達到門檻")
        if (agg > c.hi or (c.hi_open and agg >= c.hi)) and not unknown_start:
            return Decision("no", agg, latest, complete, prov, "已公布的部分已經超過區間上限")
        if unknown_start and complete and not c.holds(agg) and c.hi == INF:
            return Decision("no", agg, latest, True, prov, "整年的資料都沒有達到（建立日不明，用整年判斷）")
    else:  # min, min_ma7: can only fall
        if c.holds(agg) and c.lo == -INF and not unknown_start:
            return Decision("yes", agg, latest, complete, prov, "已公布的部分已經達到門檻")
        if unknown_start and complete and not c.holds(agg) and c.lo == -INF:
            return Decision("no", agg, latest, True, prov, "整年的資料都沒有達到（建立日不明，用整年判斷）")
    return Decision("open", agg, latest, complete, prov)


@dataclass
class Check:
    market: Market
    event_title: str
    condition: Condition
    decision: Decision
    notes: list[str] = field(default_factory=list)

    @property
    def mismatch(self) -> float | None:
        """How far the price is from what the published data already decided (None when still open)."""
        if self.decision.state == "open" or self.market.mid is None:
            return None
        return (1 - self.market.mid) if self.decision.state == "yes" else self.market.mid
