"""Run the settlement-data checks over a snapshot and render the report."""

from __future__ import annotations

from collections import Counter
from datetime import date
from pathlib import Path

from pmpol.models import Event
from pmpol.osint import portwatch
from pmpol.proof import Proof
from pmpol.settlement import Check, decide, read
from pmpol.venues import info, source_url

STATE_ZH = {"yes": "已確定 YES", "no": "已確定 NO", "open": "還沒確定"}
STAT_ZH = {"value": "公布值", "sum": "加總", "max": "單日最高", "min": "單日最低", "ma7": "7 日平均", "max_ma7": "7 日平均的最高",
           "min_ma7": "7 日平均的最低"}


SOURCES = ("portwatch", "energy information administration", "fred series")
FRED_CACHE = Path("data/macro/fred_settlement")


def _load(series: str, since: date, fetch_text, cache) -> dict:
    kind, key = series.split(":", 1)
    if kind == "portwatch":
        return {r.day: r.total for r in portwatch.fetch(key, since, fetch_text, cache)}
    if kind == "fred":
        code, _, transform = key.partition("|")
        values = _fred(code, fetch_text, cache if cache is not portwatch.CACHE else FRED_CACHE)
        if transform == "yoy":  # percent change on the same month a year earlier
            values = {d: round(100 * (v / values[p] - 1), 1) for d, v in values.items()
                      if (p := d.replace(year=d.year - 1)) in values}
        # the same window as the other sources: a window "from issuance" is bounded by `since`, never by 1959
        return {d: v for d, v in values.items() if d >= since}
    if kind == "eia":
        from pmpol.macro import eia

        return eia.fetch(key, fetch_text, cache if cache is not portwatch.CACHE else eia.CACHE)
    raise ValueError(series)


def _fred(code: str, fetch_text, cache: Path) -> dict[date, float]:
    """Monthly (or other) observations of a FRED series, cached for the day; '.' (missing) rows dropped."""
    import json
    from datetime import datetime, timezone

    from pmpol.macro.sources import _default_fetch

    today = datetime.now(timezone.utc).date()
    cache.mkdir(parents=True, exist_ok=True)
    path = cache / f"{today:%Y%m%d}_{code}.json"
    if path.exists():
        return {date.fromisoformat(k): v for k, v in json.loads(path.read_text()).items()}
    text = (fetch_text or _default_fetch)(f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={code}")
    out = {}
    for line in text.strip().splitlines()[1:]:
        d, _, v = line.partition(",")
        try:
            out[date.fromisoformat(d)] = float(v)
        except ValueError:
            continue
    if not out:
        raise ValueError(f"FRED {code}: no rows parsed")
    path.write_text(json.dumps({k.isoformat(): v for k, v in out.items()}))
    return out


def _same_units(c, data: dict) -> bool:
    """Guard against unit mismatches (a strike in millions on a series in thousands): the threshold must be
    within a factor of 3 of the latest observation."""
    if not data:
        return False
    if c.rule in ("kalshi_fred_yoy_month", "kalshi_fred_touch"):  # percent changes and indicators: stated in the
        return True  # series' own units by the rule itself, and they can be near zero or negative
    latest = data[max(data)]
    if c.stat == "sum":  # an annual total: compare with a year of the latest month
        latest *= 12
    x = c.lo if c.lo != float("-inf") else c.hi
    return latest > 0 and x > 0 and 1 / 3 <= x / latest <= 3


def run(events: list[Event], since: date = date(2026, 1, 1), fetch_text=None,
        cache=portwatch.CACHE) -> tuple[list[Check], dict, Counter]:
    """Checks for every live market whose rules name a series we read; plus per-series data and reasons
    for markets that name one but could not be read."""
    data: dict[str, dict] = {}
    checks, unread = [], Counter()
    for e in events:
        for m in e.markets:
            if not m.active or not any(k in (m.rules or "").lower() for k in SOURCES):
                continue
            c = read(m)
            if c is None:
                unread[e.title] += 1
                continue
            if c.series not in data:
                data[c.series] = _load(c.series, since, fetch_text, cache)
            if c.series.startswith("fred:") and not _same_units(c, data[c.series]):
                unread[f"{e.title}（單位對不上：門檻和序列的數量級不同）"] += 1
                continue
            checks.append(Check(m, e.title, c, decide(c, data[c.series])))
    return checks, data, unread


def explain(ch: Check, observed_at: str) -> Proof:
    c, d, m = ch.condition, ch.decision, ch.market
    p = Proof(f"結算資料｜{ch.event_title}｜{m.outcome}",
              f"{STATE_ZH[d.state]}；市場價格 {100 * m.mid:.0f}%" if m.mid is not None else STATE_ZH[d.state],
              result={"state": d.state, "value": d.value, "known_until": str(d.known_until),
                      "mismatch": ch.mismatch, "rule": c.rule})
    src = ("EIA 週報" if c.series.startswith("eia:") else f"FRED {c.series[5:]}" if c.series.startswith("fred:")
           else "IMF PortWatch")
    p.add("L0", f"結算規則（平台規則原文）：{(m.rules or '')[:240]}", source_url(m), kind="rule", id="rule")
    p.add("L5", f"讀成：{c.text()}", "pmpol.settlement", kind="logic", id="cond", inputs=("rule",))
    if d.value is not None:
        p.add("L1", f"{src} 已公布到 {d.known_until}：{STAT_ZH[c.stat]} = {d.value:,.1f}",
              ("https://www.eia.gov/petroleum/supply/weekly/" if c.series.startswith("eia:")
               else f"https://fred.stlouisfed.org/series/{c.series[5:]}" if c.series.startswith("fred:")
               else "https://portwatch.imf.org"),
              str(d.known_until), kind="data", id="data")
    p.add("L4", f"{info(m.venue).code} 中間價 {100 * (m.mid or 0):.1f}%", source_url(m), observed_at, kind="data", id="quote")
    p.add("L5", STATE_ZH[d.state] + (f"：{d.detail}" if d.detail else ""), kind="logic", id="decide",
          inputs=tuple(i for i in ("cond", "data") if i != "data" or d.value is not None))
    if c.start is None:
        p.caveats.append("期間從市場建立日開始，建立日不明：永遠不自動判定 YES；只有整年的資料都沒達到、而且期間結束時才判定 NO。")
    if d.provisional:
        p.caveats.append("用到最近 7 天的資料，PortWatch 之後可能修正。")
    if c.series.startswith(("eia:", "fred:")):
        p.caveats.append("用的是目前版本的資料；Kalshi 多半用第一次公布的數字結算，之後的修正可能造成差異。")
    else:
        p.caveats.append("Source: International Monetary Fund（IMF PortWatch）。")
    return p


def render(checks: list[Check], data: dict, unread: Counter, generated_at: str) -> str:
    states = Counter(ch.decision.state for ch in checks)
    flagged = sorted((ch for ch in checks if (ch.mismatch or 0) >= 0.05), key=lambda ch: -ch.mismatch)
    L = [f"# 結算資料檢查 — {generated_at}", "",
         "市場的結算來源是我們讀得到的公開資料時，用已經公布的部分判斷它是不是其實已經確定了。"
         "已確定、價格卻還沒反映的，是最乾淨的不一致：L1 事實對 L4 價格。目前涵蓋 IMF PortWatch 的海峽通行數"
         "（Kalshi、Polymarket、Limitless 的荷姆茲、曼德、蘇伊士、巴拿馬題目），以及 EIA 週報"
         "（Kalshi 商業原油庫存、Polymarket 戰略石油儲備），以及規則寫明 FRED 序列的 Kalshi 題目（某個月的公布值）。", "",
         f"- 讀懂結算條件的市場：**{len(checks)}** 個（" + "、".join(f"{STATE_ZH[k]} {v}" for k, v in states.items()) + "）",
         f"- 已確定但價格偏離 ≥ 5 點：**{len(flagged)}** 個",
         "- 讀不懂的（類別題，例如「哪一天最高」）：" + ("、".join(f"{t}（{n}）" for t, n in unread.most_common(5)) or "無"),
         ""]
    L += ["## 1. 資料", "", "| 海峽 | 資料期間 | 最近 7 日平均 | 今年最高的 7 日平均 |", "|---|---|---|---|"]
    from pmpol.settlement import _ma7

    for series, daily in sorted(data.items()):
        if not daily or not series.startswith("portwatch:"):
            continue
        cp = series.split(":", 1)[1]
        last = max(daily)
        mas = [v for d in daily if (v := _ma7(daily, d)) is not None]
        L.append(f"| {portwatch.CHOKEPOINTS[cp]} | {min(daily)} → {last} | {_ma7(daily, last) or 0:.1f} | "
                 f"{max(mas) if mas else 0:.1f} |")
    from pmpol.macro.eia import SERIES as EIA_SERIES

    eia_rows = [(k.split(":", 1)[1], v) for k, v in sorted(data.items()) if k.startswith("eia:") and v]
    if eia_rows:
        L += ["", "| EIA 序列 | 最新一週 | 數值（千桶） | 一年前 |", "|---|---|---|---|"]
        for code, wk in eia_rows:
            last = max(wk)
            ago = min(wk, key=lambda d: abs((last - d).days - 364))
            L.append(f"| {code}（{EIA_SERIES.get(code, '')}） | {last} | {wk[last]:,.0f} | {wk[ago]:,.0f}（{ago}） |")
    L += ["", "## 2. 已確定、價格卻偏離的市場", ""]
    if flagged:
        L += ["| 偏離 | 平台 | 市場 | 選項 | 價格 | 資料 | 條件 |", "|---|---|---|---|---|---|---|"]
        for ch in flagged[:30]:
            d = ch.decision
            L.append(f"| {100 * ch.mismatch:.0f} | {info(ch.market.venue).code} | {ch.event_title[:60]} | "
                     f"{ch.market.outcome[:20]} | {100 * ch.market.mid:.0f}% | {STATE_ZH[d.state]}（{d.value:,.1f}，"
                     f"資料到 {d.known_until}{'，暫定' if d.provisional else ''}） | {ch.condition.text()} |")
    else:
        L.append("- 沒有。已經確定的市場價格都已經反映（或已經結算下架）。")
    L += ["", "## 3. 還沒確定、但已公布部分很接近門檻的市場", "",
          "| 平台 | 市場 | 選項 | 價格 | 已公布部分 | 條件 |", "|---|---|---|---|---|---|"]
    near = [ch for ch in checks if ch.decision.state == "open" and ch.decision.value is not None
            and ch.condition.lo not in (float("-inf"),) and ch.condition.lo > 0]
    near.sort(key=lambda ch: abs(ch.decision.value - ch.condition.lo) / max(ch.condition.lo, 1))
    for ch in near[:15]:
        L.append(f"| {info(ch.market.venue).code} | {ch.event_title[:60]} | {ch.market.outcome[:20]} | "
                 f"{100 * (ch.market.mid or 0):.0f}% | {ch.decision.value:,.1f}（到 {ch.decision.known_until}） | "
                 f"{ch.condition.text()} |")
    L += ["", "資料來源：IMF PortWatch（Source: International Monetary Fund；再利用需註明出處，商業用途需先取得同意）；"
          "U.S. Energy Information Administration（公共領域）；FRED（依序列，BLS／BEA 資料為公共領域）。", ""]
    return "\n".join(L)
