"""Proofs as nanopublications (TriG), 2026-10-07.

A nanopublication is the smallest publishable unit of a claim: four named graphs,

  head        this is a nanopublication, and which graphs hold what
  assertion   the claim itself: the proof's conclusion, its knowledge layer (L5 for inferences), analytic confidence
              and, when the proof has one, its probability
  provenance  where the claim comes from: the steps (layer, text, source, time) and what each was derived from, as
              in the PROV export (pmpol.prov)
  pubinfo     who made it and when: the software, the git commit, the generation time, the usage terms

This writes them locally (data/nanopubs.trig, not versioned). They are not signed and not published to the
nanopublication network: publishing is a decision for a person. The IRIs end in a SHA-256 of the content (not a
Trusty URI), so a changed proof gets a new IRI. An inference stays an inference: the assertion says "the system
concludes", with its layer, never a fact about the world.
"""

from __future__ import annotations

import hashlib
import json
import re
from urllib.parse import quote

BASE = "https://github.com/bellafc/polymarket_politics/ns/np/"
PREFIXES = {"np": "http://www.nanopub.org/nschema#", "prov": "http://www.w3.org/ns/prov#",
            "rdfs": "http://www.w3.org/2000/01/rdf-schema#", "xsd": "http://www.w3.org/2001/XMLSchema#",
            "dct": "http://purl.org/dc/terms/", "pmpol": "https://github.com/bellafc/polymarket_politics/ns#"}
KB = "https://github.com/bellafc/polymarket_politics/blob/claude/gallant-ritchie-j6n5c8/kb#"
SOURCE = "https://github.com/bellafc/polymarket_politics/ns/source#"
TERMS = ("Research output of pmpol; not investment advice. Market quotes remain subject to each venue's data terms; "
         "knowledge-base facts carry their own source licences.")


def _lit(text: str, lang: str | None = "zh-Hant") -> str:
    t = str(text).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")
    return f'"{t}"' + (f"@{lang}" if lang else "")


def _iri(url: str) -> str:
    return "<" + quote(url, safe=":/?#[]@!$&'()*+,;=%-._~") + ">"


def _source(ref: str, facts: set[str]) -> str:
    if ref in facts:
        return _iri(KB + ref)
    if ref.startswith(("http://", "https://")):
        return _iri(ref)
    return _iri(SOURCE + hashlib.sha256(ref.encode()).hexdigest()[:16])


def _local(step_id: str, i: int) -> str:
    return "step_" + (re.sub(r"[^A-Za-z0-9_]", "_", step_id) if step_id else f"s{i}")


def _probability(result: dict) -> float | None:
    for k in ("recalibrated", "pooled", "probability", "p_d_control", "external"):
        v = result.get(k)
        if isinstance(v, (int, float)) and 0 <= v <= 1:
            return float(v)
    return None


def nanopub(row: dict, facts: set[str], generated_at: str, commit: str = "") -> str:
    """TriG for one published proof row ({"id", "proof": {...}})."""
    p = row.get("proof", row)
    body = json.dumps({"id": row.get("id", ""), "proof": {k: p.get(k) for k in ("title", "conclusion", "steps")}},
                      ensure_ascii=False, sort_keys=True, default=str)
    this = BASE + hashlib.sha256(body.encode()).hexdigest()[:32]
    sub = this + "#"
    steps = p.get("steps", [])
    used = {i for s in steps for i in s.get("inputs", [])}
    ids = [s.get("id") or f"s{i}" for i, s in enumerate(steps)]
    feeding = [_local(s.get("id", ""), i) for i, s in enumerate(steps) if ids[i] not in used]

    L = [f"<{sub}Head> {{", f"  <{this}> a np:Nanopublication ;", f"    np:hasAssertion <{sub}assertion> ;",
         f"    np:hasProvenance <{sub}provenance> ;", f"    np:hasPublicationInfo <{sub}pubinfo> .", "}", "",
         f"<{sub}assertion> {{", f"  <{sub}conclusion> a pmpol:Conclusion ;",
         f"    rdfs:label {_lit(p.get('title', ''))} ;", f"    pmpol:statement {_lit(p.get('conclusion', ''))} ;",
         f"    pmpol:knowledgeLayer {_lit(p.get('layer', 'L5'), None)} ;",
         f"    pmpol:analyticConfidence {_lit(p.get('analytic_confidence', ''), None)} ;",
         f"    pmpol:grounded {'true' if p.get('grounded') else 'false'}"]
    prob = _probability(p.get("result") or {})
    if prob is not None:
        L[-1] += " ;"
        L.append(f'    pmpol:probability "{prob:.4f}"^^xsd:decimal')
    if row.get("id"):
        L[-1] += " ;"
        L.append(f"    pmpol:signal {_lit(row['id'], None)}")
    L[-1] += " ."
    L += ["}", "", f"<{sub}provenance> {{"]
    if feeding:
        L.append(f"  <{sub}assertion> prov:wasDerivedFrom " + ", ".join(f"<{sub}{x}>" for x in feeding) + " .")
    for i, s in enumerate(steps):
        node = f"<{sub}{_local(s.get('id', ''), i)}>"
        parts = [f"  {node} a pmpol:Step", f"pmpol:layer {_lit(s.get('layer', ''), None)}",
                 f"pmpol:kind {_lit(s.get('kind', ''), None)}", f"rdfs:label {_lit(s.get('text', ''))}"]
        if s.get("as_of"):
            parts.append(f"pmpol:asOf {_lit(s['as_of'], None)}")
        derived = [f"<{sub}{_local(x, ids.index(x))}>" for x in s.get("inputs", []) if x in ids]
        if s.get("ref"):
            derived.append(_source(s["ref"], facts))
        if derived:
            parts.append("prov:wasDerivedFrom " + ", ".join(derived))
        L.append(" ;\n    ".join(parts) + " .")
    L += ["}", "", f"<{sub}pubinfo> {{", f"  <{this}> prov:wasAttributedTo pmpol:system ;",
          f'    prov:generatedAtTime "{generated_at}"^^xsd:dateTime ;', f"    dct:rights {_lit(TERMS, 'en')}"
          + (" ;" if commit else " ."),
          ]
    if commit:
        L.append(f"    pmpol:commit {_lit(commit, None)} .")
    L += ["}", ""]
    return "\n".join(L)


def document(rows: list[dict], facts: set[str], generated_at: str, commit: str = "") -> str:
    head = [f"@prefix {k}: <{v}> ." for k, v in PREFIXES.items()]
    return "\n".join(head) + "\n\n" + "\n".join(nanopub(r, facts, generated_at, commit) for r in rows)
