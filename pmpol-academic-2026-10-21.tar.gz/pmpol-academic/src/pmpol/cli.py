"""Command line entry point.

  pmpol senate      price 2026 Senate seat/control/combo markets off the race markets
  pmpol scan        model-free consistency scan over all political events on both venues
  pmpol universe    the whole political universe: tag, cluster, relate across events and venues
  pmpol kb          the layered knowledge base (validate / verify / show)
"""

from __future__ import annotations

import argparse
import os
import itertools
import sys
from datetime import datetime, timezone
from pathlib import Path

from pmpol import constraints, store
from pmpol.senate import analyze
from pmpol.senate.config import DEFAULT_CONFIG, load_config
from pmpol.venues import VENUES
from pmpol.venues.kalshi import KalshiClient
from pmpol.venues.polymarket import PolymarketClient

KALSHI_POLITICAL = {"Politics", "Elections", "World"}
POLYMARKET_TAGS = ("politics", "elections", "geopolitics", "world")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _snapshot_time(path: Path) -> str:
    """Quote time from a snapshot file name like universe_20261002T1509Z.json.gz."""
    import re

    m = re.search(r"(\d{8})T(\d{4})Z", path.name)
    if not m:
        return ""
    d, t = m.groups()
    return f"{d[:4]}-{d[4:6]}-{d[6:]}T{t[:2]}:{t[2:]}+00:00"


def cmd_senate(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    if args.snapshot_in:
        snap = analyze.load_snapshot(Path(args.snapshot_in))
    else:
        snap = analyze.fetch_snapshot(cfg)
    stamp = _now().strftime("%Y%m%dT%H%MZ")
    if not args.snapshot_in:
        analyze.save_snapshot(snap, Path("data/snapshots") / f"senate_{stamp}.json")

    res = analyze.run(cfg, snap, rho=args.rho, min_edge=args.min_edge, nu=args.nu, tails=args.tails,
                      clusters=args.clusters)
    report = analyze.render_report(res, _now().strftime("%Y-%m-%d %H:%M UTC"))
    print(report)
    if args.report:
        out = Path(args.report)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(report)
        print(f"\nreport written to {out}", file=sys.stderr)
    with store.connect() as conn:
        store.save_events(conn, [e for d in snap.race_events.values() for e in d.values()])
        store.save_events(conn, snap.observable_events.values())
        store.save_signals(conn, res.signals)
    return 0


def cmd_scan(args: argparse.Namespace) -> int:
    events = []
    if args.venue in ("kalshi", "both"):
        events += list(KalshiClient().iter_events(categories=KALSHI_POLITICAL))
    if args.venue in ("polymarket", "both"):
        seen = set()
        pm = PolymarketClient()
        for tag in POLYMARKET_TAGS:
            for e in pm.iter_events(tag_slug=tag):
                if e.event_id not in seen:
                    seen.add(e.event_id)
                    events.append(e)
    print(f"scanned {len(events)} events", file=sys.stderr)

    signals = constraints.scan(events, min_edge=args.min_edge)
    for s in itertools.islice(signals, args.limit):
        p = s.payload
        print(f"{s.edge * 100:+6.2f}  {s.kind:9s} {s.subject}  {p.get('title', '')[:70]}")
        for k in ("buy", "sell"):
            if k in p:
                print(f"          {k}: {p[k]}")
        if "legs" in p and len(p["legs"]) <= 12:
            for leg in p["legs"]:
                print(f"          leg: {leg}")
    with store.connect() as conn:
        store.save_events(conn, events)
        store.save_signals(conn, signals)
    return 0


def cmd_universe(args: argparse.Namespace) -> int:
    from collections import defaultdict

    from pmpol import contracts, runs
    from pmpol.universe import pipeline

    with runs.track("universe", vars(args)) as run:
        if args.snapshot_in:
            snap = Path(args.snapshot_in)
            if args.snapshot_in == "latest":  # the newest snapshot on disk (e.g. to recompute after `pmpol people`)
                snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
                if not snaps:
                    print("no snapshot: run `pmpol universe` first", file=sys.stderr)
                    return 1
                snap = snaps[-1]
            events = pipeline.load_snapshot(snap)
            observed = _snapshot_time(snap)
            run.read(snap)
        else:
            events = pipeline.crawl(tuple(v.strip() for v in args.venues.split(",") if v.strip()), run=run)
            stamp = _now().strftime("%Y%m%dT%H%MZ")
            observed = _now().isoformat(timespec="minutes")
            snap = Path("data/snapshots") / f"universe_{stamp}.json.gz"
            pipeline.save_snapshot(events, snap)
            run.wrote(snap, rows=len(events))
        by_venue = defaultdict(list)
        for e in events:
            by_venue[e.venue].append(e)
        with store.connect() as conn:
            prev = runs.previous_counts(conn) if not args.snapshot_in else {}
        for v, es in sorted(by_venue.items()):
            run.check(contracts.venue_checks(v, es, prev.get(f"venue:{v}") if not args.snapshot_in else None))
        from pmpol.universe.relations import RecordedBooks, VenueBooks, depth_path

        recorded = depth_path(snap)
        replay = bool(args.snapshot_in) and recorded.exists()
        books = RecordedBooks.load(recorded) if replay else RecordedBooks(VenueBooks())
        res = pipeline.run(events, min_edge=args.min_edge, depth=not args.no_depth, entities=not args.no_entities,
                           books=books, observed_at=observed, run_id=run.id)
        if replay:
            run.read(recorded)
            run.counts["depth_replayed"] = True
        elif not args.snapshot_in and not args.no_depth:  # a fresh crawl: keep the books with the snapshot
            books.save(recorded)
            run.wrote(recorded, rows=len(books.recorded))
        terms = runs.licence_terms(by_venue)
        n_proofs = pipeline.export_proofs(res, Path("data/proofs.json"))
        if res.coherence is not None:
            import json

            from pmpol import coherence

            summ = coherence.summary(res.coherence, res.universe)
            Path("data/coherence.json").write_text(json.dumps({"observed_at": observed, **summ}, ensure_ascii=False))
            run.wrote("data/coherence.json", licence=terms)
            run.counts.update({"coherence_distance": summ["distance"], "coherence_markets": summ["markets"]})
        run.wrote("data/proofs.json", rows=n_proofs, licence=terms)
        run.check(contracts.proof_checks("proofs:universe", "data/proofs.json"))
        from pmpol import judgments

        with store.connect() as conn:  # the judgment log: values every run, inputs when a judgment changes
            run.counts["judgments_changed"] = judgments.record(
                conn, [(jid, "consensus" if jid.startswith("consensus:") else "relation" if jid.startswith("onto:")
                        else jid.split(":", 1)[0], p.title, p.to_dict()) for jid, p in res.proofs.items()],
                ts=observed, run_id=run.id)
        from pmpol.kb import KnowledgeBase

        run.check(contracts.rule_checks(res.rule_relations, KnowledgeBase.load()))
        from pmpol.audit import grounding

        run.counts.update({"propositions": res.n_props, "unread": len(res.unread),
                           "grounding": dict(grounding(res.rule_relations))})
        residual_lines = _residual(res, snap, observed, run)
        report = pipeline.render_report(res, _now().strftime("%Y-%m-%d %H:%M UTC"), residual_lines=residual_lines)
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_universe.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(report)
        run.wrote(out, licence=terms)
        pipeline.export_graph(res, Path(args.graph))
        run.wrote(args.graph, licence=terms)
        u = res.universe
        with store.connect() as conn:
            new_quotes = store.save_events(conn, u.events.values(), observed_at=observed, run_id=run.id)
            store.save_tags(conn, [(e, u.tags[k], u.clusters.get(k)) for k, e in u.events.items()])
            store.save_relations(conn, res.rule_relations + res.text_relations)
            store.save_signals(conn, res.rule_signals + res.text_signals + res.event_signals, observed_at=observed,
                               run_id=run.id)
            # Consensus estimates, kept so they can be scored against outcomes (signal registry).
            store.save_signals(conn, [pipeline.consensus_signal(c) for c in res.consensus], observed_at=observed,
                               run_id=run.id)
            if res.entity_graph is not None:
                store.save_entities(conn, res.entity_graph)
        if res.entity_graph is not None:
            from pmpol.entities.graph import export, export_ftm
            export(res.entity_graph, Path("data/entity_graph.json"))
            export_ftm(res.entity_graph, Path("data/entities.ftm.jsonl"))
        run.counts.update({"observed_at": observed, "events": len(u.events), "markets": len(u.markets),
                           "rule_relations": len(res.rule_relations), "violations": len(res.rule_signals),
                           "consensus": len(res.consensus), "proofs": n_proofs, "new_quotes": new_quotes,
                           "relation_source": "ontology", "text_relations": len(res.text_relations)})
        if res.crosscheck is not None:  # templates run alongside as a cross-check
            run.counts.update({"template_agree": len(res.crosscheck.agree),
                               "template_differ": len(res.crosscheck.disagree),
                               "template_not_read": len(res.crosscheck.not_covered),
                               "template_only_violations": len(res.template_only)})
        if not args.no_depth and not replay:  # order books read live (no recording for this snapshot): say when
            run.counts["depth_observed_at"] = _now().isoformat(timespec="minutes")
    bad = [c for c in run.checks if not c.ok]
    print(f"{len(u.events):,} events, {len(res.rule_relations):,} rule relations, "
          f"{len(res.rule_signals)} rule violations -> {out}, graph -> {args.graph}, {n_proofs} proofs -> "
          f"data/proofs.json; run {run.id}, {len(bad)} failed checks", file=sys.stderr)
    return 0


def _residual(res, snap: Path, observed: str, run) -> list[str]:
    """Residual monitor for the universe report: what the taxonomy and the ontology cannot read, against the
    previous snapshot and recent runs (pmpol.residual)."""
    from pmpol import residual
    from pmpol.propositions.derive import parse_universe
    from pmpol.universe import pipeline

    parsed = parse_universe(res.universe)
    older = [p for p in sorted(Path("data/snapshots").glob("universe_*.json.gz"))
             if p.resolve() != snap.resolve() and _snapshot_time(p) < (_snapshot_time(snap) or observed)]
    prev_keys = {e.key for e in pipeline.load_snapshot(older[-1])} if older else None
    r = residual.compute(res.universe, parsed.unparsed, {p.market for p in parsed.props}, prev_keys,
                         _snapshot_time(older[-1]) if older else "")
    run.counts.update(r.counts())
    with store.connect() as conn:
        history = residual.trend(conn)
    history.append((run.id, {**r.counts(), "observed_at": observed}))
    return residual.render(res.universe, r, history)


def cmd_kb(args: argparse.Namespace) -> int:
    from collections import Counter

    from pmpol.kb import KnowledgeBase, verify_sources

    kb = KnowledgeBase.load()
    if args.action == "validate":
        counts = Counter((f.layer, f.status) for f in kb.facts.values())
        print(f"{len(kb.facts)} facts: " + ", ".join(f"{layer} {s} {n}" for (layer, s), n in sorted(counts.items())))
        for e in kb.errors:
            print("ERROR", e)
        return 1 if kb.errors else 0
    if args.action == "derive":
        from pmpol.kb.derived import check

        rows = check(kb)
        for r in rows:
            print(f"{'OK  ' if r['ok'] else 'DIFF'} {r['fact']}: kb={r['kb']} computed={r['computed']} ({r['note']})")
        return 0 if all(r["ok"] for r in rows) else 1
    if args.action == "history":  # every committed version of one fact
        from pmpol.kb.history import versions

        for v in versions(args.query or ""):
            print(f"{v.when:%Y-%m-%d %H:%M} {v.commit} {v.change:8} {v.status:9} {v.value!r}  {v.source}")
        return 0
    if args.action == "as-of":  # what the knowledge base said at a past time
        from datetime import datetime

        from pmpol.kb.history import as_of

        old, sha = as_of(datetime.fromisoformat(args.query))
        added = sorted(set(kb.facts) - set(old.facts))
        changed = sorted(i for i in set(kb.facts) & set(old.facts)
                         if repr(kb.facts[i].value) != repr(old.facts[i].value) or kb.facts[i].status != old.facts[i].status)
        print(f"as of {args.query}: commit {sha}, {len(old.facts)} facts (now {len(kb.facts)}); "
              f"added since {len(added)}, changed since {len(changed)}")
        for i in changed:
            print(f"  changed {i}: {old.facts[i].value!r} ({old.facts[i].status}) -> {kb.facts[i].value!r} ({kb.facts[i].status})")
        for i in added[:20]:
            print(f"  added {i}")
        return 0
    if args.action == "verify":
        results = verify_sources(kb)
        bad = {k: v for k, v in results.items() if v not in ("verified", "no quote", "computed", "dataset")}
        print(f"verified {sum(v == 'verified' for v in results.values())}, "
              f"computed by this system {sum(v == 'computed' for v in results.values())}, "
              f"datasets {sum(v == 'dataset' for v in results.values())}, "
              f"text sources without a quote {sum(v == 'no quote' for v in results.values())}, problems {len(bad)}")
        for k, v in sorted(results.items()):
            if v == "no quote":
                print(f"  no quote: {k}")
        for k, v in sorted(bad.items()):
            print(f"  {k}: {v}")
        return 1 if bad else 0
    # show
    for f in kb.facts.values():
        if args.query and args.query.lower() not in f"{f.id} {f.subject}".lower():
            continue
        print(f"{f.id} [{f.layer} {f.status} {f.admiralty}] {f.subject} — {f.predicate}: {f.value}")
        print(f"    {f.source.title} <{f.source.url}>" + (f"\n    “{f.source.quote}”" if f.source.quote else ""))
    return 0


def cmd_macro(args: argparse.Namespace) -> int:
    from pmpol import runs
    from pmpol.macro.sources import fetch_all, load_specs

    with runs.track("macro", vars(args)) as run:
        return _macro(args, run, fetch_all(load_specs()))


def _macro(args: argparse.Namespace, run, fetched) -> int:
    import json
    from collections import defaultdict

    from pmpol import contracts
    from pmpol.kb import KnowledgeBase
    from pmpol.macro import report as macro_report
    from pmpol.macro.regimes import MacroData

    by_source = defaultdict(list)
    for f in fetched:
        by_source[f.spec.source].append(f)
    for src, fs in sorted(by_source.items()):
        failed = [f.spec.id for f in fs if not f.observations]
        run.source(f"macro:{src}", len(failed) < len(fs), len(fs) - len(failed),
                   error=f"{len(failed)} of {len(fs)} series failed: " + ", ".join(failed[:5]) if failed else "")
    with store.connect() as conn:
        new, revised = store.save_macro(conn, fetched)
        stale = store.fill_failed_macro(conn, fetched)  # last good data, marked stale, when a source is down
    run.check(contracts.macro_checks(fetched, _now().date()))
    events = tags = None
    observed = ""  # quote time of the related markets: every L4 step carries the time it refers to
    snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
    if args.snapshot_in or snaps:
        from pmpol.universe import pipeline
        from pmpol.universe.taxonomy import tag_event

        snap = Path(args.snapshot_in) if args.snapshot_in else snaps[-1]
        events = pipeline.load_snapshot(snap)
        observed = _snapshot_time(snap)
        run.read(snap)
        tags = {e.key: tag_event(e).topic for e in events}
    kb = KnowledgeBase.load()
    text = macro_report.render(fetched, kb, _now().strftime("%Y-%m-%d %H:%M UTC"), events, tags, observed)
    out = Path(args.report or f"reports/{_now():%Y-%m-%d}_macro.md")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text)
    from pmpol.goals import goal_proof, load_goals

    data = MacroData.from_fetched(fetched)
    proofs = [p.to_dict() for p in macro_report.run_regimes(data, kb)]
    proofs += [goal_proof(g, kb, events, data, observed).to_dict() for g in load_goals()]
    Path("data/macro").mkdir(parents=True, exist_ok=True)
    Path("data/macro/regimes.json").write_text(json.dumps(proofs, ensure_ascii=False, default=str, indent=1))
    run.check(contracts.proof_checks("proofs:macro", "data/macro/regimes.json"))
    run.wrote(out)
    run.wrote("data/macro/regimes.json", rows=len(proofs))
    ok = sum(1 for f in fetched if f.observations)
    run.counts.update({"series": len(fetched), "series_ok": ok, "stale": stale, "new": new, "revised": revised})
    print(f"{ok}/{len(fetched)} series ({stale} from stored data), {new} new and {revised} revised observations, "
          f"{len(proofs)} regime proofs "
          f"-> {out}, data/macro/regimes.json", file=sys.stderr)
    return 0


def cmd_track(args: argparse.Namespace) -> int:
    from pmpol import runs, track
    from pmpol.universe.pipeline import load_snapshot

    snaps = [(_snapshot_time(p), p) for p in sorted(Path("data/snapshots").glob("universe_*.json.gz"))]
    pairs = track.pick_pairs(snaps, min_hours=args.min_hours)
    if not pairs:
        print("need universe snapshots at least --min-hours apart: run `pmpol universe` again later", file=sys.stderr)
        return 1
    with runs.track("track", vars(args)) as run:
        cache = {}

        def get(i):
            if i not in cache:
                cache[i] = track.universe_with_relations(load_snapshot(snaps[i][1]))
                run.read(snaps[i][1])
            return cache[i]

        onto_cache = {}

        def onto(i):  # the coherence claim is defined on the ontology's relations, the others on the templates
            if i not in onto_cache:
                from pmpol.entities import wd_peps
                from pmpol.entities.graph import load_index
                from pmpol.propositions import relations as onto_rel

                u = get(i)[0]
                from pmpol.entities import wikidata

                onto_cache[i] = onto_rel.build(u, index=load_index(u, log=open(os.devnull, "w")),
                                               wd_people=wd_peps.load(), candidacies=wikidata.load()).relations
            return onto_cache[i]

        results = [track.evaluate_pair(get(i), get(j)[0], snaps[i][0], snaps[j][0], onto=onto(i)) for i, j in pairs]
        claims = track.load_registry()
        from pmpol.track import leads

        with store.connect() as conn:  # silent leads old enough: search the news after them
            fu = leads.follow_up(conn) if not args.no_news else {"due": 0, "checked": 0, "failed": 0}
            if not args.no_news:
                leads.backfill_drift(conn)
            lead_summary = leads.summary(conn)
        if fu["due"]:
            run.source("news:lead_followup", fu["failed"] < fu["due"], fu["checked"],
                       error=f"{fu['failed']} of {fu['due']} searches failed" if fu["failed"] else "")
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_track.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        chain = [(snaps[i][0], get(i)) for i in range(len(snaps))]  # every snapshot, in time order
        gap_spells = track.spells(chain)
        from pmpol.track import ic

        scores = {i: {"outlier": ic.outlier_scores(*get(i)), "coherence": ic.coherence_scores(get(i)[0], onto(i))}
                  for i in range(len(snaps) - 1)}
        reg = next((c.registered_at for c in claims if c.id == "reversion_ic"), "")
        ic_rows = ic.table(ic.observations([(t, u) for t, (u, _) in chain], scores), reg)
        out.write_text(track.render(results, claims, _now().strftime("%Y-%m-%d %H:%M UTC"), lead_summary, gap_spells)
                       + "\n".join(ic.render(ic_rows, reg)) + "\n")
        run.wrote(out, licence=runs.licence_terms({e.venue for u, _ in cache.values() for e in u.events.values()}))
        summary = track.summarize(results, claims)
        run.counts.update({"pairs": len(pairs), "gap_spells": len(gap_spells), **{k: v["n"] for k, v in summary.items()},
                           "ic_observations": sum(r.n for r in ic_rows)})
    print(f"{len(pairs)} snapshot pairs -> {out}", file=sys.stderr)
    return 0


def cmd_assumptions(args: argparse.Namespace) -> int:
    from pmpol import assumptions

    rows = assumptions.load_proof_rows([Path("data/proofs.json"), Path("data/movers.json"),
                                        Path("data/macro/regimes.json")])
    text = assumptions.render(rows, _now().date())
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        Path(args.report).write_text(text)
        print(f"-> {args.report}", file=sys.stderr)
    else:
        print(text)
    return 0


# One cycle, in dependency order (an asset graph kept as a list): each step reads what earlier ones wrote.
CYCLE = (
    ("people", ["people"], ()),  # identities for the universe step; a failure leaves the previous subset
    ("candidates", ["candidates"], ()),  # L1 candidate lists (cached 7 days); a failure keeps the previous lists
    ("baseline", ["baseline"], ()),  # series for the official-statistics baseline; a failure keeps the cached ones
    ("universe", ["universe"], ()),
    ("macro", ["macro"], ()),
    ("settle", ["settle"], ("universe",)),
    ("movers", ["movers"], ("universe",)),
    ("track", ["track"], ("universe",)),
    ("assumptions", ["assumptions", "--report", "reports/{date}_assumptions.md"], ("universe", "movers", "macro")),
    ("status", ["status", "--report", "reports/{date}_status.md"], ()),
    ("signposts", ["signposts"], ("universe",)),
    ("newswatch", ["newswatch"], ()),
    ("gdelt", ["gdelt", "--report", "reports/{date}_gdelt.md"], ()),
    ("cn-household", ["cn-household"], ()),
    ("external", ["external", "--report", "reports/{date}_external.md"], ("universe",)),
    ("house", ["house", "--report", "reports/{date}_house.md"], ("universe",)),
    ("requirements", ["requirements"], ("universe",)),
    ("premortem", ["premortem"], ("universe",)),
    ("brief", ["brief"], ("universe",)),
    ("prov", ["prov"], ("universe", "macro", "movers")),
    ("geo", ["geo"], ("universe",)),
    ("viewer", ["viewer"], ("universe", "macro", "movers")),
)


# A fresh cloud environment has no history in data/: only steps that need a single snapshot, with reports kept
# apart from the full cycle's (reports/cloud/) so the two schedulers never write the same file.
CLOUD_CYCLE = (
    # crawl first: `pmpol people` picks the Wikidata subset by the surnames in a snapshot, then the snapshot is
    # read again so the report uses those identities
    ("crawl", ["universe", "--report", "reports/cloud/{date}_universe.md"], ()),
    ("people", ["people"], ("crawl",)),
    ("candidates", ["candidates"], ("crawl",)),
    ("universe", ["universe", "--snapshot-in", "latest", "--report", "reports/cloud/{date}_universe.md"], ("crawl",)),
    ("macro", ["macro", "--report", "reports/cloud/{date}_macro.md"], ()),
    ("settle", ["settle", "--report", "reports/cloud/{date}_settlement.md"], ("universe",)),
    ("propositions", ["propositions", "--report", "reports/cloud/{date}_propositions.md"], ("universe",)),
    ("signposts", ["signposts", "--report", "reports/cloud/{date}_signposts.md"], ("universe",)),
    ("requirements", ["requirements", "--report", "reports/cloud/{date}_requirements.md"], ("universe",)),
    ("premortem", ["premortem", "--report", "reports/cloud/{date}_premortem.md"], ("universe",)),
    ("brief", ["brief", "--report", "reports/cloud/{date}_brief.md", "--reports-dir", "reports/cloud"], ("universe",)),
)


def cmd_cycle(args: argparse.Namespace) -> int:
    """Run every step once. A failed step is recorded and skips the steps that depend on it; the rest run."""
    from pmpol import runs

    skip = {s.strip() for s in args.skip.split(",") if s.strip()}
    failed: set[str] = set()
    steps = CLOUD_CYCLE if getattr(args, "profile", "full") == "cloud" else CYCLE
    with runs.track("cycle", vars(args)) as run:
        for name, argv, needs in steps:
            if name in skip:
                continue
            if failed & set(needs):
                run.source(f"step:{name}", False, error="skipped: " + ", ".join(sorted(failed & set(needs))) + " failed")
                failed.add(name)
                continue
            argv = [a.format(date=f"{_now():%Y-%m-%d}") for a in argv]
            if name in ("movers", "track") and args.no_news:
                argv.append("--no-news")
            t0 = _now()
            try:
                code = main(argv)
                ok = code == 0
                err = "" if ok else f"exit code {code}"
            except Exception as e:  # one step failing must not stop independent ones
                ok, err = False, f"{type(e).__name__}: {e}"
            run.source(f"step:{name}", ok, seconds=(_now() - t0).total_seconds(), error=err)
            print(f"[cycle] {name}: {'ok' if ok else 'FAILED ' + err}", file=sys.stderr)
            if not ok:
                failed.add(name)
        run.counts.update({"steps": len(steps) - len(skip & {n for n, _, _ in steps}), "failed": sorted(failed)})
    return 1 if failed else 0


def cmd_propositions(args: argparse.Namespace) -> int:
    """Experimental: read a snapshot through the proposition ontology and compare with the templates."""
    from pmpol import runs
    from pmpol.propositions import report as prop_report
    from pmpol.universe import pipeline
    from pmpol.universe.cluster import build_clusters
    from pmpol.universe.index import Universe
    from pmpol.universe.relations import build_relations

    snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
    snap = Path(args.snapshot_in) if args.snapshot_in else (snaps[-1] if snaps else None)
    if snap is None:
        print("no snapshot: run `pmpol universe` first", file=sys.stderr)
        return 1
    with runs.track("propositions", vars(args)) as run:
        run.read(snap)
        u = Universe.build(pipeline.load_snapshot(snap))
        build_clusters(u)
        from pmpol.entities import wd_peps
        from pmpol.entities.graph import load_index

        from pmpol.entities import wikidata

        parsed, derived, comp, viol = prop_report.run(u, build_relations(u), load_index(u), wd_peps.load(),
                                                      wikidata.load())
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_propositions.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(prop_report.render(u, parsed, derived, comp, viol, _now().strftime("%Y-%m-%d %H:%M UTC"),
                                          _snapshot_time(snap)))
        run.wrote(out, licence=runs.licence_terms({e.venue for e in u.events.values()}))
        run.counts.update({"propositions": len(parsed.props), "agree": len(comp.agree),
                           "disagree": len(comp.disagree), "new": len(comp.new), "violations": len(viol)})
    print(f"{len(parsed.props):,} propositions; templates: {len(comp.agree):,} agree, {len(comp.disagree)} differ; "
          f"{len(comp.new):,} new relations, {len(viol)} violated -> {out}", file=sys.stderr)
    return 0


def cmd_settle(args: argparse.Namespace) -> int:
    """Settlement-data checks: markets that settle on a public series we read, evaluated on published data."""
    import json

    from pmpol import runs
    from pmpol.osint.portwatch import LICENCE
    from pmpol.settlement import report as settle_report
    from pmpol.universe import pipeline

    snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
    snap = Path(args.snapshot_in) if args.snapshot_in else (snaps[-1] if snaps else None)
    if snap is None:
        print("no snapshot: run `pmpol universe` first", file=sys.stderr)
        return 1
    with runs.track("settle", vars(args)) as run:
        run.read(snap)
        events = pipeline.load_snapshot(snap)
        observed = _snapshot_time(snap)
        try:
            checks, data, unread = settle_report.run(events)
        except Exception as e:  # a source is down: say so, do not guess
            run.source("osint:settlement_sources", False, error=str(e))
            raise
        for series, rows in data.items():
            run.source(f"osint:{series}", bool(rows), len(rows))
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_settlement.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(settle_report.render(checks, data, unread, _now().strftime("%Y-%m-%d %H:%M UTC")))
        from pmpol.venues import info

        proofs = [{"id": f"settle:{ch.market.key}", "group": "settlement", "kind": ch.decision.state,
                   "subject": ch.event_title, "edge": round(ch.mismatch or 0.0, 4),
                   "title": f"{ch.event_title}｜{ch.market.outcome}",
                   "venues": [info(ch.market.venue).code], "confidence": "rule",
                   "proof": (p := settle_report.explain(ch, observed)).to_dict() | {"graph": p.graph()}}
                  for ch in checks if ch.decision.state != "open" or ch.decision.value is not None]
        # proxies: markets settling on a source we cannot read (Cloudflare Radar), next to one we can (IODA)
        from pmpol.osint import ioda

        proxies = []
        for e in events:
            for m in e.markets:
                if m.active and "cloudflare radar data for iran" in (m.rules or "").lower():
                    try:
                        lv = ioda.levels(ioda.fetch("ir"))
                    except Exception as ex:  # a refusal: no proxy this run
                        run.source("osint:ioda", False, error=str(ex))
                        lv = []
                    if lv:
                        run.source("osint:ioda", True, len(lv))
                        p = ioda.proof(m, e.title, "ir", lv, observed)
                        proxies.append({"id": f"proxy:{m.key}", "group": "settlement", "kind": "osint_proxy",
                                        "subject": e.title, "edge": 0.0, "title": p.title,
                                        "venues": [info(m.venue).code], "confidence": "rule",
                                        "proof": p.to_dict() | {"graph": p.graph()}})
        if proxies:
            with out.open("a", encoding="utf-8") as f:
                f.write("\n## 旁證：結算來源讀不到的市場\n\n" + "\n".join(
                    f"- {r['title']}：{r['proof']['conclusion']}" for r in proxies) + "\n")
        Path("data/settlement.json").write_text(json.dumps({"signals": proofs + proxies}, ensure_ascii=False,
                                                           default=str))
        from pmpol.contracts import proof_checks

        run.check(proof_checks("proofs:settle", "data/settlement.json"))
        from pmpol.macro.eia import LICENCE as EIA_LICENCE

        terms = runs.licence_terms({ch.market.venue for ch in checks}) + [LICENCE] + \
            ([EIA_LICENCE] if any(k.startswith("eia:") for k in data) else [])
        run.wrote(out, licence=terms)
        run.wrote("data/settlement.json", rows=len(proofs), licence=terms)
        flagged = sum((ch.mismatch or 0) >= 0.05 for ch in checks)
        run.counts.update({"markets": len(checks), "decided": sum(ch.decision.state != "open" for ch in checks),
                           "mispriced": flagged})
    print(f"{len(checks)} markets read, {sum(ch.decision.state != 'open' for ch in checks)} decided, "
          f"{flagged} priced against published data -> {out}", file=sys.stderr)
    return 0


def cmd_people(args: argparse.Namespace) -> int:
    """Refresh the Wikidata politicians extract (OpenSanctions wd_peps) and its subset for our markets' names, and
    the candidacies in upcoming elections (Wikidata query service)."""
    import time

    from pmpol import runs
    from pmpol.entities import wd_peps
    from pmpol.entities.sources import name_variants
    from pmpol.universe import pipeline
    from pmpol.universe.outcomes import _norm

    snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
    if not snaps:
        print("no snapshot: run `pmpol universe` first", file=sys.stderr)
        return 1
    with runs.track("people", vars(args)) as run:
        raw = wd_peps.RAW
        if raw.exists() and time.time() - raw.stat().st_mtime > args.max_age_days * 86400:
            raw.unlink()  # refresh the extract (OpenSanctions republishes it daily)
        t0 = time.monotonic()
        try:
            wd_peps.download(raw)
            run.source("wikidata:wd_peps", True, seconds=time.monotonic() - t0)
        except Exception as e:  # keep the previous subset; people fall back to local identities
            run.source("wikidata:wd_peps", False, seconds=time.monotonic() - t0, error=str(e))
            print(f"wd_peps download failed: {e}", file=sys.stderr)
            return 1
        run.read(snaps[-1])
        events = pipeline.load_snapshot(snaps[-1])
        surnames = {v.split()[-1] for e in events for m in e.markets for v in name_variants(m.outcome)
                    if len(v.split()) >= 2}
        people = wd_peps.compact(raw, surnames, lambda n: _norm(n).replace(".", ""))
        wd_peps.save(people)
        run.wrote(wd_peps.COMPACT, rows=len(people), licence=[wd_peps.LICENCE])
        run.counts.update({"surnames": len(surnames), "people": len(people)})
        from pmpol.entities import wikidata

        t0 = time.monotonic()
        try:  # candidacies in upcoming elections, queried directly; a refusal keeps the previous file
            cands = wikidata.refresh()
            run.source("wikidata:candidacies", True, len(cands), seconds=time.monotonic() - t0)
            run.wrote(wikidata.CANDIDACIES, rows=len(cands), licence=[wikidata.LICENCE])
            run.counts["candidacies"] = len(cands)
        except Exception as e:
            run.source("wikidata:candidacies", False, seconds=time.monotonic() - t0, error=str(e))
            print(f"Wikidata candidacies unavailable, keeping the previous file: {e}", file=sys.stderr)
    print(f"{len(people):,} Wikidata politicians with a surname seen in our markets -> {wd_peps.COMPACT}",
          file=sys.stderr)
    return 0


def cmd_scheduled(args: argparse.Namespace) -> int:
    """One cycle for a scheduler (cron, systemd, launchd): lock, time limit, log, optional commit and notification."""
    from pmpol import schedule

    cycle_args = (["--skip", args.skip] if args.skip else []) + (["--no-news"] if args.no_news else []) + \
        (["--profile", args.profile] if args.profile != "full" else [])
    return schedule.run(timeout_min=args.timeout_min, pull=args.pull, commit=args.commit, push=args.push,
                        notify_url=args.notify_url or os.environ.get("PMPOL_NOTIFY_URL"), cycle_args=cycle_args)


def cmd_brief(args: argparse.Namespace) -> int:
    """One-page daily brief from the latest cycle's outputs."""
    from pmpol import brief, runs

    with runs.track("brief", vars(args)) as run:
        with store.connect() as conn:
            text = brief.render(conn, Path(args.reports_dir))
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_brief.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text)
        run.wrote(out)
    print(f"-> {out}", file=sys.stderr)
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    from pmpol import runs

    with store.connect() as conn:
        text = runs.render_status(conn, limit=args.limit)
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        Path(args.report).write_text(text)
        print(f"-> {args.report}", file=sys.stderr)
    else:
        print(text)
    return 0


def cmd_viewer(args: argparse.Namespace) -> int:
    from pmpol import viewer

    out = Path(args.out)
    stats = viewer.build(out)
    print(f"{stats['signals']} signals, {stats['macro']} macro judgments, {stats['kb']} facts, {stats['pages']} system pages "
          f"({stats['bytes'] / 1e6:.1f} MB) -> {out}", file=sys.stderr)
    if not stats["signals"]:
        print("no data/proofs.json yet: run `pmpol universe` first", file=sys.stderr)
    return 0


def cmd_truth(args: argparse.Namespace) -> int:
    from pmpol import runs

    with runs.track(f"truth_{args.action}", vars(args)) as run:
        return _truth(args, run)


def _truth(args: argparse.Namespace, run) -> int:
    from pmpol.ground_truth import DATA, load
    from pmpol.runs import licence_terms
    from pmpol.ground_truth import report as truth_report

    if args.action == "fetch":
        from pmpol.ground_truth.fetch import fetch_kalshi, fetch_polymarket

        if "kalshi" in args.venues:
            n = fetch_kalshi(per_series=args.per_series)
            run.source("truth:kalshi", True, n)
            print(f"kalshi: +{n}", file=sys.stderr)
        if "polymarket" in args.venues:
            n = fetch_polymarket(limit=args.limit)
            run.source("truth:polymarket", True, n)
            print(f"polymarket: +{n}", file=sys.stderr)
        if "manifold" in args.venues:  # an external forecaster: calibrated apart, never a consensus venue
            from pmpol.ground_truth.fetch import fetch_manifold

            n = fetch_manifold(limit=args.limit)
            run.source("truth:manifold", True, n)
            print(f"manifold: +{n}", file=sys.stderr)
        return 0
    rows = load(DATA / "kalshi.jsonl") + load(DATA / "polymarket.jsonl")
    from pmpol.ground_truth import refine_early

    run.counts.update({f"early_{k}": v for k, v in refine_early(rows).items()})  # Kalshi's flag is too wide
    if not rows:
        print("no resolved markets yet: run `pmpol truth fetch` first", file=sys.stderr)
        return 1
    if args.action == "words-deeds":
        from pmpol.ground_truth import words_deeds as wd

        summary = wd.summarize(rows)
        for r in summary:
            print(f"{r.cls:5} {r.horizon:>2}d  {r.n:5} markets {r.events:4} events  YES {100 * r.yes:5.1f}%  price "
                  f"{100 * r.price:5.1f}%  gap {100 * r.gap:+5.1f} ({100 * r.ci[0]:+.1f} to {100 * r.ci[1]:+.1f})",
                  file=sys.stderr)
        run.counts.update({f"{r.cls}_{r.horizon}d": r.n for r in summary})
        if args.write_kb:
            path = Path("kb/L2/words_deeds.yaml")
            path.write_text(wd.kb_yaml(summary, _now().date(), len(rows)), encoding="utf-8")
            run.wrote(path)
        return 0
    out = Path(args.report or f"reports/{_now():%Y-%m-%d}_calibration.md")
    out.parent.mkdir(parents=True, exist_ok=True)
    external = load(DATA / "manifold.jsonl")  # shown beside the venues; its facts go to their own file
    out.write_text(truth_report.render(rows + external, _now().strftime("%Y-%m-%d %H:%M UTC")))
    if external and args.write_kb:
        Path("kb/L2/external_calibration.yaml").write_text(truth_report.kb_yaml(external, _now().date()))
        run.wrote("kb/L2/external_calibration.yaml")
    for f in (DATA / "kalshi.jsonl", DATA / "polymarket.jsonl"):
        run.read(f)
    run.wrote(out, licence=licence_terms(["kalshi", "polymarket"]))
    run.counts["resolved_markets"] = len(rows)
    if args.write_kb:
        Path("kb/L2/market_calibration.yaml").write_text(truth_report.kb_yaml(rows, _now().date()))
        run.wrote("kb/L2/market_calibration.yaml")
    print(f"{len(rows):,} resolved markets -> {out}" + (" and kb/L2/market_calibration.yaml" if args.write_kb else ""),
          file=sys.stderr)
    return 0


def cmd_candidates(args: argparse.Namespace) -> int:
    """L1 general-election candidate lists for the U.S. races in the latest snapshot (Wikipedia, cached)."""
    from pmpol import runs
    from pmpol.entities import candidates as cand
    from pmpol.propositions.people import parse_name
    from pmpol.universe.index import Universe
    from pmpol.universe.pipeline import load_snapshot

    snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
    if not snaps:
        print("no snapshot: run `pmpol universe` first", file=sys.stderr)
        return 1
    with runs.track("candidates", vars(args)) as run:
        u = Universe.build(load_snapshot(snaps[-1]))
        run.read(snaps[-1])
        subjects = sorted({t.race_key for k, t in u.tags.items()
                           if t.topic == "elections_us" and t.measure == "winner" and t.race_key
                           and t.office in ("house", "senate", "governor") and t.stage == "general"
                           and not t.variant and str(t.year) == args.year
                           and any(parse_name(m.outcome or "") for m in u.events[k].markets)})
        subjects = [s for s in subjects if cand.page_for(s)]
        got = cand.build(subjects, pause=args.pause)
        races = {c.race for c in got}
        run.source("candidates:wikipedia", bool(got) or not subjects, len(got),
                   error="" if got or not subjects else "no page fetched (rate-limited?)")
        run.wrote(cand.DATA / "candidates.json", rows=len(got), licence=[cand.LICENCE])
        run.counts.update({"races_wanted": len(subjects), "races_listed": len(races), "candidates": len(got)})
    print(f"{len(got):,} candidates in {len(races)} of {len(subjects)} races -> {cand.DATA / 'candidates.json'}",
          file=sys.stderr)
    return 0


def cmd_audit(args: argparse.Namespace) -> int:
    """Foundation health (pmpol.audit): coverage, how relations are grounded, provenance, knowledge base."""
    from pmpol import store
    from pmpol.audit import section

    with store.connect() as conn:
        text = "\n".join(section(conn))
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        Path(args.report).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0


def cmd_rules(args: argparse.Namespace) -> int:
    """List the inference rules and their grounds, and check that every ground exists."""
    from pmpol.propositions.rules import load, validate

    from pmpol.kb import KnowledgeBase

    book, kb = load(), KnowledgeBase.load()
    print("| 規則 | 類型 | 內容 | 依據 |\n|---|---|---|---|")
    for r in book.rules.values():
        extra = f"；每條關係另加：{r.instance_grounds}" if r.instance_grounds else ""
        print(f"| `{r.id}` {r.label} | {'等價' if r.kind == 'equivalent' else '蘊含'} | {r.statement} | "
              f"{'、'.join(r.grounds)}{extra} |")
    problems = validate(book, kb)
    for x in problems:
        print(f"problem: {x}", file=sys.stderr)
    return 1 if problems else 0


def cmd_famcorr(args: argparse.Namespace) -> int:
    """Estimate the correlation between venue families' quote errors (the consensus band's rho)."""
    from pmpol import runs
    from pmpol.propositions import relations as onto_rel
    from pmpol.runs import licence_terms
    from pmpol.universe import consensus as cons
    from pmpol.universe import family_corr
    from pmpol.universe.index import Universe
    from pmpol.universe.pipeline import load_snapshot

    snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))[-args.snapshots:]
    if len(snaps) < 1:
        print("no snapshot: run `pmpol universe` first", file=sys.stderr)
        return 1
    with runs.track("famcorr", vars(args)) as run:
        # contracts: the equivalence classes of the latest snapshot (the same ones the consensus uses)
        u = Universe.build(load_snapshot(snaps[-1]))
        # structural matches only: the estimate the consensus relies on is not fitted on its own weaker matches
        classes = [(g, ks) for g, ks, _ in cons.classes(u, onto_rel.build(u).relations, admit=("rule",))]
        gaps = family_corr.collect(classes, ((s.name[9:22], load_snapshot(s)) for s in snaps))
        for s in snaps:
            run.read(s)
        if not gaps:
            print("no contract is quoted by two venue families", file=sys.stderr)
            return 1
        noisy = tuple(v.strip() for v in args.noisy.split(",") if v.strip())
        est = family_corr.estimate(gaps, noisy, reps=args.reps)
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_family_correlation.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(family_corr.render(est, _now().strftime("%Y-%m-%d %H:%M UTC")), encoding="utf-8")
        fams = {v for g in gaps for v in g.pair.split("-")}
        venues = fams | {v for v, f in cons.FAMILY.items() if f in fams}  # family members' quotes went in too
        run.wrote(out, licence=licence_terms(sorted(venues)))
        run.counts.update({"rho": round(est.rho, 3), "gaps": est.n_gaps, "contracts": est.n_contracts,
                           **{f"noise_{f}": round(v, 4) for f, v in est.noise.items()}})
        if args.write_kb:
            kb_path = Path("kb/L2/family_correlation.yaml")
            kb_path.write_text(family_corr.kb_yaml(est, _now().date()), encoding="utf-8")
            run.wrote(kb_path)
    extra = "".join(f", {f} +{100 * v:.1f} pts" for f, v in est.noise.items())
    print(f"rho = {est.rho:.2f} (95% {est.ci[0]:.2f}-{est.ci[1]:.2f}){extra} from {est.n_gaps:,} gaps on "
          f"{est.n_contracts:,} contracts, {len(snaps)} snapshots -> {out}", file=sys.stderr)
    return 0


def cmd_reference(args: argparse.Namespace) -> int:
    """Election reference classes (the outside view): the president's party's House and Senate seat changes in every
    midterm since 1946, from the House historian's and Senate Historical Office's tables and the Miller Center (cached
    under data/reference/)."""
    from pmpol import reference as refmod
    from pmpol import runs

    with runs.track("reference", vars(args)) as run:
        try:
            ref = refmod.build(pause=args.pause)
        except Exception as e:  # a refusal or an outage stops the run; nothing is retried or disguised
            run.source("reference", False, error=str(e))
            print(f"cannot fetch the reference tables: {e}", file=sys.stderr)
            return 1
        rows = ref.rows
        run.source("reference", bool(rows), len(rows))
        run.counts.update({"midterms": len(rows), "congresses": len(ref.house), "presidents": len(ref.parties),
                           "lost": sum(r["change"] < 0 for r in rows), "senate_midterms": len(ref.senate_rows)})
        if args.write_kb:
            l1, l2 = refmod.kb_yaml(ref, _now().date())
            files = [(Path("kb/L1/us_house_history.yaml"), l1), (Path("kb/L2/election_reference.yaml"), l2)]
            if ref.senate:
                files.append((Path("kb/L1/us_senate_history.yaml"), refmod.senate_kb_yaml(ref, _now().date())))
            for path, text in files:
                path.write_text(text, encoding="utf-8")
                run.wrote(path, licence=sorted(set(refmod.LICENCE.values())))
    senate = {r["year"]: r["change"] for r in ref.senate_rows}
    for r in rows:
        s = f"{senate[r['year']]:+4d}" if r["year"] in senate else "   —"
        print(f"{r['year']}  {r['party']}  house {r['change']:+4d}  senate {s}  {r['president']}")
    print(f"{len(rows)} midterms; the president's party lost seats in {sum(r['change'] < 0 for r in rows)}",
          file=sys.stderr)
    return 0


def cmd_review(args: argparse.Namespace) -> int:
    """Human review of knowledge-base facts under the two-person rule (pmpol.review)."""
    from pmpol import review
    from pmpol.kb import KnowledgeBase, verify_sources

    kb = KnowledgeBase.load()
    if args.action.startswith("agents"):
        return _agent_review(args, kb)
    if args.action in review.DECISIONS:
        if not args.fact or args.fact not in kb.facts:
            print(f"unknown fact: {args.fact!r}", file=sys.stderr)
            return 1
        try:
            r = review.decide(kb, args.fact, args.action, args.reviewer or "", args.note or "")
        except PermissionError as e:
            print(f"refused: {e}", file=sys.stderr)
            return 1
        print(f"{r.decision} {r.fact} by {r.reviewer} ({r.at}, content {r.hash}); commit kb/ to record it",
              file=sys.stderr)
        return 0
    from pmpol import agent_review

    st = review.state(kb, review.load_reviews(), review.proposers(), review.citations())
    st.agents = agent_review.summarize(kb, agent_review.load())
    if args.action == "log":
        for it in sorted(st.items.values(), key=lambda it: it.fact.id):
            for r in it.reviews:
                print(f"{r.at} {r.decision:8} {r.fact} by {r.reviewer}" + (f": {r.note}" if r.note else ""))
        for e in st.errors:
            print("ERROR", e)
        return 1 if st.errors else 0

    def offline(url: str) -> str:  # the queue only reads quotes already checked (pmpol kb verify)
        raise OSError("not fetched")

    label = {"verified": "核對過", "quote not found": "找不到引文", "no quote": "無引文"}
    verified = {k: label.get(v, "未核對") for k, v in verify_sources(kb, fetch=offline).items()}
    text = review.render(st, verified, _now().strftime("%Y-%m-%d %H:%M UTC"))
    out = Path(args.report or f"reports/{_now():%Y-%m-%d}_review_queue.md")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    c = st.counts()
    print(f"waiting {len(st.queue())} (proposed {c.get('proposed', 0)}, legacy {c.get('legacy', 0)}, stale "
          f"{c.get('stale', 0)}); reviewed with a record {c.get('reviewed', 0)}; {len(st.errors)} problems -> {out}",
          file=sys.stderr)
    return 1 if st.errors else 0


def cmd_requirements(args: argparse.Namespace) -> int:
    """Priority intelligence requirements: per stated question, the current answers, evidence lines and gaps."""
    from pmpol import requirements as rq
    from pmpol import runs

    with runs.track("requirements", vars(args)) as run:
        reqs = rq.load()
        ev = rq.gather()
        covs = [rq.cover(r, ev) for r in reqs]
        orphan = rq.residue(reqs, ev)
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_requirements.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(rq.render(covs, orphan, _now().strftime("%Y-%m-%d %H:%M UTC")), encoding="utf-8")
        run.wrote(out)
        run.counts.update({"requirements": len(reqs), "gaps": sum(len(c.gaps) for c in covs),
                           "without_markets": sum(not c.markets for c in covs), "orphan_proofs": orphan[0],
                           "proofs": orphan[1]})
    print(f"{len(reqs)} requirements, {sum(len(c.gaps) for c in covs)} evidence gaps; "
          f"{orphan[0]:,} of {orphan[1]:,} proofs answer no stated question -> {out}", file=sys.stderr)
    return 0


def cmd_signposts(args: argparse.Namespace) -> int:
    """Measure the signposts of the load-bearing assumptions (config/signposts.toml) and keep the readings."""
    from pmpol import assumptions, runs, signposts, store
    from pmpol.kb import KnowledgeBase

    with runs.track("signposts", vars(args)) as run, store.connect() as conn:
        sps = signposts.load()
        ctx = signposts.Context(_now().date(), KnowledgeBase.load(), Path("data"), conn)
        readings = signposts.measure(sps, ctx)
        signposts.record(conn, readings, _now().isoformat(timespec="seconds"), run.id)
        impact = assumptions.impact(assumptions.load_proof_rows(
            [Path("data/proofs.json"), Path("data/movers.json"), Path("data/macro/regimes.json")]))
        bare = signposts.uncovered(sps, impact)
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_signposts.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(signposts.render(readings, impact, bare, _now().strftime("%Y-%m-%d %H:%M UTC"),
                                        signposts.events(conn)), encoding="utf-8")
        run.wrote(out)
        states = [r.state for r in readings]
        run.counts.update({"signposts": len(readings), "triggered": states.count("triggered"), "watch": states.count("watch"),
                           "no_data": states.count("no_data"), "uncovered": len(bare)})
    print(f"{len(readings)} signposts: {states.count('triggered')} triggered, {states.count('no_data')} without a "
          f"reading; {len(bare)} load-bearing assumptions without one -> {out}", file=sys.stderr)
    return 0


def cmd_premortem(args: argparse.Namespace) -> int:
    """Pre-mortem of the judgments that matter most: the requirements' headline answers and the largest violations."""
    import json

    from pmpol import assumptions, premortem, review, runs, store
    from pmpol import requirements as rq
    from pmpol.assumptions import load as load_assumptions
    from pmpol.kb import KnowledgeBase
    from pmpol.signposts import latest

    with runs.track("premortem", vars(args)) as run, store.connect() as conn:
        rows = json.loads(Path("data/proofs.json").read_text(encoding="utf-8")).get("signals", []) \
            if Path("data/proofs.json").exists() else []
        ev = rq.gather()
        heads = {}
        for r in rq.load():
            c = rq.cover(r, ev)
            if c.answers:
                heads[r.question] = c.answers[0][3]
        kb = KnowledgeBase.load()
        st = review.state(kb, review.load_reviews(), review.proposers())
        cites = review.citations()
        cites.update(assumptions.impact(rows))
        ctx = premortem.Context(load_assumptions(), {fid: st.bucket(it) for fid, it in st.items.items()},
                                {aid: detail for _, aid, state, _, detail in latest(conn) if state == "triggered"},
                                {k for k, n in cites.items() if n >= premortem.SHARED})
        pms = [premortem.challenge(row, ctx, why) for row, why in premortem.select(rows, heads, args.top)]
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_premortem.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(premortem.render(pms, _now().strftime("%Y-%m-%d %H:%M UTC")), encoding="utf-8")
        from dataclasses import asdict

        Path("data/premortem.json").write_text(json.dumps([asdict(p) for p in pms], ensure_ascii=False), encoding="utf-8")
        run.read(Path("data/proofs.json"))
        run.wrote(out)
        run.counts.update({"judgments": len(pms), "failures": sum(len(p.failures) for p in pms),
                           "high": sum(f.level == "high" for p in pms for f in p.failures)})
    print(f"{len(pms)} judgments challenged, {sum(len(p.failures) for p in pms)} failure points -> {out}",
          file=sys.stderr)
    return 0


def _agent_review(args: argparse.Namespace, kb) -> int:
    """Multi-agent pre-review (pmpol.agent_review): export the facts, ingest the agents' verdicts, or report."""
    import json

    from pmpol import agent_review as ar

    if args.action == "agents-export":
        out = Path(args.out or "data/agent_review/facts.json")
        out.parent.mkdir(parents=True, exist_ok=True)
        facts = ar.export(kb, [args.fact] if args.fact else None)
        out.write_text(json.dumps(facts, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"{len(facts)} facts -> {out} (input of .claude/workflows/kb-review.js)", file=sys.stderr)
        return 0
    if args.action == "agents-ingest":
        src = Path(args.results or "data/agent_review/results.json")
        exported = json.loads(Path(args.out or "data/agent_review/facts.json").read_text(encoding="utf-8"))
        n, problems = ar.ingest(json.loads(src.read_text(encoding="utf-8")), exported,
                                args.run or src.stem, _now().isoformat(timespec="seconds"))
        for p in problems:
            print("SKIPPED", p, file=sys.stderr)
        print(f"{n} agent verdicts -> {ar.AGENT_REVIEWS}", file=sys.stderr)
        return 1 if problems and not n else 0
    sums = ar.summarize(kb, ar.load())
    out = Path(args.report or f"reports/{_now():%Y-%m-%d}_agent_review.md")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(ar.render(sums, kb, _now().strftime("%Y-%m-%d %H:%M UTC")), encoding="utf-8")
    c = ar.counts(sums)
    print(f"ready {c.get('ready', 0)}, objection {c.get('objection', 0)}, partial {c.get('partial', 0)}, "
          f"none {c.get('none', 0)} -> {out}", file=sys.stderr)
    return 0


def cmd_presidential(args: argparse.Namespace) -> int:
    """Presidential elections: the incumbent party's record and its vote share against income growth."""
    from pmpol import fundamentals as fm
    from pmpol import presidential as pr
    from pmpol import runs
    from pmpol.kb import KnowledgeBase
    from pmpol.reference import TERMS_FACT

    kb = KnowledgeBase.load()
    if TERMS_FACT not in kb.facts:
        print("no presidents' terms: run `pmpol reference --write-kb` first", file=sys.stderr)
        return 1
    with runs.track("presidential", vars(args)) as run:
        try:
            votes = pr.collect()
        except Exception as e:  # a refusal or an unreadable table stops the run; nothing is retried
            run.source("census+fec", False, error=str(e))
            print(f"cannot read the popular-vote tables: {e}", file=sys.stderr)
            return 1
        run.source("census+fec", True, len(votes.all()))
        rows = pr.record(votes.all(), kb.facts[TERMS_FACT].value, pr.parties(kb))
        try:
            monthly = fm.fetch(today=_now().date())
            run.source("fred:" + fm.SERIES, True, len(monthly))
            model = pr.fit(rows, monthly)
        except Exception as e:
            run.source("fred:" + fm.SERIES, False, error=str(e))
            monthly, model = {}, None
        rates = pr.base_rates(rows)
        run.counts.update({"elections": len(rows), "kept": rates["all"]["kept"],
                           **({"b": round(model.b, 2), "b_t": round(model.b / model.se_b, 2), "r2": round(model.r2, 3)}
                              if model else {})})
        out = Path(args.report or f"reports/{_now().date().isoformat()}_presidential.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(pr.render(rows, model), encoding="utf-8")
        run.wrote(out)
        if args.write_kb:
            from pmpol.reference import _yaml

            today = _now().date()
            l1 = pr.kb_l1(votes, today)
            p1, p2 = Path("kb/L1/us_president_votes.yaml"), Path("kb/L2/presidential_reference.yaml")
            head = "# Generated by `pmpol presidential --write-kb`; review before marking the facts reviewed.\n"
            p1.write_text(head + _yaml({"facts": l1}), encoding="utf-8")
            p2.write_text(head + _yaml({"facts": pr.kb_l2(rows, model, today, [f["id"] for f in l1],
                                                          max(monthly) if monthly else "")}), encoding="utf-8")
            run.wrote(p1, licence=[pr.LICENCE])
            run.wrote(p2, licence=[pr.LICENCE, "public domain (U.S. government data via FRED)"])
    a = rates["all"]
    print(f"{len(rows)} elections: incumbent party kept the White House {a['kept']}/{a['n']}; first term "
          f"{rates['first_term']['kept']}/{rates['first_term']['n']}, open seat {rates['open_seat']['kept']}/"
          f"{rates['open_seat']['n']}" + (f"; share = {model.a:.1f} + {model.b:.2f} x income growth (t = "
                                           f"{model.b / model.se_b:.2f}, R2 = {model.r2:.2f})" if model else "")
          + f" -> {out}", file=sys.stderr)
    return 0


def cmd_fundamentals(args: argparse.Namespace) -> int:
    """The midterm reference class conditioned on real income growth (pmpol.fundamentals)."""
    from pmpol import fundamentals as fm
    from pmpol import runs
    from pmpol.kb import KnowledgeBase
    from pmpol.reference import MAJORITY, MIDTERM_FACT, outside_view

    kb = KnowledgeBase.load()
    if MIDTERM_FACT not in kb.facts:
        print("no midterm reference class: run `pmpol reference --write-kb` first", file=sys.stderr)
        return 1
    with runs.track("fundamentals", vars(args)) as run:
        try:
            monthly = fm.fetch(today=_now().date())
        except Exception as e:  # an outage stops the run; nothing is retried or disguised
            run.source("fred:" + fm.SERIES, False, error=str(e))
            print(f"cannot fetch {fm.SERIES}: {e}", file=sys.stderr)
            return 1
        run.source("fred:" + fm.SERIES, True, len(monthly))
        model = fm.fit(kb.facts[MIDTERM_FACT].value["rows"], monthly)
        x0 = fm.income_growth(monthly, args.year)
        view = outside_view(kb, args.year)
        if x0 is None or view is None:
            print(f"no income data or no outside view for {args.year}", file=sys.stderr)
            return 1
        p = model.p_at_least(x0, view.needed)
        run.counts.update({"n": model.n, "b": round(model.b, 2), "b_t": round(model.b / model.se_b, 2),
                           "r2": round(model.r2, 3), "x": round(x0, 2), "p_keep": round(p, 3)})
        if args.write_kb:
            path = Path("kb/L2/election_fundamentals.yaml")
            path.write_text(fm.kb_yaml(model, args.year, x0, view.needed, _now().date(), max(monthly)),
                            encoding="utf-8")
            run.wrote(path, licence=["public domain (U.S. government data via FRED)"])
    lo, hi = model.interval(x0)
    print(f"{model.n} midterms {model.years[0]}-{model.years[-1]}: change = {model.a:.1f} + {model.b:.2f} x income "
          f"growth (t = {model.b / model.se_b:.2f}, R2 = {model.r2:.2f}); {args.year}: x = {x0:.2f}%, predicted "
          f"{model.predict(x0)[0]:+.0f} seats (95% {lo:+.0f} to {hi:+.0f}); P(president's party keeps the House, "
          f"change >= {view.needed:+d}) = {p:.0%} (majority {MAJORITY})", file=sys.stderr)
    return 0


def cmd_realtime(args: argparse.Namespace) -> int:
    """The Sahm rule's real-time record from ALFRED vintages of the unemployment rate (pmpol.realtime)."""
    from pmpol import realtime as rtm
    from pmpol import runs

    with runs.track("realtime", vars(args)) as run:
        today = _now().date()
        last = f"{today.year}-{today.month:02d}"
        data_months = [m for m in rtm.months(rtm.START, last) if f"{rtm._shift(m, 1)}-15" <= today.isoformat()]
        try:
            vintages = rtm.fetch_vintages(data_months, pause=args.pause)
            revised, usrec = rtm.fetch_current("UNRATE", today=today), rtm.fetch_current("USREC", today=today)
        except Exception as e:  # a refusal or an outage stops the run; nothing is retried or disguised
            run.source("alfred:UNRATE", False, error=str(e))
            print(f"cannot fetch ALFRED or FRED: {e}", file=sys.stderr)
            return 1
        run.source("alfred:UNRATE", bool(vintages), len(vintages))
        rec = rtm.record(vintages, revised, usrec)
        run.counts.update({"vintages": len(vintages), "hits": rec["real_time"]["hits"],
                           "false_alarms": rec["real_time"]["false_alarms"]})
        if args.write_kb:
            path = Path("kb/L2/macro_realtime.yaml")
            path.write_text(rtm.kb_yaml(rec, today), encoding="utf-8")
            run.wrote(path, licence=["public domain (BLS via ALFRED/FRED)"])
    for name in ("real_time", "revised"):
        r = rec[name]
        print(f"{name}: {r['hits']} hits, {r['false_alarms']} false alarms "
              f"({', '.join(t['month'] for t in r['triggers'] if t['outcome'] == 'false_alarm')}), missed {r['missed']}",
              file=sys.stderr)
    return 0


def cmd_geo(args: argparse.Namespace) -> int:
    """Relationship graphs by theme (config/geo_themes.toml) from rosters, Wikidata positions, data, facts and markets."""
    from pmpol import geo, runs
    from pmpol.kb import KnowledgeBase

    with runs.track("geo", vars(args)) as run:
        events, kb = geo.latest_events(), KnowledgeBase.load()
        graphs = [geo.build(t, events, kb) for t in geo.load_themes()]
        geo.write(graphs)
        out = geo.page(graphs, generated_at=_now().strftime("%Y-%m-%d %H:%M UTC"))
        run.wrote(out, licence=sorted(set(geo.LICENCES.values())))
        for g in graphs:
            run.counts[f"{g.theme.id}_nodes"] = len(g.nodes)
            run.counts[f"{g.theme.id}_edges"] = len(g.edges)
    for g in graphs:
        print(f"{g.theme.id}: {len(g.nodes)} nodes, {len(g.edges)} edges", file=sys.stderr)
    print(f"-> {out}", file=sys.stderr)
    return 0


def cmd_newswatch(args: argparse.Namespace) -> int:
    """Search the news for every requirement with a news query (config/requirements.toml) and keep the articles."""
    from pmpol import evidence, newswatch, requirements, runs, store

    with runs.track("newswatch", vars(args)) as run:
        rows = newswatch.watch(requirements.load(), hours=args.hours)
        for req, res in rows:
            run.source(f"news:{req.id}", res.count is not None, res.count or 0, error=res.error or "")
        with store.connect() as conn:
            items = [e for req, res in rows if res.count
                     for e in evidence.from_news(f"requirement:{req.id}", res.articles, res.source)]
            store.save_evidence(conn, items, run.id)
        n = newswatch.export(rows)
        run.wrote(Path("data/news.json"))
        run.counts.update({"requirements": n, "articles": sum(res.count or 0 for _, res in rows)})
    for req, res in rows:
        print(f"{req.id:14} {res.query!r}: {res.count if res.count is not None else 'failed'} ({res.source})",
              file=sys.stderr)
    return 0 if all(res.count is not None for _, res in rows) else 1


def cmd_gdelt(args: argparse.Namespace) -> int:
    """GDELT 2.0 event files (15 minutes): conflict-event shares for the requirements' country pairs."""
    from pmpol import runs, store
    from pmpol.osint import gdelt_files as gd

    topics = gd.load_topics()
    with runs.track("gdelt", vars(args)) as run:
        with store.connect() as conn:
            try:
                got = gd.ingest(conn, topics, args.hours)
            except Exception as e:  # a refusal stops the run; what is stored stays usable
                run.source("gdelt:files", False, error=str(e))
                print(f"cannot fetch GDELT files: {e}", file=sys.stderr)
                got = {"fetched": 0, "missing": [], "error": str(e)}
            else:
                run.source("gdelt:files", True, got["fetched"])
            readings = [r for t in topics if (r := gd.reading(conn, t)) is not None]
        n = gd.export(readings)
        run.wrote(Path("data/gdelt.json"))
        out = Path(args.report or f"reports/{_now().date().isoformat()}_gdelt.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(gd.render(readings, got), encoding="utf-8")
        run.wrote(out, licence=[gd.LICENCE])
        run.counts.update({"files": got["fetched"], "missing": len(got["missing"]), "topics": n})
    for r in readings:
        print(f"{r.topic.id:14} recent {r.recent_rate:.2f} per mille, before {r.base_rate:.2f} "
              f"({len(r.blocks)} blocks), elevated: {r.elevated}", file=sys.stderr)
    return 0 if "error" not in got else 1


def cmd_classify(args: argparse.Namespace) -> int:
    """Local decision models as classifiers (docs/THESIS_DECISION_MODELS.md): datasets, gold sample, labelling,
    agreement, baselines, model runs and the report. Nothing here needs a model except `run`."""
    import json

    from pmpol.classify import TASKS, datasets, labeling, metrics
    from pmpol.classify import baselines as bl
    from pmpol.classify import report as rep
    from pmpol.classify.splits import gold_sample

    out = Path(args.out)
    if args.action == "export":
        from pmpol.universe import pipeline

        snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
        snap = Path(args.snapshot_in) if args.snapshot_in else snaps[-1]
        ds = datasets.build(pipeline.load_snapshot(snap))
        paths = datasets.save(ds, snap.name, out)
        for tid, rows in ds.items():
            print(f"{tid}: {len(rows)} examples -> {paths[tid]}", file=sys.stderr)
        return 0
    tasks = [args.task] if args.task else list(TASKS)
    if args.action == "sample":
        for tid in tasks:
            snap, rows = datasets.load(tid, out)
            sample = gold_sample(rows, args.n, args.seed)
            p = out / f"{tid}.sample.jsonl"
            p.write_text("\n".join(json.dumps(r.to_dict(), ensure_ascii=False) for r in sample), encoding="utf-8")
            print(f"{tid}: {len(sample)} of {len(rows)} -> {p}", file=sys.stderr)
        return 0
    if args.action == "label":
        if not args.annotator or not args.task:
            print("label needs --task and --annotator", file=sys.stderr)
            return 1
        sample = [datasets.Example(**json.loads(l)) for l in (out / f"{args.task}.sample.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
        n = labeling.annotate(args.task, sample, args.annotator)
        print(f"{n} labelled by {args.annotator}", file=sys.stderr)
        return 0
    sections = []
    gen = _now().strftime("%Y-%m-%d %H:%M UTC")
    if args.action in ("baseline", "report"):
        ds = {tid: datasets.load(tid, out)[1] for tid in tasks}
        snap = datasets.load(tasks[0], out)[0]
        sections.append(rep.dataset_lines(ds, snap))
    if args.action in ("agree", "report") and args.annotators:
        names = tuple(args.annotators.split(","))
        for tid in tasks:
            g = labeling.agreement(tid, names[:2])
            sections.append(rep.agreement_lines(tid, g))
            print(f"{tid}: kappa {g['kappa']} on {g['n_compared']}, {len(g['disputed'])} disputed", file=sys.stderr)
    if args.action in ("baseline", "report"):
        for tid in tasks:
            rows = ds[tid]
            if len(rows) < 20:
                continue
            gold_w = {r.id: r.weak for r in rows}
            results = {"majority": metrics.summary(bl.majority(rows), gold_w),
                       "tfidf_lr (grouped 5-fold CV)": metrics.summary(bl.tfidf_lr_cv(rows), gold_w)}
            sections.append(rep.results_lines(tid, results, "weak"))
            if args.annotators:  # against the human gold where it exists
                names = tuple(args.annotators.split(","))
                gold = labeling.gold_labels(tid, names[:2], names[2] if len(names) > 2 else None)
                if gold:
                    sub = [r for r in rows if r.id in gold]
                    res_g = {"regex": metrics.summary(bl.regex(sub), gold),
                             "tfidf_lr (weak-trained, grouped CV)": metrics.summary([p for p in bl.tfidf_lr_cv(rows) if p.id in gold], gold)}
                    for f in sorted(out.glob(f"{tid}.pred.*.jsonl")):  # model runs written by `run`
                        preds = [metrics.Prediction(**json.loads(l)) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()]
                        res_g[f.name.split(".pred.", 1)[1][:-6]] = metrics.summary(preds, gold)
                    sections.append(rep.results_lines(tid, res_g, "gold"))
                    sections.append(["學習曲線（gold 訓練、gold 測試，TF-IDF）：" + "；".join(
                        f"n={c['n_train']} → {100 * (c['accuracy'] or 0):.1f}%" for c in bl.learning_curve(rows, gold))])
    if args.action == "run":
        from pmpol.classify.client import SystemOneClient, run as run_model

        client = SystemOneClient(args.base_url, args.model, os.environ.get("TYPESAFE_API_KEY"), replay_only=args.replay)
        for tid in tasks:
            p = out / f"{tid}.sample.jsonl"
            rows = [datasets.Example(**json.loads(l)) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
            name = (args.model or "default").replace("/", "_")
            preds = run_model(client, rows, out / f"{tid}.pred.{name}.jsonl", log=sys.stderr)
            print(f"{tid}: {len(preds)} predictions by {name}", file=sys.stderr)
        return 0
    if sections:
        path = Path(args.report or f"reports/{_now().date().isoformat()}_classify.md")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(rep.render("本地決策模型當分類器：資料集、基準線與對照", sections, gen), encoding="utf-8")
        print(f"-> {path}", file=sys.stderr)
    return 0


def cmd_cn_household(args: argparse.Namespace) -> int:
    """RMB balance-sheet repair monitor: three lights on Chinese households (config/cn_balance_sheet.toml)."""

    from pmpol import cn_balance_sheet as cb
    from pmpol import runs

    cfg = cb.load()
    with runs.track("cn-household", vars(args)) as run:
        try:
            y, m = (int(args.month[:4]), int(args.month[5:7])) if args.month else cb.latest()
            ytd = cb.fetch_ytd(cb.needed(y, m))
            run.source("pbc:financial_statistics", True, len(ytd))
        except Exception as e:  # the official readings are missing; the supplied ones are still shown
            run.source("pbc:financial_statistics", False, error=str(e))
            print(f"PBOC reports not read: {e}", file=sys.stderr)
            y, m, ytd = 0, 0, {}
        readings = dict(cfg.readings)
        if ytd:
            readings.update(cb.pbc_readings(ytd, y, m))
        cb.derived(readings)
        snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
        events, observed = [], ""
        if snaps:
            from pmpol.universe.pipeline import load_snapshot

            events, observed = load_snapshot(snaps[-1]), _snapshot_time(snaps[-1])
        p = cb.proof(cfg, readings, cb.related_markets(events), observed)
        cb.export(p)
        out = Path(args.report or f"reports/{_now().date().isoformat()}_cn_household.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(cb.render(cfg, readings, p, _now().strftime("%Y-%m-%d %H:%M UTC")), encoding="utf-8")
        run.wrote(out, licence=[cb.LICENCE])
        run.wrote(Path("data/cn_balance_sheet.json"))
        run.counts.update({"month": f"{y}-{m:02d}", "met": p.result["met"]})
    print(f"{p.conclusion} -> {out}", file=sys.stderr)
    return 0


def cmd_external(args: argparse.Namespace) -> int:
    """External forecasts beside the markets (config/external.toml): Manifold pairs and ViEWS conflict forecasts."""
    import gzip
    import json

    from pmpol import external, runs
    from pmpol.kb import KnowledgeBase

    cfg = external.load()
    kb = KnowledgeBase.load()  # Manifold's own calibration (L2), when it has been measured
    today, failed, proofs = _now().date(), 0, []
    with runs.track("external", vars(args)) as run:
        snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
        events, observed_at = [], ""
        if snaps:
            with gzip.open(snaps[-1], "rt", encoding="utf-8") as f:
                events = json.load(f)
            observed_at = _snapshot_time(snaps[-1])
            run.read(snaps[-1])
        rows = []
        if Path("data/proofs.json").exists():
            rows = json.loads(Path("data/proofs.json").read_text(encoding="utf-8")).get("signals", [])
        for pair in cfg.pairs:
            try:
                m = external.manifold(pair.slug, today)
            except Exception as e:  # a refusal or an outage stops this pair; nothing is retried or disguised
                run.source(f"manifold:{pair.slug}", False, error=str(e))
                failed += 1
                continue
            run.source(f"manifold:{pair.slug}", True, 1)
            event, market = external.find_market(events, pair.market)
            p = external.pair_proof(pair, m, event, market, external.consensus_for(rows, pair.market), observed_at,
                                    kb=kb)
            proofs.append((pair.id, pair.requirement, p))
        try:
            vrun, data = external.views(sorted({c.iso for c in cfg.views}), today)
            run.source("views", bool(vrun), sum(len(v) for v in data.values()))
            for c in cfg.views:
                proofs.append((f"views_{c.iso.lower()}", c.requirement,
                               external.views_proof(c, vrun, data.get(c.iso, []), today)))
        except Exception as e:
            run.source("views", False, error=str(e))
            failed += 1
        n = external.export(proofs)
        run.wrote(Path("data/external.json"), rows=n, licence=sorted(external.LICENCE.values()))
        run.counts.update({"pairs": sum(p.result.get("source") == "manifold" for _, _, p in proofs),
                           "views": sum(p.result.get("source") == "views" for _, _, p in proofs)})
        text = external.render(proofs, f"{_now():%Y-%m-%d %H:%M UTC}")
        if args.report:
            Path(args.report).parent.mkdir(parents=True, exist_ok=True)
            Path(args.report).write_text(text, encoding="utf-8")
            run.wrote(Path(args.report))
    for i, _, p in proofs:
        print(f"{i:20} {p.conclusion}", file=sys.stderr)
    if args.report:
        print(f"-> {args.report}", file=sys.stderr)
    return 1 if failed and not proofs else 0


def cmd_house(args: argparse.Namespace) -> int:
    """House 2026 from its districts: copula + Fourier aggregation, fitted to the national markets (pmpol.house)."""
    from pmpol import house, runs
    from pmpol.kb import KnowledgeBase
    from pmpol.propositions.derive import parse_universe
    from pmpol.universe.cluster import build_clusters
    from pmpol.universe.index import Universe
    from pmpol.universe.pipeline import load_snapshot

    snaps = sorted(Path("data/snapshots").glob("universe_*.json.gz"))
    if not snaps:
        print("no snapshot: run `pmpol universe` first", file=sys.stderr)
        return 1
    with runs.track("house", vars(args)) as run:
        run.read(snaps[-1])
        u = Universe.build(load_snapshot(snaps[-1]))
        build_clusters(u)
        kb = KnowledgeBase.load()
        res = house.run(u, parse_universe(u).props, kb, levels=not args.no_levels)
        observed_at = _snapshot_time(snaps[-1])
        n = house.export(res, kb, observed_at, Path("data/house.json"))
        if n:
            run.wrote(Path("data/house.json"), rows=n)
        text = house.render(res, f"{_now():%Y-%m-%d %H:%M UTC}（報價 {observed_at}）")
        if args.report:
            Path(args.report).parent.mkdir(parents=True, exist_ok=True)
            Path(args.report).write_text(text, encoding="utf-8")
            run.wrote(Path(args.report))
        run.counts.update({"districts": len(res.districts), "targets": len(res.targets),
                           "rho": round(res.fits[-1].rho, 3) if res.fits else None})
    print(text if not args.report else f"-> {args.report}", file=sys.stderr if args.report else sys.stdout)
    return 0 if res.fits else 1


def cmd_backtest(args: argparse.Namespace) -> int:
    """Backtests on a frozen corpus of resolved markets (pmpol.backtest): the calibration layer out of sample."""
    import json

    from pmpol import backtest as bt
    from pmpol import runs

    with runs.track("backtest", vars(args)) as run:
        if args.corpus:
            manifest = json.loads(Path(args.corpus).read_text(encoding="utf-8"))
        else:
            manifest = bt.freeze(today=_now().date())
            run.wrote(bt.write_manifest(manifest))
        problems = bt.verify(manifest)
        tests = [] if problems else bt.run(bt.corpus_rows(manifest), manifest.get("split", bt.SPLIT))
        for f in manifest["files"]:
            run.read(Path(f["path"]))
        text = bt.render(manifest, tests, problems)
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_backtest.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        run.wrote(out)
        run.counts.update({"tests": len(tests), "problems": len(problems)})
    print(f"{len(tests)} tests -> {out}" + (f"; corpus problems: {problems}" if problems else ""), file=sys.stderr)
    return 1 if problems else 0


def cmd_diagnostics(args: argparse.Namespace) -> int:
    """Likelihood ratios of recession warning indicators (pmpol.diagnostics): the Sahm rule in real time, the
    inverted yield curve."""
    from pmpol import diagnostics as dg
    from pmpol import realtime as rtm
    from pmpol import runs

    with runs.track("diagnostics", vars(args)) as run:
        today = _now().date()
        data_months = [m for m in rtm.months(rtm.START, f"{today.year}-{today.month:02d}")
                       if f"{rtm._shift(m, 1)}-15" <= today.isoformat()]
        try:
            vintages = rtm.fetch_vintages(data_months, pause=args.pause)
            usrec = rtm.fetch_current("USREC", today=today)
            spread = rtm.fetch_current("T10Y3MM", today=today)
        except Exception as e:  # a refusal or an outage stops the run; nothing is retried or disguised
            run.source("fred:USREC,T10Y3MM", False, error=str(e))
            print(f"cannot fetch ALFRED or FRED: {e}", file=sys.stderr)
            return 1
        run.source("fred:USREC,T10Y3MM", True, len(usrec) + len(spread))
        hyp = dg.hypothesis(usrec)
        ratios = [r for r in (dg.likelihood_ratios("sahm_real_time", dg.sahm_signal(vintages), hyp),
                              dg.likelihood_ratios("yield_curve_inverted", dg.inverted(spread), hyp)) if r]
        out = Path(args.report or f"reports/{today:%Y-%m-%d}_diagnostics.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(dg.render(ratios), encoding="utf-8")
        run.wrote(out)
        if args.write_kb:
            path = Path("kb/L2/macro_diagnostics.yaml")
            path.write_text(dg.kb_yaml(ratios, today), encoding="utf-8")
            run.wrote(path, licence=["public domain (BLS, Treasury via FRED/ALFRED)"])
        run.counts.update({r.indicator: round(r.lr_pos, 2) for r in ratios})
    for r in ratios:
        print(f"{r.indicator}: LR+ {r.lr_pos:.2f}, LR- {r.lr_neg:.2f} ({r.sample})", file=sys.stderr)
    return 0


def cmd_gdp_realtime(args: argparse.Namespace) -> int:
    """U.S. real GDP growth as first published (ALFRED vintages of GDPC1) against today's series (pmpol.gdp_realtime)."""
    from pmpol import gdp_realtime as gr
    from pmpol import recession, runs

    with runs.track("gdp-realtime", vars(args)) as run:
        today = _now().date()
        last_q = f"{today.year}Q{(today.month - 1) // 3 + 1}"
        try:
            first = gr.first_prints(gr.quarters(gr.FIRST, last_q), today, pause=args.pause)
            latest = recession.fetch(today=today)
        except Exception as e:  # a refusal or an outage stops the run; nothing is retried or disguised
            run.source("alfred:GDPC1", False, error=str(e))
            print(f"cannot fetch ALFRED or FRED: {e}", file=sys.stderr)
            return 1
        run.source("alfred:GDPC1", bool(first), len(first))
        rec = gr.record(first, latest)
        out = Path(args.report or f"reports/{today:%Y-%m-%d}_gdp_realtime.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(gr.render(rec), encoding="utf-8")
        run.wrote(out)
        if args.write_kb:
            path = Path("kb/L2/gdp_first_prints.yaml")
            path.write_text(gr.kb_yaml(rec, today), encoding="utf-8")
            run.wrote(path, licence=["public domain (BEA via ALFRED)"])
        run.counts.update({"quarters": rec.quarters, "sign_flips": len(rec.sign_flips)})
    print(f"{rec.quarters} quarters ({rec.sample}); sign flips {len(rec.sign_flips)}; negative pairs first prints "
          f"{rec.pairs_first}, revised {rec.pairs_latest} -> {out}", file=sys.stderr)
    return 0


def cmd_baseline(args: argparse.Namespace) -> int:
    """Download the monthly series behind official-statistics markets (pmpol.baseline) for the universe run's
    historical baseline."""
    from pmpol import baseline as bl
    from pmpol import runs

    failed = 0
    with runs.track("baseline", vars(args)) as run:
        for series, (code, how) in bl.SERIES.items():
            try:
                path = bl.fetch(code, today=_now().date())
            except Exception as e:  # an outage stops this series; nothing is retried or disguised
                run.source(f"{'sidra' if code == 'IPCA_MOM' else 'fred'}:{code}", False, error=str(e))
                failed += 1
                continue
            values = bl.derived(bl.monthly(path.read_text(encoding="utf-8")), how)
            run.source(f"{'sidra' if code == 'IPCA_MOM' else 'fred'}:{code}", bool(values), len(values))
            run.read(path)
            last = max(values) if values else "—"
            nd = 2 if bl.step_of(series) < 0.1 else 1
            print(f"{series:18} {code:9} latest {last} {values.get(last, float('nan')):.{nd}f}", file=sys.stderr)
    return 1 if failed == len(bl.SERIES) else 0


def cmd_prov(args: argparse.Namespace) -> int:
    """Export the published proofs as W3C PROV (PROV-JSON) so a conclusion can be followed back to its sources."""
    import json
    import subprocess

    from pmpol import prov, runs
    from pmpol.kb import KnowledgeBase

    with runs.track("prov", vars(args)) as run:
        inputs = [Path("data/proofs.json"), Path("data/movers.json"), Path("data/macro/regimes.json"),
                  Path("data/settlement.json"), Path("data/external.json"), Path("data/house.json"),
                  Path("data/news.json"), Path("data/gdelt.json")]
        rows = prov.load_rows(inputs)
        for p in inputs:
            if p.exists():
                run.read(p)
        try:
            commit = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
        except OSError:
            commit = ""
        doc = prov.document(rows, set(KnowledgeBase.load().facts), commit)
        problems = prov.check(doc)
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
        run.wrote(out)
        if args.nanopub:  # the same proofs as nanopublications (TriG); local only, never published from here
            from pmpol import nanopub

            npath = Path(args.nanopub)
            npath.write_text(nanopub.document(rows, set(KnowledgeBase.load().facts),
                                              _now().strftime("%Y-%m-%dT%H:%M:%SZ"), commit), encoding="utf-8")
            run.wrote(npath, rows=len(rows))
        rels = sum(len(doc.get(k, {})) for k in ("wasDerivedFrom", "wasGeneratedBy", "used", "wasAssociatedWith",
                                                  "wasAttributedTo"))
        run.counts.update({"proofs": len(rows), "entities": len(doc.get("entity", {})), "relations": rels,
                           "problems": len(problems)})
        from pmpol.contracts import Check

        run.check([Check("prov", "consistent", not problems, "error", f"{len(problems)} problems", "0",
                         problems[0] if problems else "")])
    print(f"{len(rows):,} proofs -> {len(doc.get('entity', {})):,} entities, {rels:,} relations -> {out}"
          + (f"; {len(problems)} problems, e.g. {problems[0]}" if problems else ""), file=sys.stderr)
    return 1 if problems else 0


def cmd_recession(args: argparse.Namespace) -> int:
    """The reference class of technical-recession markets: how often n more quarters of real GDP completed two
    negative quarters in a row since 1947 (pmpol.recession)."""
    from pmpol import recession as rc
    from pmpol import runs

    with runs.track("recession", vars(args)) as run:
        try:
            growth = rc.fetch(today=_now().date())
        except Exception as e:  # an outage stops the run; nothing is retried or disguised
            run.source("fred:" + rc.SERIES, False, error=str(e))
            print(f"cannot fetch {rc.SERIES}: {e}", file=sys.stderr)
            return 1
        run.source("fred:" + rc.SERIES, True, len(growth))
        rates = rc.base_rates(growth)
        run.counts.update({"quarters": len(growth), "latest": growth[-1][0]})
        if args.write_kb:
            path = Path("kb/L2/recession_reference.yaml")
            path.write_text(rc.kb_yaml(growth, rates, _now().date()), encoding="utf-8")
            run.wrote(path, licence=["public domain (U.S. government data via FRED)"])
    for n in (2, 4, 6, 8):
        h, c = rates["pos"][n]
        print(f"after a positive quarter, two negative quarters within {n}: {h}/{c} ({h / c:.0%})")
    print(f"{len(growth)} quarters {growth[0][0]}-{growth[-1][0]}", file=sys.stderr)
    return 0


def cmd_movers(args: argparse.Namespace) -> int:
    from pmpol import runs
    from pmpol.movers import report as movers_report

    if args.from_snap and args.to_snap:
        a, b = Path(args.from_snap), Path(args.to_snap)
    else:
        pair = movers_report.pick_snapshots(min_hours=args.min_hours)
        if pair is None:
            print("need two universe snapshots at least --min-hours apart: run `pmpol universe` twice", file=sys.stderr)
            return 1
        a, b = pair
    with runs.track("movers", vars(args)) as run:
        run.read(a)
        run.read(b)
        moves, rows, ts_a, ts_b, near_close = movers_report.run(a, b, top=args.top, min_move=args.min_move,
                                                                news=not args.no_news, flow=not args.no_flow)
        # News searches as a source: a failed search is "not observed", never "no news".
        searched = [p.result["news"] for _, p in rows]
        if searched and not args.no_news:
            failed = sum(n is None for n in searched)
            run.source("news:search", failed < len(searched), len(searched) - failed,
                       error=f"{failed} of {len(searched)} searches failed" if failed else "")
        from pmpol import crosslink

        observed, violations = crosslink.load_violations()  # the forward engine's violations: link both ways
        links = crosslink.link(moves, violations, observed)
        for mv, p in rows:
            crosslink.add_to_proof(p, mv, links, ts_b)
        run.counts["violations_moved"] = len(links.moved)
        out = Path(args.report or f"reports/{_now():%Y-%m-%d}_movers.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        goals = movers_report.goal_rows(a, b, news=not args.no_news)
        run.counts["goal_comovements"] = len(goals)
        out.write_text(movers_report.render(moves, rows, ts_a, ts_b, near_close, goals)
                       + "\n".join(crosslink.render(links) + [""]))
        n = movers_report.export(rows, Path("data/movers.json"), goals)
        from pmpol.contracts import proof_checks

        run.check(proof_checks("proofs:movers", "data/movers.json"))
        from pmpol.track.leads import lead_signals

        from pmpol.evidence import Evidence

        with store.connect() as conn:  # silent leads, followed up after 72 hours by `pmpol track`
            store.save_signals(conn, lead_signals(rows), run_id=run.id)
            n_ev = store.save_evidence(conn, [Evidence(**e) for _, p in rows for e in p.result.get("evidence", [])],
                                       run_id=run.id)
        run.counts["evidence_new"] = n_ev
        terms = runs.licence_terms({mv.venue for mv, _ in rows})
        run.wrote(out, licence=terms)
        run.wrote("data/movers.json", rows=n, licence=terms)
        silent = sum(1 for _, p in rows if p.result.get("silent"))
        from collections import Counter

        run.counts.update({"from": ts_a, "to": ts_b, "moves": len(moves), "explained": n, "silent": silent,
                           "near_close": near_close, **{f"lane_{k}": v for k, v in Counter(m.lane for m in moves).items()}})
    print(f"{len(moves)} moves {ts_a[:16]} -> {ts_b[:16]}, {n} explained, {silent} silent -> {out}, "
          f"data/movers.json", file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="pmpol")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("senate", help="price Senate seat/control markets from race markets")
    s.add_argument("--config", default=DEFAULT_CONFIG)
    s.add_argument("--rho", type=float, default=None, help="fix the copula correlation instead of fitting it")
    s.add_argument("--min-edge", type=float, default=0.01)
    s.add_argument("--nu", type=float, default=None,
                   help="Student t copula with these degrees of freedom (default: Gaussian copula)")
    s.add_argument("--tails", action="store_true",
                   help="also fit the Gaussian and t copulas (nu 30, 10, 5, 3) and compare their correlation skew")
    s.add_argument("--clusters", action="store_true",
                   help="also fit national + pre-set second-factor copulas (Census divisions, education) against one factor")
    s.add_argument("--report", default=None, help="also write the markdown report to this path")
    s.add_argument("--snapshot-in", default=None, help="re-run on a saved snapshot instead of live data")
    s.set_defaults(func=cmd_senate)

    c = sub.add_parser("scan", help="model-free consistency scan of political events")
    c.add_argument("--venue", choices=("kalshi", "polymarket", "both"), default="both")
    c.add_argument("--min-edge", type=float, default=0.005)
    c.add_argument("--limit", type=int, default=50)
    c.set_defaults(func=cmd_scan)

    w = sub.add_parser("universe", help="crawl, tag, cluster and relate every political event on every venue")
    w.add_argument("--venues", default=",".join(VENUES), help=f"comma-separated venues (default: all of {', '.join(VENUES)})")
    w.add_argument("--min-edge", type=float, default=0.005)
    w.add_argument("--report", default=None, help="markdown report path (default reports/<date>_universe.md)")
    w.add_argument("--graph", default="data/universe_graph.json", help="graph export path")
    w.add_argument("--snapshot-in", default=None, help="re-run on a saved universe snapshot")
    w.add_argument("--no-entities", action="store_true", help="skip the person/office entity layer")
    w.add_argument("--no-depth", action="store_true", help="skip order-book depth lookups")
    w.set_defaults(func=cmd_universe)

    mc = sub.add_parser("macro", help="fetch macro series, store them bitemporally, and write the macro report")
    mc.add_argument("--report", default=None, help="markdown path (default reports/<date>_macro.md)")
    mc.add_argument("--snapshot-in", default=None, help="universe snapshot for related markets (default: latest)")
    mc.set_defaults(func=cmd_macro)

    tr = sub.add_parser("truth", help="resolved markets (ground truth): fetch them, or write the calibration report")
    tr.add_argument("action", choices=("fetch", "calibrate", "words-deeds"))
    tr.add_argument("--venues", default="kalshi,polymarket")
    tr.add_argument("--per-series", type=int, default=10, help="Kalshi: most recent resolved markets per series")
    tr.add_argument("--limit", type=int, default=6000, help="Polymarket: closed political markets to scan")
    tr.add_argument("--report", default=None)
    tr.add_argument("--write-kb", action="store_true", help="also write proposed L2 facts to kb/L2/market_calibration.yaml "
                    "(calibrate) or kb/L2/words_deeds.yaml (words-deeds)")
    tr.set_defaults(func=cmd_truth)

    ca = sub.add_parser("candidates", help="L1 general-election candidate lists for U.S. races (Wikipedia, cached)")
    ca.add_argument("--year", default="2026")
    ca.add_argument("--pause", type=float, default=3.0, help="seconds between page requests")
    ca.set_defaults(func=cmd_candidates)

    au = sub.add_parser("audit", help="foundation health: coverage, grounding of relations, provenance, knowledge base")
    au.add_argument("--report", default=None)
    au.set_defaults(func=cmd_audit)

    ru = sub.add_parser("rules", help="list the inference rules and their grounds (config/inference_rules.toml)")
    ru.set_defaults(func=cmd_rules)

    fc = sub.add_parser("famcorr", help="estimate the correlation between venue families' quote errors (consensus band)")
    fc.add_argument("--snapshots", type=int, default=30, help="most recent universe snapshots to use")
    fc.add_argument("--reps", type=int, default=300, help="cluster bootstrap replicates")
    fc.add_argument("--noisy", default="predictit",  # pmpol.universe.family_corr.NOISY
                    help="venue families that get their own extra quote noise (comma-separated)")
    fc.add_argument("--report", default=None, help="markdown path (default reports/<date>_family_correlation.md)")
    fc.add_argument("--write-kb", action="store_true", help="also write the proposed L2 fact to kb/L2/family_correlation.yaml")
    fc.set_defaults(func=cmd_famcorr)

    rf = sub.add_parser("reference", help="election reference classes: midterm House and Senate seat changes since 1946 (outside view)")
    rf.add_argument("--pause", type=float, default=2.0, help="seconds between page requests")
    rf.add_argument("--write-kb", action="store_true",
                    help="write proposed facts to kb/L1/us_house_history.yaml, kb/L1/us_senate_history.yaml and "
                         "kb/L2/election_reference.yaml")
    rf.set_defaults(func=cmd_reference)

    rv = sub.add_parser("review", help="human review of knowledge-base facts (two-person rule): queue, approve, reject, dispute, log")
    rv.add_argument("action", nargs="?", default="queue",
                    choices=["queue", "log", "approve", "reject", "dispute", "agents", "agents-export", "agents-ingest"])
    rv.add_argument("fact", nargs="?", help="fact id (for approve, reject, dispute)")
    rv.add_argument("--reviewer", help="your name; machine authors cannot review, nor can the fact's proposer")
    rv.add_argument("--note", help="why (recorded with the decision)")
    rv.add_argument("--report", default=None, help="markdown path (default reports/<date>_review_queue.md)")
    rv.add_argument("--out", default=None, help="agents-export: facts JSON (default data/agent_review/facts.json)")
    rv.add_argument("--results", default=None, help="agents-ingest: the workflow's results JSON")
    rv.add_argument("--run", default=None, help="agents-ingest: run label recorded with each verdict")
    rv.set_defaults(func=cmd_review)

    pq = sub.add_parser("requirements", help="priority intelligence requirements: answers, evidence lines and gaps per question")
    pq.add_argument("--report", default=None, help="markdown path (default reports/<date>_requirements.md)")
    pq.set_defaults(func=cmd_requirements)

    sg = sub.add_parser("signposts", help="measure the signposts of load-bearing assumptions (config/signposts.toml)")
    sg.add_argument("--report", default=None, help="markdown path (default reports/<date>_signposts.md)")
    sg.set_defaults(func=cmd_signposts)

    pm = sub.add_parser("premortem", help="pre-mortem of the judgments that matter most (structured challenge)")
    pm.add_argument("--top", type=int, default=5, help="largest violations to challenge besides the requirements' answers")
    pm.add_argument("--report", default=None, help="markdown path (default reports/<date>_premortem.md)")
    pm.set_defaults(func=cmd_premortem)

    fu = sub.add_parser("fundamentals", help="midterm reference class conditioned on real income growth (Tufte 1975)")
    fu.add_argument("--year", type=int, default=2026)
    fu.add_argument("--write-kb", action="store_true", help="write the proposed L2 fact to kb/L2/election_fundamentals.yaml")
    fu.set_defaults(func=cmd_fundamentals)

    pz = sub.add_parser("presidential", help="presidential elections: incumbent party record and income growth (1952-)")
    pz.add_argument("--report", default=None, help="markdown path (default reports/<date>_presidential.md)")
    pz.add_argument("--write-kb", action="store_true",
                    help="write proposed facts to kb/L1/us_president_votes.yaml and kb/L2/presidential_reference.yaml")
    pz.set_defaults(func=cmd_presidential)

    rt = sub.add_parser("realtime", help="the Sahm rule's real-time record from ALFRED vintages (1970-)")
    rt.add_argument("--write-kb", action="store_true", help="write the proposed L2 fact to kb/L2/macro_realtime.yaml")
    rt.add_argument("--pause", type=float, default=2.0, help="seconds between ALFRED requests")
    rt.set_defaults(func=cmd_realtime)

    ge = sub.add_parser("geo", help="relationship graphs by theme (Iran-Hormuz-oil, China's leadership) and their viewer")
    ge.set_defaults(func=cmd_geo)

    cl = sub.add_parser("classify", help="local decision models as classifiers: datasets, gold labelling, baselines, model runs")
    cl.add_argument("action", choices=["export", "sample", "label", "agree", "baseline", "run", "report"])
    cl.add_argument("--task", default=None, help="one task id (default: all)")
    cl.add_argument("--out", default="data/classify")
    cl.add_argument("--snapshot-in", default=None)
    cl.add_argument("--n", type=int, default=300, help="gold sample size per task")
    cl.add_argument("--seed", type=int, default=7)
    cl.add_argument("--annotator", default=None, help="label: your name (annotations/classify/<task>.<name>.jsonl)")
    cl.add_argument("--annotators", default=None, help="agree/report: 'a,b' or 'a,b,adjudicator'")
    cl.add_argument("--base-url", default="http://127.0.0.1:8000", help="run: ollajev or https://api.typesafe.ai")
    cl.add_argument("--model", default=None, help="run: model name (default: the server's default)")
    cl.add_argument("--replay", action="store_true", help="run: fixtures only, never call the server")
    cl.add_argument("--report", default=None)
    cl.set_defaults(func=cmd_classify)

    cn = sub.add_parser("cn-household", help="RMB balance-sheet repair monitor: three lights on Chinese households")
    cn.add_argument("--month", default=None, help="YYYY-MM of the PBOC report (default: the newest on the list)")
    cn.add_argument("--report", default=None, help="markdown path (default reports/<date>_cn_household.md)")
    cn.set_defaults(func=cmd_cn_household)

    gd = sub.add_parser("gdelt", help="GDELT 15-minute event files: conflict-event shares per requirement topic")
    gd.add_argument("--hours", type=float, default=24, help="fetch the files of the last N hours not yet stored")
    gd.add_argument("--report", default=None, help="markdown path (default reports/<date>_gdelt.md)")
    gd.set_defaults(func=cmd_gdelt)

    nw = sub.add_parser("newswatch", help="search the news for the requirements list's questions (last 72 hours)")
    nw.add_argument("--hours", type=int, default=72)
    nw.set_defaults(func=cmd_newswatch)

    gq = sub.add_parser("gdp-realtime", help="U.S. real GDP growth as first published (ALFRED) against today's series")
    gq.add_argument("--write-kb", action="store_true", help="write the proposed L2 fact to kb/L2/gdp_first_prints.yaml")
    gq.add_argument("--pause", type=float, default=2.0, help="seconds between ALFRED requests (only for missing vintages)")
    gq.add_argument("--report", default=None)
    gq.set_defaults(func=cmd_gdp_realtime)

    dx = sub.add_parser("diagnostics", help="likelihood ratios of recession warnings (Sahm rule in real time, yield curve)")
    dx.add_argument("--write-kb", action="store_true", help="write the proposed L2 facts to kb/L2/macro_diagnostics.yaml")
    dx.add_argument("--pause", type=float, default=2.0, help="seconds between ALFRED requests (only for missing vintages)")
    dx.add_argument("--report", default=None)
    dx.set_defaults(func=cmd_diagnostics)

    bk = sub.add_parser("backtest", help="backtests on a frozen corpus of resolved markets (calibration out of sample)")
    bk.add_argument("--corpus", default=None, help="run against this manifest (reports/backtest/corpus_<date>.json); "
                                                     "default: freeze the current files")
    bk.add_argument("--report", default=None, help="Markdown path (default reports/<date>_backtest.md)")
    bk.set_defaults(func=cmd_backtest)

    ho = sub.add_parser("house", help="House 2026 from its districts: copula + FFT seat distribution vs the markets")
    ho.add_argument("--report", default=None, help="write the Markdown report here")
    ho.add_argument("--no-levels", action="store_true", help="skip the national + state two-level fit (about 2 minutes)")
    ho.set_defaults(func=cmd_house)

    ex = sub.add_parser("external", help="external forecasts beside the markets: Manifold pairs, ViEWS conflict forecasts")
    ex.add_argument("--report", default=None, help="write the Markdown report here")
    ex.set_defaults(func=cmd_external)

    bs = sub.add_parser("baseline", help="download the monthly series behind official-statistics markets (FRED)")
    bs.set_defaults(func=cmd_baseline)

    pv = sub.add_parser("prov", help="export the published proofs as W3C PROV-JSON")
    pv.add_argument("--out", default="data/proofs.prov.json")
    pv.add_argument("--nanopub", default="data/nanopubs.trig",
                    help="also write the proofs as nanopublications (TriG; empty to skip; local, unsigned)")
    pv.set_defaults(func=cmd_prov)

    rc = sub.add_parser("recession", help="technical-recession reference class from quarterly real GDP since 1947")
    rc.add_argument("--write-kb", action="store_true", help="write the proposed facts to kb/L2/recession_reference.yaml")
    rc.set_defaults(func=cmd_recession)

    mv = sub.add_parser("movers", help="reverse engine: political price moves between two snapshots, checked against news")
    mv.add_argument("--from", dest="from_snap", default=None, help="older snapshot (default: auto)")
    mv.add_argument("--to", dest="to_snap", default=None, help="newer snapshot (default: latest)")
    mv.add_argument("--min-hours", type=float, default=1.0)
    mv.add_argument("--min-move", type=float, default=0.05)
    mv.add_argument("--top", type=int, default=20, help="moves to check against the news (GDELT: 1 request / 5 s)")
    mv.add_argument("--no-news", action="store_true")
    mv.add_argument("--no-flow", action="store_true", help="skip the Polymarket order-flow features of silent moves")
    mv.add_argument("--report", default=None)
    mv.set_defaults(func=cmd_movers)

    tk = sub.add_parser("track", help="signal track record: test pre-registered claims on later snapshots")
    tk.add_argument("--min-hours", type=float, default=1.0)
    tk.add_argument("--no-news", action="store_true", help="skip the news follow-up of silent leads")
    tk.add_argument("--report")
    tk.set_defaults(func=cmd_track)

    se = sub.add_parser("settle", help="settlement-data checks: markets settling on public data we read (IMF PortWatch)")
    se.add_argument("--snapshot-in", help="snapshot to read (default: the latest)")
    se.add_argument("--report")
    se.set_defaults(func=cmd_settle)

    cy = sub.add_parser("cycle", help="one full cycle in dependency order: universe, macro, movers, track, "
                                      "assumptions, status, viewer (for a scheduler)")
    cy.add_argument("--skip", default="", help="comma-separated steps to leave out")
    cy.add_argument("--no-news", action="store_true", help="movers without news queries")
    cy.add_argument("--profile", choices=("full", "cloud"), default="full",
                    help="cloud: only single-snapshot steps, reports under reports/cloud/ (no history needed)")
    cy.set_defaults(func=cmd_cycle)

    po = sub.add_parser("propositions", help="experimental: read markets as propositions (ontology prototype) and "
                                             "compare the derived relations with the templates")
    po.add_argument("--snapshot-in", help="snapshot to read (default: the latest)")
    po.add_argument("--report")
    po.set_defaults(func=cmd_propositions)

    sc = sub.add_parser("scheduled", help="one cycle for cron/systemd/launchd: lock, time limit, log, "
                                          "optional report commit and failure notification")
    sc.add_argument("--timeout-min", type=float, default=150, help="stop the cycle after this many minutes")
    sc.add_argument("--pull", action="store_true", help="git pull --ff-only before the cycle (code updates)")
    sc.add_argument("--commit", action="store_true", help="commit reports/ afterwards (never data/)")
    sc.add_argument("--push", action="store_true", help="push the report commit")
    sc.add_argument("--notify-url", help="webhook to POST to when a run fails (default: $PMPOL_NOTIFY_URL)")
    sc.add_argument("--skip", default="", help="cycle steps to leave out, comma-separated")
    sc.add_argument("--no-news", action="store_true", help="movers and track without news queries")
    sc.add_argument("--profile", choices=("full", "cloud"), default="full",
                    help="cloud: a fresh environment without history (single-snapshot steps, reports/cloud/)")
    sc.set_defaults(func=cmd_scheduled)

    pe = sub.add_parser("people", help="refresh Wikidata politicians (OpenSanctions wd_peps) for person identities")
    pe.add_argument("--max-age-days", type=float, default=7, help="re-download the extract when older than this")
    pe.set_defaults(func=cmd_people)

    br = sub.add_parser("brief", help="one-page daily brief from the latest cycle's outputs")
    br.add_argument("--report")
    br.add_argument("--reports-dir", default="reports", help="where to read the cycle's reports from")
    br.set_defaults(func=cmd_brief)

    ka = sub.add_parser("assumptions", help="key assumptions: status, review dates, and how many proofs rely on each")
    ka.add_argument("--report")
    ka.set_defaults(func=cmd_assumptions)

    st = sub.add_parser("status", help="run history, source health and failed data checks")
    st.add_argument("--limit", type=int, default=15, help="recent runs to list")
    st.add_argument("--report", help="write the status page here instead of printing it")
    st.set_defaults(func=cmd_status)

    vw = sub.add_parser("viewer", help="build the layered proof viewer (one HTML file) from the latest runs")
    vw.add_argument("--out", default="data/viewer/index.html")
    vw.set_defaults(func=cmd_viewer)

    k = sub.add_parser("kb", help="knowledge base: validate, verify source quotes online, or show facts")
    k.add_argument("action", choices=("validate", "verify", "show", "derive", "history", "as-of"))
    k.add_argument("query", nargs="?", default=None,
                   help="show: filter by id or subject text; history: a fact id; as-of: a time (2026-10-03T12:00)")
    k.set_defaults(func=cmd_kb)

    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
