"""Multi-agent pre-review of knowledge-base facts: independent AI reviewers prepare the human review.

Under the two-person rule (pmpol.review) a machine may propose a fact but never approve one. Machines can still
do most of the checking a human reviewer would otherwise start from, if several of them look independently and
from different angles, and their disagreements are kept rather than averaged away. Each fact is read by three
roles that do not see each other's work:

  source       does the cited source exist, contain the quote, and actually support the value (not just mention
               it)? Is the licence stated and the Admiralty grade plausible? For computed facts: does the method
               and its report reproduce the value?
  consistency  is the fact coherent with the rest of the knowledge base: the right layer, validity windows,
               derived_from inputs that support it, conflicts with other facts, still current today?
  adversary    try to refute it: a newer law, a changed office holder, a better source that says otherwise.

Each verdict is pass, fail or uncertain, with reasons and the evidence used. Records go to kb/agent_reviews.yaml
bound to the fact's content hash (a change to the fact makes them stale), alongside the human reviews:

  - they never change a fact's status and never count as an approval (reviewer names are machine names);
  - the human review queue shows them: facts an agent failed come first (they need a person's attention), facts
    every role passed are marked ready for a quick human sign-off;
  - when roles disagree, both verdicts are shown side by side.

The agents are run by the workflow in .claude/workflows/kb-review.js (Claude Code); `pmpol review agents-export`
writes its input and `pmpol review agents-ingest` records its output.
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path

import yaml

from pmpol.kb import KB_DIR, KnowledgeBase
from pmpol.review import fact_hash

AGENT_REVIEWS = KB_DIR / "agent_reviews.yaml"
ROLES = ("source", "consistency", "adversary")
VERDICTS = ("pass", "fail", "uncertain")
ZH = {"source": "來源", "consistency": "一致性", "adversary": "反方", "pass": "通過", "fail": "不通過",
      "uncertain": "不確定"}


def _cached_source(url: str) -> str:
    """A local copy of the source page when one exists (pmpol kb verify, pmpol reference)."""
    p = Path("data/kb_sources") / (hashlib.sha1(url.encode()).hexdigest() + ".txt")
    if p.exists():
        return str(p)
    import re

    q = Path("data/reference") / (re.sub(r"[^A-Za-z0-9]+", "_", url.split("://", 1)[-1]).strip("_") + ".html")
    return str(q) if q.exists() else ""


def export(kb: KnowledgeBase, ids: list[str] | None = None) -> list[dict]:
    """The facts as the agents see them: every field, the content hash, and a local copy of the source if any."""
    out = []
    for fid in sorted(ids or kb.facts):
        f = kb.facts[fid]
        out.append({"id": f.id, "layer": f.layer, "subject": f.subject, "predicate": f.predicate,
                    "value": json.loads(json.dumps(f.value, default=str)),
                    "source": {"title": f.source.title, "url": f.source.url, "quote": f.source.quote,
                               "license": f.source.license},
                    "admiralty": f.admiralty, "status": f.status, "recorded_at": str(f.recorded_at),
                    "valid_from": str(f.valid_from or ""), "valid_to": str(f.valid_to or ""),
                    "derived_from": list(f.derived_from), "note": f.note, "file": f"kb/{f.file}",
                    "hash": fact_hash(f), "cached_source": _cached_source(f.source.url)})
    return out


@dataclass(frozen=True)
class AgentReview:
    fact: str
    hash: str  # the fact's content hash when it was exported for review
    role: str
    verdict: str
    reasons: str
    evidence: tuple[str, ...] = ()
    fix: str = ""  # a suggested correction, for the human reviewer to consider
    run: str = ""
    at: str = ""

    @property
    def reviewer(self) -> str:
        return f"pmpol agent {self.role}"  # a machine name: pmpol.review never accepts it as an approval


def load(path: Path = AGENT_REVIEWS) -> list[AgentReview]:
    if not path.exists():
        return []
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return [AgentReview(**{**r, "evidence": tuple(r.get("evidence", ()))}) for r in raw.get("agent_reviews", []) or []]


def ingest(results: list[dict], exported: list[dict], run: str, at: str, path: Path = AGENT_REVIEWS) -> tuple[int, list[str]]:
    """results: {"role", "reviews": [{"fact", "verdict", "reasons", "evidence", "fix"}]} per agent. Appends the
    valid verdicts (bound to the exported hash) and returns (recorded, problems)."""
    hashes = {e["id"]: e["hash"] for e in exported}
    problems, rows = [], []
    for res in results:
        role = res.get("role")
        if role not in ROLES:
            problems.append(f"unknown role {role!r}")
            continue
        for r in res.get("reviews", []):
            fid, verdict = r.get("fact"), r.get("verdict")
            if fid not in hashes:
                problems.append(f"{role}: fact {fid!r} was not in the export")
            elif verdict not in VERDICTS:
                problems.append(f"{role}: {fid}: verdict {verdict!r}")
            else:
                rows.append(AgentReview(fid, hashes[fid], role, verdict, str(r.get("reasons", "")).strip(),
                                        tuple(str(e) for e in r.get("evidence", []) or []),
                                        str(r.get("fix", "") or "").strip(), run, at))
    head = ("# Multi-agent pre-review of knowledge-base facts (pmpol.agent_review). Machine reviewers: these records\n"
            "# never approve a fact; they prepare the human review. Appended by `pmpol review agents-ingest`.\n"
            "agent_reviews:\n")
    text = path.read_text(encoding="utf-8") if path.exists() else head
    if rows:
        text += yaml.safe_dump([{k: (list(v) if isinstance(v, tuple) else v) for k, v in asdict(r).items()
                                 if v not in ("", ())} for r in rows], allow_unicode=True, sort_keys=False, width=120)
    path.write_text(text, encoding="utf-8")
    return len(rows), problems


@dataclass
class Summary:
    """The latest verdict of each role on the fact's current content."""
    fact: str
    verdicts: dict[str, AgentReview] = field(default_factory=dict)
    stale: int = 0  # verdicts on an earlier version of the fact (ignored)

    @property
    def state(self) -> str:
        v = {r.verdict for r in self.verdicts.values()}
        if not v:
            return "none"
        if "fail" in v:
            return "objection"  # at least one role failed it: a person must look
        if v == {"pass"} and set(self.verdicts) == set(ROLES):
            return "ready"  # every role passed: ready for a quick human sign-off
        return "partial"  # some uncertain, or not every role has looked

    @property
    def split(self) -> bool:
        """Roles disagree (one passes what another fails): shown side by side, not resolved."""
        v = {r.verdict for r in self.verdicts.values()}
        return "pass" in v and "fail" in v


STATE_ZH = {"none": "未預審", "objection": "有異議", "ready": "預審全數通過", "partial": "部分通過或不確定"}


def summarize(kb: KnowledgeBase, records: list[AgentReview]) -> dict[str, Summary]:
    out = {fid: Summary(fid) for fid in kb.facts}
    for r in records:  # in file order: later records replace earlier ones of the same role
        s = out.get(r.fact)
        if s is None:
            continue
        if r.hash != fact_hash(kb.facts[r.fact]):
            s.stale += 1
            continue
        s.verdicts[r.role] = r
    return out


def counts(summaries: dict[str, Summary]) -> Counter:
    return Counter(s.state for s in summaries.values())


def render(summaries: dict[str, Summary], kb: KnowledgeBase, when: str) -> str:
    c = counts(summaries)
    split = [s for s in summaries.values() if s.split]
    L = [f"# 知識庫的多 Agent 預審｜{when}", "",
         "三個互相看不到彼此結果的 AI 審查角色各自看每筆事實：**來源**（來源存在、引文逐字出現、而且真的支持這個值）、"
         "**一致性**（層級、有效期間、推導來源、和其他事實的衝突、今天是否仍然成立）、**反方**（試著推翻它）。"
         "這是給人工審核的準備，**不算審核**：機器不能核准事實（兩人規則），事實的狀態不會因此改變。", "",
         f"- 預審全數通過（等人簽核）{c.get('ready', 0)}；有異議 {c.get('objection', 0)}（其中角色之間意見相反 {len(split)}）；"
         f"部分通過或不確定 {c.get('partial', 0)}；未預審 {c.get('none', 0)}", ""]
    bad = sorted((s for s in summaries.values() if s.state == "objection"), key=lambda s: s.fact)
    if bad:
        L += ["## 有異議的事實（人工先看這些）", ""]
        for s in bad:
            f = kb.facts[s.fact]
            L.append(f"### `{s.fact}`（{f.layer}，{f.status}）" + ("　⚠️ 角色之間意見相反，並列" if s.split else ""))
            L.append("")
            L.append(f"- 內容：{f.subject}：{f.predicate} = {str(f.value)[:160]}")
            for role in ROLES:
                r = s.verdicts.get(role)
                if r is None:
                    continue
                L.append(f"- **{ZH[role]}：{ZH[r.verdict]}**　{r.reasons}"
                         + (f"（依據：{'；'.join(r.evidence[:3])}）" if r.evidence else "")
                         + (f"　建議修正：{r.fix}" if r.fix else ""))
            L.append("")
    unsure = sorted((s for s in summaries.values() if s.state == "partial"), key=lambda s: s.fact)
    if unsure:
        L += ["## 部分通過或不確定", "", "| 事實 | " + " | ".join(ZH[r] for r in ROLES) + " | 理由（不確定的） |",
              "|---|---|---|---|---|"]
        for s in unsure:
            why = "；".join(f"{ZH[r.role]}：{r.reasons}" for r in s.verdicts.values() if r.verdict != "pass")
            L.append(f"| `{s.fact}` | " + " | ".join(ZH[s.verdicts[r].verdict] if r in s.verdicts else "—" for r in ROLES)
                     + f" | {why[:300]} |".replace("\n", " "))
        L.append("")
    ready = sorted(s.fact for s in summaries.values() if s.state == "ready")
    if ready:
        L += ["## 預審全數通過（等人簽核）", "", "、".join(f"`{x}`" for x in ready), "",
              "簽核方式：讀過來源後 `pmpol review approve <事實> --reviewer <你的名字>`。", ""]
    return "\n".join(L)
