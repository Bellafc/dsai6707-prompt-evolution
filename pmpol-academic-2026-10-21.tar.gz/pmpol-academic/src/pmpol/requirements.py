"""Priority intelligence requirements (PIR): start from the questions, not from what the markets happen to list.

`config/requirements.toml` holds the questions in priority order, each with how to recognise the evidence that
bears on it and which evidence lines a good answer needs. This module reads what the latest runs published
(proofs, macro judgments, settlement checks, price moves) and the latest snapshot's event titles, and reports
per question:

  answers   the cross-venue consensus estimates and outside views that bear on it (L5 inferences, with their
            analytic confidence; never facts)
  lines     which evidence lines exist and how much of each
  gaps      the lines a good answer needs that do not exist yet: the collection requirements

and the other way round, how much of the system's output answers no stated question (market-driven residue).
"""

from __future__ import annotations

import gzip
import json
import re
import tomllib
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[2] / "config" / "requirements.toml"
LINES = {"market": "市場（任一平台有題目）", "consensus": "跨平台共識", "structure": "一致性違反",
         "reference": "參考類別（外部視角）", "ratings": "專家評級", "polls": "民調", "fundamentals": "基本面",
         "macro": "總經判斷", "settlement": "結算資料", "news": "新聞與異動",
         "external": "外部預測"}
_STRUCTURE = re.compile(r"^(onto:|sum_|ladder|deadline|cross_venue)")


@dataclass
class Requirement:
    id: str
    question: str
    priority: int
    why: str
    subjects: list[str]
    markets: str = ""
    macro: str = ""
    lines: list[str] = field(default_factory=list)
    status: str = "proposed"
    review_by: str = ""
    news: str = ""  # news query polled for this question (pmpol newswatch)
    # the same in local editions: [{query, lang, country, edition}] (Google News hl, gl and ceid language)
    news_local: list = field(default_factory=list)

    def about(self, subject: str) -> bool:
        return any(re.search(p, subject or "") for p in self.subjects)


def load(path: Path = CONFIG) -> list[Requirement]:
    raw = tomllib.loads(path.read_text(encoding="utf-8"))
    out = [Requirement(**r) for r in raw.get("requirement", [])]
    for r in out:
        bad = [x for x in r.lines if x not in LINES]
        if bad:
            raise ValueError(f"requirement {r.id}: unknown evidence lines {bad}")
    return sorted(out, key=lambda r: (r.priority, r.id))


@dataclass
class Evidence:
    """What the latest runs published, flattened: (line, subject, title, conclusion, confidence, value, id)."""
    items: list[tuple] = field(default_factory=list)
    titles: list[tuple[str, str]] = field(default_factory=list)  # (venue, event title) of the latest snapshot
    ratings: list[str] = field(default_factory=list)  # races with expert ratings (data/candidates/ratings.json)


def _rows(path: Path) -> list[dict]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return raw.get("signals", []) if isinstance(raw, dict) else raw


def gather(data: Path = Path("data")) -> Evidence:
    ev = Evidence()
    for r in _rows(data / "proofs.json"):
        kind, p = r.get("kind", ""), r.get("proof", {})
        line = ("consensus" if kind == "consensus" else "reference" if kind == "outside_view" else
                "ratings" if kind == "rating_divergence" else "structure" if _STRUCTURE.match(kind) else None)
        if line == "reference" and isinstance(p.get("result", {}).get("fundamentals_p"), float):
            ev.items.append(("fundamentals", r.get("subject", ""), r.get("title", ""), p.get("conclusion", ""),
                             p.get("analytic_confidence", ""), 0.0, r.get("id", "")))
        if line:
            res = p.get("result", {})
            value = next((res[k] for k in ("recalibrated", "pooled", "base_rate") if isinstance(res.get(k), float)), 0.0)
            ev.items.append((line, r.get("subject", ""), r.get("title", ""), p.get("conclusion", ""),
                             p.get("analytic_confidence", ""), value, r.get("id", "")))
    for p in _rows(data / "macro" / "regimes.json"):
        ev.items.append(("macro", p.get("title", ""), p.get("title", ""), p.get("conclusion", ""),
                         p.get("analytic_confidence", ""), 0.0, p.get("title", "")))
    for name, line in (("settlement.json", "settlement"), ("movers.json", "news"), ("news.json", "news"),
                       ("gdelt.json", "news"), ("cn_balance_sheet.json", "macro"),
                       ("external.json", "external")):
        for r in _rows(data / name):
            ev.items.append((line, r.get("subject", ""), r.get("title", ""), r.get("proof", {}).get("conclusion", ""),
                             r.get("proof", {}).get("analytic_confidence", ""), 0.0, r.get("id", "")))
    snaps = sorted((data / "snapshots").glob("universe_*.json.gz"))
    if snaps:
        with gzip.open(snaps[-1], "rt", encoding="utf-8") as f:
            ev.titles = [(e["venue"], e["title"]) for e in json.load(f)]
    ev.ratings = sorted({r.get("race", "") for r in _rows(data / "candidates" / "ratings.json")})
    return ev


@dataclass
class Coverage:
    req: Requirement
    markets: Counter  # venue -> events whose title matches
    lines: Counter  # evidence line -> items
    answers: list[tuple[str, str, str, str]]  # (title, conclusion, confidence, proof id): consensus, outside views
    confidence: Counter  # analytic confidence of the matched proofs
    external: list[tuple[str, str]] = field(default_factory=list)  # (title, conclusion): external forecasts (L3)

    @property
    def gaps(self) -> list[str]:
        return [x for x in self.req.lines if not self.lines.get(x)]


def cover(req: Requirement, ev: Evidence) -> Coverage:
    lines, conf, answers, external = Counter(), Counter(), [], []
    rx_m = re.compile(req.markets, re.I) if req.markets else None
    rx_macro = re.compile(req.macro) if req.macro else None
    for line, subject, title, conclusion, level, value, iid in ev.items:
        if line == "macro":
            hit = bool(rx_macro and rx_macro.search(title))
        elif line == "external":  # pmpol external names the question it bears on
            hit = subject == f"external:{req.id}"
        elif line in ("settlement", "news"):
            hit = (subject == f"news:{req.id}" or req.about(subject)
                   or bool(rx_m and (rx_m.search(subject) or rx_m.search(title))))
        else:
            hit = req.about(subject)
        if not hit:
            continue
        lines[line] += 1
        if line == "external":
            external.append((title, conclusion))
            continue
        if level:
            conf[level] += 1
        if line in ("consensus", "reference"):
            rank = next(i for i, pat in enumerate(req.subjects) if re.search(pat, subject))
            answers.append((rank, line != "reference", subject, -value, title, conclusion, level, iid))
    markets = Counter(v for v, t in ev.titles if rx_m and rx_m.search(t))
    if markets:
        lines["market"] = sum(markets.values())
    rated = [r for r in ev.ratings if req.about(r) or req.about(f"winner({r})")]
    if rated:
        lines["ratings"] += len(rated)
    # the headline subject first (the outside view, then its likeliest outcome)
    answers = [a[4:] for a in sorted(answers, key=lambda a: a[:4])]
    return Coverage(req, markets, lines, answers, conf, external)


def residue(reqs: list[Requirement], ev: Evidence) -> tuple[int, int]:
    """(published proofs that answer no stated question, all published proofs) for the market-driven lines."""
    rows = [(line, s) for line, s, *_ in ev.items if line in ("consensus", "structure", "reference", "ratings")]
    orphan = sum(not any(r.about(s) for r in reqs) for _, s in rows)
    return orphan, len(rows)


def render(covs: list[Coverage], orphan: tuple[int, int], when: str) -> str:
    from pmpol.confidence import ZH

    L = [f"# 需求清單（PIR）｜{when}", "",
         "先列出要回答的問題，再看手上的證據夠不夠（`config/requirements.toml`；問題由系統提議，等團隊確認、調整順序）。"
         "答案是 L5 推論（跨平台共識、外部視角），附分析信心，不是事實；「缺口」是一個好答案需要、但還沒有的證據線，也就是下一步要蒐集的。",
         "", "| 優先 | 問題 | 相關市場 | 已有的證據線 | 缺口 |", "|---|---|---|---|---|"]
    for c in covs:
        have = "、".join(f"{LINES[x]} {c.lines[x]:,}" for x in c.req.lines if c.lines.get(x)) or "—"
        L.append(f"| {c.req.priority} | {c.req.question} | {sum(c.markets.values()):,} | {have} | "
                 f"{'、'.join(LINES[x] for x in c.gaps) or '無'} |")
    o, n = orphan
    L += ["", f"沒有對應任何問題的發布證明（共識、違反、外部視角、評級）：{o:,} / {n:,}（{100 * o / max(n, 1):.0f}%）——"
              "這部分是「有什麼市場就分析什麼」的產出，問題清單擴充後會變少。", ""]
    for c in covs:
        r = c.req
        L += [f"## {r.priority}. {r.question}（`{r.id}`，{'已確認' if r.status == 'confirmed' else '提議中'}，"
              f"{r.review_by} 前檢查）", "", f"- 為什麼：{r.why}"]
        if c.markets:
            L.append("- 相關市場：" + "、".join(f"{v} {n}" for v, n in c.markets.most_common()))
        else:
            L.append("- 相關市場：沒有找到（市場題目寫法要再擴充，或真的沒有市場）")
        if c.confidence:
            L.append("- 相關推理證明的分析信心：" + "、".join(f"{ZH.get(k, k)} {c.confidence.get(k, 0):,}"
                                                   for k in ("high", "moderate", "low") if c.confidence.get(k)))
        for title, conclusion, level, _ in c.answers[:6]:
            L.append(f"- 目前的答案：{title.split('｜', 1)[-1]}：{conclusion}（分析信心：{ZH.get(level, level or '—')}）")
        if len(c.answers) > 6:
            L.append(f"- ……另有 {len(c.answers) - 6} 個相關的共識估計")
        for title, conclusion in c.external:
            L.append(f"- 外部預測（L3 意見，不是事實）：{title.split('｜', 2)[-1]}：{conclusion}")
        if c.gaps:
            L.append("- **缺口（要蒐集的）**：" + "、".join(LINES[x] for x in c.gaps))
        L.append("")
    return "\n".join(L)
