"""Run manifests and source health: what each command read, wrote and saw, so any report can be traced
back to the exact inputs and code that produced it.

Modelled on OpenLineage (a run of a job reads input datasets and writes output datasets, with facets
for code version and data quality) and Dagster (asset checks, freshness policies), kept to one JSON
file per run plus three SQLite tables so it needs no server:

  runs           one row per command run: command, times, status, git sha, arguments, counts
  source_health  one row per source per run: ok, rows, seconds, error
  checks         one row per data-contract check (pmpol.contracts)

The manifest is written even when the command fails, so a broken run leaves a trace.
"""

from __future__ import annotations

import hashlib
import json
import platform
import sqlite3
import subprocess
import time
import traceback
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from pmpol.contracts import Check

RUNS_DIR = Path("data/runs")

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY, command TEXT, started_at TEXT, finished_at TEXT, status TEXT, git_sha TEXT,
    args TEXT, counts TEXT, error TEXT
);
CREATE TABLE IF NOT EXISTS source_health (
    run_id TEXT, source TEXT, ok INTEGER, n INTEGER, seconds REAL, error TEXT, at TEXT
);
CREATE INDEX IF NOT EXISTS source_health_source ON source_health (source, at);
CREATE TABLE IF NOT EXISTS checks (
    run_id TEXT, source TEXT, name TEXT, ok INTEGER, severity TEXT, observed TEXT, expected TEXT, detail TEXT
);
"""

# A source is stale when its last successful fetch is older than this (hours), by source family.
FRESHNESS_HOURS = {"venue": 36, "macro": 72, "news": 72, "osint": 72, "step": 26}  # step: a cycle at least daily


def _git(*args: str) -> str:
    try:
        return subprocess.run(["git", *args], capture_output=True, text=True, timeout=10,
                              cwd=Path(__file__).resolve().parent).stdout
    except Exception:
        return ""


CODE_DIRS = ("src/", "config/", "kb/")


def code_version() -> dict:
    """The commit plus a hash of every uncommitted change to code, config or the knowledge base, so a
    result produced from a dirty tree never claims to come from a clean commit."""
    sha = _git("rev-parse", "--short", "HEAD").strip()
    root = Path(_git("rev-parse", "--show-toplevel").strip() or ".")
    changed = sorted(line[3:].split(" -> ")[-1] for line in _git("status", "--porcelain").splitlines()
                     if line[3:].startswith(CODE_DIRS))
    h = hashlib.sha256()
    for rel in changed:
        p = root / rel
        h.update(rel.encode())
        if p.is_file():
            h.update(p.read_bytes())
    return {"git_sha": sha, "dirty": bool(changed), "dirty_files": len(changed),
            "diff_sha256": h.hexdigest()[:16] if changed else ""}


def module_version(*packages: str) -> str:
    """Hash of the source of the given pmpol packages or modules (Hamilton/Dagster-style code_version):
    a change elsewhere, or to the docs, does not change it."""
    base = Path(__file__).resolve().parent
    h = hashlib.sha256()
    for pkg in sorted(packages):
        p = base / pkg.replace("pmpol.", "").replace(".", "/")
        files = sorted(p.rglob("*.py")) if p.is_dir() else [p.with_suffix(".py")]
        for f in files:
            if f.is_file():
                h.update(f.relative_to(base).as_posix().encode())
                h.update(f.read_bytes())
    return h.hexdigest()[:12]


def licence_terms(venues) -> list[str]:
    """The restrictive terms an output inherits from the venues whose data went into it (licence taint):
    anything not marked commercial-use-free in pmpol.venues travels with the output."""
    from pmpol.venues import info

    return sorted({f"{info(v).label}: {info(v).terms}" for v in set(venues) if not info(v).commercial})


def file_digest(path: Path) -> dict:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return {"path": str(path), "sha256": h.hexdigest(), "bytes": path.stat().st_size}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass
class SourceResult:
    source: str
    ok: bool
    n: int = 0
    seconds: float = 0.0
    error: str = ""


@dataclass
class Run:
    command: str
    args: dict = field(default_factory=dict)
    id: str = ""
    started_at: str = ""
    finished_at: str = ""
    status: str = "running"
    code: dict = field(default_factory=dict)
    inputs: list[dict] = field(default_factory=list)
    outputs: list[dict] = field(default_factory=list)
    sources: list[SourceResult] = field(default_factory=list)
    checks: list[Check] = field(default_factory=list)
    counts: dict = field(default_factory=dict)
    error: str = ""

    def __post_init__(self):
        if not self.started_at:
            self.started_at = _now()
        if not self.id:
            self.id = f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}_{self.command}"

    def read(self, path: Path | str) -> None:
        p = Path(path)
        if p.is_file():
            self.inputs.append(file_digest(p))

    def wrote(self, path: Path | str, rows: int | None = None, licence: list[str] | None = None) -> None:
        p = Path(path)
        if p.is_file():
            d = file_digest(p)
            if rows is not None:
                d["rows"] = rows
            if licence:
                d["licence"] = licence
            self.outputs.append(d)

    def source(self, name: str, ok: bool, n: int = 0, seconds: float = 0.0, error: str = "") -> None:
        self.sources.append(SourceResult(name, ok, n, round(seconds, 2), error[:300]))

    def check(self, checks: list[Check]) -> None:
        self.checks += checks

    def to_dict(self) -> dict:
        return {"id": self.id, "command": self.command, "args": self.args, "started_at": self.started_at,
                "finished_at": self.finished_at, "status": self.status,
                "code": {**self.code, "python": platform.python_version()},
                "inputs": self.inputs, "outputs": self.outputs, "counts": self.counts,
                "sources": [s.__dict__ for s in self.sources], "checks": [c.to_dict() for c in self.checks],
                "error": self.error}

    def save(self, conn: sqlite3.Connection, runs_dir: Path = RUNS_DIR) -> Path:
        runs_dir.mkdir(parents=True, exist_ok=True)
        path = runs_dir / f"{self.id}.json"
        path.write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=1, default=str))
        conn.executescript(SCHEMA)
        conn.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?,?,?,?)",
                     (self.id, self.command, self.started_at, self.finished_at, self.status,
                      self.code.get("git_sha", "") + ("+dirty" if self.code.get("dirty") else ""),
                      json.dumps(self.args, default=str), json.dumps(self.counts, default=str), self.error))
        conn.executemany("INSERT INTO source_health VALUES (?,?,?,?,?,?,?)",
                         [(self.id, s.source, int(s.ok), s.n, s.seconds, s.error, self.started_at)
                          for s in self.sources])
        conn.executemany("INSERT INTO checks VALUES (?,?,?,?,?,?,?,?)",
                         [(self.id, c.source, c.name, int(c.ok), c.severity, c.observed, c.expected, c.detail)
                          for c in self.checks])
        conn.commit()
        return path


@contextmanager
def track(command: str, args: dict | None = None, db: Path | None = None, runs_dir: Path = RUNS_DIR):
    """`with track("universe", vars(args)) as run:` records the run, and saves it even if the body raises."""
    from pmpol import store

    run = Run(command, {k: v for k, v in (args or {}).items() if k != "func"}, code=code_version())
    t0 = time.monotonic()
    try:
        yield run
        run.status = "ok" if not any(c.severity == "error" and not c.ok for c in run.checks) else "ok_with_errors"
    except BaseException as e:
        run.status, run.error = "failed", "".join(traceback.format_exception_only(type(e), e)).strip()[:500]
        raise
    finally:
        run.finished_at = _now()
        run.counts.setdefault("seconds", round(time.monotonic() - t0, 1))
        with store.connect(db) if db else store.connect() as conn:
            run.save(conn, runs_dir)


def previous_counts(conn: sqlite3.Connection, prefix: str = "venue:") -> dict[str, int]:
    """Rows in the last successful fetch of each source (for the count_vs_previous_run check)."""
    conn.executescript(SCHEMA)
    rows = conn.execute("""SELECT source, n FROM source_health h WHERE ok = 1 AND source LIKE ? AND at = (
                             SELECT MAX(at) FROM source_health WHERE source = h.source AND ok = 1)""",
                        (prefix + "%",)).fetchall()
    return {s: n for s, n in rows}


@dataclass
class Health:
    source: str
    last_ok: str | None
    last_n: int
    last_attempt: str
    last_error: str
    failures_in_a_row: int
    stale: bool


def health(conn: sqlite3.Connection, now: datetime | None = None) -> list[Health]:
    """Per-source freshness: last success, consecutive failures, and whether it is past its freshness window."""
    conn.executescript(SCHEMA)
    now = now or datetime.now(timezone.utc)
    out = []
    for (src,) in conn.execute("SELECT DISTINCT source FROM source_health ORDER BY source").fetchall():
        rows = conn.execute("SELECT ok, n, at, error FROM source_health WHERE source = ? ORDER BY at DESC",
                            (src,)).fetchall()
        streak = 0
        for ok, *_ in rows:
            if ok:
                break
            streak += 1
        last_ok = next(((at, n) for ok, n, at, _ in rows if ok), None)
        family = src.split(":", 1)[0]
        limit = timedelta(hours=FRESHNESS_HOURS.get(family, 72))
        stale = last_ok is None or now - datetime.fromisoformat(last_ok[0]) > limit
        out.append(Health(src, last_ok[0] if last_ok else None, last_ok[1] if last_ok else 0, rows[0][2],
                          rows[0][3] if not rows[0][0] else "", streak, stale))
    return out


def recent_runs(conn: sqlite3.Connection, limit: int = 20) -> list[tuple]:
    conn.executescript(SCHEMA)
    return conn.execute("SELECT id, command, status, started_at, finished_at, git_sha, counts, error FROM runs "
                        "ORDER BY started_at DESC LIMIT ?", (limit,)).fetchall()


def failed_checks(conn: sqlite3.Connection, run_id: str) -> list[tuple]:
    return conn.execute("SELECT source, name, severity, observed, expected, detail FROM checks "
                        "WHERE run_id = ? AND ok = 0 ORDER BY severity, source", (run_id,)).fetchall()


STATUS_ZH = {"ok": "完成", "ok_with_errors": "完成（有資料錯誤）", "failed": "失敗", "running": "執行中或中斷"}


def render_status(conn: sqlite3.Connection, now: datetime | None = None, limit: int = 15) -> str:
    """System status: recent runs, per-source freshness, failed data checks, and what we could not see."""
    now = now or datetime.now(timezone.utc)
    L = [f"# 系統狀態 — {now:%Y-%m-%d %H:%M} UTC", "",
         "每次執行都會留下一份紀錄（`data/runs/<執行代號>.json`）：讀了哪些檔、寫了哪些檔（附 SHA-256）、程式版本"
         "（含未提交的修改）、各來源的結果、資料檢查。這一頁是這些紀錄的摘要。", ""]
    from pmpol.audit import section

    L += section(conn, now.date())
    hs = health(conn, now)
    gaps = [h for h in hs if h.stale or h.failures_in_a_row]
    L += ["## 1. 這次看不到什麼", ""]
    if gaps:
        for h in gaps:
            why = (f"連續失敗 {h.failures_in_a_row} 次（{h.last_error[:80]}）" if h.failures_in_a_row
                   else f"最後一次成功是 {(h.last_ok or '從未')[:16]}，已超過新鮮度期限")
            L.append(f"- `{h.source}`：{why}")
    else:
        L.append("- 所有來源都在新鮮度期限內，最近一次都成功。")
    from pmpol.assumptions import load as load_assumptions

    overdue = [a for a in load_assumptions().values() if a.overdue(now.date())]
    if overdue:
        L.append("- 關鍵假設過了檢查日期（`pmpol assumptions`）：" + "、".join(f"`{a.id}`（{a.review_by}）" for a in overdue))
    from pmpol.schedule import last_run

    lr = last_run()
    L += ["", "## 1b. 排程", ""]
    if lr is None:
        L.append("- 還沒有排程執行的紀錄（`pmpol scheduled`，設定方式見 `deploy/README.md`）。")
    else:
        ago = (now - datetime.fromisoformat(lr["started"])).total_seconds() / 3600
        state = "逾時" if lr.get("timed_out") else ("成功" if lr.get("exit_code") == 0 else
                                                 "有步驟失敗：" + "、".join(lr.get("failed_steps") or ["?"]))
        L.append(f"- 最近一次排程循環：{lr['started'][:16]}（{ago:.1f} 小時前），{state}；記錄 `{lr['log']}`"
                 + (f"；報告：{lr['commit']}" if lr.get("commit") else ""))
        if ago > FRESHNESS_HOURS["step"]:
            L.append(f"- ⚠️ 超過 {FRESHNESS_HOURS['step']} 小時沒有排程循環：排程可能停了。")
    L += ["", "## 2. 來源健康", "",
          f"新鮮度期限：平台 {FRESHNESS_HOURS['venue']} 小時、總經 {FRESHNESS_HOURS['macro']} 小時。", "",
          "| 來源 | 狀態 | 最後成功 | 筆數 | 連續失敗 |", "|---|---|---|---|---|"]
    for h in hs:
        state = "❌ 失敗中" if h.failures_in_a_row else ("⚠️ 過期" if h.stale else "✅")
        L.append(f"| `{h.source}` | {state} | {(h.last_ok or '—')[:16]} | {h.last_n:,} | {h.failures_in_a_row} |")
    L += ["", "## 3. 最近的執行", "", "| 執行 | 指令 | 狀態 | 程式版本 | 秒數 | 摘要 |", "|---|---|---|---|---|---|"]
    rows = recent_runs(conn, limit)
    for rid, cmd, status, started, finished, sha, counts, err in rows:
        c = json.loads(counts or "{}")
        brief = "、".join(f"{k} {v:,}" if isinstance(v, int) else f"{k} {v}" for k, v in c.items()
                         if k not in ("seconds",))[:120]
        L.append(f"| `{rid}` | {cmd} | {STATUS_ZH.get(status, status)} | `{sha or '?'}` | {c.get('seconds', '')} | "
                 f"{brief or (err or '')[:80]} |")
    L += ["", "## 4. 未通過的資料檢查（每個指令最近一次執行）", ""]
    latest = {}
    for rid, cmd, *_ in rows:
        latest.setdefault(cmd, rid)
    any_bad = False
    for cmd, rid in latest.items():
        bad = failed_checks(conn, rid)
        if not bad:
            continue
        any_bad = True
        L += [f"**{cmd}**（`{rid}`）", "", "| 對象 | 檢查 | 嚴重度 | 實際 | 預期 | 例子 |", "|---|---|---|---|---|---|"]
        L += [f"| `{s}` | {n} | {sev} | {o} | {e} | {d[:60]} |" for s, n, sev, o, e, d in bad]
        L.append("")
    if not any_bad:
        L += ["全部通過。", ""]
    L += ["## 怎麼讀", "",
          "- **error**：資料本身錯了（價格超出 0–1、代號重複），要從來源端修正；資料不會被刪掉，但下游要小心。",
          "- **warn**：資料看起來不尋常（掛單交叉、筆數比上次少一半、序列太久沒更新），值得人工看一眼。",
          "- **未觀測不等於沒發生**：來源失敗時，相關的推理證明會標明「未觀測」，不會把它當成「沒有新聞」或「其他平台沒動」。", ""]
    return "\n".join(L)
