"""Signposts for load-bearing assumptions (RAND assumption-based planning: Dewar 2002, "Assumption-Based
Planning"; Dewar et al. 1993).

The key-assumptions register says what would overturn each assumption and how to check it, but the checks were
manual. Here the assumptions most proofs rest on get observables that are measured automatically on every cycle
(`config/signposts.toml`):

  load-bearing   cited by at least LOAD_BEARING published proofs (pmpol.assumptions.impact)
  signpost       a metric with a threshold; when crossed, the assumption is failing or is due to be tested
  action         what to do then (the pre-planned shaping or hedging action)

Readings are kept (`signposts` table) so a trend is visible. A triggered signpost calls for the action and a
review; it never changes an assumption's status by itself. Load-bearing assumptions without any signpost are
listed: they rest on a manual check alone.

Version 2 (2026-10-05), so that a noisy metric does not flap and every change of state leaves a record:
  persist    a signpost triggers only after this many readings in a row beyond the threshold (default 1); before
             that it is on "watch"
  clear      once triggered, it clears only when the reading is back beyond this level (hysteresis; default: the
             threshold itself)
  events     every change of state is logged (`signpost_events`), so that later, with outcomes, one can count how
             often a trigger was followed by the assumption actually failing (the signpost's hit rate)
"""

from __future__ import annotations

import gzip
import json
import operator
import sqlite3
import statistics
import tomllib
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[2] / "config" / "signposts.toml"
LOAD_BEARING = 100
OPS = {">": operator.gt, "<": operator.lt}
SCHEMA = """
CREATE TABLE IF NOT EXISTS signposts (
    ts TEXT, id TEXT, assumption TEXT, value REAL, threshold REAL, state TEXT, detail TEXT, run_id TEXT,
    UNIQUE (ts, id)
);
CREATE TABLE IF NOT EXISTS signpost_events (
    ts TEXT, id TEXT, assumption TEXT, from_state TEXT, to_state TEXT, value REAL, run_id TEXT,
    UNIQUE (ts, id)
);
"""


@dataclass
class Signpost:
    id: str
    assumption: str
    metric: str
    op: str
    threshold: float
    meaning: str
    action: str
    args: dict = field(default_factory=dict)
    persist: int = 1  # readings in a row beyond the threshold before it triggers
    clear: float | None = None  # a triggered signpost clears only beyond this level (None: the threshold)

    def beyond(self, value: float) -> bool:
        return OPS[self.op](value, self.threshold)

    def cleared(self, value: float) -> bool:
        """Back on the safe side of the clear level (strictly)."""
        level = self.threshold if self.clear is None else self.clear
        return not OPS[self.op](value, level) and value != level


def load(path: Path = CONFIG) -> list[Signpost]:
    out = [Signpost(**s) for s in tomllib.loads(path.read_text(encoding="utf-8")).get("signpost", [])]
    for s in out:
        if s.metric not in METRICS or s.op not in OPS:
            raise ValueError(f"signpost {s.id}: unknown metric {s.metric!r} or op {s.op!r}")
        if s.clear is not None and OPS[s.op](s.clear, s.threshold):
            raise ValueError(f"signpost {s.id}: clear level {s.clear} must be on the safe side of the threshold")
    return out


@dataclass
class Context:
    today: date
    kb: object = None  # pmpol.kb.KnowledgeBase
    data: Path = Path("data")
    conn: sqlite3.Connection | None = None


# --- metrics: each returns (value, detail) or (None, why there is no reading) --------------------------------------

def kb_age_days(ctx: Context, fact: str = "", prefix: str = "") -> tuple[float | None, str]:
    """Days since the fact (or the oldest of the facts with `prefix`) was recorded."""
    facts = [f for fid, f in ctx.kb.facts.items() if fid == fact or (prefix and fid.startswith(prefix))]
    if not facts:
        return None, "知識庫裡沒有這筆事實"
    oldest = min(facts, key=lambda f: f.recorded_at)
    return float((ctx.today - oldest.recorded_at).days), f"{oldest.id} 記錄於 {oldest.recorded_at}"


def days_since(ctx: Context, date: str) -> tuple[float | None, str]:
    from datetime import date as _date

    return float((ctx.today - _date.fromisoformat(date)).days), f"從 {date} 起算"


def family_change_corr(ctx: Context, family: str, member: str, other: str, min_hours: float = 1.0,
                       snapshots: int = 6) -> tuple[float | None, str]:
    """corr(change of family, change of member) - corr(change of family, change of other), over the consensus
    classes quoted by all three in consecutive snapshots at least `min_hours` apart (the latest `snapshots`).
    Below 0: the member moves with its family less than an outside venue does."""
    from datetime import datetime

    if ctx.conn is None:
        return None, "沒有資料庫"
    times = [r[0] for r in ctx.conn.execute("SELECT DISTINCT ts FROM signals WHERE module = 'consensus' ORDER BY ts")]
    times = times[-snapshots:]

    def mids(ts: str) -> dict[str, dict[str, float]]:
        out = {}
        for subject, payload in ctx.conn.execute("SELECT subject, payload FROM signals WHERE module = 'consensus' "
                                                 "AND ts = ?", (ts,)):
            by: dict[str, list[float]] = {}
            for key, mid in json.loads(payload).get("mids", {}).items():
                by.setdefault(key.split(":", 1)[0], []).append(mid)
            out[subject] = {v: statistics.mean(m) for v, m in by.items()}
        return out

    df, dm, do, pairs = [], [], [], 0
    for a, b in zip(times, times[1:]):
        if (datetime.fromisoformat(b) - datetime.fromisoformat(a)).total_seconds() < 3600 * min_hours:
            continue
        pairs += 1
        A, B = mids(a), mids(b)
        for s in set(A) & set(B):
            if all(v in A[s] and v in B[s] for v in (family, member, other)):
                df.append(B[s][family] - A[s][family])
                dm.append(B[s][member] - A[s][member])
                do.append(B[s][other] - A[s][other])
    if len(df) < 30:
        return None, f"相隔 {min_hours:g} 小時以上的快照配對只有 {len(df)} 個合約變動"
    try:
        same, cross = statistics.correlation(df, dm), statistics.correlation(df, do)
    except statistics.StatisticsError:
        return None, "價格沒有變動"
    return same - cross, (f"{pairs} 組快照配對、{len(df):,} 個合約變動：{family} 和 {member} 的價格變動相關係數 "
                          f"{same:.2f}，和 {other} {cross:.2f}")


def kalshi_election_close_share(ctx: Context, year: int, before: str) -> tuple[float | None, str]:
    snaps = sorted((ctx.data / "snapshots").glob("universe_*.json.gz"))
    if not snaps:
        return None, "沒有快照"
    with gzip.open(snaps[-1], "rt", encoding="utf-8") as f:
        events = json.load(f)
    closes = [m.get("close_time") or "" for e in events if e["venue"] == "kalshi" and str(year) in e["title"]
              and any(w in e["title"] for w in ("House", "Senate", "Governor", "governor"))
              for m in e["markets"]]
    closes = [c for c in closes if c]
    if not closes:
        return None, "快照裡沒有 Kalshi 的選舉市場"
    early = sum(c < before for c in closes)
    return early / len(closes), f"{snaps[-1].name[9:22]}：{len(closes):,} 個 Kalshi {year} 選舉市場，{early:,} 個在 {before} 前截止"


def outside_view_gap(ctx: Context, group: str) -> tuple[float | None, str]:
    try:
        rows = json.loads((ctx.data / "proofs.json").read_text(encoding="utf-8")).get("signals", [])
    except (OSError, ValueError):
        return None, "沒有推理證明檔"
    for r in rows:
        if r.get("kind") == "outside_view" and r.get("subject") == group:
            res = r["proof"]["result"]
            if res.get("market") is None:
                return None, "這組沒有市場共識"
            return abs(res["gap"]), f"市場 {100 * res['market']:.0f}%、基準率 {100 * res['base_rate']:.0f}%"
    return None, "沒有這組的外部視角證明"


METRICS: dict[str, Callable[..., tuple[float | None, str]]] = {
    "kb_age_days": kb_age_days, "days_since": days_since, "family_change_corr": family_change_corr,
    "kalshi_election_close_share": kalshi_election_close_share, "outside_view_gap": outside_view_gap}


@dataclass
class Reading:
    signpost: Signpost
    value: float | None
    detail: str
    previous: float | None = None
    history: list[float] = field(default_factory=list)  # earlier readings, newest first
    last_state: str | None = None  # the latest recorded state other than no_data

    @property
    def state(self) -> str:
        """no_data, ok, watch (beyond the threshold, not yet for `persist` readings) or triggered."""
        s = self.signpost
        if self.value is None:
            return "no_data"
        if self.last_state == "triggered":
            return "ok" if s.cleared(self.value) else "triggered"
        if not s.beyond(self.value):
            return "ok"
        run = 1
        for v in self.history:
            if run >= s.persist or not s.beyond(v):
                break
            run += 1
        return "triggered" if run >= s.persist else "watch"


def measure(signposts: list[Signpost], ctx: Context) -> list[Reading]:
    out = []
    for s in signposts:
        try:
            value, detail = METRICS[s.metric](ctx, **s.args)
        except (OSError, ValueError, KeyError) as e:  # a broken input is a missing reading, not a crash
            value, detail = None, f"無法計算：{e}"
        prev, history, last = None, [], None
        if ctx.conn is not None:
            ctx.conn.executescript(SCHEMA)
            history = [r[0] for r in ctx.conn.execute(
                "SELECT value FROM signposts WHERE id = ? AND value IS NOT NULL ORDER BY ts DESC LIMIT ?",
                (s.id, max(s.persist, 1))).fetchall()]
            prev = history[0] if history else None
            row = ctx.conn.execute("SELECT state FROM signposts WHERE id = ? AND state != 'no_data' ORDER BY ts DESC "
                                   "LIMIT 1", (s.id,)).fetchone()
            last = row[0] if row else None
        out.append(Reading(s, value, detail, prev, history, last))
    return out


def record(conn: sqlite3.Connection, readings: list[Reading], ts: str, run_id: str = "") -> None:
    conn.executescript(SCHEMA)
    conn.executemany("INSERT OR REPLACE INTO signposts VALUES (?,?,?,?,?,?,?,?)",
                     [(ts, r.signpost.id, r.signpost.assumption, r.value, r.signpost.threshold, r.state, r.detail,
                       run_id) for r in readings])
    # a change of state (no_data is a missing reading, not a state) is an event
    conn.executemany("INSERT OR REPLACE INTO signpost_events VALUES (?,?,?,?,?,?,?)",
                     [(ts, r.signpost.id, r.signpost.assumption, r.last_state or "new", r.state, r.value, run_id)
                      for r in readings if r.state != "no_data" and r.state != r.last_state])
    conn.commit()


def events(conn: sqlite3.Connection, limit: int = 30) -> list[tuple[str, str, str, str, str, float | None]]:
    """(ts, id, assumption, from, to, value), newest first."""
    conn.executescript(SCHEMA)
    return conn.execute("SELECT ts, id, assumption, from_state, to_state, value FROM signpost_events "
                        "ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()


def latest(conn: sqlite3.Connection, ids: set[str] | None = None) -> list[tuple[str, str, str, float | None, str]]:
    """(id, assumption, state, value, detail) of the latest reading of every configured signpost (signposts
    removed from the configuration keep their history but are not reported)."""
    conn.executescript(SCHEMA)
    ids = ids if ids is not None else {s.id for s in load()}
    return [r for r in conn.execute("SELECT s.id, s.assumption, s.state, s.value, s.detail FROM signposts s JOIN (SELECT id, "
                                    "MAX(ts) ts FROM signposts GROUP BY id) m ON s.id = m.id AND s.ts = m.ts "
                                    "ORDER BY s.id").fetchall() if r[0] in ids]


def uncovered(signposts: list[Signpost], impact: dict[str, int]) -> list[tuple[str, int]]:
    """Load-bearing assumptions with no signpost: (assumption, proofs citing it)."""
    have = {s.assumption for s in signposts}
    return sorted(((a, n) for a, n in impact.items() if n >= LOAD_BEARING and a not in have), key=lambda t: -t[1])


def _fmt(v: float | None) -> str:
    return "—" if v is None else f"{v:.2f}" if abs(v) < 10 else f"{v:.0f}"


ZH = {"triggered": "⚠️ 觸發", "watch": "觀察中", "ok": "正常", "no_data": "沒有讀數", "new": "（新路標）"}


def render(readings: list[Reading], impact: dict[str, int], bare: list[tuple[str, int]], when: str,
           log: list[tuple] | None = None) -> str:
    zh = ZH
    L = [f"# 承重假設的路標｜{when}", "",
         f"承重假設：被 {LOAD_BEARING} 份以上發布的推理證明引用。每個路標是一個自動量測的指標，越過門檻代表假設正在失效、"
         "或到了可以檢驗的時候，要執行預先想好的行動並重新審核假設（`config/signposts.toml`；方法：RAND 以假設為基礎的規劃）。"
         "路標觸發不會自動改變假設的狀態。連續幾次越過門檻才觸發（之前是「觀察中」），觸發後要回到解除水準以內才解除"
         "（避免讀數在門檻附近來回跳）；每次狀態改變都留下紀錄，之後可以算路標的命中率。", "",
         "| 路標 | 假設（引用數） | 讀數 | 門檻 | 連續次數／解除水準 | 上次 | 狀態 | 依據 |", "|---|---|---|---|---|---|---|---|"]
    for r in sorted(readings, key=lambda r: (r.state != "triggered", r.state != "watch", r.state != "no_data",
                                             r.signpost.id)):
        s = r.signpost
        rule = f"{s.persist} 次／{_fmt(s.threshold if s.clear is None else s.clear)}"
        L.append(f"| `{s.id}` | `{s.assumption}`（{impact.get(s.assumption, 0):,}） | {_fmt(r.value)} | {s.op} {_fmt(s.threshold)} | "
                 f"{rule} | {_fmt(r.previous)} | {zh[r.state]} | {r.detail} |")
    trig = [r for r in readings if r.state == "triggered"]
    if trig:
        L += ["", "## 觸發的路標：要做的事", ""]
        for r in trig:
            L += [f"- **`{r.signpost.id}`**（假設 `{r.signpost.assumption}`）：{r.signpost.meaning}", f"  - 行動：{r.signpost.action}"]
    if log:
        L += ["", "## 狀態變化紀錄（最近）", "", "| 時間 | 路標 | 假設 | 從 | 到 | 讀數 |", "|---|---|---|---|---|---|"]
        L += [f"| {ts[:16]} | `{i}` | `{a}` | {zh.get(f, f)} | {zh.get(t, t)} | {_fmt(v)} |" for ts, i, a, f, t, v in log]
    L += ["", "## 沒有自動路標的承重假設", ""]
    L += [f"- `{a}`（{n:,} 份證明）：只靠 `config/assumptions.toml` 裡的人工檢查" for a, n in bare] or ["- 沒有。"]
    return "\n".join(L + [""])
