"""Coherence projection: the nearest set of probabilities that satisfies every relation at once (2026-10-05).

A violation says two quotes cannot both be right; it does not say which one is off. Projecting all quotes onto the
set of coherent probabilities does: find q minimising sum_i w_i (q_i - mid_i)^2 subject to every relation the
ontology derived (equivalent: sum q(lhs) = sum q(rhs); implies: sum q(lhs) <= sum q(rhs)), 0 <= q <= 1, and
options of a mutually exclusive event adding up to at most 1. The weight is the quote's precision, w = 1/sigma^2
with sigma = half the spread plus a floor, so a tight book moves little and a wide one absorbs the adjustment.
The size of a market's move, in units of its sigma, is how strongly the rest of the market disagrees with it.

Method: Dykstra's alternating projections (Boyle & Dykstra 1986) in the weighted norm, which converge to the exact
projection onto an intersection of convex sets (here half-spaces, hyperplanes and the box), one connected
component of markets at a time. The idea of projecting forecasts onto logical constraints follows Paleka et al.
("Consistency checks for language model forecasters", 2024) and, for markets, Kroer et al. 2016; their code is
not used (the former has no licence).

The output is an L5 inference about the market, never a fact: where a relation rests on an assumption or on
rules that differ across venues, the move inherits that weakness (each market lists the relations that bind it).
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field

SIGMA_FLOOR = 0.01  # probability units: no quote is trusted to better than a point
MAX_SPREAD = 0.20  # wider books carry no information worth projecting


@dataclass
class Constraint:
    coef: dict[str, float]  # market key -> coefficient (a . q)
    rhs: float
    equal: bool  # a . q == rhs, else a . q <= rhs
    source: str = ""  # relation template or "exclusive:<event>"


def from_relation(kind: str, lhs: list[str], rhs: list[str], source: str) -> Constraint:
    coef: dict[str, float] = defaultdict(float)
    for k in lhs:
        coef[k] += 1.0
    for k in rhs:
        coef[k] -= 1.0
    return Constraint(dict(coef), 0.0, kind == "equivalent", source)


@dataclass
class Result:
    q: dict[str, float]  # coherent probability per market
    mid: dict[str, float]
    sigma: dict[str, float]
    binding: dict[str, list[str]] = field(default_factory=dict)  # market -> sources of constraints that moved it
    components: list[tuple[list[str], float]] = field(default_factory=list)  # (markets, weighted distance)
    iterations: int = 0

    def z(self, k: str) -> float:
        return (self.q[k] - self.mid[k]) / self.sigma[k]


def _project(x: dict[str, float], c: Constraint, w: dict[str, float]) -> dict[str, float] | None:
    """Weighted projection of x onto one half-space or hyperplane; None when x already satisfies it."""
    a = c.coef
    val = sum(a[k] * x[k] for k in a)
    gap = val - c.rhs
    if (c.equal and abs(gap) < 1e-12) or (not c.equal and gap <= 0):
        return None
    norm = sum(a[k] * a[k] / w[k] for k in a)
    if norm == 0:
        return None
    t = gap / norm
    return {k: x[k] - t * a[k] / w[k] for k in a}


def project(prices: dict[str, tuple[float, float]], constraints: list[Constraint], iters: int = 400,
            tol: float = 1e-7) -> Result:
    """prices: market -> (mid, sigma). Constraints whose markets are not all priced are left out."""
    cons = [c for c in constraints if c.coef and all(k in prices for k in c.coef)]
    mid = {k: v[0] for k, v in prices.items()}
    sigma = {k: v[1] for k, v in prices.items()}
    w = {k: 1.0 / (s * s) for k, s in sigma.items()}
    # connected components over the constraints
    parent = {k: k for k in prices}

    def find(k):
        while parent[k] != k:
            parent[k] = parent[parent[k]]
            k = parent[k]
        return k

    for c in cons:
        ks = list(c.coef)
        for k in ks[1:]:
            ra, rb = find(ks[0]), find(k)
            if ra != rb:
                parent[ra] = rb
    groups: dict[str, list[int]] = defaultdict(list)
    for i, c in enumerate(cons):
        groups[find(next(iter(c.coef)))].append(i)
    res = Result(dict(mid), mid, sigma)
    moved_by: dict[str, set[str]] = defaultdict(set)
    total_iters = 0
    for root, idx in groups.items():
        members = sorted({k for i in idx for k in cons[i].coef})
        x = {k: mid[k] for k in members}
        corr = [None] * len(idx)  # Dykstra corrections, one per constraint
        box_corr = {k: 0.0 for k in members}
        for it in range(iters):
            change = 0.0
            for j, i in enumerate(idx):
                c = cons[i]
                p = corr[j] or {}
                y = {k: x[k] + p.get(k, 0.0) for k in c.coef}
                z = _project(y, c, w)
                z = z if z is not None else y
                corr[j] = {k: y[k] - z[k] for k in c.coef}
                for k in c.coef:
                    change = max(change, abs(z[k] - x[k]))
                    x[k] = z[k]
                if any(abs(v) > 1e-9 for v in corr[j].values()):
                    for k in c.coef:
                        moved_by[k].add(c.source)
            for k in members:  # the box [0, 1]
                y = x[k] + box_corr[k]
                z = min(max(y, 0.0), 1.0)
                box_corr[k] = y - z
                change = max(change, abs(z - x[k]))
                x[k] = z
            total_iters += 1
            if change < tol:
                break
        res.q.update(x)
        res.components.append((members, sum(w[k] * (x[k] - mid[k]) ** 2 for k in members)))
    res.binding = {k: sorted(v) for k, v in moved_by.items()}
    res.iterations = total_iters
    res.components.sort(key=lambda t: -t[1])
    return res


def prices_from(u, keys) -> dict[str, tuple[float, float]]:
    """(mid, sigma) for live markets with a two-sided book no wider than MAX_SPREAD."""
    out = {}
    for k in keys:
        m = u.markets.get(k)
        if m is None or not m.active or m.bid is None or m.ask is None or m.ask <= 0 or m.ask < m.bid:
            continue
        if m.ask - m.bid > MAX_SPREAD:
            continue
        out[k] = ((m.bid + m.ask) / 2, (m.ask - m.bid) / 2 + SIGMA_FLOOR)
    return out


def exclusive_constraints(u, keys: set[str]) -> list[Constraint]:
    """Options of a mutually exclusive event add up to at most 1 (at most one pays)."""
    out = []
    by_event: dict[str, list[str]] = defaultdict(list)
    for k in keys:
        ev = u.market_event.get(k)
        if ev and u.events[ev].mutually_exclusive:
            by_event[ev].append(k)
    for ev, ks in by_event.items():
        if len(ks) >= 2:
            out.append(Constraint({k: 1.0 for k in ks}, 1.0, False, f"exclusive:{ev}"))
    return out


def run(u, relations) -> Result:
    """Project the universe's quotes onto the relations (pipeline helper)."""
    cons = [from_relation(r.kind, r.lhs, r.rhs, r.template) for r in relations]
    keys = {k for r in relations for k in r.lhs + r.rhs}
    prices = prices_from(u, keys)
    cons += exclusive_constraints(u, set(prices))
    return project(prices, cons)


def render(res: Result, u, top: int = 25) -> list[str]:
    """Report section: the markets the rest of the market disagrees with most."""
    from pmpol.venues import info

    moved = sorted((k for k in res.q if abs(res.q[k] - res.mid[k]) > 1e-4), key=lambda k: -abs(res.z(k)))
    if not moved:
        return []
    dist = sum(d for _, d in res.components)
    L = ["### 3c. 一致性投影：誰最可能錯價", "",
         "在所有關係同時成立的前提下，找離市價最近的一組機率（以價差加權：價差窄的報價移動得少）。下表是被移動最多的市場，"
         "「移動」以它自己的不確定度（半價差＋1 點）為單位：其他市場合起來越不同意它，數字越大。這是 L5 推論，不是事實；"
         "依據的關係如果建立在假設或規則不同的配對上，移動也一樣不可靠（見「依據」欄）。", "",
         f"{len(res.q):,} 個市場、{len(res.components):,} 個連通的群組；總加權距離 {dist:,.1f}（{res.iterations:,} 次迭代）", "",
         "| 市場 | 平台 | 市價 | 一致的機率 | 移動（σ） | 依據 |", "|---|---|---|---|---|---|"]
    for k in moved[:top]:
        m = u.markets[k]
        ev = u.events.get(u.market_event.get(k, ""))
        name = f"{(ev.title if ev else m.question)[:50]}｜{(m.outcome or 'Yes')[:24]}".replace("|", "／")
        src = "、".join(s.replace("onto:", "") for s in res.binding.get(k, [])[:3])
        L.append(f"| {name} | {info(m.venue).code} | {100 * res.mid[k]:.1f}% | {100 * res.q[k]:.1f}% | "
                 f"{res.z(k):+.1f} | {src} |")
    L.append("")
    return L


def summary(res: Result, u, top: int = 200) -> dict:
    moved = sorted((k for k in res.q if abs(res.q[k] - res.mid[k]) > 1e-4), key=lambda k: -abs(res.z(k)))
    return {"markets": len(res.q), "components": len(res.components),
            "distance": round(sum(d for _, d in res.components), 3), "iterations": res.iterations,
            "moved": [{"market": k, "mid": round(res.mid[k], 4), "coherent": round(res.q[k], 4),
                       "z": round(res.z(k), 2), "binding": res.binding.get(k, [])} for k in moved[:top]]}


def _check(res: Result, constraints: list[Constraint], tol: float = 1e-4) -> float:
    """Largest remaining violation (for tests and the run log)."""
    worst = 0.0
    for c in constraints:
        if not all(k in res.q for k in c.coef):
            continue
        v = sum(a * res.q[k] for k, a in c.coef.items()) - c.rhs
        worst = max(worst, abs(v) if c.equal else max(v, 0.0))
    return worst if not math.isnan(worst) else 0.0
