"""Kalshi public market data (no authentication needed for reads)."""

from __future__ import annotations

from pmpol import USER_AGENT

import time
from collections.abc import Iterator

import httpx

from pmpol.models import Event, Market

BASE_URL = "https://api.elections.kalshi.com/trade-api/v2"
# Kalshi general taker fee: 0.07 * P * (1 - P) per contract, rounded up per order.
TAKER_FEE_RATE = 0.07


def _f(x) -> float | None:
    if x in (None, ""):
        return None
    return float(x)


def parse_market(m: dict, event_id: str) -> Market:
    rules = "\n".join(r for r in (m.get("rules_primary"), m.get("rules_secondary")) if r)
    return Market(
        venue="kalshi",
        market_id=m["ticker"],
        event_id=event_id,
        question=m.get("title") or "",
        outcome=m.get("yes_sub_title") or "",
        rules=rules,
        bid=_f(m.get("yes_bid_dollars")),
        ask=_f(m.get("yes_ask_dollars")),
        last=_f(m.get("last_price_dollars")),
        bid_size=_f(m.get("yes_bid_size_fp")),
        ask_size=_f(m.get("yes_ask_size_fp")),
        volume=_f(m.get("volume_fp")),
        close_time=m.get("close_time"),
        active=m.get("status") == "active",
        strike_type=m.get("strike_type"),
        floor_strike=_f(m.get("floor_strike")),
        cap_strike=_f(m.get("cap_strike")),
        fee_rate=TAKER_FEE_RATE,
    )


def parse_event(e: dict, markets: list[dict] | None = None) -> Event:
    markets = markets if markets is not None else e.get("markets") or []
    return Event(
        venue="kalshi",
        event_id=e["event_ticker"],
        title=e.get("title") or "",
        category=e.get("category") or "",
        mutually_exclusive=bool(e.get("mutually_exclusive")),
        markets=[parse_market(m, e["event_ticker"]) for m in markets],
    )


class KalshiClient:
    def __init__(self, base_url: str = BASE_URL, timeout: float = 30.0):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def _get(self, path: str, params: dict | None = None, retries: int = 5) -> httpx.Response:
        """GET with backoff on gateway errors (502-504, the network path). A rate limit (429) or a refusal is raised
        at once, never retried (the project's rule)."""
        for attempt in range(retries + 1):
            r = self._http.get(path, params=params)
            if r.status_code not in (502, 503, 504) or attempt == retries:
                r.raise_for_status()
                return r
            wait = r.headers.get("Retry-After")
            time.sleep(float(wait) if wait and wait.replace(".", "", 1).isdigit() else 2 ** attempt)
        raise AssertionError("unreachable")

    def get_event(self, event_ticker: str) -> Event:
        r = self._get(f"/events/{event_ticker}", params={"with_nested_markets": "true"})
        d = r.json()
        return parse_event(d["event"], d.get("markets") or d["event"].get("markets"))

    def iter_events(self, status: str = "open", categories: set[str] | None = None) -> Iterator[Event]:
        cursor = None
        while True:
            params = {"limit": 200, "status": status, "with_nested_markets": "true"}
            if cursor:
                params["cursor"] = cursor
            r = self._get("/events", params=params)
            d = r.json()
            for e in d.get("events", []):
                if categories is None or e.get("category") in categories:
                    yield parse_event(e)
            cursor = d.get("cursor")
            if not cursor or not d.get("events"):
                return
