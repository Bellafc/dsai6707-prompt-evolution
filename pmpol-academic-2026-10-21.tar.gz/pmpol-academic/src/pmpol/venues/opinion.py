"""Opinion (Opinion Labs, BNB Chain order book). OpenAPI; documented as needing an `apikey` header,
which is sent when PMPOL_OPINION_KEY is set (reads worked without one on 2026-10-02).

Listings carry no prices, so each YES token's order book is fetched.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import os
from collections.abc import Iterator
from datetime import datetime, timezone

import httpx

from pmpol.models import Event, Market
from pmpol.venues import fetch_all, one_of

BASE_URL = "https://openapi.opinion.trade/openapi"
VENUE = "opinion"
POLITICS_LABEL = 1
# Fees are not published in the listing; assume a flat 2 cents per contract (conservative, unverified).
FLAT_FEE = 0.02


def _ts(x) -> str | None:
    return datetime.fromtimestamp(int(x), tz=timezone.utc).isoformat() if x else None


def top_of_book(book: dict) -> tuple[float | None, float | None, float | None, float | None]:
    bids = [(float(b["price"]), float(b["size"])) for b in book.get("bids") or []]
    asks = [(float(a["price"]), float(a["size"])) for a in book.get("asks") or []]
    bid = max(bids) if bids else (None, None)
    ask = min(asks) if asks else (None, None)
    return bid[0], ask[0], bid[1], ask[1]


def parse_market(m: dict, parent: dict, book: dict | None) -> Market:
    bid, ask, bid_size, ask_size = top_of_book(book or {})
    child = m is not parent
    return Market(
        venue=VENUE,
        market_id=str(m["marketId"]),
        event_id=str(parent["marketId"]),
        question=parent.get("marketTitle") or "",
        outcome=(m.get("marketTitle") or "").strip() if child else "Yes",
        rules=parent.get("rules") or m.get("rules") or "",
        bid=bid if bid is not None else (0.0 if ask is not None else None),
        ask=ask, bid_size=bid_size, ask_size=ask_size,
        close_time=_ts(m.get("cutoffAt") or parent.get("cutoffAt")),
        active=(m.get("statusEnum") or parent.get("statusEnum")) == "Activated",
        token_id=m.get("yesTokenId"),
        fee_rate=FLAT_FEE,
        fee_exponent=0.0,
    )


def parse_event(parent: dict, books: dict[str, dict]) -> Event:
    legs = parent.get("childMarkets") or [parent]
    markets = [parse_market(m, parent, books.get(m.get("yesTokenId"))) for m in legs]
    return Event(
        venue=VENUE,
        event_id=str(parent["marketId"]),
        title=(parent.get("marketTitle") or "").strip(),
        category=",".join(parent.get("labels") or []),
        mutually_exclusive=one_of(parent.get("marketTitle") or "", [m.outcome for m in markets]),
        markets=markets,
    )


class OpinionClient:
    def __init__(self, base_url: str = BASE_URL, timeout: float = 60.0):
        headers = {"User-Agent": USER_AGENT}
        if key := os.environ.get("PMPOL_OPINION_KEY"):
            headers["apikey"] = key
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers=headers)

    def _result(self, path: str, params: dict) -> dict:
        r = self._http.get(path, params=params)
        r.raise_for_status()
        d = r.json()
        if d.get("errno"):
            raise RuntimeError(f"opinion {path}: {d.get('errmsg')}")
        return d.get("result") or {}

    def book(self, token_id: str) -> dict:
        return self._result("/token/orderbook", {"token_id": token_id})

    def size_at(self, token_id: str, side: str, price: float) -> float:
        book = self.book(token_id)
        levels = book.get("bids" if side == "bid" else "asks") or []
        ok = (lambda p: p >= price - 1e-9) if side == "bid" else (lambda p: p <= price + 1e-9)
        return sum(float(lv["size"]) for lv in levels if ok(float(lv["price"])))

    def iter_events(self, label: int = POLITICS_LABEL) -> Iterator[Event]:
        parents: dict[int, dict] = {}
        for market_type in (0, 1, 2):  # the listing only returns every type when asked per type
            page = 1
            while True:
                res = self._result("/market", {"labelId": label, "status": "activated", "marketType": market_type,
                                               "page": page, "limit": 20})
                for m in res.get("list") or []:
                    parents[m["marketId"]] = m
                if len(res.get("list") or []) < 20:
                    break
                page += 1
        tokens = [m["yesTokenId"] for p in parents.values() for m in (p.get("childMarkets") or [p])
                  if m.get("yesTokenId")]
        books = fetch_all(self.book, tokens)
        for p in parents.values():
            yield parse_event(p, books)
