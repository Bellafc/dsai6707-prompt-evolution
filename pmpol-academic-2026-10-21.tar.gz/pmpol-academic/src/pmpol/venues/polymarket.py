"""Polymarket public market data via the Gamma API."""

from __future__ import annotations

from pmpol import USER_AGENT

import json
from collections.abc import Iterator

import httpx

from pmpol.models import Event, Market

GAMMA_URL = "https://gamma-api.polymarket.com"
CLOB_URL = "https://clob.polymarket.com"


def _f(x) -> float | None:
    if x in (None, ""):
        return None
    return float(x)


def parse_market(m: dict, event_id: str) -> Market:
    last = _f(m.get("lastTradePrice"))
    prices = m.get("outcomePrices")
    if last is None and prices:
        last = _f(json.loads(prices)[0])
    schedule = (m.get("feeSchedule") or {}) if m.get("feesEnabled") else {}
    tokens = json.loads(m["clobTokenIds"]) if m.get("clobTokenIds") else []
    bid = _f(m.get("bestBid"))
    ask = _f(m.get("bestAsk"))
    return Market(
        venue="polymarket",
        market_id=m.get("slug") or str(m.get("id")),
        event_id=event_id,
        question=m.get("question") or "",
        outcome=(m.get("groupItemTitle") or "").strip(),
        rules=m.get("description") or "",
        # An empty book shows up as missing bid; treat it as a zero bid.
        bid=bid if bid is not None else (0.0 if ask is not None else None),
        ask=ask,
        last=last,
        volume=_f(m.get("volumeNum")),
        close_time=m.get("endDate"),
        active=bool(m.get("active")) and not m.get("closed") and bool(prices),
        token_id=tokens[0] if tokens else None,
        fee_rate=float(schedule.get("rate") or 0.0),
        fee_exponent=float(schedule.get("exponent") or 1.0),
    )


def parse_event(e: dict) -> Event:
    return Event(
        venue="polymarket",
        event_id=e["slug"],
        title=(e.get("title") or "").strip(),
        category=",".join(t.get("slug", "") for t in e.get("tags") or []),
        mutually_exclusive=bool(e.get("negRisk")),
        markets=[parse_market(m, e["slug"]) for m in e.get("markets") or []],
    )


class PolymarketClient:
    def __init__(self, base_url: str = GAMMA_URL, timeout: float = 60.0):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def get_event(self, slug: str) -> Event:
        r = self._http.get("/events", params={"slug": slug})
        r.raise_for_status()
        d = r.json()
        if not d:
            raise KeyError(f"polymarket event not found: {slug}")
        return parse_event(d[0])

    def iter_events(self, tag_slug: str | None = None, closed: bool = False) -> Iterator[Event]:
        """Keyset pagination; the offset-based /events endpoint stops at offset 2000."""
        cursor = None
        while True:
            params = {"limit": 100, "closed": str(closed).lower()}
            if tag_slug:
                params["tag_slug"] = tag_slug
            if cursor:
                params["after_cursor"] = cursor
            r = self._http.get("/events/keyset", params=params)
            r.raise_for_status()
            d = r.json()
            for e in d.get("events", []):
                yield parse_event(e)
            cursor = d.get("next_cursor")
            if not cursor or not d.get("events"):
                return


class ClobBooks:
    """Read-only Polymarket CLOB (V2) order books. Gamma quotes carry no size; this fills it in."""

    def __init__(self, base_url: str = CLOB_URL, timeout: float = 20.0):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def book(self, token_id: str) -> dict:
        r = self._http.get("/book", params={"token_id": token_id})
        r.raise_for_status()
        return r.json()

    def size_at(self, token_id: str, side: str, price: float) -> float:
        """Shares available at `price` or better: side "bid" for selling YES, "ask" for buying YES."""
        book = self.book(token_id)
        levels = book.get("bids" if side == "bid" else "asks") or []
        ok = (lambda p: p >= price - 1e-9) if side == "bid" else (lambda p: p <= price + 1e-9)
        return sum(float(lv["size"]) for lv in levels if ok(float(lv["price"])))
