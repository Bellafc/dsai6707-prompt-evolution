"""Limitless (Base chain order book). Keyless API.

Groups of markets are linked with a neg-risk adapter, as on Polymarket, so their outcomes are
mutually exclusive. Listings carry only a mid price; each market's order book is fetched.
Order sizes are in USDC base units (1e6).
"""

from __future__ import annotations

from pmpol import USER_AGENT

from collections.abc import Iterator
from datetime import datetime, timezone

import httpx

from pmpol.models import Event, Market
from pmpol.venues import fetch_all

BASE_URL = "https://api.limitless.exchange"
VENUE = "limitless"
POLITICS_CATEGORY = 51
SIZE_UNIT = 1_000_000
# Fees are not in the listing; assume a flat 2 cents per contract (conservative, unverified).
FLAT_FEE = 0.02


def _ts(ms) -> str | None:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc).isoformat() if ms else None


def top_of_book(book: dict) -> tuple[float | None, float | None, float | None, float | None]:
    bids = [(float(b["price"]), float(b["size"]) / SIZE_UNIT) for b in book.get("bids") or []]
    asks = [(float(a["price"]), float(a["size"]) / SIZE_UNIT) for a in book.get("asks") or []]
    bid = max(bids) if bids else (None, None)
    ask = min(asks) if asks else (None, None)
    return bid[0], ask[0], bid[1], ask[1]


def _plain(html: str) -> str:
    import re
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html or "")).strip()


def parse_market(m: dict, group: dict, book: dict | None) -> Market:
    bid, ask, bid_size, ask_size = top_of_book(book or {})
    child = m is not group
    return Market(
        venue=VENUE,
        market_id=m["slug"],
        event_id=group["slug"],
        question=group.get("title") or "",
        outcome=("Other" if m.get("isOther") else (m.get("title") or "").strip()) if child else "Yes",
        rules=_plain(m.get("description") or group.get("description") or ""),
        bid=bid if bid is not None else (0.0 if ask is not None else None),
        ask=ask, bid_size=bid_size, ask_size=ask_size,
        close_time=_ts(m.get("expirationTimestamp") or group.get("expirationTimestamp")),
        active=not m.get("expired") and not m.get("hidden") and m.get("status") == "FUNDED",
        fee_rate=FLAT_FEE,
        fee_exponent=0.0,
    )


def parse_event(group: dict, books: dict[str, dict]) -> Event:
    legs = group.get("markets") or [group]
    markets = [parse_market(m, group, books.get(m["slug"])) for m in legs]
    neg_risk = len(legs) > 1 and all(m.get("negRiskRequestId") for m in legs)
    return Event(
        venue=VENUE,
        event_id=group["slug"],
        title=(group.get("title") or "").strip(),
        category=",".join(group.get("categories") or []),
        mutually_exclusive=neg_risk,
        markets=markets,
    )


class LimitlessClient:
    def __init__(self, base_url: str = BASE_URL, timeout: float = 60.0):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def book(self, slug: str) -> dict:
        r = self._http.get(f"/markets/{slug}/orderbook")
        r.raise_for_status()
        return r.json()

    def size_at(self, slug: str, side: str, price: float) -> float:
        book = self.book(slug)
        levels = book.get("bids" if side == "bid" else "asks") or []
        ok = (lambda p: p >= price - 1e-9) if side == "bid" else (lambda p: p <= price + 1e-9)
        return sum(float(lv["size"]) / SIZE_UNIT for lv in levels if ok(float(lv["price"])))

    def iter_events(self, category: int = POLITICS_CATEGORY) -> Iterator[Event]:
        groups, page = [], 1
        while True:
            r = self._http.get(f"/markets/active/{category}", params={"page": page, "limit": 25})
            r.raise_for_status()
            d = r.json()
            groups += d.get("data") or []
            if not d.get("data") or len(groups) >= d.get("totalMarketsCount", 0):
                break
            page += 1
        slugs = [m["slug"] for g in groups for m in (g.get("markets") or [g]) if m.get("slug")]
        books = fetch_all(self.book, slugs)
        for g in groups:
            yield parse_event(g, books)
