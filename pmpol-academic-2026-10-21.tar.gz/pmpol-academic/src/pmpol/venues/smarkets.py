"""Smarkets (UK betting exchange). Public v3 API, no key for events, markets, contracts and quotes.

Smarkets nests event -> market -> contract. A Smarkets *market* (e.g. "Michigan Senate Election
Winner") is the set of mutually exclusive outcomes, so it maps to our Event; each contract maps
to a Market. Prices are basis points of probability (1852 = 18.52%).
"""

from __future__ import annotations

from pmpol import USER_AGENT

from collections import defaultdict
from collections.abc import Iterator

import httpx

from pmpol.models import Event, Market

BASE_URL = "https://api.smarkets.com/v3"
VENUE = "smarkets"
# Commission on net winnings; 2% is the published standard rate (check current rate before relying on it).
COMMISSION = 0.02
# Quote quantities are in 1/10,000 of a GBP-1 contract (unverified unit; used only for depth).
QUANTITY_UNIT = 10_000


def _best(levels: list[dict], best) -> tuple[float | None, float | None]:
    if not levels:
        return None, None
    lv = best(levels, key=lambda x: x["price"])
    return lv["price"] / 10_000, lv["quantity"] / QUANTITY_UNIT


def _quote(q: dict | None) -> tuple[float | None, float | None, float | None, float | None]:
    q = q or {}
    bid, bid_size = _best(q.get("bids") or [], max)
    ask, ask_size = _best(q.get("offers") or [], min)
    return bid, ask, bid_size, ask_size


def parse_market(contract: dict, market: dict, event: dict, quotes: dict, no: dict | None = None) -> Market:
    """One contract as a YES market. For a Yes/No pair, the No book adds to the YES side:
    buying No at a is selling YES at 1 - a."""
    bid, ask, bid_size, ask_size = _quote(quotes.get(contract["id"]))
    if no is not None:
        n_bid, n_ask, n_bid_size, n_ask_size = _quote(quotes.get(no["id"]))
        if n_ask is not None and (bid is None or 1 - n_ask > bid):
            bid, bid_size = 1 - n_ask, n_ask_size
        if n_bid is not None and (ask is None or 1 - n_bid < ask):
            ask, ask_size = 1 - n_bid, n_bid_size
    if ask is not None and bid is None:
        bid, bid_size = 0.0, None
    title = market.get("name") or event.get("name") or ""
    return Market(
        venue=VENUE,
        market_id=contract["id"],
        event_id=market["id"],
        question=market.get("description") or title,
        outcome="Yes" if no is not None else (contract.get("name") or "").strip(),
        rules=event.get("special_rules") or "",
        bid=bid, ask=ask, bid_size=bid_size, ask_size=ask_size,
        close_time=event.get("start_datetime"),
        active=market.get("state") == "open" and contract.get("state_or_outcome") == "open",
        profit_commission=COMMISSION,
    )


def parse_event(market: dict, event: dict, contracts: list[dict], quotes: dict) -> Event:
    names = {c.get("name", "").strip().lower(): c for c in contracts}
    if set(names) == {"yes", "no"}:
        markets = [parse_market(names["yes"], market, event, quotes, no=names["no"])]
    else:
        markets = [parse_market(c, market, event, quotes) for c in contracts if not c.get("hidden")]
    return Event(
        venue=VENUE,
        event_id=market["id"],
        title=(market.get("name") or event.get("name") or "").strip(),
        category=(event.get("full_slug") or "").strip("/").rsplit("/", 1)[0],
        mutually_exclusive=market.get("winner_count") == 1 and len(markets) > 1,
        markets=markets,
    )


class SmarketsClient:
    def __init__(self, base_url: str = BASE_URL, timeout: float = 60.0):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def _get(self, path: str) -> dict:
        r = self._http.get(path)
        r.raise_for_status()
        return r.json()

    def iter_events(self, domain: str = "politics", batch: int = 50) -> Iterator[Event]:
        events, url = [], f"/events/?type_domain={domain}&state=upcoming&state=live&type_scope=single_event&limit=50"
        while url:
            d = self._get(url)
            events += d.get("events") or []
            nxt = (d.get("pagination") or {}).get("next_page")
            url = f"/events/{nxt}" if nxt else None
        by_id = {e["id"]: e for e in events}
        markets = []
        for i in range(0, len(events), batch):
            markets += self._get(f"/events/{','.join(e['id'] for e in events[i:i + batch])}/markets/")["markets"]
        markets = [m for m in markets if m.get("state") == "open" and not m.get("hidden")]
        contracts: dict[str, list[dict]] = defaultdict(list)
        quotes: dict = {}
        for i in range(0, len(markets), 100):
            ids = ",".join(m["id"] for m in markets[i:i + 100])
            for c in self._get(f"/markets/{ids}/contracts/")["contracts"]:
                contracts[c["market_id"]].append(c)
            quotes.update(self._get(f"/markets/{ids}/quotes/"))
        for m in markets:
            yield parse_event(m, by_id[m["event_id"]], contracts[m["id"]], quotes)
