"""Venue registry: which prediction markets we read, how their contracts are shaped, and their data terms.

Only venues with their own order book are listed. Front ends that resell another venue's
liquidity (FRONT_ENDS) are never crawled, so the same liquidity is not counted twice.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass


@dataclass(frozen=True)
class VenueInfo:
    name: str  # Market.venue value
    code: str  # short label in reports
    label: str
    terms: str  # data licence / terms of use
    commercial: bool  # whether the data may be used commercially without a separate licence
    # How margin markets are written: "ladder" = "party wins by >= k" (Kalshi strikes);
    # "bucket" = "party wins by a-b%" (one market per interval).
    margin_style: str
    # Whether a mutually exclusive event is only exhaustive when a live "Other" bucket exists ("other"),
    # or when an open-ended label such as "below"/"above" is present ("words").
    exhaustive_rule: str
    # Main customer region ("US" or "non-US"; survey of 2026-10-02, not legal advice). Two venues in
    # different regions usually cannot be traded by the same person, so a gap between them is a
    # disagreement between two trader populations, not an arbitrage.
    region: str = "unknown"


VENUES: dict[str, VenueInfo] = {v.name: v for v in (
    VenueInfo("kalshi", "K", "Kalshi", "Kalshi data terms: personal research; no redistribution of compiled data",
              False, "ladder", "words", "US"),
    VenueInfo("polymarket", "P", "Polymarket", "public API", True, "bucket", "other", "non-US"),
    VenueInfo("polymarket_us", "PU", "Polymarket US", "public API (docs.polymarket.us)", True, "bucket", "other", "US"),
    VenueInfo("gemini", "G", "Gemini Predictions", "Gemini API terms", True, "bucket", "other", "US"),
    VenueInfo("smarkets", "S", "Smarkets", "Smarkets API terms", False, "bucket", "other", "non-US"),
    VenueInfo("cryptocom", "C", "Crypto.com", "data API EULA: non-commercial use only", False, "bucket", "other", "US"),
    VenueInfo("opinion", "O", "Opinion", "Opinion OpenAPI terms", False, "bucket", "other", "non-US"),
    VenueInfo("predictit", "PI", "PredictIt", "PredictIt data: non-commercial use only", False, "bucket", "other",
              "US"),
    VenueInfo("limitless", "L", "Limitless", "public API", True, "bucket", "other", "non-US"),
)}

# Venues with their own book that are not crawled yet, and why.
PENDING: dict[str, str] = {
    "predict.fun": "needs a free API key (Binance Wallet's prediction markets run on it)",
    "betfair": "needs an account and an app key",
    "forecastex": "needs an Interactive Brokers account",
}

# Products that route to another venue's book (survey of 2026-10-02, docs/OSS_SURVEY.md part 4).
FRONT_ENDS: dict[str, str] = {
    "Binance Wallet": "predict.fun",
    "OKX Web3 Wallet": "polymarket",
    "Bitget Wallet": "polymarket",
    "Bybit Prediction": "polymarket",
    "Coinbase Wallet": "polymarket",
    "Coinbase Predictions": "kalshi",
    "FanDuel / Underdog / Fanatics": "crypto.com",
}


def info(venue: str) -> VenueInfo:
    return VENUES.get(venue) or VenueInfo(venue, venue[:2].upper(), venue, "unknown", False, "bucket", "other",
                                          "unknown")


def fetch_all(fn: Callable[[str], dict], ids: Iterable[str], workers: int = 8) -> dict[str, dict]:
    """Call fn(id) for each id in parallel; ids whose call fails are left out (reported by absence)."""
    ids = list(dict.fromkeys(ids))

    def safe(i):
        try:
            return i, fn(i)
        except Exception:
            return i, None

    with ThreadPoolExecutor(max_workers=workers) as pool:
        return {i: r for i, r in pool.map(safe, ids) if r is not None}


# Fees that are assumptions rather than published schedules (see each adapter).
ASSUMED_FEES = {"cryptocom", "opinion", "limitless"}


def source_url(m) -> str:
    """A public URL where the market's current quote can be re-checked (API endpoints, which are exact)."""
    v, mid, eid = m.venue, m.market_id, m.event_id
    return {
        "kalshi": f"https://api.elections.kalshi.com/trade-api/v2/markets/{mid}",
        "polymarket": f"https://polymarket.com/event/{eid}",
        "polymarket_us": f"https://gateway.polymarket.us/v1/markets/{mid}/bbo",
        "gemini": f"https://api.gemini.com/v1/book/{mid}",
        "smarkets": f"https://api.smarkets.com/v3/markets/{eid}/quotes/",
        "cryptocom": f"https://data-api.crypto.com/api/v1/predictions/events/{eid}/contracts",
        "opinion": f"https://openapi.opinion.trade/openapi/token/orderbook?token_id={m.token_id}",
        "predictit": f"https://www.predictit.org/markets/detail/{eid}",
        "limitless": f"https://api.limitless.exchange/markets/{mid}/orderbook",
    }.get(v, f"{v}:{mid}")


def venue_order(venue: str) -> int:
    names = list(VENUES)
    return names.index(venue) if venue in names else len(names)


# --- mutual exclusivity for venues that do not flag it ----------------------------------

# Titles that name a single slot: exactly one listed outcome can win.
_ONE_SLOT = re.compile(
    r"\bwinner\b|margin of victory|\bcombo\b|\bclosest\b|\bcloser\b|\bnominee\b|^next\b|\bthe next\b|"
    r"after (?:the )?(?:next )?(?:\w+ )?election|balance of power|which party|how many|seats\?|popular vote|"
    r"\bturnout\b", re.I)
# Outcome labels that make an event a ladder or a set of deadlines, which are nested, not exclusive.
_NESTED_LABEL = re.compile(r"^(by|before|above|below|over|under|at least|more than|fewer than|less than)\b|^[≥>]", re.I)
# "180+", "5% or more": one such label can be the top bucket of a partition; two or more make a ladder.
_THRESHOLD_LABEL = re.compile(r"^\$?\d[\d,.]*\s*[kmb%]?\s*(\+|or more|or higher|or above)$", re.I)


def one_of(title: str, labels: list[str]) -> bool:
    """Whether a venue's event is a single-winner question. Precision first: unknown shapes are False."""
    if len(labels) < 2 or any(_NESTED_LABEL.match(lab.strip()) for lab in labels):
        return False
    if sum(bool(_THRESHOLD_LABEL.match(lab.strip())) for lab in labels) >= 2:
        return False
    return bool(_ONE_SLOT.search(title))
