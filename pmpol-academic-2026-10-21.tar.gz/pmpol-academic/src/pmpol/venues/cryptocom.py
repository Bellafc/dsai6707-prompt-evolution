"""Crypto.com / OG prediction markets (CDNA, a CFTC-registered exchange) via the keyless data API.

The same contracts are sold through several US front ends (Underdog, Fanatics, Truth Social's
OG link), so this is one book, counted once. Data is under a non-commercial EULA.
The feed gives only the price to buy YES and to buy NO; there are no sizes and no rules text.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import re
from collections.abc import Iterator
from datetime import datetime, timezone

import httpx

from pmpol.models import Event, Market
from pmpol.venues import one_of

BASE_URL = "https://data-api.crypto.com/api/v1/predictions"
VENUE = "cryptocom"
# Fees are not published in the feed; assume a flat 2 cents per contract (conservative, unverified).
FLAT_FEE = 0.02
_EXPIRY = re.compile(r"_(\d{6})-(\d{4})_")


def _f(x) -> float | None:
    return None if x in (None, "") else float(x)


def _expiry(symbol: str) -> str | None:
    """Expiry encoded in the symbol, e.g. "..._270131-0500_..." -> 2027-01-31 (the event_date field is stale)."""
    m = _EXPIRY.search(symbol or "")
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%y%m%d").replace(tzinfo=timezone.utc).isoformat()
    except ValueError:
        return None


def parse_market(c: dict, e: dict) -> Market:
    ask, no_ask = _f(c.get("yes")), _f(c.get("no"))
    bid = 1 - no_ask if no_ask is not None else None
    single = len(e.get("contracts") or []) == 1
    return Market(
        venue=VENUE,
        market_id=c["symbol"],
        event_id=e["id"],
        question=e.get("title") or "",
        outcome="Yes" if single and (c.get("title") or "").lower() == "yes" else (c.get("title") or "").strip(),
        bid=round(bid, 4) if bid is not None else (0.0 if ask is not None else None),
        ask=ask,
        close_time=_expiry(c.get("symbol", "")),
        active=c.get("status") == "active" and e.get("status") == "active",
        fee_rate=FLAT_FEE,
        fee_exponent=0.0,
    )


def parse_event(e: dict) -> Event:
    markets = [parse_market(c, e) for c in e.get("contracts") or []]
    return Event(
        venue=VENUE,
        event_id=e["id"],
        title=(e.get("title") or "").strip(),
        category=e.get("kind") or "",
        mutually_exclusive=one_of(e.get("title") or "", [m.outcome for m in markets]),
        markets=markets,
    )


class CryptoComClient:
    def __init__(self, base_url: str = BASE_URL, timeout: float = 60.0):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def iter_events(self, kind: str = "ELECT") -> Iterator[Event]:
        cursor = None
        while True:
            params = {"kind": kind, "limit": 50}
            if cursor:
                params["cursor"] = cursor
            r = self._http.get("/events", params=params)
            r.raise_for_status()
            d = r.json()
            for e in d.get("data") or []:
                yield parse_event(e)
            page = d.get("pagination") or {}
            cursor = page.get("next_cursor")
            if not page.get("has_more") or not cursor:
                return
