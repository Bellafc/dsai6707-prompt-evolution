"""PredictIt (US, CFTC no-action relief). One keyless endpoint with every market's top of book.

Data is for non-commercial use. No sizes and no rules text in this feed.
Fees: 10% of profit on each winning contract (plus 5% on withdrawals, not modelled).
"""

from __future__ import annotations

from pmpol import USER_AGENT

from collections.abc import Iterator

import httpx

from pmpol.models import Event, Market
from pmpol.venues import one_of

URL = "https://www.predictit.org/api/marketdata/all/"
VENUE = "predictit"
PROFIT_FEE = 0.10


def _f(x) -> float | None:
    return float(x) if isinstance(x, (int, float)) else None


def parse_market(c: dict, m: dict) -> Market:
    # Selling YES at b is the same as buying NO at 1 - b, and vice versa: take the better of each.
    buy_no, sell_no = _f(c.get("bestBuyNoCost")), _f(c.get("bestSellNoCost"))
    bids = [p for p in (_f(c.get("bestSellYesCost")), None if buy_no is None else 1 - buy_no) if p is not None]
    asks = [p for p in (_f(c.get("bestBuyYesCost")), None if sell_no is None else 1 - sell_no) if p is not None]
    bid, ask = (round(max(bids), 4) if bids else None), (round(min(asks), 4) if asks else None)
    single = len(m.get("contracts") or []) == 1
    end = c.get("dateEnd")
    return Market(
        venue=VENUE,
        market_id=str(c["id"]),
        event_id=str(m["id"]),
        question=m.get("name") or "",
        outcome="Yes" if single else (c.get("name") or "").strip(),
        bid=bid if bid is not None else (0.0 if ask is not None else None),
        ask=ask,
        last=_f(c.get("lastTradePrice")),
        close_time=end if end and end[:4].isdigit() else None,  # "NA" / "N/A" when open-ended
        active=c.get("status") == "Open" and m.get("status") == "Open",
        profit_commission=PROFIT_FEE,
    )


def parse_event(m: dict) -> Event:
    markets = [parse_market(c, m) for c in m.get("contracts") or []]
    return Event(
        venue=VENUE,
        event_id=str(m["id"]),
        title=(m.get("name") or "").strip(),
        category="",
        mutually_exclusive=one_of(m.get("name") or "", [x.outcome for x in markets]),
        markets=markets,
    )


class PredictItClient:
    def __init__(self, url: str = URL, timeout: float = 60.0):
        self._url = url
        self._http = httpx.Client(timeout=timeout, headers={"User-Agent": USER_AGENT})

    def iter_events(self) -> Iterator[Event]:
        r = self._http.get(self._url)
        r.raise_for_status()
        for m in r.json().get("markets") or []:
            yield parse_event(m)
