"""Polymarket US (CFTC-regulated exchange, separate order book from international Polymarket).

Public gateway, no key, about 20 requests per second per IP. Prices are for the "long"
side of each market, which is YES.
"""

from __future__ import annotations

from pmpol import USER_AGENT

from collections.abc import Iterator

import httpx

from pmpol.models import Event, Market
from pmpol.venues import one_of

BASE_URL = "https://gateway.polymarket.us"
VENUE = "polymarket_us"


def _px(q) -> float | None:
    if not q:
        return None
    v = q.get("value") if isinstance(q, dict) else q
    return None if v in (None, "") else float(v)


def parse_market(m: dict, event_id: str) -> Market:
    long_side = next((s for s in m.get("marketSides") or [] if s.get("long")), None)
    yes_is_long = long_side is not None and (long_side.get("description") or "").strip().lower() == "yes"
    bid, ask = _px(m.get("bestBidQuote")), _px(m.get("bestAskQuote"))
    return Market(
        venue=VENUE,
        market_id=m["slug"],
        event_id=event_id,
        question=m.get("question") or "",
        outcome=(m.get("title") or m.get("titleShort") or "").strip(),
        rules=m.get("description") or "",
        # An empty bid side shows up as a missing quote; treat it as a zero bid, as on Polymarket.
        bid=bid if bid is not None else (0.0 if ask is not None else None),
        ask=ask,
        close_time=m.get("endDate"),
        # Quotes are for the long side; a market whose long side is not YES is left out rather than guessed.
        active=bool(m.get("active")) and not m.get("closed") and m.get("status") == "MARKET_STATUS_OPEN"
        and yes_is_long,
        fee_rate=float(m.get("feeCoefficient") or 0.0),
    )


def parse_event(e: dict) -> Event:
    markets = [parse_market(m, e["slug"]) for m in e.get("markets") or []]
    return Event(
        venue=VENUE,
        event_id=e["slug"],
        title=(e.get("title") or "").strip(),
        category=",".join(t.get("slug", "") for t in e.get("tags") or []) or e.get("category") or "",
        mutually_exclusive=one_of(e.get("title") or "", [m.outcome for m in markets]),
        markets=markets,
    )


class PolymarketUSClient:
    def __init__(self, base_url: str = BASE_URL, timeout: float = 60.0):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def iter_events(self, category: str = "politics", page: int = 200) -> Iterator[Event]:
        offset = 0
        while True:
            r = self._http.get("/v1/events", params={"categories": category, "active": "true", "closed": "false",
                                                     "limit": page, "offset": offset})
            r.raise_for_status()
            events = r.json().get("events") or []
            for e in events:
                yield parse_event(e)
            if len(events) < page:
                return
            offset += page

    def book(self, slug: str) -> dict:
        r = self._http.get(f"/v1/markets/{slug}/book")
        r.raise_for_status()
        return r.json().get("marketData") or {}

    def size_at(self, slug: str, side: str, price: float) -> float:
        """Contracts available at `price` or better: side "bid" for selling YES, "ask" for buying YES."""
        book = self.book(slug)
        levels = book.get("bids" if side == "bid" else "offers") or []
        ok = (lambda p: p >= price - 1e-9) if side == "bid" else (lambda p: p <= price + 1e-9)
        return sum(float(lv["qty"]) for lv in levels if ok(_px(lv["px"])))
