"""Gemini Predictions (Gemini Titan, a CFTC-designated contract market). Public, no key.

Events hold contracts; each contract is a YES/NO instrument with its own order book.
Taker fee for contracts listed from 2026-03-18: 0.07 * P * (1 - P) per contract.
"""

from __future__ import annotations

from pmpol import USER_AGENT

from collections.abc import Iterator

import httpx

from pmpol.models import Event, Market
from pmpol.venues import one_of

BASE_URL = "https://api.gemini.com"
VENUE = "gemini"
TAKER_FEE_RATE = 0.07
CATEGORIES = ("Politics", "Midterms")


def _f(x) -> float | None:
    return None if x in (None, "") else float(x)


def _rich_text(node) -> str:
    """Flatten Gemini's rich-text description (a Contentful document) to plain text."""
    if isinstance(node, str):
        return node
    if not isinstance(node, dict):
        return ""
    if "value" in node:
        return node["value"]
    return "\n".join(t for c in node.get("content") or [] if (t := _rich_text(c)))


def parse_market(c: dict, e: dict) -> Market:
    prices = c.get("prices") or {}
    bid, ask = _f(prices.get("bestBid")), _f(prices.get("bestAsk"))
    return Market(
        venue=VENUE,
        market_id=c["instrumentSymbol"],
        event_id=e["ticker"],
        question=(e.get("title") or "").strip(),
        outcome=(c.get("label") or "").strip(),
        rules=_rich_text(c.get("description")),
        bid=bid if bid is not None else (0.0 if ask is not None else None),
        ask=ask,
        last=_f(prices.get("lastTradePrice")),
        close_time=c.get("expiryDate") or e.get("expiryDate"),
        active=c.get("status") == "active" and c.get("marketState") == "open",
        fee_rate=TAKER_FEE_RATE,
    )


def parse_event(e: dict) -> Event:
    markets = [parse_market(c, e) for c in e.get("contracts") or []]
    sub = e.get("subcategory")
    category = sub.get("slug", "") if isinstance(sub, dict) else (sub or e.get("category") or "")
    return Event(
        venue=VENUE,
        event_id=e["ticker"],
        title=(e.get("title") or "").strip(),
        category=category,
        # Gemini's rules often state it outright ("This event is mutually exclusive").
        mutually_exclusive=e.get("type") == "categorical" and (
            one_of(e.get("title") or "", [m.outcome for m in markets])
            or any("this event is mutually exclusive" in m.rules.lower() for m in markets)),
        markets=markets,
    )


class GeminiClient:
    def __init__(self, base_url: str = BASE_URL, timeout: float = 60.0):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def iter_events(self, categories: tuple[str, ...] = CATEGORIES, page: int = 100) -> Iterator[Event]:
        seen = set()
        for category in categories:
            offset = 0
            while True:
                r = self._http.get("/v1/prediction-markets/events",
                                   params={"category": category, "status": "active", "limit": page, "offset": offset})
                r.raise_for_status()
                d = r.json()
                for e in d.get("data") or []:
                    if e["ticker"] not in seen:
                        seen.add(e["ticker"])
                        yield parse_event(e)
                offset += page
                if offset >= (d.get("pagination") or {}).get("total", 0) or not d.get("data"):
                    break

    def size_at(self, symbol: str, side: str, price: float) -> float:
        r = self._http.get(f"/v1/book/{symbol}")
        r.raise_for_status()
        book = r.json()
        levels = book.get("bids" if side == "bid" else "asks") or []
        ok = (lambda p: p >= price - 1e-9) if side == "bid" else (lambda p: p <= price + 1e-9)
        return sum(float(lv["amount"]) for lv in levels if ok(float(lv["price"])))
