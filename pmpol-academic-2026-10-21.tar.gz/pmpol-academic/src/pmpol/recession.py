"""The outside view of a "technical recession" market (2026-10-05).

Most U.S. recession markets resolve on two consecutive quarters of negative real GDP growth (BEA, seasonally
adjusted annualized rate) inside a window of quarters, and some of those quarters are already published. So the
question a market prices is narrower than "will there be a recession": given the quarters already known, will the
n quarters still to be published (plus the last known one, when it was negative) contain two negative quarters in a
row? The reference class answers exactly that from the post-war record:

  base rate(n, last)  over every point in 1947-now where the last published quarter was positive (or negative, for
                      last = "neg"), the share in which the next n quarters completed a pair of negative quarters

It is an L2 frequency from L1 data (BEA via FRED, public domain), shown next to the market and, as a second and
differently defined line, the yield-curve model's probability of an NBER recession (pmpol.macro.regimes). The markets
that also resolve on an NBER announcement or other conditions are wider than the technical definition: their price
should be at least the technical probability, and the proof says so instead of calling a gap a violation.
"""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path

SERIES = "A191RL1Q225SBEA"
URL = f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={SERIES}"
UA = "pmpol/0.1 (https://github.com/bellafc/polymarket_politics; research, read-only)"
DATA = Path("data/fundamentals")
GDP_FACT = "us.gdp.real_growth_quarterly"
BASE_FACT = "us.recession.technical_base_rates"
MAX_N = 12  # longest window of unknown quarters tabulated


def fetch(cache: Path = DATA, get=None, today: date | None = None) -> list[tuple[str, float]]:
    """[("2026Q2", 2.2), ...] in time order, cached per day."""
    path = cache / f"{SERIES}_{(today or date.today()).isoformat()}.csv"
    if path.exists():
        text = path.read_text(encoding="utf-8")
    else:
        if get is None:
            import httpx

            def get(url):
                r = httpx.get(url, timeout=60, headers={"User-Agent": UA}, follow_redirects=True)
                r.raise_for_status()
                return r.text
        text = get(URL)
        cache.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    out = []
    for row in csv.DictReader(io.StringIO(text)):
        v = row.get(SERIES)
        if v and v != ".":
            y, m = int(row["observation_date"][:4]), int(row["observation_date"][5:7])
            out.append((f"{y}Q{(m - 1) // 3 + 1}", float(v)))
    return out


def _date_of(q: str) -> str:
    """"2026Q2" -> "2026-04-01", the series' own date for the quarter (so the quote is verbatim)."""
    return f"{q[:4]}-{(int(q[-1]) - 1) * 3 + 1:02d}-01"


def q_index(q: str) -> int:
    """"2026Q2" -> a running quarter number."""
    return int(q[:4]) * 4 + int(q[-1]) - 1


def q_name(i: int) -> str:
    return f"{i // 4}Q{i % 4 + 1}"


def completes_pair(seq: list[float], last_negative: bool) -> bool:
    """Do the quarters `seq` (in order) contain two negative quarters in a row, counting the quarter just before
    them when it was negative?"""
    prev = last_negative
    for g in seq:
        neg = g < 0
        if neg and prev:
            return True
        prev = neg
    return False


def base_rates(growth: list[tuple[str, float]], max_n: int = MAX_N) -> dict:
    """{"pos": {n: [hits, cases]}, "neg": {...}}: from every quarter t with n later quarters published, whether
    quarters t+1..t+n complete a pair, split by whether quarter t was negative. Points already inside a completed
    pair (t and t-1 both negative) are left out: the question then is when it ends, not whether it starts."""
    vals = [g for _, g in growth]
    out = {"pos": {}, "neg": {}}
    for n in range(1, max_n + 1):
        for state in out:
            out[state][n] = [0, 0]
        for t in range(len(vals) - n):
            if t > 0 and vals[t] < 0 and vals[t - 1] < 0:
                continue
            state = "neg" if vals[t] < 0 else "pos"
            out[state][n][1] += 1
            out[state][n][0] += completes_pair(vals[t + 1:t + 1 + n], vals[t] < 0)
    return out


# --- reading the markets ------------------------------------------------------------------------------------------

_Q = r"Q([1-4])\s*((?:19|20)\d\d)"


@dataclass(frozen=True)
class Window:
    first: int  # quarter index
    last: int
    wider: bool  # the market also resolves on something besides two negative quarters (NBER, ...)


def read_window(rules: str, title: str = "") -> Window | None:
    """The window of quarters of a U.S. two-negative-quarters market, from its rules; None when the rules say
    something else (another country, NBER only, a world recession)."""
    text = re.sub(r"\s+", " ", rules or "")
    if not re.search(r"two consecutive quarters", text, re.I) or not re.search(r"\bGDP\b", text):
        return None
    if re.search(r"United Kingdom|Japan|China|India|Germany|Canada|IMF|euro", f"{title} {text}", re.I):
        return None
    hit = (re.search(rf"between {_Q} and {_Q}", text) or re.search(rf"in {_Q} through {_Q}", text))
    if hit:
        first = int(hit.group(2)) * 4 + int(hit.group(1)) - 1
        last = int(hit.group(4)) * 4 + int(hit.group(3)) - 1
    else:
        years = re.search(r"growth in (20\d\d) or (20\d\d)", text) or re.search(r"growth in (20\d\d)\b", text)
        if not years:
            return None
        first = int(years.group(1)) * 4
        last = int(years.group(years.lastindex)) * 4 + 3
    wider = bool(re.search(r"either of the following|NBER|National Bureau", text, re.I))
    return Window(first, last, wider)


@dataclass
class Outlook:
    window: Window
    known: list[tuple[str, float]]  # published quarters inside the window
    decided: bool  # a pair is already in the published data
    unknown: int  # quarters of the window still to be published
    last_negative: bool  # the last published quarter (inside or just before the window) was negative
    hits: int
    cases: int

    @property
    def base_rate(self) -> float | None:
        if self.decided:
            return 1.0
        if self.unknown <= 0:
            return 0.0
        return self.hits / self.cases if self.cases else None


def outlook(w: Window, growth: list[tuple[str, float]], rates: dict) -> Outlook:
    by = {q_index(q): g for q, g in growth}
    latest = max(by)
    known = [(q_name(i), by[i]) for i in range(w.first, min(w.last, latest) + 1) if i in by]
    decided = completes_pair([g for _, g in known], False)  # both quarters of a pair must be inside the window
    # quarters of the window still to come; a window starting later than the next release counts from its start
    unknown = max(0, w.last - max(latest, w.first - 1))
    # a negative last published quarter inside the window can start the pair
    last_neg = bool(known) and known[-1][1] < 0
    n = min(unknown, MAX_N)
    hits, cases = rates["neg" if last_neg else "pos"].get(n, [0, 0]) if n else (0, 0)
    return Outlook(w, known, decided, unknown, last_neg, hits, cases)


def kb_yaml(growth: list[tuple[str, float]], rates: dict, recorded: date) -> str:
    from pmpol.reference import _yaml

    first, last = growth[0], growth[-1]
    facts = [
        {"id": GDP_FACT, "layer": "L1", "subject": "U.S. real GDP", "predicate": "percent_change_saar_quarterly",
         "value": {q: g for q, g in growth},
         "source": {"title": "BEA, Real Gross Domestic Product, percent change from preceding period, SAAR (FRED "
                             f"{SERIES})", "url": URL, "quote": f"{_date_of(last[0])},{last[1]}",
                    "license": "public domain (U.S. government data via FRED)"},
         "admiralty": "A1", "status": "proposed", "recorded_at": recorded,
         "note": f"{first[0]}-{last[0]}, latest estimates (later revisions replace earlier ones; markets settle on "
                 "the estimate their rules name). Generated by `pmpol recession --write-kb`."},
        {"id": BASE_FACT, "layer": "L2", "subject": "U.S. technical recessions",
         "predicate": "share_completing_two_negative_quarters_within_n_quarters",
         "value": {"sample": f"{first[0]}-{last[0]}",
                   "after_positive": {n: {"hits": h, "cases": c, "share": round(h / c, 4) if c else None}
                                      for n, (h, c) in rates["pos"].items()},
                   "after_negative": {n: {"hits": h, "cases": c, "share": round(h / c, 4) if c else None}
                                      for n, (h, c) in rates["neg"].items()}},
         "source": {"title": "pmpol reference class, from the BEA real GDP series",
                    "url": "https://github.com/bellafc/polymarket_politics/blob/claude/gallant-ritchie-j6n5c8/"
                           "src/pmpol/recession.py"},
         "admiralty": "A2", "status": "proposed", "recorded_at": recorded, "derived_from": [GDP_FACT],
         "note": "For every quarter t whose next n quarters are published: did quarters t+1..t+n complete two "
                 "negative quarters in a row (counting t itself when negative)? Split by the sign of quarter t; "
                 "quarters already inside a pair are left out. Overlapping windows: the cases are not independent."}]
    return "# Generated by `pmpol recession --write-kb`; review before marking the facts reviewed.\n" + _yaml({"facts": facts})


def rates_from_kb(kb) -> dict | None:
    f = kb.facts.get(BASE_FACT) if kb is not None else None
    if f is None:
        return None
    conv = {}
    for state, key in (("pos", "after_positive"), ("neg", "after_negative")):
        conv[state] = {int(n): [row["hits"], row["cases"]] for n, row in f.value[key].items()}
    return conv


def growth_from_kb(kb) -> list[tuple[str, float]] | None:
    f = kb.facts.get(GDP_FACT) if kb is not None else None
    if f is None:
        return None
    return sorted(((q, float(g)) for q, g in f.value.items()), key=lambda t: q_index(t[0]))
