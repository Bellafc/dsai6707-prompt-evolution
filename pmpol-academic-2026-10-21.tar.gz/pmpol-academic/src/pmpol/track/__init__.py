"""Signal track record: pre-registered claims about our own signals, tested on later snapshots.

The point is to turn "the system finds things" into "the system's signals have a measured record".
Methods: pre-registration (claims fixed in config/signal_registry.toml before the data that tests them;
only snapshots taken after registration count as prospective), convergence of gaps between venues,
and attribution of who moved when venues disagreed (the outlier, or everyone else).

Evidence is three-state: a gap whose legs are missing or unquoted in the later snapshot is counted as
"not observed", never as converged or persisting.

Version 2 (2026-10-05) adds two things the pair counts cannot give:
  - the half-life of a cross-venue gap, from the whole chain of snapshots with the Kaplan-Meier estimator: a gap
    is followed from the snapshot where it opens until it halves (the event) or its legs stop being observed or
    the snapshots end (censored), so gaps still open at the end are not dropped and not counted as never closing;
  - a p-value for each prospective test (one-sided sign test against the registered 50% line) and Holm's
    correction across the claims (Holm 1979), so that testing several claims at once does not make one of them
    look supported by chance. The registered criteria stay the verdict; the corrected p-value is shown beside it.
"""

from __future__ import annotations

import math
import statistics
import tomllib
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from pmpol.models import Event, Relation
from pmpol.universe.cluster import build_clusters
from pmpol.universe.index import Universe
from pmpol.universe.relations import build_relations, mid_gap

REGISTRY = Path(__file__).resolve().parents[3] / "config" / "signal_registry.toml"


@dataclass
class Claim:
    id: str
    version: int
    registered_at: str
    signal: str
    claim: str
    metric: str
    supported_if: str
    min_gap: float = 0.03
    min_hours: float = 1.0
    min_n: int = 30
    status: str = ""


def load_registry(path: Path = REGISTRY) -> list[Claim]:
    with open(path, "rb") as f:
        return [Claim(**c) for c in tomllib.load(f)["claim"]]


@dataclass
class GapObs:
    relation: str
    template: str
    venues: tuple[str, str]
    gap_a: float
    gap_b: float | None  # None: not observed later (leg missing or book too wide)
    move_lhs: float | None = None  # change in the lhs side's summed mids
    move_rhs: float | None = None

    @property
    def converged(self) -> bool | None:
        return None if self.gap_b is None else abs(self.gap_b) <= 0.5 * abs(self.gap_a)

    def closed_by(self) -> dict[str, float]:
        """How much of the gap each side closed (positive = moved toward the other side)."""
        if self.move_lhs is None:
            return {}
        s = 1 if self.gap_a > 0 else -1
        return {self.venues[0]: -s * self.move_lhs, self.venues[1]: s * self.move_rhs}


@dataclass
class OutlierObs:
    market: str
    venue: str
    dev_a: float  # outlier mid minus the others' consensus, first snapshot
    outlier_move: float | None  # toward the others (positive = closing)
    others_move: float | None  # the others toward the outlier

    @property
    def outlier_share(self) -> float | None:
        if self.outlier_move is None or self.others_move is None:
            return None
        total = self.outlier_move + self.others_move
        return None if abs(total) < 1e-9 else self.outlier_move / total


@dataclass
class CoherenceObs:
    market: str
    z_a: float  # how far the coherence projection moved the quote, in its own sigma (pmpol.coherence)
    gap_a: float  # mid minus the coherent price, first snapshot
    gap_b: float | None  # later mid minus the same coherent price

    @property
    def closer(self) -> bool | None:
        return None if self.gap_b is None else abs(self.gap_b) < abs(self.gap_a)


@dataclass
class PairResult:
    ts_a: str
    ts_b: str
    hours: float
    gaps: list[GapObs] = field(default_factory=list)
    outliers: list[OutlierObs] = field(default_factory=list)
    coherence: list[CoherenceObs] = field(default_factory=list)


def _venue(key: str) -> str:
    return key.split(":", 1)[0]


def universe_with_relations(events: list[Event]) -> tuple[Universe, list[Relation]]:
    u = Universe.build(events)
    build_clusters(u)
    # The registered claims were defined on the template relations; the main pipeline now takes its relations
    # from the proposition ontology, but changing the sample after registration would not be a prospective
    # test, so the track record keeps the templates (a new claim version can be registered for the ontology).
    return u, build_relations(u)


def _side_mid(u: Universe, keys: list[str]) -> float | None:
    ms = [u.markets.get(k) for k in keys]
    if any(m is None or m.mid is None for m in ms):
        return None
    return sum(m.mid for m in ms)


def _logit(p: float) -> float:
    p = min(max(p, 0.005), 0.995)
    return math.log(p / (1 - p))


def _others_mid(u: Universe, keys: list[str], weights: dict[str, float]) -> float | None:
    ms = [u.markets.get(k) for k in keys]
    ms = [m for m in ms if m is not None and m.mid is not None]
    if not ms:
        return None
    w = [weights.get(m.key, 1.0) for m in ms]
    return 1 / (1 + math.exp(-sum(wi * _logit(m.mid) for wi, m in zip(w, ms)) / sum(w)))


def evaluate_pair(a: tuple[Universe, list[Relation]], b: Universe, ts_a: str, ts_b: str,
                  min_gap: float = 0.03, onto: list[Relation] | None = None) -> PairResult:
    """`onto`: the first snapshot's ontology relations (pmpol.propositions.relations), which the coherence claim is
    defined on; the other claims keep the template relations they were registered on."""
    ua, rules = a
    hours = (datetime.fromisoformat(ts_b) - datetime.fromisoformat(ts_a)).total_seconds() / 3600
    out = PairResult(ts_a, ts_b, hours)
    for r in rules:
        if not r.template.startswith("cross_venue") or r.confidence != "rule":
            continue
        g0 = mid_gap(ua, r)
        if g0 is None or abs(g0) < min_gap:
            continue
        venues = (_venue(r.lhs[0]), _venue(r.rhs[0]))
        g1 = mid_gap(b, r)
        obs = GapObs(r.key, r.template, venues, g0, g1)
        if g1 is not None:
            la, lb = _side_mid(ua, r.lhs), _side_mid(b, r.lhs)
            ra, rb = _side_mid(ua, r.rhs), _side_mid(b, r.rhs)
            obs.move_lhs, obs.move_rhs = lb - la, rb - ra
        out.gaps.append(obs)

    from pmpol.universe import consensus

    for c in consensus.run(ua, rules, None):
        keys = [m.key for m in c.markets]
        for m in c.markets:
            others = [k for k in keys if k != m.key and _venue(k) != m.venue]
            if not others:
                continue
            o0 = _others_mid(ua, others, c.weights)
            if o0 is None or abs(m.mid - o0) < min_gap:
                continue
            mb = b.markets.get(m.key)
            o1 = _others_mid(b, others, c.weights)
            if mb is None or mb.mid is None or o1 is None:
                out.outliers.append(OutlierObs(m.key, m.venue, m.mid - o0, None, None))
                continue
            s = 1 if m.mid > o0 else -1
            out.outliers.append(OutlierObs(m.key, m.venue, m.mid - o0, -s * (mb.mid - m.mid), s * (o1 - o0)))

    from pmpol import coherence

    onto = [r for r in rules if r.template.startswith("onto:")] if onto is None else onto
    res = coherence.run(ua, [r for r in onto if r.confidence in ("rule", "entity", "name", "descriptor")
                             and r.rules != "material"])
    for k in res.q:
        if abs(res.z(k)) < 2:
            continue
        mb = b.markets.get(k)
        mid_b = mb.mid if mb is not None and mb.bid is not None and mb.ask is not None else None
        out.coherence.append(CoherenceObs(k, res.z(k), res.mid[k] - res.q[k],
                                          None if mid_b is None else mid_b - res.q[k]))
    return out


def pick_pairs(snapshots: list[tuple[str, Path]], min_hours: float = 1.0) -> list[tuple[int, int]]:
    """For each snapshot, the next one at least `min_hours` later, and the latest one (two horizons)."""
    times = [datetime.fromisoformat(t) for t, _ in snapshots]
    pairs = []
    for i, t in enumerate(times):
        nxt = next((j for j in range(i + 1, len(times)) if (times[j] - t).total_seconds() >= min_hours * 3600), None)
        if nxt is not None:
            pairs.append((i, nxt))
            last = len(times) - 1
            if last != nxt:
                pairs.append((i, last))
    return pairs


def summarize(results: list[PairResult], claims: list[Claim]) -> dict[str, dict]:
    """Per claim: n, the metric and verdict on all pairs, and separately on prospective pairs only (first
    snapshot on or after the registration date). Only the prospective verdict tests the claim; the
    overall one is exploratory."""
    reg = {c.id: c for c in claims}
    out = {}

    def gap_metric(rows):
        seen = [g for _, g in rows if g.converged is not None]
        return len(seen), (sum(g.converged for g in seen) / len(seen) if seen else None)

    def outlier_metric(rows):
        shares = [o.outlier_share for _, o in rows if o.outlier_share is not None]
        return len(shares), (statistics.median(shares) if shares else None)

    def coherence_metric(rows):
        seen = [o for _, o in rows if o.closer is not None]
        return len(seen), (sum(o.closer for o in seen) / len(seen) if seen else None)

    # sign tests against the registered 50% line: successes among the observed rows
    successes = {"cross_venue_gap_closes": lambda rows: sum(g.converged is True for _, g in rows),
                 "outlier_moves_to_consensus": lambda rows: sum((o.outlier_share or 0) > 0.5 for _, o in rows
                                                                if o.outlier_share is not None),
                 "coherence_pull": lambda rows: sum(o.closer is True for _, o in rows)}

    sizes = {"cross_venue_gap_closes": lambda o: abs(o.gap_a), "outlier_moves_to_consensus": lambda o: abs(o.dev_a),
             "coherence_pull": lambda o: abs(o.z_a)}  # for coherence_pull, min_gap is in sigmas
    for cid, pick, metric, threshold in (
            ("cross_venue_gap_closes", lambda r: r.gaps, gap_metric, 0.5),
            ("outlier_moves_to_consensus", lambda r: r.outliers, outlier_metric, 0.5),
            ("coherence_pull", lambda r: r.coherence, coherence_metric, 0.5)):
        c = reg.get(cid)
        if not c:
            continue
        size = sizes[cid]
        rows = [(r, o) for r in results if r.hours >= c.min_hours for o in pick(r) if size(o) >= c.min_gap]
        prosp = [(r, o) for r, o in rows if r.ts_a[:10] >= c.registered_at]
        n, v = metric(rows)
        pn, pv = metric(prosp)
        d = {"n": n, "value": v, "prospective": pn, "prospective_value": pv,
             "supported": None if v is None or n < c.min_n else v > threshold,
             "prospective_supported": None if pv is None or pn < c.min_n else pv > threshold,
             "p": None if pn < c.min_n else binom_sf(successes[cid](prosp), pn)}
        if cid == "coherence_pull":
            d["not_observed"] = sum(o.closer is None for _, o in rows)
        elif cid == "cross_venue_gap_closes":
            d["not_observed"] = sum(g.converged is None for _, g in rows)
        else:
            d["not_observed"] = sum(o.outlier_move is None for _, o in rows)
            d["no_movement"] = sum(o.outlier_move is not None and o.outlier_share is None for _, o in rows)
        out[cid] = d
    adjusted = holm({k: d["p"] for k, d in out.items() if d["p"] is not None})
    for k, d in out.items():
        d["p_holm"] = adjusted.get(k)
    return out


# --- version 2: half-lives (Kaplan-Meier) and multiple testing (Holm) -------------------------------------------

@dataclass
class Spell:
    relation: str
    venues: tuple[str, str]
    gap: float  # the gap when it opened
    hours: float  # until it halved, or until it was last observed (censored)
    halved: bool
    left_censored: bool  # already open in the first snapshot: its true start is earlier


def spells(chain: list[tuple[str, tuple[Universe, list[Relation]]]], min_gap: float = 0.03) -> list[Spell]:
    """Gaps of cross-venue rule relations followed through a time-ordered chain of (timestamp, (universe,
    relations)). A spell starts where a gap of at least `min_gap` opens (it was below, or unobserved, in the
    snapshot before) and ends at the first snapshot where it is at most half as wide (halved), or is censored at
    the last snapshot where it was still observed."""
    times = [datetime.fromisoformat(t) for t, _ in chain]
    out = []
    for i, (_, (u, rules)) in enumerate(chain):
        prev = chain[i - 1][1][0] if i else None
        for r in rules:
            if not r.template.startswith("cross_venue") or r.confidence != "rule":
                continue
            g0 = mid_gap(u, r)
            if g0 is None or abs(g0) < min_gap:
                continue
            if prev is not None:
                gp = mid_gap(prev, r)
                if gp is not None and abs(gp) >= min_gap:
                    continue  # still the spell that opened earlier
            last, halved = times[i], False
            for j in range(i + 1, len(chain)):
                g = mid_gap(chain[j][1][0], r)
                if g is None:
                    break
                last = times[j]
                if abs(g) <= 0.5 * abs(g0):
                    halved = True
                    break
            out.append(Spell(r.key, (_venue(r.lhs[0]), _venue(r.rhs[0])), g0,
                             (last - times[i]).total_seconds() / 3600, halved, i == 0))
    return out


def kaplan_meier(sp: list[Spell]) -> list[tuple[float, float, int]]:
    """[(hours, survival after that time, at risk)] at each time a gap halved."""
    times = sorted({s.hours for s in sp if s.halved})
    out, surv = [], 1.0
    for t in times:
        at_risk = sum(s.hours >= t for s in sp)
        d = sum(s.halved and s.hours == t for s in sp)
        if at_risk:
            surv *= 1 - d / at_risk
            out.append((t, surv, at_risk))
    return out


def median_half_life(curve: list[tuple[float, float, int]]) -> float | None:
    return next((t for t, s, _ in curve if s <= 0.5), None)


def survival_at(curve: list[tuple[float, float, int]], hours: float) -> float:
    s = 1.0
    for t, v, _ in curve:
        if t > hours:
            break
        s = v
    return s


def binom_sf(k: int, n: int, p: float = 0.5) -> float:
    """P(X >= k) for X ~ Binomial(n, p): the one-sided sign test."""
    if n == 0:
        return 1.0
    try:
        from scipy.stats import binom

        return float(binom.sf(k - 1, n, p))
    except ImportError:  # pragma: no cover - normal approximation with continuity correction
        z = (k - 0.5 - n * p) / math.sqrt(n * p * (1 - p))
        return 0.5 * math.erfc(z / math.sqrt(2))


def holm(pvalues: dict[str, float]) -> dict[str, float]:
    """Holm-Bonferroni adjusted p-values (step-down, monotone)."""
    order = sorted(pvalues, key=pvalues.get)
    m, out, running = len(order), {}, 0.0
    for i, k in enumerate(order):
        running = max(running, min(1.0, (m - i) * pvalues[k]))
        out[k] = running
    return out


def leaders(results: list[PairResult], min_hours: float = 1.0, by_template: bool = False) -> dict[tuple, dict[str, float]]:
    """For each venue pair that disagreed: total gap closed by each venue (who follows whom).
    With by_template, keys are (venue a, venue b, relation template)."""
    out: dict[tuple, dict[str, float]] = {}
    for r in results:
        if r.hours < min_hours:
            continue
        for g in r.gaps:
            moves = g.closed_by()
            if not moves:
                continue
            pair = tuple(sorted(g.venues)) + ((g.template,) if by_template else ())
            d = out.setdefault(pair, {pair[0]: 0.0, pair[1]: 0.0, "n": 0})
            for v, x in moves.items():
                d[v] += x
            d["n"] += 1
    return out


def _share(a: float, b: float) -> str:
    """Share of the closed gap carried by a; undefined when either side moved away on balance."""
    if a < 0 or b < 0 or a + b <= 1e-9:
        return "—（有一方整體往反方向移動）"
    return f"{100 * a / (a + b):.0f}%"


def _pct(x: float | None) -> str:
    return "—" if x is None else f"{100 * x:.1f}%"


def _p(x: float | None) -> str:
    return "—" if x is None else ("< 0.001" if x < 0.001 else f"{x:.3f}")


def render(results: list[PairResult], claims: list[Claim], generated_at: str, leads: dict | None = None,
           gap_spells: list[Spell] | None = None) -> str:
    from pmpol.universe.pipeline import TEMPLATE_ZH
    from pmpol.venues import info

    summary = summarize(results, claims)
    L = [f"# 訊號成績單 — {generated_at}", "",
         "我們自己的訊號準不準？每種訊號在 `config/signal_registry.toml` 事先寫下它主張什麼、用什麼指標、"
         "看多久、最少要多少樣本、什麼結果算支持。這裡用之後的快照檢驗。"
         "第一個快照在登記日期之前的評估是**探索性**的（回頭看，可能有後見之明）；登記之後的才算**前瞻**。", "",
         "## 1. 登記的主張", "", "| 主張 | 版本 | 登記日 | 內容 | 指標 | 支持的條件 | 狀態 |", "|---|---|---|---|---|---|---|"]
    for c in claims:
        L.append(f"| `{c.id}` | {c.version} | {c.registered_at} | {c.claim} | {c.metric} | {c.supported_if} | "
                 f"{c.status or '可評估'} |")
    L += ["", "## 2. 結果", "",
          "**判定只看前瞻樣本**（第一個快照在登記日之後）；全部樣本的數字含登記前的資料，只是探索性的參考。", "",
          "p 值是單邊符號檢定（對登記的 50% 線），Holm 校正是同時檢定幾個主張後的修正；判定仍以登記的條件為準，"
          "校正後 p ≥ 0.05 的「支持」要當成可能是巧合。配對有重疊、樣本不獨立，p 值偏樂觀。", "",
          "| 主張 | 前瞻樣本 | 前瞻指標值 | 前瞻判定 | p 值 | Holm 校正後 | 全部樣本 | 全部指標值 | 未觀測 |",
          "|---|---|---|---|---|---|---|---|---|"]

    def fmt(cid, v):
        return "—" if v is None else (_pct(v) if cid == "cross_venue_gap_closes" else f"{v + 0.0:.2f}".replace("-0.00", "0.00"))

    def verdict(x):
        return "樣本不足" if x is None else ("支持" if x else "不支持")

    for c in claims:
        s = summary.get(c.id)
        if c.id == "silent_move_followed_by_news" and leads and leads["checked"]:
            ok = None if leads["checked"] < c.min_n else leads["share"] > 0.3
            L.append(f"| `{c.id}` | {leads['checked']:,} | {_pct(leads['share'])} | **{verdict(ok)}**（自動計數，待人工稽核） | "
                     f"— | — | {leads['leads']:,} 個線索 | — | — |")
            continue
        if s is None:
            L.append(f"| `{c.id}` | — | — | {c.status or '還沒有評估方法'} | — | — | — | — | — |")
            continue
        extra = f"；完全沒有人動 {s['no_movement']:,}" if "no_movement" in s else ""
        L.append(f"| `{c.id}` | {s['prospective']:,} | {fmt(c.id, s['prospective_value'])} | "
                 f"**{verdict(s['prospective_supported'])}** | {_p(s.get('p'))} | {_p(s.get('p_holm'))} | "
                 f"{s['n']:,} | {fmt(c.id, s['value'])}（探索性） | "
                 f"{s['not_observed']:,}{extra} |")
    if gap_spells:
        curve = kaplan_meier(gap_spells)
        med = median_half_life(curve)
        halved = sum(s.halved for s in gap_spells)
        L += ["", "## 2b. 跨平台差距的半衰期（Kaplan–Meier）", "",
              "把所有快照串成一條時間線：一條跨平台關係的中間價差距從「打開」（≥3 點，前一個快照還沒有或看不到）開始追，"
              "到差距縮到一半以下為止（事件）；之後某一腳看不到了、或快照用完還沒縮一半的，算「截尾」，不當成永遠不收斂、也不丟掉。"
              "第一個快照就已經打開的差距，真正的起點更早（左截尾），半衰期會被低估。這是描述性的統計，不是登記的主張。", "",
              f"{len(gap_spells):,} 段差距：縮到一半 {halved:,}、截尾 {len(gap_spells) - halved:,}（其中第一個快照就已打開的 "
              f"{sum(s.left_censored for s in gap_spells):,}）。**半衰期中位數："
              f"{'超過觀察期（還沒有一半的差距縮到一半）' if med is None else f'{med:.1f} 小時'}**。", "",
              "| 經過時間 | 還沒縮到一半的比例 |", "|---|---|"]
        for h in (2, 6, 12, 24, 48, 72):
            L.append(f"| {h} 小時 | {_pct(survival_at(curve, h))} |")
        by_pair: dict[tuple, list[Spell]] = {}
        for s in gap_spells:
            by_pair.setdefault(tuple(sorted(s.venues)), []).append(s)
        rows = [(k, v) for k, v in by_pair.items() if len(v) >= 30]
        if rows:
            L += ["", "| 平台配對 | 差距段數 | 縮到一半 | 24 小時後還沒縮一半 | 半衰期中位數 |", "|---|---|---|---|---|"]
            for (a, b), v in sorted(rows, key=lambda kv: -len(kv[1])):
                cv = kaplan_meier(v)
                m = median_half_life(cv)
                L.append(f"| {info(a).code}／{info(b).code} | {len(v):,} | {sum(s.halved for s in v):,} | "
                         f"{_pct(survival_at(cv, 24))} | {'超過觀察期' if m is None else f'{m:.1f} 小時'} |")
    L += ["", "## 3. 評估用的快照配對", "",
          "| 從 | 到 | 小時 | 價差 ≥3 點的關係 | 一半以上收斂 | 未觀測 | 偏離共識的報價 |", "|---|---|---|---|---|---|---|"]
    for r in results:
        L.append(f"| {r.ts_a[:16]} | {r.ts_b[:16]} | {r.hours:.1f} | {len(r.gaps):,} | "
                 f"{sum(g.converged is True for g in r.gaps):,} | {sum(g.converged is None for g in r.gaps):,} | "
                 f"{len(r.outliers):,} |")
    L += ["", "## 4. 平台之間不一致時，誰往誰靠", "",
          "同一合約在兩個平台的價差 ≥3 點時，下一個快照中每個平台往對方移動了多少（各配對加總，單位：百分點）。"
          "移動較少的一方比較像「領先者」，另一方在跟隨。", "",
          "| 平台配對 | 次數 | 甲往乙移動 | 乙往甲移動 | 甲承擔的收斂比例 |", "|---|---|---|---|---|"]
    for (a, b), d in sorted(leaders(results).items(), key=lambda t: -t[1]["n"]):
        if d["n"] < 30:
            continue
        share = _share(d[a], d[b])
        L.append(f"| {info(a).code}（甲）／{info(b).code}（乙） | {d['n']:,} | {100 * d[a]:+.1f} | {100 * d[b]:+.1f} | {share} |")
    if leads is not None:
        L += ["", "## 4b. 沉默異動的後續（72 小時後再查新聞）", "",
              f"已記錄 {leads['leads']:,} 個沉默異動線索；滿 72 小時、已重查新聞的 {leads['checked']:,} 個，"
              f"其中之後出現相關新聞的 {leads['with_news']:,} 個。新聞數是自動計數，標題列在下面供人工判斷是否真的相關。", ""]
        bv = leads.get("by_venue") or {}
        if bv:
            from pmpol.reference import wilson

            L += ["依平台（Kalshi 沒有錢包資料，當市場層級的對照組）。「之後有新聞」的比例是精確率的代理：線索真的指向一件後來被報導的事；"
                  "召回率（有多少後來被報導的事件，事前被標成沉默異動）要人工標註，還沒有做。", "",
                  "| 平台 | 已重查 | 之後有新聞 | 比例（Wilson 95%） |", "|---|---|---|---|"]
            for venue, (n, k) in sorted(bv.items(), key=lambda t: -t[1][0]):
                lo, hi = wilson(k, n)
                L.append(f"| {venue} | {n} | {k} | {100 * k / n:.0f}%（{100 * lo:.0f}–{100 * hi:.0f}%） |")
            L.append("")
        dr = leads.get("drift") or {}
        if dr.get("n"):
            L += [f"新聞前漂移（Polymarket 線索，有新聞而且整段變動至少 2 點的 {dr['n']} 個）：第一篇報導之前已完成的變動比例，"
                  f"中位數 {100 * dr['median']:.0f}%，一半以上在報導前完成的 {dr['mostly_before']} 個。第一篇是搜尋找到的最早一篇，"
                  "不一定是最早的報導。", ""]
        if leads["rows"]:
            L += ["| 線索 | 關鍵字 | 之後 72 小時的新聞數 | 報導前完成的變動 | 標題 |", "|---|---|---|---|---|"]
            for r in leads["rows"][-20:]:
                pre = r.get("pre_news_share")
                L.append(f"| `{r['lead'][:60]}` | {r['query']} | {r['news']} | {'—' if pre is None else f'{100 * pre:.0f}%'} | "
                         f"{'；'.join(t[:60] for t in r['titles'])} |")
    by_t = {k: d for k, d in leaders(results, by_template=True).items() if d["n"] >= 50}
    if by_t:
        L += ["", "### 依題型", "", "只列 50 次以上的組合。", "",
              "| 平台配對 | 題型 | 次數 | 甲承擔的收斂比例 |", "|---|---|---|---|"]
        for (a, b, t), d in sorted(by_t.items(), key=lambda kv: (kv[0][:2], -kv[1]["n"])):
            share = _share(d[a], d[b])
            L.append(f"| {info(a).code}（甲）／{info(b).code}（乙） | {TEMPLATE_ZH.get(t, t)} | {d['n']:,} | {share} |")
    L += ["", "## 5. 限制", "",
          "- 配對有重疊（同一個快照會出現在好幾個配對裡），同一條關係會被算好幾次，樣本不是獨立的，數字只能看方向。",
          "- 時間很短（幾小時），很多市場這段期間根本沒有成交；「沒收斂」有一部分只是「沒有人交易」。",
          "- 用的是中間價的差距；如果兩邊的價差很寬，3 點的中間價差距可能還在雙方的買賣價之內，不算真正的不一致。",
          "- 各快照涵蓋的平台不同（早期只有 Kalshi 和 Polymarket），未觀測的不計入。", ""]
    return "\n".join(L)
