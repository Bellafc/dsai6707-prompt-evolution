"""Information coefficient by horizon (track record v2, 2026-10-07).

A signal ranks markets: the further a venue's price sits from the others' consensus, or from the price the
coherence projection says all relations allow, the more it should move back. The information coefficient (IC) is
the rank correlation (Spearman) between the signal at a snapshot and the later change in the market's own price,
both in logit; mean reversion shows as a negative IC. Measured at every later snapshot, its decay with the horizon
says how long the signal stays useful (the alphalens idea; written here, not imported).

Scores are computed once per snapshot and prices looked up in every later one, so every pair of snapshots counts.
Pairs overlap and markets repeat across them: the interval is a bootstrap over markets. Quotes wider than
MAX_SPREAD at either time are left out (an empty book's mid moves for no reason).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime

import numpy as np
from scipy.stats import spearmanr

MAX_SPREAD = 0.10
BUCKETS = ((0.5, 3.0), (3.0, 12.0), (12.0, 30.0), (30.0, 72.0))  # hours
B = 500
SIGNALS = {"outlier": "偏離共識（某平台和其他平台的加權共識之差）", "coherence": "偏離一致機率（一致性投影移動的方向和大小）"}


def _logit(p: float) -> float:
    p = min(max(p, 0.005), 0.995)
    return math.log(p / (1 - p))


def _quoted(m) -> bool:
    return m is not None and m.mid is not None and m.spread is not None and m.spread <= MAX_SPREAD


def outlier_scores(u, rules) -> dict[str, float]:
    """market -> logit(mid) minus the weighted logit of the other venues' quotes in its consensus group."""
    from pmpol.universe import consensus

    out = {}
    for c in consensus.run(u, rules, None):
        for m in c.markets:
            others = [o for o in c.markets if o.venue != m.venue and _quoted(o)]
            if not _quoted(m) or not others:
                continue
            w = [c.weights.get(o.key, 1.0) for o in others]
            out[m.key] = _logit(m.mid) - sum(wi * _logit(o.mid) for wi, o in zip(w, others)) / sum(w)
    return out


def coherence_scores(u, onto, min_z: float = 1.0) -> dict[str, float]:
    """market -> logit(mid) minus logit(coherent price), for quotes the projection moved at least min_z sigmas."""
    from pmpol import coherence

    res = coherence.run(u, [r for r in onto if r.confidence in ("rule", "entity", "name", "descriptor")
                            and r.rules != "material"])
    return {k: _logit(res.mid[k]) - _logit(res.q[k]) for k in res.q
            if abs(res.z(k)) >= min_z and _quoted(u.markets.get(k))}


@dataclass
class ICRow:
    signal: str
    bucket: tuple[float, float]
    n: int
    markets: int
    ic: float | None
    lo: float | None = None
    hi: float | None = None
    prospective: int = 0  # observations whose first snapshot is on or after the registration date


@dataclass
class Obs:
    market: str
    hours: float
    score: float
    move: float
    ts: str


@dataclass
class ICResult:
    rows: list[ICRow] = field(default_factory=list)
    obs: dict[str, list[Obs]] = field(default_factory=dict)


def observations(chain: list[tuple[str, object]], scores: dict[int, dict[str, dict[str, float]]]) -> dict[str, list[Obs]]:
    """chain: [(time, universe)] in time order; scores: snapshot index -> signal -> market -> score."""
    out: dict[str, list[Obs]] = {s: [] for s in SIGNALS}
    times = [datetime.fromisoformat(t) for t, _ in chain]
    for i, by_signal in scores.items():
        ua = chain[i][1]
        for j in range(i + 1, len(chain)):
            hours = (times[j] - times[i]).total_seconds() / 3600
            ub = chain[j][1]
            for signal, sc in by_signal.items():
                for k, s in sc.items():
                    a, b = ua.markets.get(k), ub.markets.get(k)
                    if _quoted(a) and _quoted(b):
                        out[signal].append(Obs(k, hours, s, _logit(b.mid) - _logit(a.mid), chain[i][0]))
    return out


def _ic(obs: list[Obs]) -> float | None:
    if len(obs) < 10:
        return None
    s = np.array([o.score for o in obs])
    m = np.array([o.move for o in obs])
    if np.all(m == m[0]) or np.all(s == s[0]):
        return None
    return float(spearmanr(s, m).statistic)


def table(obs: dict[str, list[Obs]], registered_at: str = "", seed: int = 0) -> list[ICRow]:
    rng = np.random.default_rng(seed)
    rows = []
    for signal, xs in obs.items():
        for lo, hi in BUCKETS:
            sel = [o for o in xs if lo <= o.hours < hi]
            ic = _ic(sel)
            row = ICRow(signal, (lo, hi), len(sel), len({o.market for o in sel}), ic,
                        prospective=sum(o.ts[:10] >= registered_at for o in sel) if registered_at else 0)
            if ic is not None:
                by: dict[str, list[Obs]] = {}
                for o in sel:
                    by.setdefault(o.market, []).append(o)
                keys = list(by)
                draws = []
                for _ in range(B):
                    pick = [o for k in rng.choice(keys, len(keys)) for o in by[k]]
                    v = _ic(pick)
                    if v is not None:
                        draws.append(v)
                if draws:
                    row.lo, row.hi = float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))
            rows.append(row)
    return rows


def render(rows: list[ICRow], registered_at: str = "") -> list[str]:
    L = ["", "## 2c. 資訊係數依時間長度的衰減（探索性）", "",
         "訊號在某個快照的值，和之後每一個快照該市場自己價格的變化（都用 logit）的等級相關（Spearman）。負的代表價格往回走"
         "（偏離越大、回得越多）；看它隨時間長度怎麼變小，就知道訊號能用多久。配對互相重疊、同一個市場重複出現，區間用"
         f"以市場為單位的自助法。價差超過 {100 * MAX_SPREAD:.0f} 點的報價不算。"
         + (f"主張 `reversion_ic` 在 {registered_at} 登記，之前的快照都只是探索性的。" if registered_at else ""), "",
         "| 訊號 | 時間長度 | 觀測 | 市場 | IC | 95% 區間 | 前瞻觀測 |", "|---|---|---|---|---|---|---|"]
    for r in rows:
        ci = "—" if r.lo is None else f"{r.lo:+.2f} – {r.hi:+.2f}"
        L.append(f"| {SIGNALS[r.signal]} | {r.bucket[0]:g}–{r.bucket[1]:g} 小時 | {r.n:,} | {r.markets:,} | "
                 f"{'—' if r.ic is None else f'{r.ic:+.2f}'} | {ci} | {r.prospective:,} |")
    return L
