"""Signal lifecycle: when each signal was first seen, whether it is still open, and when it closed.

Signals are stored per snapshot with a stable id (store.save_signals), so a lifecycle needs no table of its own:
a signal is open when it is in the latest snapshot of its module, closed when it was seen before but not in
the latest one, and reopened when it disappeared and came back. Ages count from the first snapshot it was in.
This is what "how long do violations last" and "what did we flag, and when" are measured on.
"""

from __future__ import annotations

import sqlite3
import statistics
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Lifecycle:
    module: str
    snapshots: list[str] = field(default_factory=list)  # snapshot times seen for the module, oldest first
    open: int = 0
    closed: int = 0
    reopened: int = 0
    median_open_hours: float | None = None  # age of the open signals, from first seen to the latest snapshot
    median_closed_hours: float | None = None  # how long closed signals lasted (first seen to last seen)


def _h(a: str, b: str) -> float:
    return (datetime.fromisoformat(b) - datetime.fromisoformat(a)).total_seconds() / 3600


def lifecycle(conn: sqlite3.Connection, module: str = "relations") -> Lifecycle:
    rows = conn.execute("SELECT sig_id, ts FROM signals WHERE module = ? AND sig_id IS NOT NULL", (module,)).fetchall()
    out = Lifecycle(module)
    if not rows:
        return out
    out.snapshots = sorted({ts for _, ts in rows})
    order = {ts: i for i, ts in enumerate(out.snapshots)}
    seen: dict[str, list[int]] = {}
    for sid, ts in rows:
        seen.setdefault(sid, []).append(order[ts])
    latest = len(out.snapshots) - 1
    open_age, closed_len = [], []
    for idx in seen.values():
        idx = sorted(set(idx))
        first, last = idx[0], idx[-1]
        if idx != list(range(first, last + 1)):
            out.reopened += 1
        if last == latest:
            out.open += 1
            open_age.append(_h(out.snapshots[first], out.snapshots[latest]))
        else:
            out.closed += 1
            closed_len.append(_h(out.snapshots[first], out.snapshots[last]))
    out.median_open_hours = statistics.median(open_age) if open_age else None
    out.median_closed_hours = statistics.median(closed_len) if closed_len else None
    return out
