"""Silent-move leads and their follow-up: the test of the registered claim silent_move_followed_by_news.

Every `pmpol movers` run stores its silent leads (signals table, module "movers", kind "silent_move",
keyed by the later snapshot's time). Once a lead is FOLLOW_HOURS old, `pmpol track` searches the news
again for the window after the move and records how many articles appeared. A failed search is not
recorded, so it is retried next time (not observed is not "no news").

The count is automatic; the claim asks for a hand audit (are the articles about the move?), so the
report lists the headlines next to each lead.

Pre-news drift (2026-10-07): when news did appear, how much of the market's move had happened before the first
article? For Polymarket leads the price path comes from the CLOB's public price history (YES token, 10-minute
points): share = (p at the first article - p at the earlier snapshot) / (p DRIFT_AFTER_HOURS after the first
article - p at the earlier snapshot), only when the whole move is at least MIN_MOVE. Near 1: the market had moved
before the news (it anticipated, or the news was late); near 0: the move came with the news. The first article is
the earliest one the search found, which can be later than the first report anywhere.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone

from pmpol.models import Signal

FOLLOW_HOURS = 72
DRIFT_AFTER_HOURS = 24
MIN_MOVE = 0.02
GAMMA = "https://gamma-api.polymarket.com/markets"
CLOB_HISTORY = "https://clob.polymarket.com/prices-history"
SCHEMA = """
CREATE TABLE IF NOT EXISTS lead_followups (
    lead_id TEXT PRIMARY KEY, market TEXT, ts_b TEXT, query TEXT, checked_at TEXT, news INTEGER, source TEXT,
    titles TEXT
);
"""
COLUMNS = (("first_news", "TEXT"), ("ts_a", "TEXT"), ("p_a", "REAL"), ("p_news", "REAL"), ("p_after", "REAL"),
           ("pre_news_share", "REAL"))


def _schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    have = {r[1] for r in conn.execute("PRAGMA table_info(lead_followups)")}
    for col, typ in COLUMNS:
        if col not in have:
            conn.execute(f"ALTER TABLE lead_followups ADD COLUMN {col} {typ}")


def lead_signals(rows) -> list[Signal]:
    """Signals for the silent leads among `pmpol movers` rows [(Move, Proof)]."""
    from pmpol.movers.news import query_for

    out = []
    for mv, p in rows:
        if not p.result.get("silent"):
            continue
        out.append(Signal("movers", "silent_move", mv.key, round(mv.delta, 4), {
            "title": mv.title, "outcome": mv.outcome, "venue": mv.venue, "ts_a": mv.ts_a, "ts_b": mv.ts_b,
            "query": query_for(mv.title, mv.outcome), "lane": mv.lane}, ts=mv.ts_b))
    return out


def _parse(ts: str) -> datetime:
    d = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def due(conn: sqlite3.Connection, now: datetime) -> list[dict]:
    """Leads at least FOLLOW_HOURS old with no recorded follow-up."""
    _schema(conn)
    done = {r[0] for r in conn.execute("SELECT lead_id FROM lead_followups")}
    out = []
    for ts, subject, payload in conn.execute(
            "SELECT ts, subject, payload FROM signals WHERE module = 'movers' AND kind = 'silent_move'"):
        lead_id = f"{subject}@{ts}"
        if lead_id in done or now - _parse(ts) < timedelta(hours=FOLLOW_HOURS):
            continue
        out.append({"lead_id": lead_id, "market": subject, "ts_b": ts, **json.loads(payload)})
    return out


def _get(url: str, params: dict):
    import httpx

    from pmpol import USER_AGENT

    r = httpx.get(url, params=params, timeout=60, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
    r.raise_for_status()  # a refusal or a rate limit stops here, never retried
    return r.json()


def price_path(slug: str, start: datetime, end: datetime, get=None) -> list[tuple[int, float]]:
    """[(unix time, YES price)] of a Polymarket market between start and end (CLOB price history, 10 minutes)."""
    get = get or _get
    rows = get(GAMMA, {"slug": slug})
    if not rows:
        return []
    tokens = rows[0].get("clobTokenIds") or "[]"
    tokens = json.loads(tokens) if isinstance(tokens, str) else tokens
    if not tokens:
        return []
    # an hour earlier, so that a price at or before `start` exists (points are every 10 minutes)
    hist = get(CLOB_HISTORY, {"market": tokens[0], "startTs": int(start.timestamp()) - 3600,
                              "endTs": int(end.timestamp()), "fidelity": 10})
    return sorted((int(h["t"]), float(h["p"])) for h in (hist or {}).get("history", []))


def at(path: list[tuple[int, float]], t: datetime) -> float | None:
    """The last price at or before t."""
    ts = t.timestamp()
    before = [p for u, p in path if u <= ts]
    return before[-1] if before else None


def drift(path: list[tuple[int, float]], ts_a: datetime, first_news: datetime,
          after_hours: int = DRIFT_AFTER_HOURS) -> tuple[float | None, float | None, float | None, float | None]:
    """(p_a, p_news, p_after, share of the move made before the first article)."""
    p_a, p_n, p_x = at(path, ts_a), at(path, first_news), at(path, first_news + timedelta(hours=after_hours))
    if None in (p_a, p_n, p_x) or abs(p_x - p_a) < MIN_MOVE:
        return p_a, p_n, p_x, None
    return p_a, p_n, p_x, round((p_n - p_a) / (p_x - p_a), 4)


def first_article(articles: list[dict]) -> datetime | None:
    from pmpol.evidence import _t

    times = [t for a in articles if (t := _t(a.get("seendate", ""))) is not None]
    return min(times) if times else None


def follow_up(conn: sqlite3.Connection, now: datetime | None = None, search=None, get=None) -> dict[str, int]:
    """Search the news after each due lead; record successful searches. Returns counts."""
    from pmpol.movers.news import search as news_search

    search = search or news_search
    now = now or datetime.now(timezone.utc)
    counts = {"due": 0, "checked": 0, "failed": 0}
    for lead in due(conn, now):
        counts["due"] += 1
        end = (_parse(lead["ts_b"]) + timedelta(hours=FOLLOW_HOURS)).isoformat()
        from pmpol.movers.news import query_for

        lead["query"] = query_for(lead["title"], lead["outcome"])  # today's query rules, not the stored ones
        res = search(lead["query"], lead["ts_b"], end, pad_hours=0)
        if res.count is None:  # not observed: retry next time
            counts["failed"] += 1
            continue
        first = first_article(res.articles) if res.count else None
        d = (None, None, None, None)
        if first is not None and lead["market"].startswith("polymarket:") and lead.get("ts_a"):
            try:
                path = price_path(lead["market"].split(":", 1)[1], _parse(lead["ts_a"]),
                                  first + timedelta(hours=DRIFT_AFTER_HOURS), get)
                d = drift(path, _parse(lead["ts_a"]), first)
            except Exception:  # the drift is optional; the news count is still recorded
                counts["drift_failed"] = counts.get("drift_failed", 0) + 1
        conn.execute("INSERT OR REPLACE INTO lead_followups (lead_id, market, ts_b, query, checked_at, news, source, "
                     "titles, first_news, ts_a, p_a, p_news, p_after, pre_news_share) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     (lead["lead_id"], lead["market"], lead["ts_b"], lead["query"], now.isoformat(timespec="seconds"),
                      res.count, res.source, json.dumps([a["title"] for a in res.articles[:3]], ensure_ascii=False),
                      None if first is None else first.isoformat(timespec="seconds"), lead.get("ts_a"), *d))
        # the articles themselves are evidence published after the move (the market moved first)
        from pmpol.evidence import from_news
        from pmpol.store import save_evidence

        save_evidence(conn, from_news(f"market:{lead['market']}", res.articles, res.source,
                                      now.isoformat(timespec="seconds")), run_id="track")
        counts["checked"] += 1
    conn.commit()
    return counts


def backfill_drift(conn: sqlite3.Connection, get=None) -> int:
    """Compute the drift for followed-up Polymarket leads with news that do not have it yet."""
    _schema(conn)
    n = 0
    for lead_id, market, ts_a, first in conn.execute(
            "SELECT lead_id, market, ts_a, first_news FROM lead_followups WHERE news > 0 AND first_news IS NOT NULL "
            "AND ts_a IS NOT NULL AND pre_news_share IS NULL AND market LIKE 'polymarket:%'").fetchall():
        a, f = _parse(ts_a), _parse(first)
        try:
            d = drift(price_path(market.split(":", 1)[1], a, f + timedelta(hours=DRIFT_AFTER_HOURS), get), a, f)
        except Exception:
            continue
        conn.execute("UPDATE lead_followups SET p_a = ?, p_news = ?, p_after = ?, pre_news_share = ? WHERE lead_id = ?",
                     (*d, lead_id))
        n += d[3] is not None
    conn.commit()
    return n


def summary(conn: sqlite3.Connection) -> dict:
    import statistics

    _schema(conn)
    rows = conn.execute("SELECT lead_id, query, news, titles, ts_b, pre_news_share FROM lead_followups "
                        "ORDER BY ts_b").fetchall()
    shares = [r[5] for r in rows if r[5] is not None]
    by_venue: dict[str, list[int]] = {}
    for r in rows:  # the lead's venue: Kalshi has no wallet data, so it is the market-level comparison
        v = by_venue.setdefault(r[0].split(":", 1)[0], [0, 0])
        v[0] += 1
        v[1] += r[2] > 0
    pending = conn.execute("SELECT COUNT(*) FROM signals WHERE module = 'movers' AND kind = 'silent_move'").fetchone()[0]
    with_news = sum(1 for r in rows if r[2] > 0)
    return {"leads": pending, "checked": len(rows), "with_news": with_news,
            "share": with_news / len(rows) if rows else None,
            "by_venue": by_venue,
            "drift": {"n": len(shares), "median": statistics.median(shares) if shares else None,
                      "mostly_before": sum(x >= 0.5 for x in shares)},
            "rows": [{"lead": r[0], "query": r[1], "news": r[2], "titles": json.loads(r[3] or "[]"), "ts_b": r[4],
                      "pre_news_share": r[5]} for r in rows]}
