"""The two engines, each pointing at the other (2026-10-07).

The forward engine (pmpol universe) finds prices that cannot all be right: a consistency violation names its legs
(the markets in it). The reverse engine (pmpol movers) finds prices that moved between two snapshots. A market that
is in both is worth a second look from each side:

  move -> violations   a moved market is a leg of these violations: the move may have opened one (one venue moved,
                       the others did not yet) or closed one (it caught up)
  violation -> moves   a violation one of whose legs moved: the gap is fresh, not a stale quote left behind

Both engines read the same latest snapshot when `pmpol movers` runs after `pmpol universe` in the cycle; when the
violations come from another snapshot, the proof says so. Only violations whose rules match (not "material") are
linked, as in the coherence step. Nothing here decides which side is right.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

MAX_SHOWN = 3


@dataclass
class Violation:
    id: str
    kind: str
    subject: str
    edge: float
    markets: list[str]
    title: str


@dataclass
class Links:
    observed_at: str = ""
    by_market: dict[str, list[Violation]] = field(default_factory=dict)  # market -> violations it is a leg of
    moved: list[tuple[Violation, list]] = field(default_factory=list)  # violation -> its legs that moved [(Move)]


def load_violations(path: Path = Path("data/proofs.json")) -> tuple[str, list[Violation]]:
    if not path.exists():
        return "", []
    d = json.loads(path.read_text(encoding="utf-8"))
    out = [Violation(r["id"], r.get("kind", ""), r.get("subject", ""), float(r.get("edge") or 0), r.get("markets", []),
                     r.get("title", ""))
           for r in d.get("signals", []) if r.get("group") == "rule" and r.get("rules") != "material"
           and r.get("markets")]
    return d.get("observed_at", ""), out


def link(moves, violations: list[Violation], observed_at: str = "") -> Links:
    """moves: pmpol.movers.diff.Move (key, delta)."""
    by_market: dict[str, list[Violation]] = {}
    for v in violations:
        for k in v.markets:
            by_market.setdefault(k, []).append(v)
    moved_keys = {m.key: m for m in moves}
    out = Links(observed_at, {k: sorted(vs, key=lambda v: -v.edge) for k, vs in by_market.items() if k in moved_keys})
    for v in violations:
        legs = [moved_keys[k] for k in v.markets if k in moved_keys]
        if legs:
            out.moved.append((v, legs))
    out.moved.sort(key=lambda t: -t[0].edge)
    return out


def add_to_proof(p, mv, links: Links, ts_b: str) -> None:
    """A step on a move's proof: the violations this market is a leg of."""
    vs = links.by_market.get(mv.key, [])
    if not vs:
        return
    when = links.observed_at or ts_b
    same = not links.observed_at or links.observed_at[:16] == ts_b[:16]
    p.add("L5", f"這個市場是 {len(vs)} 條一致性違反的一腿（最大差距 {100 * vs[0].edge:.1f} 點："
                + "；".join(v.title[:60] for v in vs[:MAX_SHOWN]) + "）"
                + ("" if same else f"；違反來自 {when[:16]} 的快照，不是這次異動的快照"),
          "data/proofs.json", kind="logic", id="violations")
    p.result["violations"] = [v.id for v in vs]
    p.alt("這次變動造成或修正了跨市場的不一致（一個平台先動、其他平台還沒跟上，或反過來）", "unchecked",
          f"{len(vs)} 條違反牽涉這個市場；要比較異動前後的差距才知道是哪一種")


def render(links: Links, top: int = 20) -> list[str]:
    if not links.moved:
        return []
    L = ["", "## 3b. 與一致性違反的交集（兩個引擎互相觸發）", "",
         f"一致性違反（{links.observed_at[:16] or '最新全景'}）中，至少一腿在這兩個快照之間變動 5 點以上的：{len(links.moved)} 條。"
         "差距是新的（有人剛動價），不是放著沒人更新的舊報價；但誰對誰錯，兩個引擎都不判斷。", "",
         "| 差距 | 違反 | 變動的腿 |", "|---|---|---|"]
    for v, legs in links.moved[:top]:
        L.append(f"| {100 * v.edge:.1f} | {v.title[:70]} | "
                 + "；".join(f"{m.title[:30]}／{m.outcome[:20]} {100 * m.delta:+.1f}" for m in legs[:MAX_SHOWN]) + " |")
    return L
