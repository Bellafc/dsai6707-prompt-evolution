"""Datasets from a universe snapshot: one example per decision the pipeline already makes, with its answer as the
weak label. The text is venue data (rules, titles) and stays in data/ (not versioned); the gold labels reference
examples by id."""

from __future__ import annotations

import json
from pathlib import Path

from pmpol.classify import OFFICE_FOLD, TASKS, Example
from pmpol.models import Event
from pmpol.propositions.resolution import attributes

OUT = Path("data/classify")
MAX_RULES = 6000  # characters of rules text kept (Vega's context is 73k tokens; most rules are under 2k characters)


def rules_examples(u, relations, task_id: str) -> list[Example]:
    """Legs of cross-venue relations whose variable kind carries the attribute, one example per market."""
    task = TASKS[task_id]
    out: dict[str, Example] = {}
    for r in relations:
        if not r.cross_venue or r.template.count(":") < 2:
            continue
        kind = r.template.split(":")[1]
        if kind not in task.kinds:
            continue
        for k in r.lhs + r.rhs:
            m = u.markets.get(k)
            if m is None or k in out or not (m.rules or "").strip():
                continue
            attrs = attributes(m, kind)
            if task_id not in attrs:
                continue
            state = f"Market: {m.question}\nOption: {m.outcome}\n\nResolution rules:\n{m.rules[:MAX_RULES]}"
            out[k] = Example(k, task_id, state, attrs[task_id], r.group, m.venue,
                             {"kind": kind, "relation_status": r.rules, "question": m.question, "outcome": m.outcome})
    return list(out.values())


def event_examples(u, task_id: str = "office") -> list[Example]:
    out = []
    for key, e in u.events.items():
        t = u.tags.get(key)
        if t is None:
            continue
        options = [m.outcome for m in e.markets[:6] if m.outcome]
        state = (f"Venue: {e.venue}\nEvent: {e.title}\nOptions: {', '.join(options) or '(yes/no)'}\n"
                 f"Venue category: {e.category or '(none)'}")
        weak = OFFICE_FOLD.get(t.office, t.office) if t.topic in ("elections_us", "elections_intl") else "none"
        if weak not in TASKS[task_id].labels:
            weak = "none"
        out.append(Example(key, task_id, state, weak, u.clusters.get(key) or t.race_key or key, e.venue,
                           {"topic": t.topic, "office": t.office, "jurisdiction": t.jurisdiction, "country": t.country}))
    return out


def build(events: list[Event], relations=None, tasks: tuple[str, ...] = tuple(TASKS)) -> dict[str, list[Example]]:
    """All tasks from the events of a snapshot. `relations` (pmpol.models.Relation) are built when not given."""
    from pmpol.universe.cluster import build_clusters
    from pmpol.universe.index import Universe

    u = Universe.build(events)
    build_clusters(u)
    if relations is None:
        from pmpol.universe import pipeline

        relations = pipeline.run(events, depth=False, proofs=False, entities=False).rule_relations
    out = {}
    for tid in tasks:
        task = TASKS[tid]
        out[tid] = rules_examples(u, relations, tid) if task.source == "rules" else event_examples(u, tid)
    return out


def save(datasets: dict[str, list[Example]], snapshot: str, out: Path = OUT) -> dict[str, Path]:
    out.mkdir(parents=True, exist_ok=True)
    paths = {}
    for tid, rows in datasets.items():
        p = out / f"{tid}.jsonl"
        with p.open("w", encoding="utf-8") as f:
            f.write(json.dumps({"_snapshot": snapshot, "task": tid, "n": len(rows)}) + "\n")
            for r in rows:
                f.write(json.dumps(r.to_dict(), ensure_ascii=False) + "\n")
        paths[tid] = p
    return paths


def load(tid: str, out: Path = OUT) -> tuple[str, list[Example]]:
    rows, snapshot = [], ""
    with (out / f"{tid}.jsonl").open(encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if "_snapshot" in d:
                snapshot = d["_snapshot"]
                continue
            rows.append(Example(**d))
    return snapshot, rows
