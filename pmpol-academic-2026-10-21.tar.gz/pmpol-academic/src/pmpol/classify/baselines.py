"""Baselines that need no decision model: the majority label, the regex itself, and TF-IDF + logistic regression
fitted on the weak labels with grouped cross-validation (what a plain supervised classifier gets from the
same text)."""

from __future__ import annotations

from collections import Counter

from pmpol.classify import TASKS, Example, Prediction
from pmpol.classify.splits import grouped_split


def majority(rows: list[Example], labels_from: list[Example] | None = None) -> list[Prediction]:
    top = Counter(r.weak for r in (labels_from or rows)).most_common(1)[0][0]
    n = len(TASKS[rows[0].task].labels) if rows else 1
    return [Prediction(r.id, top, {top: 1.0}, 1.0 / n, "majority") for r in rows]


def regex(rows: list[Example]) -> list[Prediction]:
    """The pipeline's own answer, as a prediction with probability 1 (no uncertainty: what we compare against)."""
    return [Prediction(r.id, r.weak, {r.weak: 1.0}, None, "regex") for r in rows]


def tfidf_lr(train: list[Example], test: list[Example], labels: dict[str, str] | None = None,
             seed: int = 7) -> list[Prediction]:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline

    y = [r.weak if labels is None else labels.get(r.id, r.weak) for r in train]
    if len(set(y)) < 2:
        return majority(test, train)
    clf = make_pipeline(TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, max_features=50_000),
                        LogisticRegression(max_iter=2000, C=4.0, random_state=seed))
    clf.fit([r.state for r in train], y)
    classes = list(clf.classes_)
    out = []
    for r, probs in zip(test, clf.predict_proba([r.state for r in test])):
        p = {c: float(x) for c, x in zip(classes, probs)}
        top = max(p, key=p.get)
        out.append(Prediction(r.id, top, p, p[top], "tfidf_lr"))
    return out


def tfidf_lr_cv(rows: list[Example], folds: int = 5, seed: int = 7) -> list[Prediction]:
    """Grouped k-fold: every example predicted by a model that never saw its race."""
    import random

    groups = sorted({r.group for r in rows})
    random.Random(seed).shuffle(groups)
    fold_of = {g: i % folds for i, g in enumerate(groups)}
    out = []
    for k in range(folds):
        train = [r for r in rows if fold_of[r.group] != k]
        test = [r for r in rows if fold_of[r.group] == k]
        if test:
            out += tfidf_lr(train, test, seed=seed)
    return out


def learning_curve(rows: list[Example], gold: dict[str, str], sizes=(25, 50, 100, 200, 400), seed: int = 7):
    """Accuracy on the held-out gold as the number of gold training examples grows (grouped split)."""
    from pmpol.classify.metrics import accuracy

    labelled = [r for r in rows if r.id in gold]
    train, test = grouped_split(labelled, 0.4, seed)
    out = []
    for n in sizes:
        sub = train[:n]
        if len(sub) < 5:
            continue
        preds = tfidf_lr(sub, test, gold, seed)
        out.append({"n_train": len(sub), "n_test": len(test), "accuracy": accuracy(preds, gold)})
    return out
