"""Metrics for typed decisions: how often right, and whether the probabilities mean what they say."""

from __future__ import annotations

import math
import random
from collections import Counter, defaultdict

from pmpol.classify import Prediction


def accuracy(preds: list[Prediction], gold: dict[str, str]) -> float | None:
    ids = [p for p in preds if p.id in gold]
    return sum(p.label == gold[p.id] for p in ids) / len(ids) if ids else None


def macro_f1(preds: list[Prediction], gold: dict[str, str]) -> float | None:
    ids = [p for p in preds if p.id in gold]
    if not ids:
        return None
    labels = sorted({gold[p.id] for p in ids} | {p.label for p in ids})
    f1s = []
    for lab in labels:
        tp = sum(p.label == lab and gold[p.id] == lab for p in ids)
        fp = sum(p.label == lab and gold[p.id] != lab for p in ids)
        fn = sum(p.label != lab and gold[p.id] == lab for p in ids)
        if tp + fp + fn == 0:
            continue
        pr = tp / (tp + fp) if tp + fp else 0.0
        rc = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(2 * pr * rc / (pr + rc) if pr + rc else 0.0)
    return sum(f1s) / len(f1s) if f1s else None


def ece(preds: list[Prediction], gold: dict[str, str], bins: int = 10) -> float | None:
    """Expected calibration error of the top-label probability (equal-width bins)."""
    ids = [p for p in preds if p.id in gold and p.probs]
    if not ids:
        return None
    buckets: dict[int, list[tuple[float, bool]]] = defaultdict(list)
    for p in ids:
        conf = max(p.probs.values())
        buckets[min(int(conf * bins), bins - 1)].append((conf, p.label == gold[p.id]))
    total = 0.0
    for rows in buckets.values():
        total += len(rows) / len(ids) * abs(sum(c for c, _ in rows) / len(rows) - sum(ok for _, ok in rows) / len(rows))
    return total


def brier(preds: list[Prediction], gold: dict[str, str]) -> float | None:
    """Multi-class Brier score, summed over labels (0 perfect, 2 worst)."""
    ids = [p for p in preds if p.id in gold and p.probs]
    if not ids:
        return None
    tot = 0.0
    for p in ids:
        labels = set(p.probs) | {gold[p.id]}
        tot += sum((p.probs.get(l, 0.0) - (1.0 if l == gold[p.id] else 0.0)) ** 2 for l in labels)
    return tot / len(ids)


def selective(preds: list[Prediction], gold: dict[str, str], thresholds=(0.5, 0.6, 0.7, 0.8, 0.9, 0.95)) -> list[dict]:
    """Coverage and accuracy when the system abstains below a confidence threshold (confidence, else top prob)."""
    ids = [p for p in preds if p.id in gold]
    out = []
    for t in thresholds:
        kept = [p for p in ids if (p.confidence if p.confidence is not None else max(p.probs.values(), default=0)) >= t]
        out.append({"threshold": t, "coverage": len(kept) / len(ids) if ids else None,
                    "accuracy": sum(p.label == gold[p.id] for p in kept) / len(kept) if kept else None})
    return out


def per_label(preds: list[Prediction], gold: dict[str, str]) -> dict[str, dict]:
    ids = [p for p in preds if p.id in gold]
    out: dict[str, dict] = {}
    for lab in sorted({gold[p.id] for p in ids}):
        mine = [p for p in ids if gold[p.id] == lab]
        out[lab] = {"n": len(mine), "recall": sum(p.label == lab for p in mine) / len(mine),
                    "predicted_as": dict(Counter(p.label for p in mine))}
    return out


def mcnemar(a: list[Prediction], b: list[Prediction], gold: dict[str, str]) -> dict:
    """Exact McNemar test on paired right/wrong: are two systems' accuracies different?"""
    bi = {p.id: p for p in b}
    n01 = n10 = 0
    for p in a:
        if p.id in gold and p.id in bi:
            ra, rb = p.label == gold[p.id], bi[p.id].label == gold[p.id]
            n01 += ra and not rb
            n10 += rb and not ra
    n = n01 + n10
    if n == 0:
        return {"a_only_right": 0, "b_only_right": 0, "p": 1.0}
    k = min(n01, n10)
    p = min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n)
    return {"a_only_right": n01, "b_only_right": n10, "p": p}


def bootstrap_ci(preds: list[Prediction], gold: dict[str, str], stat=accuracy, n: int = 2000, seed: int = 7,
                 level: float = 0.95) -> tuple[float, float] | None:
    ids = [p for p in preds if p.id in gold]
    if not ids:
        return None
    rng = random.Random(seed)
    vals = sorted(stat([rng.choice(ids) for _ in ids], gold) for _ in range(n))
    lo, hi = int((1 - level) / 2 * n), int((1 + level) / 2 * n) - 1
    return vals[lo], vals[hi]


def summary(preds: list[Prediction], gold: dict[str, str]) -> dict:
    return {"n": sum(p.id in gold for p in preds), "accuracy": accuracy(preds, gold), "macro_f1": macro_f1(preds, gold),
            "ece": ece(preds, gold), "brier": brier(preds, gold), "selective": selective(preds, gold),
            "per_label": per_label(preds, gold), "accuracy_ci": bootstrap_ci(preds, gold)}
