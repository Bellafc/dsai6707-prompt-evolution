"""Two-annotator labelling and agreement.

Each annotator labels the same sample without seeing the other's labels or the weak label; the gold label is
where they agree, and disagreements go to a third reader. Annotation files are versioned
(annotations/classify/<task>.<annotator>.jsonl) and hold ids and labels only, never the venues' text."""

from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from pmpol.classify import TASKS, Example

DIR = Path("annotations/classify")
SKIP = "?"  # the annotator cannot decide from the text


def path(task: str, annotator: str, root: Path = DIR) -> Path:
    return root / f"{task}.{annotator}.jsonl"


def read(p: Path) -> dict[str, dict]:
    out = {}
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.strip():
                d = json.loads(line)
                out[d["id"]] = d
    return out


def annotate(task: str, sample: list[Example], annotator: str, root: Path = DIR, ask=input, out=sys.stdout) -> int:
    """Interactive: show the state, take a label (number or name, '?' to skip, 'q' to stop). Resumes."""
    t = TASKS[task]
    labels = list(t.labels)
    p = path(task, annotator, root)
    p.parent.mkdir(parents=True, exist_ok=True)
    done = read(p)
    n = 0
    with p.open("a", encoding="utf-8") as f:
        for i, ex in enumerate(sample):
            if ex.id in done:
                continue
            print(f"\n[{i + 1}/{len(sample)}] {ex.id}\n{'-' * 80}\n{ex.state[:3000]}\n{'-' * 80}", file=out)
            print(t.question, file=out)
            for j, lab in enumerate(labels, 1):
                print(f"  {j}. {lab}: {t.labels[lab]}", file=out)
            print(f"  ?  cannot tell   q  quit", file=out)
            while True:
                a = ask("> ").strip()
                if a == "q":
                    return n
                if a == SKIP or a in labels:
                    break
                if a.isdigit() and 1 <= int(a) <= len(labels):
                    a = labels[int(a) - 1]
                    break
                print("label by number or name", file=out)
            note = ask("note (enter to skip)> ").strip()
            f.write(json.dumps({"id": ex.id, "label": a, "annotator": annotator, "task": task, "note": note,
                                "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}) + "\n")
            f.flush()
            n += 1
    return n


def kappa(a: dict[str, str], b: dict[str, str]) -> tuple[float | None, int]:
    """Cohen's kappa over the ids both labelled (skips excluded)."""
    ids = [i for i in a if i in b and a[i] != SKIP and b[i] != SKIP]
    if not ids:
        return None, 0
    agree = sum(a[i] == b[i] for i in ids) / len(ids)
    ca, cb = Counter(a[i] for i in ids), Counter(b[i] for i in ids)
    chance = sum(ca[l] * cb[l] for l in set(ca) | set(cb)) / len(ids) ** 2
    return (1.0 if chance == 1 else (agree - chance) / (1 - chance)), len(ids)


def agreement(task: str, annotators: tuple[str, str], root: Path = DIR) -> dict:
    a = {k: v["label"] for k, v in read(path(task, annotators[0], root)).items()}
    b = {k: v["label"] for k, v in read(path(task, annotators[1], root)).items()}
    k, n = kappa(a, b)
    both = [i for i in a if i in b]
    confusion: dict[str, Counter] = defaultdict(Counter)
    for i in both:
        confusion[a[i]][b[i]] += 1
    gold = {i: a[i] for i in both if a[i] == b[i] and a[i] != SKIP}
    disputed = [i for i in both if a[i] != b[i]]
    return {"n_both": len(both), "n_compared": n, "kappa": k, "gold": gold, "disputed": disputed,
            "confusion": {x: dict(c) for x, c in confusion.items()},
            "only_a": [i for i in a if i not in b], "only_b": [i for i in b if i not in a]}


def gold_labels(task: str, annotators: tuple[str, str], adjudicator: str | None = None, root: Path = DIR) -> dict[str, str]:
    """Agreed labels, plus the adjudicator's label on disputed ids when one is given."""
    g = agreement(task, annotators, root)
    gold = dict(g["gold"])
    if adjudicator:
        adj = {k: v["label"] for k, v in read(path(task, adjudicator, root)).items()}
        for i in g["disputed"]:
            if adj.get(i) not in (None, SKIP):
                gold[i] = adj[i]
    return gold
