"""Client for the System One API (/v1/systemone: ollajev locally, or TypeSafe's hosted Jev) with recorded
fixtures, so a run can be replayed and tests never touch a server.

A fixture is keyed by the SHA-1 of the request body plus the model identity; `replay_only` raises instead of
calling out, which is how tests run. Every prediction carries the model name and, when the server reports it,
the model's commit, so results can be reproduced later."""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

from pmpol import USER_AGENT
from pmpol.classify import TASKS, Example, Prediction

FIXTURES = Path("data/classify/fixtures")


class SystemOneClient:
    def __init__(self, base_url: str = "http://127.0.0.1:8000", model: str | None = None, api_key: str | None = None,
                 fixtures: Path = FIXTURES, replay_only: bool = False, timeout: float = 600):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.fixtures = fixtures
        self.replay_only = replay_only
        self.timeout = timeout
        self._http = None
        self.system = model or "default"

    def _client(self):
        if self._http is None:
            import httpx

            headers = {"User-Agent": USER_AGENT}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            self._http = httpx.Client(headers=headers, timeout=self.timeout)
        return self._http

    def body(self, ex: Example) -> dict:
        t = TASKS[ex.task]
        b = {"state": ex.state, "questions": {ex.task: {"type": "choice", "instructions": t.question,
                                                         "criteria": dict(t.labels)}}}
        if self.model:
            b["model"] = self.model
        return b

    def _key(self, body: dict) -> str:
        raw = json.dumps({"url": self.base_url, "model": self.model, "body": body}, sort_keys=True, ensure_ascii=False)
        return hashlib.sha1(raw.encode()).hexdigest()

    def models(self) -> list[dict]:
        r = self._client().get(f"{self.base_url}/v1/models")
        r.raise_for_status()
        d = r.json()
        return d.get("data") or d.get("models") or []

    def ask(self, ex: Example) -> Prediction:
        body = self.body(ex)
        path = self.fixtures / f"{self._key(body)}.json"
        if path.exists():
            rec = json.loads(path.read_text(encoding="utf-8"))
        elif self.replay_only:
            raise FileNotFoundError(f"no fixture for {ex.id} ({path.name}); run online first")
        else:
            t = time.time()
            r = self._client().post(f"{self.base_url}/v1/systemone", json=body)
            r.raise_for_status()  # a 4xx stops here (never retried); the caller decides what to do
            rec = {"response": r.json(), "seconds": round(time.time() - t, 3), "example": ex.id, "task": ex.task}
            self.fixtures.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(rec, ensure_ascii=False), encoding="utf-8")
        return self.prediction(ex, rec)

    def prediction(self, ex: Example, rec: dict) -> Prediction:
        resp = rec["response"]
        a = resp["answers"][ex.task]
        probs = {k: float(v) for k, v in (a.get("probabilities") or {}).items()}
        label = a.get("choice") or (max(probs, key=probs.get) if probs else "")
        system = resp.get("model") or self.system
        if resp.get("model_revision") or resp.get("commit"):
            system += "@" + str(resp.get("model_revision") or resp.get("commit"))[:12]
        return Prediction(ex.id, label, probs, a.get("confidence"), system, rec.get("seconds"))


def run(client: SystemOneClient, rows: list[Example], out: Path, log=None) -> list[Prediction]:
    """Predict every example, appending to a JSONL file (resumable); errors are logged and skipped."""
    done = set()
    preds = []
    if out.exists():
        for line in out.read_text(encoding="utf-8").splitlines():
            if line.strip():
                d = json.loads(line)
                done.add(d["id"])
                preds.append(Prediction(**d))
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("a", encoding="utf-8") as f:
        for i, ex in enumerate(rows):
            if ex.id in done:
                continue
            try:
                p = client.ask(ex)
            except Exception as e:  # noqa: BLE001 - one bad example must not end a long run
                if log:
                    print(f"{i} {ex.id}: {e}", file=log)
                continue
            preds.append(p)
            f.write(json.dumps(p.to_dict(), ensure_ascii=False) + "\n")
            f.flush()
            if log and i % 25 == 0:
                print(f"{i}/{len(rows)} {ex.id} -> {p.label} p={max(p.probs.values(), default=0):.2f} "
                      f"conf={p.confidence} {p.seconds}s", file=log)
    return preds
