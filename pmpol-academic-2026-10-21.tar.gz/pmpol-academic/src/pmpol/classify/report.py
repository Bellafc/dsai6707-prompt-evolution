"""Markdown report of the classifier study: datasets, agreement, baselines and model runs side by side."""

from __future__ import annotations

from collections import Counter

from pmpol.classify import TASKS, Example


def _pct(x) -> str:
    return "—" if x is None else f"{100 * x:.1f}%"


def _f(x, d=3) -> str:
    return "—" if x is None else f"{x:.{d}f}"


def dataset_lines(datasets: dict[str, list[Example]], snapshot: str) -> list[str]:
    L = [f"## 1. 資料集（快照 `{snapshot}`）", "",
         "每個例子是流程現在就在做的一個離散判斷；弱標籤是正則或分類器目前的答案，不是金標準。", "",
         "| 任務 | 例子 | 群組（選舉／事件） | 平台 | 弱標籤分布 |", "|---|---|---|---|---|"]
    for tid, rows in datasets.items():
        venues = Counter(r.venue for r in rows)
        weak = Counter(r.weak for r in rows)
        L.append(f"| {tid} | {len(rows):,} | {len({r.group for r in rows}):,} | "
                 + "、".join(f"{v} {n}" for v, n in venues.most_common()) + " | "
                 + "、".join(f"{k} {n}" for k, n in weak.most_common()) + " |")
    return L


def agreement_lines(task: str, g: dict) -> list[str]:
    L = [f"### 標註一致性：{task}", "",
         f"兩位標註者都標了 {g['n_both']} 個，可比較 {g['n_compared']} 個，Cohen's κ = {_f(g['kappa'])}；"
         f"一致（金標準）{len(g['gold'])} 個，不一致（待第三人裁決）{len(g['disputed'])} 個。", ""]
    if g["confusion"]:
        labels = sorted(set(g["confusion"]) | {k for c in g["confusion"].values() for k in c})
        L += ["| A \\ B | " + " | ".join(labels) + " |", "|---|" + "---|" * len(labels)]
        for a in labels:
            L.append(f"| {a} | " + " | ".join(str(g["confusion"].get(a, {}).get(b, 0)) for b in labels) + " |")
        L.append("")
    return L


def results_lines(task: str, results: dict[str, dict], gold_kind: str) -> list[str]:
    """results: system -> metrics.summary(); gold_kind says what the labels are ('weak' or 'gold')."""
    L = [f"### {task}：各系統對照（標籤：{'弱標籤（正則）' if gold_kind == 'weak' else '人工金標準'}）", "",
         "| 系統 | n | 準確率（95% CI） | macro-F1 | ECE | Brier | 信心 ≥ 0.8 的覆蓋率／準確率 |", "|---|---|---|---|---|---|---|"]
    for sysname, m in results.items():
        ci = m.get("accuracy_ci")
        sel = next((s for s in m["selective"] if s["threshold"] == 0.8), None)
        L.append(f"| {sysname} | {m['n']} | {_pct(m['accuracy'])}"
                 + (f"（{_pct(ci[0])}–{_pct(ci[1])}）" if ci else "") + f" | {_f(m['macro_f1'])} | {_f(m['ece'])} | "
                 f"{_f(m['brier'])} | " + (f"{_pct(sel['coverage'])}／{_pct(sel['accuracy'])}" if sel else "—") + " |")
    L.append("")
    for sysname, m in results.items():
        if m.get("per_label"):
            L.append(f"{sysname} 各標籤召回率：" + "；".join(f"{lab} {_pct(v['recall'])}（n={v['n']}）"
                                                        for lab, v in m["per_label"].items()))
    L.append("")
    return L


def render(title: str, sections: list[list[str]], generated_at: str) -> str:
    L = [f"# {title}", "", f"產生時間 {generated_at}。分類器的答案是 L5 提議，不是事實；人工金標準才是比較的基準。", ""]
    for s in sections:
        L += s + [""]
    L += ["## 任務定義", ""]
    for t in TASKS.values():
        L += [f"- **{t.id}**（{t.source}）：{t.question}", "  - " + "；".join(f"`{k}`：{v}" for k, v in t.labels.items())]
    return "\n".join(L)
