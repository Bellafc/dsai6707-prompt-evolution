"""Local decision models as classifiers for the pipeline's discrete judgements (2026-10-15, Alex's MPhil project).

The pipeline makes many small discrete decisions with regular expressions: what settles a market (media call,
certification, swearing-in), whether a runoff counts, which office a contest is for. Each is a fixed set of labels
read from a short text. The project asks whether a small local decision model (System One style: typed
questions, option probabilities, a confidence value; served by ollajev or TypeSafe's Jev API) can make these
decisions at least as well as the regexes, with probabilities that mean what they say, cheaply enough to run on
every market of every crawl. Plan and experiment design: docs/THESIS_DECISION_MODELS.md.

This package holds the parts that need no model: task definitions, dataset export from a snapshot (with the
regex answer as a weak label), leakage-free splits, gold-set sampling, the two-annotator labelling protocol and
agreement, metrics (accuracy, macro-F1, ECE, Brier, selective accuracy), a recorded-fixture client for the
/v1/systemone API, and baselines (majority, regex, TF-IDF + logistic regression).

Team rules apply: a model's answer is an L5 proposal, never an approval; every prediction records the model and
its commit; tests run offline from recorded fixtures.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict


@dataclass(frozen=True)
class Task:
    id: str
    question: str  # the instruction sent with the state
    labels: dict[str, str]  # label -> description (the "criteria" of a Choice question)
    source: str  # what the state is: "rules" (a market's resolution rules) or "event" (an event's title and options)
    kinds: tuple[str, ...] = ()  # variable kinds (rules tasks) the attribute applies to


# Attribute tasks mirror pmpol.propositions.resolution: the regex answer is the weak label, the labels are the
# regex's own vocabulary plus "not stated", so model, regex and gold are compared on the same scale.
TASKS: dict[str, Task] = {t.id: t for t in (
    Task("decided_by", "According to these resolution rules, what settles who won?", {
        "media call": "A media projection or call: Associated Press, networks, decision desks, a consensus of media.",
        "certification": "The official certification of the results.",
        "sworn in": "Who is sworn in or takes office.",
        "election authorities": "The official results published by the election authority, electoral commission or government.",
        "not stated": "The rules do not say what source or event settles the market.",
    }, "rules", ("winner", "control", "nominee", "joint", "seats")),
    Task("runoff", "Do these rules say a runoff or second round counts toward the result?", {
        "included": "A runoff, second round or tiebreak is included: the eventual winner counts.",
        "not stated": "The rules do not mention a runoff or second round.",
    }, "rules", ("winner", "control", "joint", "seats")),
    Task("candidate", "If the named candidate is replaced before the election, what do these rules do?", {
        "party nominee": "The market follows the party's nominee: a replacement candidate counts.",
        "named person": "The market is about this named person only; a replacement does not count.",
        "not stated": "The rules do not say what happens if the candidate is replaced.",
    }, "rules", ("winner", "control", "joint", "seats")),
    Task("office", "Which office or kind of contest is this event about?", {
        "president": "A national presidency, presidential nomination, primary or electoral college.",
        "senate": "The U.S. Senate (a state's senator or Senate control).",
        "house": "The U.S. House of Representatives (a district, House control or seats).",
        "governor": "A state or territorial governor.",
        "state_exec": "Another statewide office: attorney general, secretary of state, treasurer, lieutenant governor.",
        "state_leg": "A state legislature: state senate, state house, assembly.",
        "mayor": "A city's mayor.",
        "local": "Another local or municipal contest: council, county office, school board, local or municipal elections.",
        "parliament": "A national parliament or legislature outside the U.S., or which party wins most seats nationally.",
        "head_of_government": "A prime minister, chancellor or premier.",
        "leadership": "A party or chamber leadership post: speaker, party leader, majority leader.",
        "ballot": "A ballot measure, referendum or proposition.",
        "none": "Not an election for an office (a policy, a court case, an appointment, an economic release).",
    }, "event"),
)}

# taxonomy offices folded into the task's coarser labels
OFFICE_FOLD = {"lt_governor": "state_exec", "attorney_general": "state_exec", "state_court": "state_exec",
               None: "none", "": "none"}


@dataclass
class Example:
    id: str  # market key (rules tasks) or event key (event tasks)
    task: str
    state: str  # the text the decision is made on
    weak: str  # the pipeline's current answer (regex / taxonomy)
    group: str  # race or event: examples of one group never straddle a split
    venue: str
    meta: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Prediction:
    id: str
    label: str
    probs: dict[str, float]
    confidence: float | None = None
    system: str = ""  # "regex", "majority", "tfidf_lr", or "<model>@<commit>"
    seconds: float | None = None

    def to_dict(self) -> dict:
        return asdict(self)
