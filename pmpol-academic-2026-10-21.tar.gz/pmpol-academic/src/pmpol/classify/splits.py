"""Leakage-free splits and the gold sample.

Markets of one race (or events of one cluster) share wording, so examples of a group never straddle train and
test. The gold sample is stratified by venue and weak label so that rare labels and small venues are represented,
and it is drawn with a fixed seed so the same ids come out every time (the annotation files cite the ids)."""

from __future__ import annotations

import hashlib
import random
from collections import defaultdict

from pmpol.classify import Example


def grouped_split(rows: list[Example], test_frac: float = 0.3, seed: int = 7) -> tuple[list[Example], list[Example]]:
    groups = sorted({r.group for r in rows})
    rng = random.Random(seed)
    rng.shuffle(groups)
    n_test = max(1, round(len(groups) * test_frac))
    test = set(groups[:n_test])
    return [r for r in rows if r.group not in test], [r for r in rows if r.group in test]


def holdout_venues(rows: list[Example], venues: tuple[str, ...]) -> tuple[list[Example], list[Example]]:
    """Train on the other venues, test on `venues`: does the decision transfer to wording never seen?"""
    return [r for r in rows if r.venue not in venues], [r for r in rows if r.venue in venues]


def stable_order(rows: list[Example], seed: int) -> list[Example]:
    return sorted(rows, key=lambda r: hashlib.sha1(f"{seed}|{r.id}".encode()).hexdigest())


def gold_sample(rows: list[Example], n: int, seed: int = 7, min_per_stratum: int = 5) -> list[Example]:
    """About n examples, stratified by (venue, weak label), at least min_per_stratum from each stratum that has
    them, the rest proportional; one example per group where possible (more wording variety per label)."""
    strata: dict[tuple[str, str], list[Example]] = defaultdict(list)
    for r in stable_order(rows, seed):
        strata[(r.venue, r.weak)].append(r)
    out: list[Example] = []
    seen_groups: set[str] = set()
    quota = {k: min(len(v), max(min_per_stratum, round(n * len(v) / max(len(rows), 1)))) for k, v in strata.items()}
    for k, v in sorted(strata.items()):
        picked = [r for r in v if r.group not in seen_groups][:quota[k]]
        if len(picked) < quota[k]:
            picked += [r for r in v if r not in picked][:quota[k] - len(picked)]
        out += picked
        seen_groups |= {r.group for r in picked}
    return stable_order(out, seed + 1)
