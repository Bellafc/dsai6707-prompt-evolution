"""Data contracts: expectations every feed must meet before its data is trusted downstream.

The idea follows Great Expectations / Pandera / Soda: declare what a feed should look like, check it
on every run, and keep the results next to the data. We keep it to plain functions because the feeds
are small and the checks are few. A failed check never deletes data (precision first, but silently
dropping rows hides problems); it is recorded in the run manifest and shown in the health report.

severity "error": the data is wrong (prices outside [0, 1], duplicate ids) and should be fixed upstream.
severity "warn":  the data looks unusual (crossed books, a feed that halved since the last run).
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import date, datetime, timezone
from statistics import median

from pmpol.models import Event


@dataclass
class Check:
    source: str
    name: str
    ok: bool
    severity: str  # "error" or "warn"
    observed: str
    expected: str
    detail: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _parse_time(s: str | None) -> datetime | None:
    if not s or not s[:4].isdigit():
        return None
    try:
        d = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def venue_checks(venue: str, events: list[Event], previous_n: int | None = None) -> list[Check]:
    """Expectations for one venue's crawl. `previous_n`: events in the last successful crawl."""
    markets = [m for e in events for m in e.markets]
    out = [Check(venue, "non_empty", bool(events), "error", f"{len(events)} events", "> 0")]
    if not markets:
        return out
    dup = [k for k, n in Counter(m.key for m in markets).items() if n > 1]
    out.append(Check(venue, "unique_market_ids", not dup, "error", f"{len(dup)} duplicated", "0",
                     ", ".join(dup[:3])))
    bad = [m.key for m in markets for x in (m.bid, m.ask, m.last)
           if x is not None and not (0 <= x <= 1 and math.isfinite(x))]
    out.append(Check(venue, "prices_in_unit_interval", not bad, "error", f"{len(bad)} prices", "0 outside [0, 1]",
                     ", ".join(sorted(set(bad))[:3])))
    two_sided = [m for m in markets if m.bid is not None and m.ask is not None and m.ask > 0]
    crossed = [m for m in two_sided if m.bid > m.ask + 1e-9]
    share = len(crossed) / len(two_sided) if two_sided else 0.0
    out.append(Check(venue, "uncrossed_books", share <= 0.01, "warn", f"{share:.1%} of {len(two_sided)} books",
                     "≤ 1% with bid > ask", ", ".join(m.key for m in crossed[:3])))
    quoted = sum(1 for m in markets if m.mid is not None) / len(markets)
    out.append(Check(venue, "quoted_share", quoted >= 0.2, "warn", f"{quoted:.0%} of {len(markets)} markets",
                     "≥ 20% have a price"))
    closes = sum(1 for m in markets if _parse_time(m.close_time)) / len(markets)
    out.append(Check(venue, "close_time_parseable", closes >= 0.9, "warn", f"{closes:.0%}", "≥ 90%"))
    if previous_n:
        ratio = len(events) / previous_n
        out.append(Check(venue, "count_vs_previous_run", 0.5 <= ratio <= 2.0, "warn",
                         f"{len(events)} events vs {previous_n} last time ({ratio:.2f}×)", "between 0.5× and 2×"))
    return out


# Longest normal publication lag, by observation frequency: days after the END of the period (annual
# 2025 data is first published in 2026). Periods are stored by their first day.
PERIOD_DAYS = {"daily": 1, "monthly": 31, "quarterly": 92, "annual": 366}
MAX_LAG_DAYS = {"daily": 10, "monthly": 100, "quarterly": 150, "annual": 400}


def _frequency(periods: list[date]) -> str:
    if len(periods) < 3:
        return "monthly"
    recent = periods[-13:]
    gaps = [(b - a).days for a, b in zip(recent, recent[1:])]
    g = median(gaps)
    return "daily" if g < 7 else "monthly" if g < 45 else "quarterly" if g < 120 else "annual"


def macro_checks(fetched, today: date) -> list[Check]:
    """Per-series expectations: values are finite, and the latest observed period is not older than its
    frequency allows (IMF projections, layer L3, are skipped: their future periods are expected)."""
    out = []
    for f in fetched:
        obs = [o for o in f.observations if o.layer == "L1"]
        if not obs:
            continue
        sid = f"macro:{f.spec.id}"
        bad = [o for o in obs if not math.isfinite(o.value)]
        out.append(Check(sid, "finite_values", not bad, "error", f"{len(bad)} non-finite", "0"))
        periods = sorted({o.period for o in obs})
        freq = _frequency(periods)
        lag = (today - periods[-1]).days - PERIOD_DAYS[freq]
        out.append(Check(sid, "fresh", lag <= MAX_LAG_DAYS[freq], "warn",
                         f"latest period starts {periods[-1]:%Y-%m-%d} ({freq}; {lag} days after it ended)",
                         f"≤ {MAX_LAG_DAYS[freq]} days after the period ends"))
    return out


def _proofs_in(x, out: list) -> list:
    if isinstance(x, dict):
        if "steps" in x and "conclusion" in x:
            out.append(x)
        for v in x.values():
            _proofs_in(v, out)
    elif isinstance(x, list):
        for v in x:
            _proofs_in(v, out)
    return out


def proof_checks(source: str, path) -> list[Check]:
    """Team rule on every written proof file: each conclusion traces back to L0-L4, and each market quote (L4)
    names its source and the time it refers to."""
    import json
    from pathlib import Path

    from pmpol.proof import GROUNDING_LAYERS

    proofs = _proofs_in(json.loads(Path(path).read_text(encoding="utf-8")), [])
    ungrounded = [p for p in proofs if p.get("grounded") is False
                  or not any(st.get("layer") in GROUNDING_LAYERS for st in p["steps"])]
    l4 = [st for p in proofs for st in p["steps"] if st.get("layer") == "L4"]
    bare = [st for st in l4 if not st.get("ref") or not st.get("as_of")]
    return [Check(source, "proofs_grounded", not ungrounded, "error", f"{len(ungrounded)} of {len(proofs)}", "0",
                  "; ".join(p["title"][:60] for p in ungrounded[:3])),
            Check(source, "quotes_have_source_and_time", not bare, "error", f"{len(bare)} of {len(l4)}", "0",
                  "; ".join(st["text"][:60] for st in bare[:3]))]


def rule_checks(relations, kb) -> list[Check]:
    """Every ontology relation comes from a declared inference rule, and every rule's grounds exist
    (config/inference_rules.toml: axioms, knowledge-base facts, registered assumptions)."""
    from pmpol.propositions.rules import check_ground, load, validate
    from pmpol.assumptions import load as load_assumptions

    book = load()
    problems = validate(book, kb)
    bases = {r.template.rsplit(":", 1)[-1] for r in relations if r.template.startswith("onto:")}
    unknown = sorted(b for b in bases if b not in book.rules)
    extra = sorted({p for r in relations for g in r.grounds for p in check_ground(g, book, kb, load_assumptions(),
                                                                                    r.template)})
    return [Check("rules", "rules_grounded", not problems, "error", f"{len(problems)} problems", "0",
                  "; ".join(problems[:3])),
            Check("rules", "relations_from_declared_rules", not unknown and not extra, "error",
                  f"{len(unknown)} undeclared, {len(extra)} bad grounds", "0", "; ".join((unknown + extra)[:3]))]
