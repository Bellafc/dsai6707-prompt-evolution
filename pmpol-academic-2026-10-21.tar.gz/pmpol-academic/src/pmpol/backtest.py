"""Backtests on a frozen corpus (layer 6; 2026-10-06).

A backtest is only worth anything if it can be re-run on the same data and cannot see the future:

  frozen corpus   the resolved-market files (data/ground_truth/*.jsonl) are listed in a manifest with their SHA-256,
                  row counts and close-time range (reports/backtest/corpus_<date>.json, versioned; the data itself is
                  not). A run against a manifest refuses files whose hash differs.
  time split      parameters are fitted on markets that closed before SPLIT and scored on markets that closed after
                  it; SPLIT is fixed in code, chosen from the corpus's date coverage before any score was computed.
  clustering      markets of one event resolve together, so uncertainty comes from a bootstrap over events.

First test: the calibration layer the consensus and the House model apply (pmpol.universe.consensus): logit p' =
k * b * logit p with b fitted per venue and horizon on resolved markets and k = n / (n + N0) shrinking b toward 1
(N0 = 200, assumption `calibration_shrinkage`). Out of sample, against the raw price: does the slope help, does the
intercept (which the consensus leaves out) help, and which N0 scores best (the assumption's own check). The sample
mirrors the L2 facts: markets that did not close early, per venue and days before close.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

import numpy as np

from pmpol.ground_truth import Resolved, load
from pmpol.ground_truth.calibration import _logit, recalibration

CORPUS = [Path("data/ground_truth/kalshi.jsonl"), Path("data/ground_truth/polymarket.jsonl")]
SPLIT = "2025-07-01"  # train: closed before; test: closed on or after (fixed from date coverage, before scoring)
HORIZONS = (1, 7, 30)
SHRINK = (0, 25, 50, 100, 200, 400, 800, 1600)  # N0 candidates; 0 means the full fitted slope
B = 1000  # bootstrap replicates (over events)
EPS = 0.005


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def freeze(paths: list[Path] = CORPUS, today: date | None = None) -> dict:
    """Manifest of the corpus: file, SHA-256, rows, close-time range."""
    files = []
    for p in paths:
        rows = load(p)
        files.append({"path": str(p), "sha256": _sha(p), "rows": len(rows),
                      "first_close": min((r.close_time for r in rows), default="")[:10],
                      "last_close": max((r.close_time for r in rows), default="")[:10]})
    return {"frozen_at": (today or date.today()).isoformat(), "split": SPLIT, "files": files}


def verify(manifest: dict) -> list[str]:
    """Problems: files missing or changed since the manifest was written."""
    out = []
    for f in manifest["files"]:
        p = Path(f["path"])
        if not p.exists():
            out.append(f"{p}: missing")
        elif _sha(p) != f["sha256"]:
            out.append(f"{p}: changed since {manifest['frozen_at']} (sha256 differs)")
    return out


def corpus_rows(manifest: dict) -> list[Resolved]:
    return [r for f in manifest["files"] for r in load(Path(f["path"]))]


def _logloss(p: np.ndarray, y: np.ndarray) -> np.ndarray:
    p = np.clip(p, EPS, 1 - EPS)
    return -(y * np.log(p) + (1 - y) * np.log(1 - p))


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1 / (1 + np.exp(-x))


@dataclass
class CalibrationTest:
    venue: str
    horizon: int
    n_train: int
    n_test: int
    events_test: int
    b: float  # fitted slope on train
    a: float  # fitted intercept on train
    loss: dict[str, float] = field(default_factory=dict)  # method -> mean test log loss
    gain: dict[str, tuple[float, float, float]] = field(default_factory=dict)  # method -> (mean, lo, hi) vs raw
    best_n0: int | None = None

    def k(self, n0: int) -> float:
        return 1.0 if n0 == 0 else self.n_train / (self.n_train + n0)


def _sample(rows: list[Resolved], venue: str, h: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    ps, ys, closes, events = [], [], [], []
    for r in rows:
        p = r.prices.get(str(h))
        if r.venue != venue or p is None or r.early:
            continue
        ps.append(p)
        ys.append(r.result)
        closes.append(r.close_time[:10])
        events.append(r.event_id)
    return np.array(ps, float), np.array(ys, float), np.array(closes, dtype=str), events


def calibration_test(rows: list[Resolved], venue: str, h: int, split: str = SPLIT, seed: int = 0) -> CalibrationTest | None:
    p, y, close, events = _sample(rows, venue, h)
    tr, te = close < split, close >= split
    if tr.sum() < 50 or te.sum() < 50:
        return None
    fit = recalibration(p[tr], y[tr])
    if fit is None:
        return None
    a, b = fit[0], fit[1]
    t = CalibrationTest(venue, h, int(tr.sum()), int(te.sum()), len({e for e, m in zip(events, te) if m}), b, a)
    x, yt = _logit(p[te]), y[te]
    per = {"raw": _logloss(p[te], yt), "slope+intercept": _logloss(_sigmoid(a + b * x), yt)}
    for n0 in SHRINK:
        per[f"slope N0={n0}"] = _logloss(_sigmoid((1 + (b - 1) * t.k(n0)) * x), yt)
    t.loss = {m: float(v.mean()) for m, v in per.items()}
    # bootstrap over events: mean improvement over the raw price (positive = better than raw)
    ev = np.array([e for e, m in zip(events, te) if m])
    uniq = np.unique(ev)
    idx = {e: np.where(ev == e)[0] for e in uniq}
    rng = np.random.default_rng(seed)
    draws = {m: [] for m in per if m != "raw"}
    for _ in range(B):
        pick = np.concatenate([idx[e] for e in rng.choice(uniq, len(uniq))])
        base = per["raw"][pick].mean()
        for m in draws:
            draws[m].append(base - per[m][pick].mean())
    for m, d in draws.items():
        d = np.array(d)
        t.gain[m] = (float(per["raw"].mean() - per[m].mean()), float(np.quantile(d, 0.025)), float(np.quantile(d, 0.975)))
    t.best_n0 = min(SHRINK, key=lambda n0: t.loss[f"slope N0={n0}"])
    return t


def run(rows: list[Resolved], split: str = SPLIT) -> list[CalibrationTest]:
    return [t for v in sorted({r.venue for r in rows}) for h in HORIZONS
            if (t := calibration_test(rows, v, h, split)) is not None]


def render(manifest: dict, tests: list[CalibrationTest], problems: list[str]) -> str:
    L = [f"# 回測：校準層的樣本外檢驗（凍結語料庫 {manifest['frozen_at']}）", "",
         f"訓練：{manifest['split']} 之前結算的市場；測試：之後結算的。分數是測試集的平均 log loss（越低越好），"
         "改善是「原始價格的 log loss − 方法的 log loss」，95% 區間來自以事件為單位的自助法。樣本和 L2 校準事實相同："
         "沒有提早結算的市場，依平台和截止前天數分開。", "", "語料庫（SHA-256 前 12 碼）："]
    for f in manifest["files"]:
        L.append(f"- `{f['path']}`：{f['rows']:,} 筆，{f['first_close']}–{f['last_close']}，`{f['sha256'][:12]}`")
    if problems:
        return "\n".join(L + ["", "**語料庫和清單不符，沒有執行**：" + "；".join(problems), ""])
    L += ["", "| 平台 | 截止前 | 訓練／測試（事件） | 斜率 b | 原始 | 斜率（N0=200，現行） | 斜率＋截距 | 最佳 N0 |",
          "|---|---|---|---|---|---|---|---|"]
    for t in tests:
        g, gi = t.gain["slope N0=200"], t.gain["slope+intercept"]
        L.append(f"| {t.venue} | {t.horizon} 天 | {t.n_train:,}／{t.n_test:,}（{t.events_test:,}） | {t.b:.2f} | "
                 f"{t.loss['raw']:.4f} | {t.loss['slope N0=200']:.4f}（{g[0]:+.4f}，{g[1]:+.4f}–{g[2]:+.4f}） | "
                 f"{t.loss['slope+intercept']:.4f}（{gi[0]:+.4f}，{gi[1]:+.4f}–{gi[2]:+.4f}） | {t.best_n0} |")
    L += ["", "N0 是校準斜率往 1 收縮的強度（k = n／(n + N0)）。訓練樣本有幾千筆時，N0 在 0–1600 之間 k 都接近 1，"
          "所以「最佳 N0」主要看斜率本身在測試期是否偏大或偏小。", ""]
    return "\n".join(L)


def write_manifest(manifest: dict, folder: Path = Path("reports/backtest")) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    out = folder / f"corpus_{manifest['frozen_at']}.json"
    out.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    return out


def summary(tests: list[CalibrationTest]) -> dict:
    """For the research log and the assumptions: does the slope help out of sample, and the intercept?"""
    def share(m):
        return sum(t.gain[m][1] > 0 for t in tests), sum(t.gain[m][2] < 0 for t in tests)
    return {"tests": len(tests), "slope_better": share("slope N0=200"), "intercept_better": share("slope+intercept"),
            "best_n0": [t.best_n0 for t in tests],
            "mean_gain_slope": float(np.mean([t.gain["slope N0=200"][0] for t in tests])) if tests else math.nan}
