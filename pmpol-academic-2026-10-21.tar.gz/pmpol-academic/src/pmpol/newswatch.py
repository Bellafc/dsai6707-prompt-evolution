"""News watch for the requirements list (2026-10-06).

The reverse engine searches the news only when a price moves, so a question whose markets sit still (Hormuz
traffic, the Taiwan Strait) never gets a news line. Here each requirement with a `news` query
(config/requirements.toml) is searched over the last WINDOW_HOURS on every cycle: GDELT first, Google News RSS when
GDELT refuses (a 429 is not retried), the same search the reverse engine uses. Each article is stored as evidence
with its publication and receipt times (pmpol.evidence: L1, an observation of what was published; graded F6 and
stance "unclear" until a person judges it), and each question gets a proof listing the latest headlines.

Headlines are claims made by their publishers, never facts about the world, and a count of articles says nothing
about which way they point.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from pmpol.proof import Proof

WINDOW_HOURS = 72
SHOWN = 8


def watch(reqs, now: datetime | None = None, hours: int = WINDOW_HOURS, fetch=None, rss_fetch=None,
          cache: Path | None = None) -> list[tuple]:
    """[(requirement, NewsResult)] for the requirements with a news query."""
    from pmpol.movers.news import CACHE, local_search, search

    now = now or datetime.now(timezone.utc)
    start = (now - timedelta(hours=hours)).isoformat(timespec="seconds")
    out = []
    end = now.isoformat(timespec="seconds")
    for r in reqs:
        if r.news:
            out.append((r, search(r.news, start, end, fetch=fetch, pad_hours=0, rss_fetch=rss_fetch,
                                  cache=cache or CACHE)))
        for loc in r.news_local:
            out.append((r, local_search(loc["query"], loc["lang"], loc["country"], start, end, cache=cache or CACHE,
                                        rss_fetch=rss_fetch, edition=loc.get("edition", ""))))
    return out


def _lang(res) -> str:
    return (res.articles[0].get("language") if res.articles else "") or ("en" if res.source == "gdelt" else "")


RELEVANT = 0.5  # share of the query's terms a headline must contain to count as on topic


def proof(req, res) -> Proof:
    from pmpol.movers.news import relevance

    scored = [(relevance(a.get("title", ""), res.query), a) for a in res.articles]
    on_topic = [x for x in scored if x[0] >= RELEVANT]
    head = ("新聞查詢失敗：" + (res.error or "沒有回應")) if res.count is None else \
        (f"過去 {WINDOW_HOURS} 小時「{res.query}」{res.count} 篇（{res.source}，{_lang(res) or '—'}），"
         f"標題含一半以上查詢詞的 {len(on_topic)} 篇")
    p = Proof(f"新聞輪詢｜{req.question}（{res.query}）", head,
              result={"requirement": req.id, "query": res.query, "count": res.count, "on_topic": len(on_topic),
                      "source": res.source, "language": _lang(res), "window": [res.start, res.end]})
    arts = sorted(on_topic or scored, key=lambda x: x[1].get("seendate", ""), reverse=True)[:SHOWN]
    for i, (score, a) in enumerate(arts):
        p.add("L1", f"{a.get('domain', '')}：{a.get('title', '')}（相關性 {score:.0%}）", a.get("url", ""),
              a.get("seendate", ""), kind="data", id=f"a{i}")
    p.caveats += ["標題是發布者的說法，不是事實；篇數多不代表事情是真的，也不代表往哪個方向。",
                  "還沒有評等（Admiralty F6）和方向判斷，需要人工看過。"]
    if res.error:
        p.caveats.append(f"查詢說明：{res.error}")
    return p


def export(rows: list[tuple], path: Path = Path("data/news.json")) -> int:
    out = []
    for req, res in rows:
        p = proof(req, res)
        lang = _lang(res)
        out.append({"id": f"news:{req.id}:{lang or 'x'}:{res.query}", "group": "evidence", "kind": "news_watch",
                    "subject": f"news:{req.id}",
                    "edge": float(res.count or 0), "venues": [], "confidence": "rule", "title": p.title,
                    "proof": {**p.to_dict(), "graph": p.graph()}})
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"signals": out}, ensure_ascii=False, default=str), encoding="utf-8")
    return len(out)
