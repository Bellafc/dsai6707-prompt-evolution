"""Macro layer: official statistics as L1 observations, and regime classifications as L5 inferences.

  config/macro_series.toml   which series, from which source, under which licence
  sources.py                 keyless fetchers and parsers (FRED/ALFRED, OECD, BIS, BCB, ONS, IMF)
  regimes.py                 Sahm rule, yield-curve recession probability, Investment Clock,
                             OECD CLI phase, credit conditions; each returns a Proof
  markets.py                 candidate prediction markets for each macro concept (keyword match)
  report.py                  markdown report

Frameworks such as the Merrill Lynch Investment Clock and Kondratiev long waves are contested;
their definitions and competing datings live in kb/L3 and are cited, never treated as facts.
"""
