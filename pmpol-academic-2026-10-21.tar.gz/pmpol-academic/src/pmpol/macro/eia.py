"""EIA weekly petroleum series (U.S. Energy Information Administration, public domain).

Read from EIA's public history pages (no key needed; FRED does not carry these codes):
  WCESTUS1  U.S. ending stocks of crude oil excluding the SPR (thousand barrels)  - Kalshi crude inventories
  WCSSTUS1  U.S. ending stocks of crude oil in the SPR (thousand barrels)          - Polymarket SPR markets
Values are the current vintage; Kalshi settles on the first publication, so a later revision can differ
(stated on every check that uses it).
"""

from __future__ import annotations

from pmpol import USER_AGENT

import json
import re
from datetime import date, datetime, timezone
from pathlib import Path

URL = "https://www.eia.gov/dnav/pet/hist/LeafHandler.ashx?n=PET&s={code}&f=W"
CACHE = Path("data/macro/eia")
SERIES = {"WCESTUS1": "U.S. commercial crude oil stocks excl. SPR (thousand barrels)",
          "WCSSTUS1": "U.S. crude oil stocks in the SPR (thousand barrels)"}
LICENCE = "EIA: U.S. government data, public domain"


def parse(html: str) -> dict[date, float]:
    """Week-ending date -> value, from the history table (rows of "YYYY-Mon" then MM/DD, value pairs)."""
    out: dict[date, float] = {}
    for row in re.findall(r"<tr>\s*<td class='B6'>(.*?)</tr>", html, re.S):
        ym = re.search(r"(\d{4})-[A-Za-z]{3}", row)
        if not ym:
            continue
        year = int(ym.group(1))
        cells = re.findall(r"<td class='B5'>([^<]*)</td>\s*<td class='B3'>([^<]*)</td>", row)
        for day, val in cells:
            day, val = day.replace("&nbsp;", "").strip(), val.replace("&nbsp;", "").replace(",", "").strip()
            if not day or not val:
                continue
            mm, dd = (int(x) for x in day.split("/"))
            out[date(year, mm, dd)] = float(val)  # each row is one month of one year
    return out


def _default_fetch(url: str) -> str:
    import httpx

    r = httpx.get(url, timeout=60, headers={"User-Agent": USER_AGENT}, follow_redirects=True)
    r.raise_for_status()
    return r.text


def fetch(code: str, fetch_text=None, cache: Path = CACHE, today: date | None = None) -> dict[date, float]:
    fetch_text = fetch_text or _default_fetch
    today = today or datetime.now(timezone.utc).date()
    cache.mkdir(parents=True, exist_ok=True)
    path = cache / f"{today:%Y%m%d}_{code}.json"
    if path.exists():
        return {date.fromisoformat(k): v for k, v in json.loads(path.read_text()).items()}
    data = parse(fetch_text(URL.format(code=code)))
    if not data:
        raise ValueError(f"EIA {code}: no rows parsed")
    path.write_text(json.dumps({k.isoformat(): v for k, v in data.items()}))
    return data
