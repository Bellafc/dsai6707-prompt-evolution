"""Candidate prediction markets for each macro concept, by keyword. These are pointers for a human,
not structural relations: a market on "CPI above 3.0% in September" is listed next to the CPI data,
but no consistency check is run until its settlement rule is parsed."""

from __future__ import annotations

import re

from pmpol.models import Event

# country -> words that must appear (US is the default when no other country is named)
_COUNTRY = {
    "us": None,
    "uk": r"\b(uk|u\.k\.|britain|british|bank of england|boe)\b",
    "br": r"\b(brazil|brazilian|selic|bcb|copom)\b",
    "cn": r"\b(china|chinese|pboc)\b",
    "il": r"\b(israel|bank of israel)\b",
    "ru": r"\b(russia|bank of russia)\b",
    "ir": r"\b(iran|iranian|rial)\b",
    "tw": r"\b(taiwan)\b",
}
_OTHER_COUNTRY = re.compile("|".join(p for p in _COUNTRY.values() if p) + r"|\b(canada|japan|euro|ecb|mexico|india|"
                            r"germany|france|australia|korea|turkey|argentina|eurozone|europe|european|ukraine)\b", re.I)

CONCEPTS = {
    "inflation": r"\b(cpi|inflation|pce|ipca)\b",
    "unemployment": r"\b(unemployment|jobless|u-?3|payrolls?|jobs report)\b",
    "policy_rate": r"\b(fed decision|fomc|federal funds|rate (?:cut|hike)s?|rate decision|bank of \w+ decision|selic|"
                   r"key rate|bps)\b",
    "gdp": r"\b(gdp|economic growth)\b",
    "recession": r"\b(recession|nber)\b",
    "credit": r"\b(defaults? on (?:its |their )?debt|sovereign default|credit spreads?|delinquenc)",
}
# Markets about people or institutions rather than the statistic itself (e.g. who chairs the Fed).
_NOT_THE_STATISTIC = re.compile(r"\b(chair|governor|nominat|fire|departure|confirm|student loan)", re.I)
CONCEPT_ZH = {"inflation": "通膨", "unemployment": "就業／失業", "policy_rate": "利率決策", "gdp": "GDP",
              "recession": "衰退", "credit": "信用違約"}


def match(events: list[Event], country: str, concept: str) -> list[Event]:
    rx = re.compile(CONCEPTS[concept], re.I)
    out = []
    for e in events:
        text = e.title + " " + next((m.question for m in e.markets), "")
        if not rx.search(text) or _NOT_THE_STATISTIC.search(e.title):
            continue
        cx = _COUNTRY[country]
        if cx is None:
            if _OTHER_COUNTRY.search(text):
                continue  # names another country: not a US market
        elif not re.search(cx, text, re.I):
            continue
        out.append(e)
    return out
