"""Keyless macro data sources. Parsers are pure functions (tested offline); fetches are cached per day
under data/macro/raw/ so a rerun the same day is offline."""

from __future__ import annotations

from pmpol import USER_AGENT

import csv
import hashlib
import io
import json
import re
import tomllib
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[3] / "config" / "macro_series.toml"
# Hosts that omit the intermediate certificate their own certificate was issued by: the intermediate (public, from the
# certificate's AIA field) is added to the default trust store for that host only; the chain must still end at a root
# the system trusts, so verification stays on.
INTERMEDIATES = {"ws.dgbas.gov.tw": Path(__file__).resolve().parents[3] / "config" / "certs" / "twca_secure_ssl_2023g3.pem"}
DGBAS = "https://ws.dgbas.gov.tw/001/Upload/461/relfile/11525/"
CBC = "https://www.cbc.gov.tw/"
CACHE = Path("data/macro/raw")

_MONTHS = {m: i for i, m in enumerate(("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV",
                                        "DEC"), start=1)}


@dataclass(frozen=True)
class SeriesSpec:
    id: str  # <country>.<concept>
    source: str
    key: str
    unit: str = ""
    licence: str = ""
    transform: str = ""  # "yoy" turns an index level into % change on a year earlier
    monthly: str = ""  # "mean" or "last": collapse daily/weekly data to months

    @property
    def country(self) -> str:
        return self.id.split(".", 1)[0]

    @property
    def concept(self) -> str:
        return self.id.split(".", 1)[1]

    @property
    def ref(self) -> str:
        return f"{self.source}:{self.key}"


@dataclass(frozen=True)
class Observation:
    series: str  # SeriesSpec.id
    source: str  # SeriesSpec.ref
    period: date  # first day of the period the value describes (valid time)
    value: float
    layer: str = "L1"  # "L3" for projections (IMF WEO current/future years)


@dataclass
class Fetched:
    spec: SeriesSpec
    url: str
    recorded_at: str  # when we fetched it (transaction time)
    observations: list[Observation] = field(default_factory=list)
    dropped_future: int = 0  # rows dated after the fetch day (e.g. BCB carries the Selic target forward)
    error: str = ""
    stale_since: str = ""  # set when the fetch failed and these are the last stored observations (their recorded_at)


def load_specs(path: Path = CONFIG) -> list[SeriesSpec]:
    with open(path, "rb") as f:
        raw = tomllib.load(f)
    return [SeriesSpec(**s) for s in raw["series"]]


# --- periods ------------------------------------------------------------------------------

def period(text: str) -> date:
    """Normalise "2026-08-01", "2026-08", "2026M08", "2026-Q2", "2026 Q2", "2026Q2", "2026 AUG", "2026", "01/08/2026"
    to a date."""
    t = text.strip()
    if m := re.fullmatch(r"(\d{2})/(\d{2})/(\d{4})", t):
        return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    if m := re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", t):
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    if m := re.fullmatch(r"(\d{4})-(\d{2})", t):
        return date(int(m.group(1)), int(m.group(2)), 1)
    if m := re.fullmatch(r"(\d{4})M(\d{2})", t):  # DGBAS "2026M09"
        return date(int(m.group(1)), int(m.group(2)), 1)
    if m := re.fullmatch(r"(\d{4})[- ]?Q([1-4])", t):
        return date(int(m.group(1)), 3 * int(m.group(2)) - 2, 1)
    if m := re.fullmatch(r"(\d{4}) ([A-Z]{3})", t.upper()):
        return date(int(m.group(1)), _MONTHS[m.group(2)], 1)
    if re.fullmatch(r"\d{4}", t):
        return date(int(t), 1, 1)
    raise ValueError(f"unrecognised period {text!r}")


# --- parsers: text -> [(period, value)] ------------------------------------------------------

def parse_fred_csv(text: str) -> list[tuple[date, float]]:
    rows = list(csv.reader(io.StringIO(text)))
    out = []
    for r in rows[1:]:
        if len(r) >= 2 and r[1] not in ("", "."):
            out.append((period(r[0]), float(r[1])))
    return out


def parse_sdmx_csv(text: str) -> list[tuple[date, float]]:
    out = []
    for r in csv.DictReader(io.StringIO(text)):
        if r.get("OBS_VALUE") not in (None, "", "NaN"):
            out.append((period(r["TIME_PERIOD"]), float(r["OBS_VALUE"])))
    return sorted(out)


def parse_bcb(text: str) -> list[tuple[date, float]]:
    return [(period(r["data"]), float(r["valor"])) for r in json.loads(text) if r.get("valor") not in (None, "")]


def parse_ons(text: str) -> list[tuple[date, float]]:
    d = json.loads(text)
    for key in ("months", "quarters", "years"):  # the finest frequency the series has
        rows = [r for r in d.get(key) or [] if r.get("value") not in (None, "")]
        if rows:
            return [(period(r["date"]), float(r["value"])) for r in rows]
    return []


def parse_imf_sdmx(text: str) -> list[tuple[date, float]]:
    """IMF SDMX 3.0 JSON (api.imf.org), one series: observations keyed by index into TIME_PERIOD values."""
    d = json.loads(text)["data"]
    series = d["dataSets"][0].get("series") or {}
    if not series:
        return []
    obs = next(iter(series.values()))["observations"]
    dims = {o["id"]: o["values"] for o in d["structures"][0]["dimensions"]["observation"]}
    times = [v.get("value") or v.get("id") for v in dims["TIME_PERIOD"]]
    return sorted((period(times[int(i)]), float(v[0])) for i, v in obs.items() if v and v[0] not in (None, ""))


def parse_imf(text: str, indicator: str, area: str) -> list[tuple[date, float]]:
    values = (json.loads(text).get("values") or {}).get(indicator, {}).get(area, {})
    return sorted((period(y), float(v)) for y, v in values.items() if v is not None)


def parse_dgbas(text: str, item: str, kind: str) -> list[tuple[date, float]]:
    """DGBAS open-data XML (<DataSet><Obs><Item/><TIME_PERIOD/><FREQ/><TYPE/><Item_VALUE/></Obs>): the rows whose item
    starts with `item` (the base year in the item name changes with rebasing) and whose TYPE is `kind`."""
    import xml.etree.ElementTree as ET

    out = []
    for o in ET.fromstring(text.lstrip("\ufeff").encode("utf-8")).iter("Obs"):
        it, tp, v = o.findtext("Item") or "", o.findtext("TYPE") or "", (o.findtext("Item_VALUE") or "").strip()
        if it.startswith(item) and tp == kind and v not in ("", "-", "…"):
            out.append((period(o.findtext("TIME_PERIOD") or ""), float(v.replace(",", ""))))
    return sorted(out)


def parse_dgbas_wide(text: str, field: str) -> list[tuple[date, float]]:
    """DGBAS open-data XML with one element per period (<DataCollection><失業率><年月別_Year_and_month/>...): the
    `field` value of monthly records ("2026M08"); annual records ("2026") are left out."""
    import xml.etree.ElementTree as ET

    out = []
    for rec in ET.fromstring(text.lstrip("\ufeff").encode("utf-8")):
        per = next((c.text or "" for c in rec if c.tag.startswith("年月別")), "").strip()
        v = (rec.findtext(field) or "").strip()
        if re.fullmatch(r"\d{4}M\d{2}", per) and v not in ("", "-"):
            out.append((period(per), float(v)))
    return sorted(out)


def parse_cbc_rate(text: str, column: str, today: date) -> list[tuple[date, float]]:
    """The central bank's rate-change table (date of change, rates) as a monthly series: the rate in effect at the end of
    each month, from the first recorded change to the current month."""
    rows = list(csv.DictReader(io.StringIO(text.lstrip("\ufeff"))))
    changes = sorted((datetime.strptime(r["調整日期"].strip(), "%Y/%m/%d").date(), float(r[column]))
                     for r in rows if (r.get(column) or "").strip())
    if not changes:
        return []
    out, m = [], changes[0][0].replace(day=1)
    while m <= today.replace(day=1):
        end = (m.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
        rate = [v for d, v in changes if d <= end]
        if rate:
            out.append((m, rate[-1]))
        m = end + timedelta(days=1)
    return out


# --- transforms -----------------------------------------------------------------------------

def to_monthly(rows: list[tuple[date, float]], how: str) -> list[tuple[date, float]]:
    by_month: dict[date, list[float]] = defaultdict(list)
    for d, v in sorted(rows):
        by_month[d.replace(day=1)].append(v)
    return [(m, (sum(vs) / len(vs)) if how == "mean" else vs[-1]) for m, vs in sorted(by_month.items())]


def yoy(rows: list[tuple[date, float]]) -> list[tuple[date, float]]:
    level = dict(rows)
    out = []
    for d, v in sorted(rows):
        prev = level.get(d.replace(year=d.year - 1))
        if prev:
            out.append((d, round(100 * (v / prev - 1), 3)))
    return out


# --- fetching -------------------------------------------------------------------------------

def url_for(spec: SeriesSpec, today: date) -> str:
    if spec.source == "fred":
        return f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={spec.key}"
    if spec.source == "oecd":
        return f"https://sdmx.oecd.org/public/rest/data/{spec.key}?startPeriod={today.year - 12}-01&format=csv"
    if spec.source == "bis":
        return f"https://stats.bis.org/api/v2/data/dataflow/BIS/{spec.key}?startPeriod={today.year - 12}-01&format=csv"
    if spec.source == "bcb":
        # Daily series need both ends and reject long windows (9 years failed on 2026-10-02; 5 works).
        start = (today - timedelta(days=365 * 5)).strftime("%d/%m/%Y")
        end = (today + timedelta(days=90)).strftime("%d/%m/%Y")
        return (f"https://api.bcb.gov.br/dados/serie/bcdata.sgs.{spec.key}/dados?formato=json"
                f"&dataInicial={start}&dataFinal={end}")
    if spec.source == "ons":
        return f"https://www.ons.gov.uk{spec.key}/data"
    if spec.source == "imf":
        return f"https://www.imf.org/external/datamapper/api/v1/{spec.key.split('/')[0]}"
    if spec.source in ("dgbas", "dgbas_wide"):  # "<path under relfile/11525/>|..."
        return DGBAS + spec.key.split("|")[0]
    if spec.source == "cbc_rate":  # "<path on www.cbc.gov.tw>|<column>"
        return CBC + spec.key.split("|")[0]
    if spec.source == "imf_sdmx":  # e.g. "IMF.STA/COFER/G001.AFXRA.CI_USD.SHRO_PT.Q"
        agency, flow, key = spec.key.split("/", 2)
        return (f"https://api.imf.org/external/sdmx/3.0/data/dataflow/{agency}/{flow}/+/{key}"
                f"?c%5BTIME_PERIOD%5D=ge:{today.year - 12}-Q1")
    raise ValueError(f"unknown macro source {spec.source}")


def alfred_url(key: str, vintage: date) -> str:
    """Values as they were published on `vintage` (FRED's real-time archive; fredgraph ignores vintage_date)."""
    return f"https://alfred.stlouisfed.org/graph/alfredgraph.csv?id={key}&vintage_date={vintage.isoformat()}"


def parse(spec: SeriesSpec, text: str, today: date | None = None) -> list[tuple[date, float]]:
    if spec.source == "dgbas":
        _, item, kind = spec.key.split("|")
        return parse_dgbas(text, item, kind)
    if spec.source == "dgbas_wide":
        return parse_dgbas_wide(text, spec.key.split("|")[1])
    if spec.source == "cbc_rate":
        return parse_cbc_rate(text, spec.key.split("|")[1], today or date.today())
    if spec.source == "fred":
        return parse_fred_csv(text)
    if spec.source in ("oecd", "bis"):
        return parse_sdmx_csv(text)
    if spec.source == "bcb":
        return parse_bcb(text)
    if spec.source == "ons":
        return parse_ons(text)
    if spec.source == "imf":
        indicator, area = spec.key.split("/")
        return parse_imf(text, indicator, area)
    if spec.source == "imf_sdmx":
        return parse_imf_sdmx(text)
    raise ValueError(spec.source)


def build(spec: SeriesSpec, text: str, url: str, recorded_at: datetime) -> Fetched:
    """Parse, transform and split one source response into observations."""
    today = recorded_at.date()
    out = Fetched(spec, url, recorded_at.isoformat(timespec="seconds"))
    rows = []
    for d, v in parse(spec, text, today):
        # Drop rows dated after today before aggregating (BCB carries the Selic target forward to the
        # next meeting). IMF WEO projections are the exception: kept, but as L3.
        if d > today and spec.source != "imf":
            out.dropped_future += 1
        else:
            rows.append((d, v))
    if spec.monthly:
        rows = to_monthly(rows, spec.monthly)
    if spec.transform == "yoy":
        rows = yoy(rows)
    for d, v in rows:
        layer = "L3" if spec.source == "imf" and d.year >= today.year else "L1"
        out.observations.append(Observation(spec.id, spec.ref, d, v, layer))
    return out


def _ssl_context(url: str):
    """Default verification; for a host in INTERMEDIATES, the default trust store plus that host's missing
    intermediate (the chain must still reach a trusted root)."""
    import ssl
    from urllib.parse import urlparse

    extra = INTERMEDIATES.get(urlparse(url).hostname or "")
    if extra is None:
        return True
    ctx = ssl.create_default_context()
    ctx.load_verify_locations(cafile=str(extra))
    return ctx


def _default_fetch(url: str) -> str:
    import httpx

    headers = {"User-Agent": USER_AGENT}
    if "api.imf.org" in url:
        headers["Accept"] = "application/json"
    r = httpx.get(url, timeout=120, follow_redirects=True, headers=headers, verify=_ssl_context(url))
    r.raise_for_status()
    if "cbc.gov.tw" in url:  # the CSV comes without a charset: Big5 (cp950), or UTF-8 in some files
        try:
            return r.content.decode("utf-8-sig")
        except UnicodeDecodeError:
            return r.content.decode("cp950")
    return r.text


def fetch_all(specs: list[SeriesSpec], fetch=None, cache: Path = CACHE,
              now: datetime | None = None) -> list[Fetched]:
    """Fetch every series (one request per distinct URL, cached for the day). Failures are recorded, not raised."""
    fetch = fetch or _default_fetch
    now = now or datetime.now(timezone.utc)
    cache.mkdir(parents=True, exist_ok=True)
    texts: dict[str, str | Exception] = {}
    out = []
    for spec in specs:
        url = url_for(spec, now.date())
        if url not in texts:
            path = cache / f"{now:%Y%m%d}_{hashlib.sha1(url.encode()).hexdigest()[:16]}.txt"
            try:
                if not path.exists():
                    text = fetch(url)
                    parse(spec, text)  # only cache responses that parse
                    path.write_text(text, encoding="utf-8")
                texts[url] = path.read_text(encoding="utf-8")
            except Exception as e:
                texts[url] = e
        text = texts[url]
        if isinstance(text, Exception):
            out.append(Fetched(spec, url, now.isoformat(timespec="seconds"), error=str(text)[:200]))
            continue
        try:
            out.append(build(spec, text, url, now))
        except Exception as e:
            out.append(Fetched(spec, url, now.isoformat(timespec="seconds"), error=f"parse: {e}"[:200]))
    return out
