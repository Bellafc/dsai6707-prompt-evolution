"""Macro report: coverage, latest values, source conflicts, structured descriptions with proofs,
contested frameworks side by side, and candidate prediction markets."""

from __future__ import annotations

from collections import Counter

from pmpol.kb import KnowledgeBase
from pmpol.macro import regimes
from pmpol.macro.markets import CONCEPT_ZH, CONCEPTS, match
from pmpol.macro.regimes import MacroData
from pmpol.macro.sources import Fetched
from pmpol.models import Event
from pmpol.venues import info

COUNTRY_ZH = {"us": "美國", "uk": "英國", "br": "巴西", "cn": "中國", "il": "以色列", "ru": "俄羅斯", "ir": "伊朗", "tw": "台灣"}


def run_regimes(data: MacroData, kb: KnowledgeBase) -> list:
    out = [regimes.sahm_rule(data, kb), regimes.yield_curve_recession(data, kb)]
    for c in ("us", "uk", "br", "cn"):
        out += [regimes.cli_phase(data, kb, c), regimes.investment_clock(data, kb, c)]
    out += [regimes.credit_conditions(data, kb, "us"), regimes.credit_conditions(data, kb, "br")]
    out = [p for p in out if p is not None]
    for p in out:
        data.mark_stale(p)
    return out


def _fmt(v: float) -> str:
    return f"{v:,.2f}" if abs(v) < 1000 else f"{v:,.0f}"


def _mid(m) -> str:
    return "—" if m.mid is None else f"{100 * m.mid:.0f}%"


def render(fetched: list[Fetched], kb: KnowledgeBase, generated_at: str, events: list[Event] | None = None,
           event_topics: dict[str, str] | None = None, observed_at: str = "") -> str:
    data = MacroData.from_fetched(fetched)
    L = [f"# 總體經濟層報告 — {generated_at}", "",
         "數值是 L1 事實（官方統計，附來源和期間）；「結構化判斷」是 L5 推論，每一項都附推理步驟；"
         "康波等有爭議的框架只列在 L3，不做判斷。", ""]

    ok = [f for f in fetched if f.observations]
    failed = [f for f in fetched if not f.observations]
    stale = [f for f in ok if f.error]
    by_source = Counter(f.spec.source for f in ok)
    L += ["## 1. 資料涵蓋", "",
          f"- {len(ok)} / {len(fetched)} 個序列取得成功；來源：" + "、".join(f"{s} {n}" for s, n in by_source.most_common()),
          f"- 抓取時間（記錄時間）：{data.recorded_at}"]
    if fut := sum(f.dropped_future for f in fetched):
        L.append(f"- 丟棄 {fut} 筆日期在未來的資料列（例如巴西央行把 Selic 目標利率預先填到下次開會）")
    for f in failed:
        L.append(f"- ⚠️ 失敗：`{f.spec.id}`（{f.spec.ref}）{f.error}")
    for f in stale:
        L.append(f"- ⚠️ 來源暫時失敗，改用資料庫裡最後一次的資料：`{f.spec.id}`（{f.error}）")
    L.append("")

    L += ["## 2. 最新數值（L1）", "", "| 國家 | 指標 | 數值 | 期間 | 來源 | 授權 |", "|---|---|---|---|---|---|"]
    for f in sorted(ok, key=lambda f: (list(COUNTRY_ZH).index(f.spec.country) if f.spec.country in COUNTRY_ZH else 99,
                                       f.spec.concept)):
        l1 = [o for o in f.observations if o.layer == "L1"]
        if not l1:
            continue
        o = l1[-1]
        L.append(f"| {COUNTRY_ZH.get(f.spec.country, f.spec.country)} | {f.spec.concept} | {_fmt(o.value)} {f.spec.unit} | "
                 f"{o.period:%Y-%m} | `{f.spec.ref}` | {f.spec.licence} |")
    proj = [f for f in ok if any(o.layer == "L3" for o in f.observations)]
    if proj:
        L += ["", "IMF 世界經濟展望對今年及以後的數字是**預測**，屬於 L3，不列在上表：", ""]
        for f in proj:
            nxt = [o for o in f.observations if o.layer == "L3"][:2]
            L.append(f"- {COUNTRY_ZH.get(f.spec.country, f.spec.country)} {f.spec.concept}："
                     + "、".join(f"{o.period.year} 年 {_fmt(o.value)}" for o in nxt))
    L.append("")

    conf = regimes.conflicts(data)
    L += ["## 3. 來源互相衝突（並列，不選邊）", ""]
    if conf:
        L += ["| 指標 | 期間 | 各來源數值 |", "|---|---|---|"]
        for sid, period, vals in conf:
            L.append(f"| {sid} | {period:%Y-%m} | " + "；".join(f"`{ref}` {v:.2f}" for ref, v in vals) + " |")
    else:
        L.append("- 沒有超過 0.15 個百分點的差異。")
    L.append("")

    L += ["## 4. 結構化判斷（L5，附推理步驟）", ""]
    for p in run_regimes(data, kb):
        L += p.markdown()

    from pmpol.goals import goal_proof, load_goals

    L += ["## 5. 共同目的（L3 詮釋，附推理步驟）", "",
          "行為者可能在手段上衝突、在目的上一致。下面每個目的列出各方立場（逐字引文）、反方觀點、可觀測指標和相關市場。"
          "這是分群與先驗，不是硬約束。", ""]
    for g in load_goals():
        L += goal_proof(g, kb, events, data, observed_at).markdown()

    L += ["## 6. 康波週期（L3，各家分期並列，不做判斷）", "",
          "長波的存在和分期在學界有爭議，下表只並列各家說法；本系統不據此推論。", "",
          "| 作者 | 第一波 | 第二波 | 第三波 | 第四波 | 第五波 | 可信度 |", "|---|---|---|---|---|---|---|"]
    for f in kb.query(subject="Kondratiev long waves", layer="L3"):
        if f.predicate == "dating":
            v = f.value
            L.append(f"| {v.get('author', '')} | {v.get('I', '')} | {v.get('II', '')} | {v.get('III', '')} | "
                     f"{v.get('IV', '')} | {v.get('V', '')} | {f.admiralty} |")
    L.append("")
    for f in kb.query(subject="Kondratiev long waves", layer="L3"):
        if f.predicate == "technological_revolutions":
            L.append(f"- {f.value['author']}：技術革命起點 {f.value['big_bangs']}（`{f.id}`）")
        elif f.predicate == "empirical_evidence":
            L.append(f"- 實證檢驗：{f.value}（`{f.id}`）")
    L.append("")

    if events is not None:
        L += ["## 7. 相關的預測市場（關鍵字配對，待人工確認規則）", "",
              "這些只是候選：標題提到同一個國家和指標（沒有提到國家的市場預設為美國）。還沒有解析結算規則，所以不做一致性檢查。", ""]
        pool = [e for e in events if (event_topics or {}).get(e.key, "economy_policy") not in ("elections_us",
                                                                                             "elections_intl")]
        for country in ("us", "uk", "br", "cn", "il", "ru", "ir", "tw"):
            for concept in CONCEPTS:
                hits = match(pool, country, concept)
                if not hits:
                    continue
                L.append(f"**{COUNTRY_ZH[country]}・{CONCEPT_ZH[concept]}**（{len(hits)} 個事件）")
                for e in sorted(hits, key=lambda e: (e.venue, e.title))[:8]:
                    live = sorted((m for m in e.markets if m.active and m.mid is not None), key=lambda m: -(m.mid or 0))
                    top = "；".join(f"{m.outcome or 'Yes'} {_mid(m)}" for m in live[:3])
                    L.append(f"- {info(e.venue).code}｜{e.title}" + (f"：{top}" if top else ""))
                L.append("")

    L += ["## 授權", "",
          "FRED 上大部分序列是公共領域；Moody's（Baa 利差）、芝加哥聯儲（NFCI）、Chauvet–Piger 需要註明出處；"
          "ICE 高收益債利差需要事先授權，所以不抓。OECD、IMF、BIS 允許註明出處後再利用；ONS 是 Open Government Licence。", ""]
    return "\n".join(L)
