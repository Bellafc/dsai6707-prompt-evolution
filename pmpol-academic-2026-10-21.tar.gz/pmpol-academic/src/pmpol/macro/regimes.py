"""Structured macro descriptions (L5), each returned as a Proof whose steps cite L1 data and L3 frameworks.

The frameworks are cited from kb/L3 by fact id; thresholds and coefficients are read from there, so
changing a convention is a reviewed knowledge-base edit, not a code change.
"""

from __future__ import annotations

import math
import statistics
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date

from pmpol.kb import KnowledgeBase
from pmpol.macro.sources import Fetched, SeriesSpec
from pmpol.proof import Proof, likelihood

PHASES_ZH = {"reflation": "再通膨（衰退）", "recovery": "復甦", "overheat": "過熱", "stagflation": "滯脹"}
CLI_ZH = {"expansion": "擴張", "downturn": "下滑", "slowdown": "放緩", "recovery": "復甦"}


@dataclass
class MacroData:
    """Observations by series id and source ref, in config order (the first source is the primary one)."""

    specs: dict[str, list[SeriesSpec]] = field(default_factory=dict)
    values: dict[str, dict[str, list[tuple[date, float, str]]]] = field(default_factory=dict)  # (period, value, layer)
    recorded_at: str = ""
    stale: dict[str, str] = field(default_factory=dict)  # source ref -> when the stored data used instead was recorded

    @classmethod
    def from_fetched(cls, fetched: list[Fetched]) -> "MacroData":
        d = cls(defaultdict(list), defaultdict(dict))
        for f in fetched:
            d.specs[f.spec.id].append(f.spec)
            d.values[f.spec.id][f.spec.ref] = [(o.period, o.value, o.layer) for o in f.observations]
            d.recorded_at = max(d.recorded_at, f.recorded_at)
            if f.stale_since:
                d.stale[f.spec.ref] = f.stale_since
        return d

    def mark_stale(self, proof) -> None:
        """Carry a failed fetch into every proof that used the stored fallback: a caveat and result flag."""
        used = sorted({s.ref for s in proof.steps if s.ref in self.stale})
        if not used:
            return
        proof.result["stale_inputs"] = used
        proof.caveats.append("、".join(f"`{r}`" for r in used) + " 這次抓取失敗，用的是資料庫裡 "
                             + "、".join(sorted({self.stale[r][:16] for r in used})) + " 存下的資料。")

    def series(self, sid: str, source: str | None = None, layer: str = "L1") -> tuple[SeriesSpec | None, list]:
        """(spec, [(period, value)]) for the first source with data, or a named source."""
        for spec in self.specs.get(sid, []):
            if source and spec.ref != source:
                continue
            rows = [(p, v) for p, v, lay in self.values[sid].get(spec.ref, []) if lay == layer]
            if rows:
                return spec, rows
        return None, []

    def latest(self, sid: str):
        spec, rows = self.series(sid)
        return (spec, rows[-1]) if rows else (spec, None)


def _fmt(x: float, nd: int = 2) -> str:
    return f"{x + 0.0:.{nd}f}" if round(x, nd) != 0 else f"{0:.{nd}f}"  # no "-0.00"


def _month(p: date) -> str:
    return p.strftime("%Y-%m")


def _phi(x: float) -> float:
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


# --- Sahm rule ------------------------------------------------------------------------------

def sahm_rule(data: MacroData, kb: KnowledgeBase) -> Proof | None:
    spec, rows = data.series("us.unemployment")
    if len(rows) < 15:
        return None
    rule = kb.get("macro.sahm_rule.definition")
    threshold = rule.value["threshold_pp"]
    vals = [v for _, v in rows]
    avg3 = [sum(vals[i - 2:i + 1]) / 3 for i in range(2, len(vals))]
    now, prior_min = avg3[-1], min(avg3[-13:-1])
    gap = now - prior_min
    hit = gap >= threshold
    p = Proof("薩姆規則（美國）", f"{'已觸發' if hit else '未觸發'}衰退訊號（差距 {_fmt(gap)} 個百分點，門檻 {threshold}）",
              result={"gap": round(gap, 3), "triggered": hit})
    p.add("L1", f"失業率最近三個月平均 {_fmt(now)}%", spec.ref, _month(rows[-1][0]))
    p.add("L1", f"前 12 個月內，三個月平均的最低值 {_fmt(prior_min)}%", spec.ref, _month(rows[-13][0]))
    p.add("L3", f"規則：三個月平均失業率比前 12 個月的最低點高出 {threshold} 個百分點以上，代表衰退已經開始", rule.id)
    pub_spec, pub = data.series("us.sahm_realtime")
    if pub:
        p.add("L1", f"聖路易聯儲公布的即時薩姆指標 {_fmt(pub[-1][1])}（交叉核對）", pub_spec.ref, _month(pub[-1][0]))
    rec = kb.facts.get("macro.sahm_rule.real_time_record")
    if rec is not None and isinstance(rec.value, dict) and "real_time" in rec.value:
        rt, rv = rec.value["real_time"], rec.value["revised"]
        lags = sorted(t["months_after_start"] for t in rt["triggers"] if t["outcome"] == "hit")
        p.add("L2", f"即時紀錄（ALFRED 當時公布的版本，{rec.value['sample']}）：訊號 {rt['hits'] + rt['false_alarms']} 次，"
                    f"{rt['hits']} 次在衰退中或衰退前 {rec.value['lead_months']} 個月內、{rt['false_alarms']} 次誤報"
                    f"（{'、'.join(t['month'] for t in rt['triggers'] if t['outcome'] == 'false_alarm')}）；"
                    f"漏掉的衰退 {len(rt['missed'])} 次；命中的訊號在衰退開始後 {lags[0]}–{lags[-1]} 個月才出現。"
                    f"用修正後的資料：{rv['hits']} 次命中、{rv['false_alarms']} 次誤報", rec.id, str(rec.recorded_at))
        p.caveats.append("這裡的讀數用最新修正後的失業率；即時紀錄顯示規則是同步或落後指標（衰退開始後幾個月才觸發），"
                         "最近一次誤報（2024 年）是否真的是誤報，要等 NBER 判定。")
    else:
        p.caveats.append("本系統用的是最新修正後的失業率；即時版本（當時公布的數字）可能不同，回測要改用 ALFRED 的歷史版本。")
    _diagnostic(p, kb, "macro.sahm_rule.diagnosticity", hit, "薩姆規則")
    return p


def _diagnostic(p: Proof, kb: KnowledgeBase, fact: str, on: bool, name: str) -> None:
    """Weigh the reading by its diagnostic power (pmpol.diagnostics): posterior odds = base-rate odds x LR."""
    f = kb.facts.get(fact)
    if f is None or not isinstance(f.value, dict) or "lr_pos" not in f.value:
        return
    v = f.value
    lr = v["lr_pos"] if on else v["lr_neg"]
    ci = v["lr_pos_90"] if on else v["lr_neg_90"]
    if not isinstance(lr, (int, float)):
        return
    prior = v["base_rate"]
    odds = prior / (1 - prior) * lr
    post = odds / (1 + odds)
    p.add("L2", f"{name}的診斷力（{v['sample']}，以月為單位）：「現在在衰退中或 {v['lead_months']} 個月內衰退開始」的月份裡亮起 "
                f"{100 * v['tpr']:.0f}%、其他月份 {100 * v['fpr']:.0f}%；{'亮起' if on else '沒亮'}的似然比 {lr:.2f}"
                f"（90% 區間 {ci[0]}–{ci[1]}）", f.id, str(f.recorded_at), kind="data", id=f"lr:{fact}")
    p.add("L5", f"以樣本的基準率 {100 * prior:.0f}% 為先驗，乘上似然比 {lr:.2f}：{v['lead_months']} 個月內衰退（或已在衰退中）"
                f"的機率約 {100 * post:.0f}%（只用這一個指標）", kind="logic", id=f"posterior:{fact}",
          inputs=(f"lr:{fact}",))
    p.result.setdefault("diagnostic", {})[fact] = {"lr": lr, "prior": prior, "posterior": round(post, 4)}
    p.alt("這個讀數對「衰退」和「不衰退」兩個假設的區別力很低（似然比接近 1）",
          "supports" if ci[0] <= 1 <= ci[1] else "against",
          f"似然比 {lr:.2f}，90% 區間 {ci[0]}–{ci[1]}" + ("，包含 1" if ci[0] <= 1 <= ci[1] else "，不包含 1"))


# --- yield curve ----------------------------------------------------------------------------

def yield_curve_recession(data: MacroData, kb: KnowledgeBase) -> Proof | None:
    spec, rows = data.series("us.yield_curve_10y3m")
    if not rows:
        return None
    today = date.fromisoformat(data.recorded_at[:10]) if data.recorded_at else date.today()
    complete = [(p, v) for p, v in rows if (p.year, p.month) < (today.year, today.month)]  # skip the partial month
    if not complete:
        return None
    period, spread = complete[-1]
    coef = kb.get("macro.nyfed_probit.coefficients")
    prob = _phi(coef.value["alpha"] + coef.value["beta"] * spread)
    p = Proof("殖利率曲線推估的衰退機率（美國，未來 12 個月）",
              f"{100 * prob:.0f}%，{likelihood(prob)}（利差 {_fmt(spread)} 個百分點）",
              result={"spread": round(spread, 3), "probability": round(prob, 4), "inverted": spread < 0})
    p.add("L1", f"10 年期減 3 個月期公債利差，{_month(period)} 月平均 {_fmt(spread)} 個百分點"
                f"（{'倒掛' if spread < 0 else '正斜率'}）", spec.ref, _month(period))
    p.add("L3", f"紐約聯儲 probit 模型：P = Φ({coef.value['alpha']} {coef.value['beta']:+} × 利差)", coef.id)
    p.caveats.append("單一指標模型；2022–2024 年長期倒掛之後並沒有出現 NBER 認定的衰退，這是這個模型近期最大的反例。")
    _diagnostic(p, kb, "macro.yield_curve.diagnosticity", spread < 0, "殖利率曲線倒掛")
    return p


# --- OECD CLI phase -------------------------------------------------------------------------

def cli_phase(data: MacroData, kb: KnowledgeBase, country: str) -> Proof | None:
    spec, rows = data.series(f"{country}.cli")
    if len(rows) < 2:
        return None
    (_, v0), (p1, v1) = rows[-2], rows[-1]
    rising = v1 > v0
    phase = ("expansion" if rising else "downturn") if v1 >= 100 else ("recovery" if rising else "slowdown")
    conv = kb.get("macro.oecd_cli.phases")
    p = Proof(f"OECD 領先指標景氣階段（{country.upper()}）", f"{CLI_ZH[phase]}",
              result={"phase": phase, "level": v1, "change": round(v1 - v0, 4)})
    p.add("L1", f"OECD 綜合領先指標 {_fmt(v1, 2)}（{'高於' if v1 >= 100 else '低於'}長期趨勢 100），"
                f"較上月{'上升' if rising else '下降'} {_fmt(abs(v1 - v0), 2)}", spec.ref, _month(p1))
    p.add("L3", "OECD 慣例：高於 100 且上升＝擴張；高於 100 且下降＝下滑；低於 100 且下降＝放緩；低於 100 且上升＝復甦", conv.id)
    return p


# --- Investment Clock -----------------------------------------------------------------------

def investment_clock(data: MacroData, kb: KnowledgeBase, country: str) -> Proof | None:
    cli_spec, cli = data.series(f"{country}.cli")
    cpi_spec, cpi = data.series(f"{country}.cpi_yoy")
    if len(cli) < 7 or len(cpi) < 13:
        return None
    growth_up = cli[-1][1] > cli[-7][1]
    ma12 = sum(v for _, v in cpi[-12:]) / 12
    infl_up = cpi[-1][1] > ma12
    phase = {(False, False): "reflation", (True, False): "recovery",
             (True, True): "overheat", (False, True): "stagflation"}[(growth_up, infl_up)]
    frame = kb.get("macro.investment_clock.definition")
    base = kb.facts.get("macro.investment_clock.us_1973_2004")
    p = Proof(f"美林投資時鐘・即時代理版（{country.upper()}）", PHASES_ZH[phase],
              result={"phase": phase, "growth_rising": growth_up, "inflation_rising": infl_up})
    p.add("L1", f"成長方向：OECD 領先指標 6 個月{'上升' if growth_up else '下降'}"
                f"（{_fmt(cli[-7][1])} → {_fmt(cli[-1][1])}）", cli_spec.ref, f"{_month(cli[-7][0])}→{_month(cli[-1][0])}")
    p.add("L1", f"通膨方向：CPI 年增率 {_fmt(cpi[-1][1])}% {'高於' if infl_up else '低於'}過去 12 個月平均 {_fmt(ma12)}%",
          cpi_spec.ref, _month(cpi[-1][0]))
    p.add("L3", "框架：成長↓通膨↓＝再通膨（債券）；成長↑通膨↓＝復甦（股票）；成長↑通膨↑＝過熱（商品）；"
                "成長↓通膨↑＝滯脹（現金）", frame.id)
    if base:
        row = base.value["phases"][phase]
        p.add("L2", f"歷史基準（美國 1973–2004）：這個階段佔 {row['share_pct']}% 的月份，平均持續 {row['avg_months']} 個月",
              base.id)
    p.caveats += ["原始報告的階段是事後判定的（作者明說不是即時交易規則），這裡改用即時代理指標，結果不能直接套用原報告的報酬率。",
                  "用中國資料的檢驗發現，階段常會跳過或逆時針轉動；這個框架屬於 L3，有爭議。"]
    return p


# --- credit conditions ----------------------------------------------------------------------

def _change(rows: list, periods: int) -> tuple[float, date, date] | None:
    if len(rows) <= periods:
        return None
    return rows[-1][1] - rows[-1 - periods][1], rows[-1 - periods][0], rows[-1][0]


def credit_conditions(data: MacroData, kb: KnowledgeBase, country: str = "us") -> Proof | None:
    checks = []  # (stress?, step layer, text, ref, as_of)
    conv = kb.facts.get("macro.financial_conditions.zero_convention")
    for sid, label in (("nfci", "芝加哥聯儲金融狀況指數 NFCI"), ("financial_stress", "聖路易聯儲金融壓力指數")):
        spec, rows = data.series(f"{country}.{sid}")
        if rows:
            v = rows[-1][1]
            checks.append((v > 0, f"{label} {_fmt(v)}（{'高於' if v > 0 else '低於'} 0 的歷史平均）", spec.ref,
                           _month(rows[-1][0])))
    for sid, label, n, unit in (("credit_card_delinquency", "信用卡逾期率", 4, "季"),
                                ("consumer_loan_delinquency", "消費貸款逾期率", 4, "季"),
                                ("business_loan_delinquency", "企業貸款逾期率", 4, "季"),
                                ("business_loan_chargeoff", "企業貸款沖銷率", 4, "季"),
                                ("mortgage_delinquency", "房貸逾期率", 4, "季"),
                                ("credit_delinquency", "信用逾期率", 12, "月")):
        spec, rows = data.series(f"{country}.{sid}")
        ch = _change(rows, n)
        if ch:
            d, p0, p1 = ch
            checks.append((d > 0, f"{label} {_fmt(rows[-1][1])}%，一年{'上升' if d > 0 else '下降'} {_fmt(abs(d))} 個百分點",
                           spec.ref, f"{_month(p0)}→{_month(p1)}"))
    spec, rows = data.series(f"{country}.baa_spread")
    if len(rows) > 120:
        med = statistics.median(v for _, v in rows[-121:-1])
        v = rows[-1][1]
        checks.append((v > med, f"Baa 公司債利差 {_fmt(v)} 個百分點，{'高於' if v > med else '低於'}過去 10 年中位數 {_fmt(med)}",
                       spec.ref, _month(rows[-1][0])))
    if not checks:
        return None
    n_stress = sum(c[0] for c in checks)
    p = Proof(f"信用與金融狀況（{country.upper()}）", f"{n_stress} / {len(checks)} 項指標顯示壓力上升",
              result={"stress": n_stress, "total": len(checks)})
    for stress, text, ref, as_of in checks:
        p.add("L1", ("⚠️ " if stress else "") + text, ref, as_of)
    if conv:
        p.add("L3", "慣例：NFCI、金融壓力指數大於 0 代表比歷史平均緊；逾期率一年變化只看方向，不設門檻", conv.id)
    p.caveats.append("公司違約率（Moody's、S&P）是付費資料，這裡用銀行逾期與沖銷率當公開替代指標。")
    return p


# --- source conflicts -----------------------------------------------------------------------

def conflicts(data: MacroData, tolerance: float = 0.15) -> list[tuple[str, date, list[tuple[str, float]]]]:
    """Same concept and period from different sources that disagree by more than `tolerance`."""
    out = []
    for sid, by_source in data.values.items():
        if len(by_source) < 2:
            continue
        maps = {ref: {p: v for p, v, lay in rows if lay == "L1"} for ref, rows in by_source.items()}
        common = set.intersection(*(set(m) for m in maps.values()))
        if not common:
            continue
        latest = max(common)
        vals = [(ref, m[latest]) for ref, m in maps.items()]
        if max(v for _, v in vals) - min(v for _, v in vals) > tolerance:
            out.append((sid, latest, vals))
    return out
