"""Calibration report over resolved markets, and the L2 base-rate facts it supports."""

from __future__ import annotations

from collections import Counter
from datetime import date

from pmpol.ground_truth import HORIZONS, Resolved
from pmpol.ground_truth.calibration import Calibration, calibrate
from pmpol.venues import info

TOPIC_ZH = {"elections_us": "美國選舉", "elections_intl": "國際選舉", "us_government": "美國政府與司法",
            "geopolitics": "地緣政治", "economy_policy": "經濟政策", "media": "媒體與發言", "other": "其他"}


def _sample(rows: list[Resolved], h: int, early: bool | None = False, venue: str | None = None,
            topic: str | None = None) -> tuple[list[float], list[int]]:
    ps, ys = [], []
    for r in rows:
        p = r.prices.get(str(h))
        if p is None or (early is not None and r.early != early) or (venue and r.venue != venue) \
                or (topic and r.topic != topic):
            continue
        ps.append(p)
        ys.append(r.result)
    return ps, ys


def _fmt_slope(c: Calibration) -> str:
    if not c.slope:
        return "—"
    a, b, sa, sb = c.slope
    return f"{b:.2f} ± {1.96 * sb:.2f}"


def _row(label: str, c: Calibration | None) -> str:
    if c is None:
        return f"| {label} | 0 | | | | | | | |"
    ls = "—" if c.longshot_return is None else f"{100 * c.longshot_return:+.1f}"
    fv = "—" if c.favourite_return is None else f"{100 * c.favourite_return:+.1f}"
    return (f"| {label} | {c.n:,} | {100 * c.base_rate:.1f}% | {100 * c.mean_price:.1f}% | {c.brier:.4f} | "
            f"{c.skill:.2f} | {_fmt_slope(c)} | {ls} | {fv} |")


HEAD = ["| 樣本 | 市場數 | 實際發生率 | 平均價格 | Brier | 技巧分數 | 校準斜率 b（95%） | 買冷門 <10% 的平均報酬（點） | 買熱門 >90% 的平均報酬（點） |",
        "|---|---|---|---|---|---|---|---|---|"]


def render(rows: list[Resolved], generated_at: str) -> str:
    venues = sorted({r.venue for r in rows}, key=lambda v: (v != "kalshi", v))
    L = [f"# 已結算市場校準報告 — {generated_at}", "",
         "已結算的市場是評估整個系統的最終標準答案。這裡看「截止前 N 天的價格」和「實際結果」差多少。", "",
         "**怎麼讀**",
         "- **校準斜率 b**：把 logit（實際機率）對 logit（價格）做回歸。b = 1 代表校準良好；"
         "**b > 1 代表價格太保守**（被壓向 50%，該確定的不夠確定）；b < 1 代表價格太極端。",
         "- **技巧分數** = 1 − Brier ／ 永遠猜平均發生率的 Brier；越接近 1 越好，0 代表沒有比猜平均好。",
         "- **買冷門的平均報酬**：在價格低於 10% 時買 YES，每份合約平均賺（＋）或賠（−）幾個百分點，"
         "不含手續費。負值就是「冷門被高估」（冷門偏差）。", ""]

    L += ["## 1. 資料涵蓋", "", "| 平台 | 市場數 | 結算期間 | YES 比例 | 提早結算 | 主題 |", "|---|---|---|---|---|---|"]
    for v in venues:
        rs = [r for r in rows if r.venue == v]
        dates = sorted(r.close_time[:10] for r in rs)
        topics = Counter(r.topic for r in rs).most_common(4)
        L.append(f"| {info(v).label} | {len(rs):,} | {dates[0]} → {dates[-1]} | "
                 f"{100 * sum(r.result for r in rs) / len(rs):.1f}% | {sum(r.early for r in rs):,} | "
                 + "、".join(f"{TOPIC_ZH.get(t, t)} {n}" for t, n in topics) + " |")
    L.append("")

    L += ["## 2. 各平台、各時間點的校準（排除提早結算的市場）", ""] + HEAD
    for v in venues:
        for h in HORIZONS:
            L.append(_row(f"{info(v).label}・截止前 {h} 天", calibrate(*_sample(rows, h, venue=v))))
    L.append("")

    L += ["## 3. 可靠度分箱（截止前 7 天，排除提早結算）", "",
          "| 平台 | 價格區間 | 市場數 | 平均價格 | 實際發生率 | 差距（點） |", "|---|---|---|---|---|---|"]
    for v in venues:
        c = calibrate(*_sample(rows, 7, venue=v))
        for b in (c.bins if c else []):
            L.append(f"| {info(v).label} | {100 * b['lo']:.0f}–{100 * b['hi']:.0f}% | {b['n']:,} | "
                     f"{100 * b['mean_price']:.1f}% | {100 * b['freq']:.1f}% | {100 * (b['freq'] - b['mean_price']):+.1f} |")
    L.append("")

    L += ["## 4. 依主題（截止前 7 天，兩個平台合併，排除提早結算）", ""] + HEAD
    for t in sorted({r.topic for r in rows}, key=lambda t: -sum(r.topic == t for r in rows)):
        c = calibrate(*_sample(rows, 7, topic=t))
        if c and c.n >= 50:
            L.append(_row(TOPIC_ZH.get(t, t), c))
    L.append("")

    L += ["## 5. 提早結算的市場（結果可能已經反映在截止時間裡）", "",
          "事件提前發生而停止交易的市場（例如「某人在 2045 年前卸任」在今天就發生了），用「截止前 N 天」"
          "來衡量會偷看到結果：截止時間本身就透露了答案。所以這些市場分開列，不放進上面的校準。", ""] + HEAD
    for v in venues:
        c = calibrate(*_sample(rows, 7, early=True, venue=v))
        L.append(_row(f"{info(v).label}・提早結算・截止前 7 天", c))
    L.append("")

    L += ["## 6. 限制", "",
          "- 樣本不是隨機的：Kalshi 每個系列只取最近 10 個有成交量的市場；Polymarket 取 Gamma 回傳的前 6,000 個已結算政治市場。",
          "- 同一個事件的市場（例如席次階梯）彼此相關，不是獨立樣本，所以信賴區間偏窄。",
          "- Kalshi 的「提早結算」旗標原本太寬（預定到期日常是固定的保底日期，或選舉的認證日）。現在重新判斷："
          "同一事件裡比其他選項早截止、或間隔比同系列最小間隔長的，才算提早結算；同系列有多個事件且間隔相同的，"
          "或所有選項同時截止的選舉，算按時程；判斷不了的仍排除（保守）。"
          + (f"這次：提早 {sum(r.early_status == 'early' for r in rows):,}、按時程 "
             f"{sum(r.early_status == 'on_schedule' for r in rows):,}、判斷不了 "
             f"{sum(r.early_status == 'unknown' for r in rows):,}。" if any(r.early_status for r in rows) else ""),
          "- Kalshi 用每日 K 線收盤時的買賣中間價（價差 ≤ 20 點），否則用最後成交價；Polymarket 用 CLOB 的小時價格。",
          "- 報酬不含手續費；扣掉手續費後，冷門的虧損會更大。",
          "- 對照文獻：Page & Clemen（2013）發現離到期越遠冷門偏差越明顯；Le（2026）發現政治市場長期信心不足（b > 1）；"
          "Bürgi 等人發現 Kalshi 低於 10 美分的合約虧損最大。", ""]
    return "\n".join(L)


def kb_yaml(rows: list[Resolved], recorded: date) -> str:
    """Proposed L2 facts (one per venue and horizon) for kb/L2/market_calibration.yaml."""
    src = {"kalshi": ("Kalshi API, settled markets in Politics/Elections/World series",
                      "https://api.elections.kalshi.com/trade-api/v2/historical/markets"),
           "polymarket": ("Polymarket Gamma API, closed markets tagged politics",
                          "https://gamma-api.polymarket.com/markets/keyset?closed=true&tag_id=2"),
           "manifold": ("Manifold Markets API, resolved binary questions in us-politics (play money, 20+ traders)",
                        "https://api.manifold.markets/v0/search-markets?filter=resolved&topicSlug=us-politics")}
    lines = ["# Generated by `pmpol truth calibrate --write-kb`; review before marking any fact reviewed.",
             "# Base rates from resolved political markets (L2). Excludes markets that closed early.", "facts:"]
    for v in sorted({r.venue for r in rows}):
        for h in HORIZONS:
            c = calibrate(*_sample(rows, h, venue=v))
            if c is None or c.slope is None:
                continue
            a, b, sa, sb = c.slope
            title, url = src.get(v, (v, "https://example.org"))
            lines += [f"  - id: calibration.{v}.politics.h{h}",
                      "    layer: L2",
                      f"    subject: {info(v).label} political markets",
                      f"    predicate: calibration_{h}d_before_close",
                      f"    value: {{n: {c.n}, base_rate: {c.base_rate:.4f}, mean_price: {c.mean_price:.4f}, "
                      f"brier: {c.brier:.4f}, skill: {c.skill:.3f}, slope_b: {b:.3f}, slope_b_se: {sb:.3f}, "
                      f"intercept_a: {a:.3f}"
                      + (f", longshot_return: {c.longshot_return:.4f}" if c.longshot_return is not None else "")
                      + (f", favourite_return: {c.favourite_return:.4f}" if c.favourite_return is not None else "")
                      + "}",
                      "    source:",
                      f"      title: {title}",
                      f"      url: {url}",
                      "    admiralty: B2",
                      "    status: proposed",
                      f"    recorded_at: {recorded.isoformat()}",
                      "    note: Computed by pmpol.ground_truth from venue APIs; sample and method in reports/<date>_calibration.md."]
    return "\n".join(lines) + "\n"
