"""Resolved Polymarket political markets (Gamma, tag "politics"), with CLOB prices before close.

Resolution: a closed binary market whose final outcomePrices are exactly ["1","0"] or ["0","1"]
and whose UMA status is "resolved"; 50-50 or unresolved markets are skipped. The CLOB
prices-history endpoint only serves short windows (about 15 days), so each horizon is a 1-day window.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import json
import time
from collections.abc import Iterator
from datetime import datetime, timezone

import httpx

from pmpol.ground_truth import HORIZONS, Resolved, topic_of

GAMMA = "https://gamma-api.polymarket.com"
CLOB = "https://clob.polymarket.com"
POLITICS_TAG = 2


def _ts(text: str) -> int:
    t = text.strip().replace(" ", "T", 1).replace("Z", "+00:00")
    if t.endswith("+00"):
        t += ":00"
    d = datetime.fromisoformat(t)
    return int((d if d.tzinfo else d.replace(tzinfo=timezone.utc)).timestamp())


def _iso(ts: int) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(timespec="seconds")


def history_price(history: list[dict], at_ts: int) -> float | None:
    before = [h for h in history if int(h["t"]) <= at_ts]
    return float(max(before, key=lambda h: int(h["t"]))["p"]) if before else None


class PolymarketHistory:
    def __init__(self, timeout: float = 60.0):
        self._gamma = httpx.Client(base_url=GAMMA, timeout=timeout, headers={"User-Agent": USER_AGENT})
        self._clob = httpx.Client(base_url=CLOB, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def _get(self, client: httpx.Client, path: str, params: dict) -> dict:
        for attempt in range(6):
            r = client.get(path, params=params)
            if r.status_code in (502, 503, 504):  # gateway errors only; a 429 or a refusal stops (raised below)
                time.sleep(2 ** attempt)
                continue
            r.raise_for_status()
            return r.json()
        r.raise_for_status()
        return {}

    def closed_markets(self, tag_id: int = POLITICS_TAG, limit: int | None = None) -> Iterator[dict]:
        cursor, n = None, 0
        while True:
            params = {"closed": "true", "tag_id": tag_id, "limit": 100}
            if cursor:
                params["after_cursor"] = cursor
            d = self._get(self._gamma, "/markets/keyset", params)
            for m in d.get("markets") or []:
                yield m
                n += 1
                if limit and n >= limit:
                    return
            cursor = d.get("next_cursor")
            if not cursor or not d.get("markets"):
                return

    def price_at(self, token: str, at_ts: int) -> float | None:
        d = self._get(self._clob, "/prices-history",
                      {"market": token, "startTs": at_ts - 86400, "endTs": at_ts, "fidelity": 60})
        return history_price(d.get("history") or [], at_ts)


def resolution(m: dict) -> int | None:
    """1 if YES won, 0 if NO won, None when not a cleanly resolved Yes/No market."""
    try:
        outcomes = json.loads(m.get("outcomes") or "[]")
        prices = json.loads(m.get("outcomePrices") or "[]")
    except json.JSONDecodeError:
        return None
    if [o.lower() for o in outcomes] != ["yes", "no"] or m.get("umaResolutionStatus") != "resolved":
        return None
    if prices == ["1", "0"]:
        return 1
    if prices == ["0", "1"]:
        return 0
    return None


def to_resolved(m: dict, prices: dict[str, float | None]) -> Resolved | None:
    result = resolution(m)
    if result is None or not m.get("closedTime"):
        return None
    close = _ts(m["closedTime"])
    due = m.get("endDate") or m["closedTime"]
    early = _ts(due) - close > 2 * 86400
    ev = (m.get("events") or [{}])[0]
    question = (m.get("question") or "").replace("[Single Market] ", "")
    return Resolved("polymarket", m.get("slug") or str(m.get("id")), ev.get("slug", ""), question,
                    (m.get("groupItemTitle") or "").strip(), _iso(close), due, early, result, m.get("volumeNum"),
                    "politics", topic_of("polymarket", ev.get("title") or question, question), prices,
                    {k: "last" for k, v in prices.items() if v is not None})


def horizon_prices(client: PolymarketHistory, m: dict) -> dict[str, float | None]:
    tokens = json.loads(m.get("clobTokenIds") or "[]")
    if not tokens or not m.get("closedTime"):
        return {}
    close = _ts(m["closedTime"])
    out = {}
    for h in HORIZONS:
        try:
            out[str(h)] = client.price_at(tokens[0], close - h * 86400)
        except httpx.HTTPError:
            out[str(h)] = None
    return out
