"""Calibration of resolved-market prices: reliability bins, Brier score, recalibration slope,
and the favourite-longshot bias.

Recalibration: logit P(YES) = a + b * logit(price). b < 1 means prices are too extreme
(overconfident); b > 1 means prices are compressed toward 50% (underconfident; Le 2026 reports this
for political markets). Fitted by Newton's method on the logistic log-likelihood.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

EPS = 0.005


def _logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, EPS, 1 - EPS)
    return np.log(p / (1 - p))


def recalibration(p: np.ndarray, y: np.ndarray, iters: int = 50) -> tuple[float, float, float, float] | None:
    """(a, b, se_a, se_b) for logit P(y=1) = a + b * logit(p); None if it does not converge."""
    if len(p) < 20 or y.min() == y.max():
        return None
    X = np.column_stack([np.ones(len(p)), _logit(p)])
    beta = np.zeros(2)
    for _ in range(iters):
        mu = 1 / (1 + np.exp(-X @ beta))
        w = mu * (1 - mu)
        H = X.T @ (X * w[:, None])
        step = np.linalg.solve(H + 1e-9 * np.eye(2), X.T @ (y - mu))
        beta += step
        if np.abs(step).max() < 1e-8:
            cov = np.linalg.inv(H)
            return float(beta[0]), float(beta[1]), float(math.sqrt(cov[0, 0])), float(math.sqrt(cov[1, 1]))
    return None


@dataclass
class Calibration:
    n: int
    base_rate: float
    mean_price: float
    brier: float
    brier_climatology: float  # Brier of always forecasting the base rate
    log_loss: float
    bins: list[dict] = field(default_factory=list)  # {lo, hi, n, mean_price, freq}
    slope: tuple | None = None  # (a, b, se_a, se_b)
    longshot_return: float | None = None  # mean (y - p) when buying YES under 10c
    favourite_return: float | None = None  # mean (y - p) when buying YES over 90c

    @property
    def skill(self) -> float:
        return 1 - self.brier / self.brier_climatology if self.brier_climatology else float("nan")


def calibrate(prices: list[float], results: list[int], edges=(0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, .95, 1.0001)
              ) -> Calibration | None:
    p, y = np.asarray(prices, float), np.asarray(results, float)
    if len(p) == 0:
        return None
    base = float(y.mean())
    pc = np.clip(p, EPS, 1 - EPS)
    c = Calibration(
        n=len(p), base_rate=base, mean_price=float(p.mean()),
        brier=float(np.mean((p - y) ** 2)), brier_climatology=float(np.mean((base - y) ** 2)),
        log_loss=float(-np.mean(y * np.log(pc) + (1 - y) * np.log(1 - pc))))
    for lo, hi in zip(edges, edges[1:]):
        m = (p >= lo) & (p < hi)
        if m.any():
            c.bins.append({"lo": lo, "hi": min(hi, 1.0), "n": int(m.sum()), "mean_price": float(p[m].mean()),
                           "freq": float(y[m].mean())})
    c.slope = recalibration(p, y)
    lo, hi = p < 0.10, p > 0.90
    c.longshot_return = float((y[lo] - p[lo]).mean()) if lo.sum() >= 10 else None
    c.favourite_return = float((y[hi] - p[hi]).mean()) if hi.sum() >= 10 else None
    return c
