"""Resolved Kalshi markets in political series, with daily-candle prices before close.

Since 2026-08 Kalshi splits data: markets settled before the cutoff (GET /historical/cutoff) are
only under /historical/*, later ones under /markets?status=settled. Candles differ too:
/historical/markets/{t}/candlesticks has price.close; /series/{s}/markets/{t}/candlesticks has
price.close_dollars. Both are read here.
"""

from __future__ import annotations

from pmpol import USER_AGENT

import time
from collections.abc import Iterator
from datetime import datetime

import httpx

from pmpol.ground_truth import HORIZONS, Resolved, topic_of

BASE_URL = "https://api.elections.kalshi.com/trade-api/v2"
CATEGORIES = ("Politics", "Elections", "World")


def _ts(iso: str) -> int:
    return int(datetime.fromisoformat(iso.replace("Z", "+00:00")).timestamp())


def _num(x) -> float | None:
    if x in (None, ""):
        return None
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _close_of(d: dict | None) -> float | None:
    if not d:
        return None
    return _num(d.get("close_dollars", d.get("close")))


def candle_price(candles: list[dict], at_ts: int, max_spread: float = 0.2) -> tuple[float | None, str]:
    """Price at the end of the last daily candle that ends on or before `at_ts`: the bid/ask midpoint
    when the book was reasonably tight, else the last trade."""
    before = [c for c in candles if int(c["end_period_ts"]) <= at_ts]
    if not before:
        return None, ""
    c = max(before, key=lambda c: int(c["end_period_ts"]))
    bid, ask = _close_of(c.get("yes_bid")), _close_of(c.get("yes_ask"))
    if bid is not None and ask is not None and 0 < ask and ask - bid <= max_spread:
        return round((bid + ask) / 2, 4), "mid"
    last = _close_of(c.get("price"))
    return (last, "last") if last is not None else (None, "")


class KalshiHistory:
    def __init__(self, base_url: str = BASE_URL, timeout: float = 60.0, pause: float = 0.06):
        self._http = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})
        self._pause = pause

    def _get(self, path: str, params: dict | None = None) -> dict:
        for attempt in range(6):
            r = self._http.get(path, params=params)
            if r.status_code in (502, 503, 504):  # gateway errors only; a 429 or a refusal stops (raised below)
                time.sleep(2 ** attempt)
                continue
            time.sleep(self._pause)
            if r.status_code == 404:
                return {}
            r.raise_for_status()
            return r.json()
        r.raise_for_status()
        return {}

    def series(self, categories=CATEGORIES) -> list[dict]:
        out = []
        for cat in categories:
            out += [{**s, "category": cat} for s in self._get("/series", {"category": cat}).get("series") or []]
        return out

    def _paged(self, path: str, params: dict) -> Iterator[dict]:
        cursor = None
        while True:
            d = self._get(path, {**params, **({"cursor": cursor} if cursor else {})})
            yield from d.get("markets") or []
            cursor = d.get("cursor")
            if not cursor or not d.get("markets"):
                return

    def settled_markets(self, series_ticker: str) -> Iterator[tuple[dict, bool]]:
        """(market, is_historical) for every settled, non-combination market in a series."""
        for m in self._paged("/markets", {"series_ticker": series_ticker, "status": "settled", "limit": 200,
                                          "mve_filter": "exclude"}):
            yield m, False  # settled since the cutoff: the most recent first
        for m in self._paged("/historical/markets", {"series_ticker": series_ticker, "limit": 200}):
            yield m, True

    def candles(self, series_ticker: str, m: dict, historical: bool) -> list[dict]:
        end = _ts(m["close_time"])
        params = {"start_ts": end - 32 * 86400, "end_ts": end, "period_interval": 1440}
        path = (f"/historical/markets/{m['ticker']}/candlesticks" if historical
                else f"/series/{series_ticker}/markets/{m['ticker']}/candlesticks")
        return self._get(path, params).get("candlesticks") or []


def to_resolved(m: dict, series: dict, candles: list[dict]) -> Resolved | None:
    result = {"yes": 1, "no": 0}.get((m.get("result") or "").lower())
    if result is None or not m.get("close_time"):
        return None
    close = _ts(m["close_time"])
    due = m.get("expected_expiration_time") or m.get("latest_expiration_time") or m["close_time"]
    early = bool(m.get("can_close_early")) and _ts(due) - close > 2 * 86400
    prices, kinds = {}, {}
    for h in HORIZONS:
        p, kind = candle_price(candles, close - h * 86400)
        prices[str(h)], kinds[str(h)] = p, kind
    title = m.get("title") or ""
    return Resolved("kalshi", m["ticker"], m.get("event_ticker", ""), title, m.get("yes_sub_title") or "",
                    m["close_time"], due, early, result, _num(m.get("volume_fp") or m.get("volume")),
                    series.get("category", ""), topic_of("kalshi", series.get("title") or title, title), prices, kinds)
