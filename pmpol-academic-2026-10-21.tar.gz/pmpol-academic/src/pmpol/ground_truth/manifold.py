"""Resolved Manifold markets (play money), for the calibration of an external forecaster (2026-10-07).

Manifold sits next to the markets as an L3 opinion (pmpol.external). How much weight such an opinion deserves is a
question for resolved questions: the same calibration test as for Kalshi and Polymarket, on Manifold's own
resolved US-politics binary questions.

  sample       topic "us-politics", binary, resolved YES or NO (CANCEL and MKT left out), play money (MANA), at
               least MIN_BETTORS distinct traders (a handful of bettors is not a market)
  close        the resolution (or the close, if earlier). Manifold moves a question's close time to its resolution
               when it is resolved early, so "early" comes from the date the question itself names ("by September
               30, 2026", "in 2026"): resolved more than two days before it is early (the event happened first; the
               price before it leaks the outcome). Questions that name no date are not fetched (their timing cannot
               be checked).
  templates    one question per template (numbers replaced): series that differ only in a threshold (gas price at
               $4.40, $4.45, ...) would otherwise fill the sample with near-copies; the one with most traders is kept
  prices       the probability after the last trade before close - h days (h = 1, 7, 30), from the bets endpoint
               with beforeTime: one request per horizon

Creator names, ids, avatars and bettors' ids are dropped as the answer is read (pmpol.external.clean_manifold); a
record keeps only the question, the times, the result and the prices. Manifold's terms allow non-commercial
research use; the questions are cited by URL.
"""

from __future__ import annotations

import time
import re
from datetime import date, datetime, timedelta, timezone

from pmpol import USER_AGENT
from pmpol.ground_truth import HORIZONS, Resolved, topic_of

API = "https://api.manifold.markets/v0"
TOPIC = "us-politics"
MIN_BETTORS = 20
PAGE = 1000
DAY_MS = 86_400_000


def _get(path: str, params: dict):
    import httpx

    for attempt in range(2):
        r = httpx.get(API + path, params=params, timeout=60, headers={"User-Agent": USER_AGENT})
        if r.status_code in (502, 503, 504) and attempt == 0:  # a gateway error: one retry after a pause
            time.sleep(5)
            continue
        r.raise_for_status()  # a refusal or a rate limit stops here, never retried
        return r.json()


def _iso(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).isoformat(timespec="seconds")


SORTS = ("most-popular", "score", "newest")  # the search pages stop at an offset of about 2,000: union of orders


def resolved(limit: int, get=None, pause: float = 0.2) -> list[dict]:
    """Resolved binary US-politics questions, cleaned of creator data (deduplicated across sort orders)."""
    import httpx

    from pmpol.external import clean_manifold

    get = get or _get
    out: dict[str, dict] = {}
    for sort in SORTS:
        offset = 0
        while len(out) < limit:
            try:
                rows = get("/search-markets", {"term": "", "filter": "resolved", "contractType": "BINARY",
                                               "topicSlug": TOPIC, "sort": sort, "limit": PAGE, "offset": offset})
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 400 and offset > 0:  # past the deepest page the search serves
                    break
                raise
            if not rows:
                break
            for m in rows:
                m = clean_manifold(m)
                if (m.get("resolution") in ("YES", "NO") and m.get("token", "MANA") == "MANA"
                        and (m.get("uniqueBettorCount") or 0) >= MIN_BETTORS and m.get("resolutionTime")):
                    out.setdefault(m["id"], m)
            offset += len(rows)
            time.sleep(pause)
            if len(rows) < PAGE:
                break
    return list(out.values())[:limit]


_MONTHS = {m: i + 1 for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
                                          "dec"))}
_DAY = re.compile(r"\b(on|by|before|through|until)\s+([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(20\d\d)\b",
                  re.I)
_MONTH = re.compile(r"\b(by|before|in|through|until|end of)\s+(?:the end of\s+)?([A-Za-z]{3})[a-z]*\s+(20\d\d)\b", re.I)
_YEAR = re.compile(r"\b(by|before|in|through|until)\s+(?:the end of\s+)?(20\d\d)\b(?!\s*[-–])", re.I)


def scheduled(question: str) -> date | None:
    """The last day the question covers (None when it names no date). "Before" excludes the date it names: before
    2027 is the end of 2026, before October 2026 the end of September."""
    if m := _DAY.search(question):
        mon = _MONTHS.get(m.group(2).lower()[:3])
        if mon:
            try:
                d = date(int(m.group(4)), mon, int(m.group(3)))
            except ValueError:
                return None
            return d - timedelta(days=1) if m.group(1).lower() == "before" else d
    if m := _MONTH.search(question):
        mon = _MONTHS.get(m.group(2).lower()[:3])
        if mon:
            y = int(m.group(3))
            if m.group(1).lower() == "before":
                return date(y, mon, 1) - timedelta(days=1)
            return date(y, 12, 31) if mon == 12 else date(y, mon + 1, 1) - timedelta(days=1)
    if m := _YEAR.search(question):
        y = int(m.group(2))
        return date(y - 1, 12, 31) if m.group(1).lower() == "before" else date(y, 12, 31)
    return None


def template(question: str) -> str:
    return re.sub(r"\$?\d[\d,.]*%?", "#", question.lower()).strip()


def pick(markets: list[dict], skip: set[str] = frozenset()) -> list[dict]:
    """Questions that name a date, one per template (most traders), templates in `skip` left out."""
    best: dict[str, dict] = {}
    for m in markets:
        t = template(m.get("question", ""))
        if t in skip or scheduled(m.get("question", "")) is None:
            continue
        if t not in best or (m.get("uniqueBettorCount") or 0) > (best[t].get("uniqueBettorCount") or 0):
            best[t] = m
    return list(best.values())


def prob_before(contract_id: str, t_ms: int, get=None) -> float | None:
    """Probability after the last trade before t (None when there was none)."""
    rows = (get or _get)("/bets", {"contractId": contract_id, "limit": 1, "beforeTime": t_ms})
    return float(rows[0]["probAfter"]) if rows and rows[0].get("probAfter") is not None else None


def to_resolved(m: dict, get=None, pause: float = 0.2) -> Resolved:
    close = min(int(m["closeTime"]), int(m["resolutionTime"]))
    prices: dict[str, float | None] = {}
    for h in HORIZONS:
        t = close - h * DAY_MS
        prices[str(h)] = prob_before(m["id"], t, get) if t > int(m.get("createdTime") or 0) else None
        time.sleep(pause)
    q = m.get("question", "")
    due = scheduled(q)
    due_ms = None if due is None else int(datetime(due.year, due.month, due.day, 23, 59, tzinfo=timezone.utc).timestamp()
                                          * 1000)
    early = due_ms is None or int(m["resolutionTime"]) < due_ms - 2 * DAY_MS  # no date: cannot tell, kept out
    return Resolved("manifold", m["id"], template(q), q, "Yes", _iso(close), "" if due is None else due.isoformat(),
                    early, 1 if m["resolution"] == "YES" else 0, float(m.get("volume") or 0), TOPIC,
                    topic_of("manifold", q, q), prices, {str(h): "last" for h in HORIZONS},
                    "unknown" if due is None else "early" if early else "on_schedule")
