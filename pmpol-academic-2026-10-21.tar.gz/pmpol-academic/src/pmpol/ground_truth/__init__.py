"""Ground truth: resolved political markets, with the price each had some days before it closed.

This is the final standard for evaluating the system (README: "另一種標準答案"): calibration of
venue prices, the favourite-longshot bias, and later backtests of both engines.

Each record keeps the market's actual close time and whether it closed early (the event
happened before the scheduled end), because early closes leak the outcome into the close time:
a market that stopped trading the day the event happened is almost always a YES.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

DATA = Path("data/ground_truth")
HORIZONS = (1, 7, 30)  # days before close


@dataclass
class Resolved:
    venue: str
    market_id: str
    event_id: str
    question: str
    outcome: str
    close_time: str  # actual close (ISO, UTC)
    scheduled_close: str  # when it was due to close
    early: bool  # closed well before it was due: the outcome may be implied by the close time
    result: int  # 1 = YES won, 0 = NO won
    volume: float | None = None
    category: str = ""  # venue category or tag
    topic: str = ""  # pmpol taxonomy topic
    prices: dict[str, float | None] = field(default_factory=dict)  # "1" / "7" / "30" days before close -> price
    price_kind: dict[str, str] = field(default_factory=dict)  # "mid" or "last" per horizon
    early_status: str = ""  # after refine_early: "early", "on_schedule" or "unknown" (unknown counts as early)

    def to_dict(self) -> dict:
        return asdict(self)


def save(rows: list[Resolved], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r.to_dict(), ensure_ascii=False) + "\n")


def load(path: Path) -> list[Resolved]:
    if not path.exists():
        return []
    return [Resolved(**json.loads(line)) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _ts(iso: str) -> float:
    from datetime import datetime

    return datetime.fromisoformat(iso.replace("Z", "+00:00")).timestamp()


def refine_early(rows: list[Resolved], tolerance_days: float = 2.0) -> dict[str, int]:
    """Narrow Kalshi's early-close flag, in place.

    The raw flag (closed more than 2 days before the expected expiration) is far too wide: Kalshi's
    expected expiration is often a fixed backstop (e.g. 90 days after the scheduled close) or, for
    elections, the certification date. A flagged market is reclassified as
      early        it closed more than `tolerance_days` before the latest close in its event, or its
                   close-to-expiration gap exceeds the smallest gap in its series by that much
                   (the event happened before the schedule: the close time leaks the outcome);
      on_schedule  its series has several events sharing its gap (a fixed lag), or it is an election
                   whose options all closed together (closed when the race was called: prices days
                   before the close are still pre-result);
      unknown      neither can be told; kept out of the clean sample like "early" (conservative).
    Rows not flagged by the venue, and other venues, are left as they are."""
    from collections import defaultdict

    day = 86400
    series, events = defaultdict(list), defaultdict(list)
    for r in rows:
        if r.venue == "kalshi":
            series[r.event_id.split("-")[0]].append(r)
            events[r.event_id].append(r)
    counts = {"early": 0, "on_schedule": 0, "unknown": 0}
    for r in rows:
        if r.venue != "kalshi" or not r.early:
            continue
        gap = _ts(r.scheduled_close) - _ts(r.close_time)
        sib = events[r.event_id]
        ser = series[r.event_id.split("-")[0]]
        min_gap = min(_ts(x.scheduled_close) - _ts(x.close_time) for x in ser)
        latest = max(_ts(x.close_time) for x in sib)
        if latest - _ts(r.close_time) > tolerance_days * day or gap > min_gap + tolerance_days * day:
            status = "early"
        elif len({x.event_id for x in ser}) >= 2:
            status = "on_schedule"
        elif r.topic.startswith("elections") and len({x.close_time[:13] for x in sib}) == 1:
            status = "on_schedule"
        else:
            status = "unknown"
        r.early_status = status
        r.early = status != "on_schedule"
        counts[status] += 1
    return counts


def topic_of(venue: str, title: str, question: str) -> str:
    """pmpol taxonomy topic for a resolved market, from its titles."""
    from pmpol.models import Event, Market
    from pmpol.universe.taxonomy import tag_event

    e = Event(venue, "x", title, markets=[Market(venue, "m", "x", question, "")])
    return tag_event(e).topic
