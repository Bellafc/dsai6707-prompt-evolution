"""Resumable fetch of resolved markets: appends to data/ground_truth/<venue>.jsonl and skips ids
already there, so an interrupted run continues where it stopped."""

from __future__ import annotations

import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from pmpol.ground_truth import DATA

MIN_VOLUME = 1000  # contracts (Kalshi) or USDC (Polymarket); thinner markets have no meaningful price


def _done(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return {json.loads(line)["market_id"] for line in path.read_text(encoding="utf-8").splitlines() if line.strip()}


def _append(path: Path, rows) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with open(path, "a", encoding="utf-8") as f:
        for r in rows:
            if r is not None:
                f.write(json.dumps(r.to_dict(), ensure_ascii=False) + "\n")
                n += 1
    return n


def fetch_kalshi(per_series: int = 25, max_series: int | None = None, out: Path = DATA / "kalshi.jsonl",
                 log=sys.stderr, max_scan: int = 400, workers: int = 3) -> int:
    from pmpol.ground_truth.kalshi import KalshiHistory, to_resolved

    k = KalshiHistory()
    done = _done(out)
    series = k.series()
    if max_series:
        series = series[:max_series]
    total = 0

    def one(s: dict) -> list:
        picked, scanned = [], 0
        for m, hist in k.settled_markets(s["ticker"]):
            scanned += 1
            if scanned > max_scan:  # long strike ladders: a sample is enough, and paging all is slow
                break
            vol = float(m.get("volume_fp") or m.get("volume") or 0)
            if m["ticker"] in done or vol < MIN_VOLUME or (m.get("result") or "") not in ("yes", "no"):
                continue
            picked.append((m, hist))
        picked.sort(key=lambda t: t[0].get("close_time") or "", reverse=True)
        return [to_resolved(m, s, k.candles(s["ticker"], m, hist)) for m, hist in picked[:per_series]]

    def safe(s: dict) -> list:
        try:
            return one(s)
        except Exception as e:  # one bad series must not stop a long run
            print(f"kalshi {s['ticker']}: {e}", file=log)
            return []

    with ThreadPoolExecutor(max_workers=workers) as pool:
        for i, rows in enumerate(pool.map(safe, series)):
            total += _append(out, rows)
            if i % 100 == 0:
                print(f"kalshi series {i}/{len(series)}: {total} resolved markets", file=log, flush=True)
    return total


def fetch_polymarket(limit: int = 6000, out: Path = DATA / "polymarket.jsonl", workers: int = 6,
                     log=sys.stderr) -> int:
    from pmpol.ground_truth.polymarket import PolymarketHistory, horizon_prices, resolution, to_resolved

    pm = PolymarketHistory()
    done = _done(out)
    todo = [m for m in pm.closed_markets(limit=limit)
            if (m.get("slug") or str(m.get("id"))) not in done and resolution(m) is not None
            and (m.get("volumeNum") or 0) >= MIN_VOLUME]
    print(f"polymarket: {len(todo)} resolved markets to price", file=log, flush=True)
    total = 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for start in range(0, len(todo), 200):
            batch = todo[start:start + 200]
            prices = list(pool.map(lambda m: horizon_prices(pm, m), batch))
            total += _append(out, [to_resolved(m, p) for m, p in zip(batch, prices)])
            print(f"polymarket {start + len(batch)}/{len(todo)}: {total}", file=log, flush=True)
    return total


def fetch_manifold(limit: int = 3000, out: Path = DATA / "manifold.jsonl", log=sys.stderr, pause: float = 0.2) -> int:
    """Resolved US-politics questions on Manifold (play money), for the external forecaster's calibration."""
    from pmpol.ground_truth.manifold import pick, resolved, template, to_resolved

    done = _done(out)
    have = {json.loads(line)["event_id"] for line in out.read_text(encoding="utf-8").splitlines()
            if line.strip()} if out.exists() else set()
    todo = [m for m in pick(resolved(limit, pause=pause), have) if m["id"] not in done
            and template(m.get("question", "")) not in have]
    total = 0
    for i in range(0, len(todo), 50):
        total += _append(out, [to_resolved(m, pause=pause) for m in todo[i:i + 50]])
        print(f"manifold {i + 50}/{len(todo)}: {total} resolved questions", file=log, flush=True)
    return total
