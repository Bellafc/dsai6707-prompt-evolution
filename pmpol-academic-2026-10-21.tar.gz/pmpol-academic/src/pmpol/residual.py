"""Residual monitor: what the taxonomy and the proposition ontology cannot read, and how that changes.

Principle (docs/PROPOSITION_ONTOLOGY.md, section 0): classification is a lens, not a wall. Nothing the
system cannot read is dropped (the reverse engine still checks it); it is watched here instead. A batch
of new questions the system cannot read is itself a signal: either the world produced something new,
or the taxonomy needs extending.
"""

from __future__ import annotations

import json
import re
import sqlite3
from collections import Counter
from dataclasses import dataclass, field

from pmpol.universe.index import Universe

_STOP = set("""will the a an of in on to by for and or be is are at with who what when which how many much does did
before after than more less this that next new win wins winner election elections 2026 2027 2028 2029 2030 yes
january february march april may june july august september october november december end year week month
announce announced market markets price prices above below least most other first second third under over longer
from into about between against during there their have been were within without""".split())


@dataclass
class Residual:
    events: int
    markets: int  # active markets
    unclassified: list[str] = field(default_factory=list)  # event keys whose topic is "other"
    unparsed: dict[str, str] = field(default_factory=dict)  # active market key -> reason (ontology)
    new_events: list[str] = field(default_factory=list)  # event keys absent from the previous snapshot
    new_unread: list[str] = field(default_factory=list)  # new events the system cannot read at all
    previous_at: str = ""

    @property
    def unclassified_share(self) -> float:
        return len(self.unclassified) / self.events if self.events else 0.0

    @property
    def unparsed_share(self) -> float:
        return len(self.unparsed) / self.markets if self.markets else 0.0

    def counts(self) -> dict:
        return {"residual_unclassified_share": round(self.unclassified_share, 4),
                "residual_unparsed_share": round(self.unparsed_share, 4),
                "residual_new_events": len(self.new_events), "residual_new_unread": len(self.new_unread)}


def compute(u: Universe, unparsed: dict[str, str], parsed_markets: set[str], previous_keys: set[str] | None,
            previous_at: str = "") -> Residual:
    live = {k: [m for m in e.markets if m.active] for k, e in u.events.items()}
    r = Residual(len(u.events), sum(len(ms) for ms in live.values()), previous_at=previous_at)
    r.unclassified = sorted(k for k, t in u.tags.items() if t.topic == "other")
    r.unparsed = {m.key: unparsed.get(m.key, "not read") for ms in live.values() for m in ms
                  if m.key not in parsed_markets}
    if previous_keys is not None:
        r.new_events = sorted(k for k in u.events if k not in previous_keys)
        uncl = set(r.unclassified)
        r.new_unread = [k for k in r.new_events
                        if k in uncl or not any(m.key in parsed_markets for m in live[k])]
    return r


def themes(titles: list[str], top: int = 8) -> list[tuple[str, list[str]]]:
    """Keyword groups among titles: a word shared by two or more titles, most shared first."""
    words = [{w for w in re.findall(r"[a-z][a-z'\-]{3,}", t.lower()) if w not in _STOP} for t in titles]
    proper = {w.lower() for t in titles for w in re.findall(r"\b[A-Z][a-z'\-]{3,}", t)}
    df = Counter(w for ws in words for w in ws)
    out, used = [], set()
    # Most shared first; on ties prefer names (capitalised in a title), then longer words.
    for w, n in sorted(df.items(), key=lambda t: (-t[1], t[0] not in proper, -len(t[0]), t[0])):
        if n < 2 or len(out) >= top:
            break
        group = [t for t, ws in zip(titles, words) if w in ws and t not in used]
        if len(group) >= 2:
            out.append((w, group))
            used |= set(group)
    return out


def trend(conn: sqlite3.Connection, limit: int = 8) -> list[tuple[str, dict]]:
    """Residual counts of recent universe runs (from the run manifests), oldest first."""
    try:
        rows = conn.execute("SELECT id, counts FROM runs WHERE command = 'universe' AND status LIKE 'ok%' "
                            "ORDER BY started_at DESC LIMIT 40").fetchall()
    except sqlite3.OperationalError:
        return []
    out = [(rid, c) for rid, raw in rows if "residual_unparsed_share" in (c := json.loads(raw or "{}"))]
    return list(reversed(out[:limit]))


def render(u: Universe, r: Residual, history: list[tuple[str, dict]] = ()) -> list[str]:
    L = ["## 8. 殘差監測：分類和本體看不到的部分", "",
         "分類系統和命題本體是透鏡，不是圍牆：讀不懂的市場不會被丟掉（逆向引擎照樣檢查），而是在這裡監測。"
         "突然多出一批讀不懂的新題目，代表世界出現了新東西，或分類規則該擴充了。", "",
         f"- 未分類事件：{len(r.unclassified):,} / {r.events:,}（{r.unclassified_share:.1%}）",
         f"- 命題本體讀不懂的有效市場：{len(r.unparsed):,} / {r.markets:,}（{r.unparsed_share:.1%}）"]
    if r.previous_at:
        L.append(f"- 和上一個快照（{r.previous_at[:16]}）相比：新出現的事件 {len(r.new_events):,} 個，"
                 f"其中完全讀不懂的 **{len(r.new_unread):,}** 個")
    else:
        L.append("- 沒有更早的快照可以比較")
    L.append("")
    if r.new_unread:
        titles = [u.events[k].title for k in r.new_unread]
        groups = themes(titles)
        L += ["### 8a. 新出現、讀不懂的題目（依共同關鍵字分群）", ""]
        for w, ts in groups:
            L.append(f"- **{w}**（{len(ts)}）：" + "；".join(t[:70] for t in ts[:4]) + ("…" if len(ts) > 4 else ""))
        grouped = {t for _, ts in groups for t in ts}
        rest = [t for t in titles if t not in grouped]
        if rest:
            L.append(f"- 其他（{len(rest)}）：" + "；".join(t[:70] for t in rest[:8]) + ("…" if len(rest) > 8 else ""))
        L.append("")
    reasons = Counter(r.unparsed.values()).most_common(6)
    if reasons:
        L += ["### 8b. 本體讀不懂的原因", "", "| 原因 | 市場數 |", "|---|---|"]
        L += [f"| {why} | {n:,} |" for why, n in reasons]
        L.append("")
    if history:
        L += ["### 8c. 趨勢（最近幾次執行）", "", "| 執行 | 報價時間 | 未分類 | 本體讀不懂 | 新出現且讀不懂 |",
              "|---|---|---|---|---|"]
        for rid, c in history:
            L.append(f"| `{rid}` | {str(c.get('observed_at', ''))[:16]} | {c['residual_unclassified_share']:.1%} | "
                     f"{c['residual_unparsed_share']:.1%} | {c.get('residual_new_unread', '—')} |")
        L.append("")
    L += [f"### 8d. 未分類事件節錄（{len(r.unclassified):,} 個中的 25 個，用來擴充分類規則）", ""]
    L += [f"- {u.events[k].title}" for k in r.unclassified[:25]]
    L.append("")
    return L
