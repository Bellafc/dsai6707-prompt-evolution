"""Distribution of a sum of independent categorical outcomes via the multi-dimensional FFT.

Each race (or any independent trial) contributes one of several integer increment
vectors with known probabilities. The distribution of the total is the convolution
of the per-race distributions; in Fourier space that convolution is a product:

    phi_total(w) = prod_i sum_k p_ik * exp(-2*pi*j * <w, v_ik> / N)

so one forward FFT per race, an element-wise product, and one inverse FFT give the
full joint pmf over the count grid. Grid sizes must exceed the largest reachable
total in each dimension, otherwise counts wrap around (circular convolution).
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np

# One outcome = (increment vector, probability).
Outcome = tuple[tuple[int, ...], float]


def grid_shape_for(trials: Sequence[Sequence[Outcome]]) -> tuple[int, ...]:
    """Smallest grid that holds every reachable total without wrap-around."""
    dims = len(trials[0][0][0])
    max_total = [0] * dims
    for outcomes in trials:
        for d in range(dims):
            max_total[d] += max((inc[d] for inc, p in outcomes if p > 0), default=0)
    return tuple(m + 1 for m in max_total)


def convolve_outcomes(
    trials: Sequence[Sequence[Outcome]], shape: tuple[int, ...] | None = None
) -> np.ndarray:
    """Joint pmf of the summed increment vectors, computed with an N-d FFT."""
    if not trials:
        raise ValueError("need at least one trial")
    shape = shape or grid_shape_for(trials)
    spectrum = np.ones(shape, dtype=np.complex128)
    for outcomes in trials:
        pmf = np.zeros(shape)
        for inc, p in outcomes:
            if p > 0:
                pmf[inc] += p
        spectrum *= np.fft.fftn(pmf)
    total = np.fft.ifftn(spectrum).real
    total[total < 0] = 0.0  # round-off below zero
    s = total.sum()
    return total / s if s > 0 else total


def convolve_outcomes_direct(
    trials: Sequence[Sequence[Outcome]], shape: tuple[int, ...] | None = None
) -> np.ndarray:
    """Reference O(n * grid) dynamic-programming convolution, used to test the FFT path."""
    shape = shape or grid_shape_for(trials)
    total = np.zeros(shape)
    total[(0,) * len(shape)] = 1.0
    for outcomes in trials:
        nxt = np.zeros(shape)
        for inc, p in outcomes:
            if p == 0:
                continue
            src = tuple(slice(0, n - k) for n, k in zip(shape, inc))
            dst = tuple(slice(k, n) for n, k in zip(shape, inc))
            nxt[dst] += p * total[src]
        total = nxt
    return total
