from pmpol import store
from pmpol.evidence import Evidence, from_news, summary, timing


def test_timing_places_publication_against_the_move_window():
    a, b = "2026-10-03T01:11:00+00:00", "2026-10-03T09:19:00+00:00"
    def e(t):
        return Evidence("market:k", "h", "s", "u", published_at=t)
    assert timing(e("2026-10-02T20:00:00+00:00"), a, b) == "before"
    assert timing(e("2026-10-03T05:00:00+00:00"), a, b) == "during"
    assert timing(e("2026-10-04T05:00:00+00:00"), a, b) == "after"  # the market moved first
    assert timing(e(""), a, b) == "unknown"


def test_news_items_become_ungraded_evidence_and_are_stored_once(tmp_path):
    items = from_news("market:kalshi:X", [{"title": "Alito retires", "url": "https://n/1", "domain": "n",
                                           "seendate": "20261003T091500Z"}], "gdelt", "2026-10-03T10:00:00+00:00")
    e = items[0]
    assert (e.published_at, e.received_at, e.reliability, e.credibility, e.stance) == (
        "2026-10-03T09:15:00+00:00", "2026-10-03T10:00:00+00:00", "F", "6", "unclear")
    assert summary(items, "2026-10-03T01:11:00+00:00", "2026-10-03T09:19:00+00:00")["during"] == 1
    conn = store.connect(tmp_path / "db.sqlite")
    assert store.save_evidence(conn, items) == 1 and store.save_evidence(conn, items) == 0
