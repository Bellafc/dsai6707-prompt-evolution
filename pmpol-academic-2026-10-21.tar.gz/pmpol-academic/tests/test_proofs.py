import json

from pmpol import viewer
from pmpol.kb import KnowledgeBase
from pmpol.models import Event, Market
from pmpol.proof import Proof, likelihood
from pmpol.universe import pipeline

KB = KnowledgeBase.load()


def _race(venue, d_bid, d_ask, eid=None, rules="Resolves Yes if the Democratic Party wins NY-02."):
    eid = eid or f"{venue}-NY02"
    return Event(venue, eid, "NY-02 House Election Winner 2026", mutually_exclusive=True, markets=[
        Market(venue, f"{eid}-D", eid, "NY-02 House Election Winner 2026", "Democratic Party", rules=rules,
               bid=d_bid, ask=d_ask, close_time="2026-11-04T00:00:00Z", fee_rate=0.07),
        Market(venue, f"{eid}-R", eid, "NY-02 House Election Winner 2026", "Republican Party", rules=rules,
               bid=1 - d_ask, ask=1 - d_bid, close_time="2026-11-04T00:00:00Z", fee_rate=0.07)])


def _run():
    events = [_race("polymarket_us", 0.30, 0.31), _race("gemini", 0.45, 0.46)]
    return pipeline.run(events, depth=False, entities=False, observed_at="2026-10-02T12:00+00:00", kb=KB)


def test_every_signal_has_a_grounded_well_formed_proof():
    res = _run()
    assert res.rule_signals
    for s in res.rule_signals:
        p = res.proofs[s.payload["id"]]
        assert p.grounded and p.check() == []
        layers = {st.layer for st in p.steps}
        assert {"L1", "L4", "L5"} <= layers  # contract terms, quotes, inference
        assert any(st.ref == "us.election.2026_general" for st in p.steps)  # knowledge-base context
        assert p.meta["quotes_observed_at"] == "2026-10-02T12:00+00:00"
        g = p.graph()
        assert any(n["id"] == "conclusion" for n in g["nodes"])
        assert {e["source"] for e in g["edges"]} <= {n["id"] for n in g["nodes"]}


def test_alternatives_weigh_competing_explanations():
    res = _run()
    p = res.proofs[res.rule_signals[0].payload["id"]]
    alts = {a["hypothesis"]: a["verdict"] for a in p.alternatives}
    assert alts["兩群交易者看法不同（平台開放地區不同）"] == "against"  # both venues are US venues
    assert alts["手續費比假設的高"] == "against"
    assert alts["其中一個平台把標籤弄反"] == "against"
    assert "其他可能的解釋" in "\n".join(p.markdown())


def test_grounding_follows_the_step_graph():
    p = Proof("x", "y").add("L1", "fact", id="a").add("L5", "inference", id="b", inputs=("a",))
    assert p.grounded and p.steps[0].kind == "data" and p.steps[1].kind == "logic"
    assert not Proof("x", "y").add("L5", "model says so").grounded
    assert Proof("x", "y").add("L5", "z", inputs=("missing",)).check() == ["z: unknown input missing"]


def test_icd203_wording():
    assert likelihood(0.14).startswith("非常不可能") and likelihood(0.5).startswith("差不多一半")
    assert likelihood(0.97).startswith("幾乎確定")


def test_event_signal_proof_lists_the_exclusivity_basis():
    e = Event("gemini", "LA06", "Louisiana-06 House Winner", mutually_exclusive=True, markets=[
        Market("gemini", f"m{i}", "LA06", "Louisiana-06 House Winner", n, bid=b, ask=b + 0.02, fee_rate=0.07)
        for i, (n, b) in enumerate([("A", 0.53), ("B", 0.49), ("C", 0.49)])])
    res = pipeline.run([e], depth=False, entities=False, kb=KB)
    (s,) = res.event_signals
    p = res.proofs[s.payload["id"]]
    assert p.grounded and any("互斥" in a["hypothesis"] for a in p.alternatives)
    assert any("預設報價" in c for c in p.caveats)


def test_viewer_embeds_data_safely(tmp_path):
    res = _run()
    proofs = tmp_path / "proofs.json"
    pipeline.export_proofs(res, proofs)
    d = json.loads(proofs.read_text())
    d["signals"][0]["title"] += " </script><b>x</b>"  # hostile text from a venue must not break out
    proofs.write_text(json.dumps(d))
    out = tmp_path / "v.html"
    stats = viewer.build(out, proofs=proofs, macro=tmp_path / "none.json", kb=KB, movers=tmp_path / "none.json",
                         settlement=tmp_path / "none.json", external=tmp_path / "none.json", house=tmp_path / "none.json", news=(),
                         pages=[{"title": "系統狀態", "md": "# t\n| a | b |\n|---|---|\n| 1 | **2** |"}],
                         history={"kalshi:X": [["2026-10-04T12:00", 0.4], ["2026-10-04T13:00", 0.45]]})
    html = out.read_text()
    assert stats["signals"] == len(d["signals"]) and stats["kb"] == len(KB.facts) and stats["pages"] == 1
    assert 'data-tab="system"' in out.read_text(encoding="utf-8")
    blob = html.split('<script id="data" type="application/json">', 1)[1].split("</script>", 1)[0]
    assert json.loads(blob.replace("<\\/", "</"))["signals"][0]["proof"]["graph"]["nodes"]
    assert "cdnjs.cloudflare.com/ajax/libs/cytoscape" in html
    assert all("markets" in r for r in d["signals"] if r["group"] in ("rule", "consensus"))
    assert stats["history"] == 1 and "function sparkline" in html


def test_price_history_reads_mids_and_thins_long_series(tmp_path):
    from pmpol import store, viewer

    db = tmp_path / "p.sqlite"
    with store.connect(db) as conn:
        conn.executemany("INSERT INTO quotes (ts, venue, market_id, bid, ask, last) VALUES (?,?,?,?,?,?)",
                         [(f"2026-10-04T{h:02d}:00", "kalshi", "A", 0.40 + h / 1000, 0.42 + h / 1000, None)
                          for h in range(24)] + [("2026-10-04T00:00", "kalshi", "B", None, None, 0.3),
                                                 ("2026-10-04T00:00", "kalshi", "C", 0.5, 0.6, None)])
    h = viewer.price_history({"kalshi:A", "kalshi:B"}, db, points=5)
    assert len(h["kalshi:A"]) == 5 and h["kalshi:A"][0] == ["2026-10-04T00:00", 0.41]
    assert h["kalshi:A"][-1] == ["2026-10-04T23:00", 0.433] and h["kalshi:B"] == [["2026-10-04T00:00", 0.3]]
    assert "kalshi:C" not in h and viewer.price_history(set(), db) == {}


def test_system_pages_read_only_the_given_reports_and_database(tmp_path):
    from pmpol import viewer

    reports = tmp_path / "reports"
    reports.mkdir()
    (reports / "2026-10-03_track.md").write_text("# 訊號成績單\n- x")
    (reports / "2026-10-03_universe.md").write_text("## 7\n## 8. 殘差監測：t\n- a\n### 8d. 節錄\n- b")
    pages = {p["title"]: p["md"] for p in viewer.system_pages(reports, db=tmp_path / "db.sqlite")}
    assert set(pages) >= {"系統狀態", "關鍵假設", "訊號成績單", "殘差監測"} and "結算資料檢查" not in pages
    assert pages["殘差監測"].startswith("## 8. 殘差監測") and "8d" not in pages["殘差監測"]


def test_relations_come_from_the_ontology_with_templates_as_crosscheck():
    res = _run()
    assert res.rule_relations and all(r.template.startswith("onto:") for r in res.rule_relations)
    c = res.crosscheck
    assert c is not None and c.agree and not c.disagree  # the templates agree with the ontology here
    assert not res.template_only
    s = res.rule_signals[0]
    proof = res.proofs[s.payload["id"]]
    assert any("同一個命題" in st.text for st in proof.steps)  # the ontology's logic, in words
    assert any(st.id == "rules" and "結算條件比對" in st.text for st in proof.steps)  # the venues' rules, compared


def test_a_market_quote_without_source_or_time_is_a_structural_problem(tmp_path):
    import json

    from pmpol.contracts import proof_checks

    bare = Proof("x", "y").add("L4", "K 40%", ref="https://kalshi.com/m")  # no time
    assert bare.check() == ["K 40%: L4 step without a source or time"]
    ok = Proof("x", "y").add("L4", "K 40%", ref="https://kalshi.com/m", as_of="2026-10-03T13:29")
    path = tmp_path / "p.json"
    path.write_text(json.dumps({"signals": [{"proof": {**bare.to_dict()}}, {"proof": ok.to_dict()}]}))
    checks = {c.name: c for c in proof_checks("proofs:test", path)}
    assert not checks["quotes_have_source_and_time"].ok and checks["quotes_have_source_and_time"].observed == "1 of 2"
    assert checks["proofs_grounded"].ok


def test_person_party_bridges_cite_that_the_party_was_learned_from_labels():
    def race(venue, label, bid, ask):
        eid = f"{venue}-TX35"
        return Event(venue, eid, "TX-35 House Election Winner 2026", mutually_exclusive=True, markets=[
            Market(venue, f"{eid}-1", eid, "TX-35 House Election Winner 2026", label, bid=bid, ask=ask,
                   close_time="2026-11-04T00:00:00Z", fee_rate=0.02),
            Market(venue, f"{eid}-2", eid, "TX-35 House Election Winner 2026", "Someone Else (D)", bid=1 - ask,
                   ask=1 - bid, close_time="2026-11-04T00:00:00Z", fee_rate=0.02)])
    # Gemini names the person, Kalshi's label teaches the party, Polymarket lists the party
    events = [race("gemini", "Carlos De La Cruz", 0.39, 0.42), race("kalshi", "Carlos De La Cruz (R)", 0.50, 0.52),
              race("polymarket", "Republican Party", 0.58, 0.60)]
    res = pipeline.run(events, depth=False, entities=False, observed_at="2026-10-02T12:00+00:00", kb=KB)
    assert res.observed_at == "2026-10-02T12:00+00:00" and isinstance(res.consensus, list)  # once lost by position
    bridged = [res.proofs[s.payload["id"]] for s in res.rule_signals
               if res.proofs[s.payload["id"]].result.get("template", "").endswith("bridge_person_party")]
    assert bridged
    for p in bridged:
        assert "labels_identify_party_candidate" in p.result["assumptions"] and p.check() == []


def test_election_facts_only_for_election_questions():
    from pmpol.universe.explain import kb_context
    from pmpol.universe.taxonomy import Tags

    vote = Tags("elections_intl", office="president", country="Brazil", year=2026, jurisdiction="Brazil")
    prices = Tags("economy_policy", country="Brazil", year=2026)  # "Brazil Annual Inflation 2026"
    assert [f.id for f in kb_context(KB, vote)] == ["br.election.2026_first_round"]
    assert kb_context(KB, prices) == [] and kb_context(KB, Tags("economy_policy", country="United States", year=2026)) == []
