from datetime import date

import pytest

from pmpol.kb import KnowledgeBase, verify_sources
from pmpol.senate.config import control_thresholds, load_config

KB = KnowledgeBase.load()


def test_repository_knowledge_base_is_valid():
    assert KB.errors == []
    assert len(KB.facts) >= 60


def test_first_batch_countries_have_l0_rules():
    by_country = KB.by_country()
    for code in ("us", "cn", "tw", "il", "uk", "ru", "ir", "br"):
        assert any(f.layer == "L0" for f in by_country[code]), code


def test_reviewed_l0_rules_are_quoted_or_derived():
    for f in KB.facts.values():
        if f.layer == "L0" and f.status == "reviewed":
            assert f.source.quote or f.derived_from, f.id


def test_query_respects_valid_time():
    (term_limit,) = KB.query(subject="President of Russia", predicate="max_terms")
    assert term_limit.valid_at(date(2026, 1, 1)) and not term_limit.valid_at(date(2019, 1, 1))


def test_validation_catches_bad_records(tmp_path):
    (tmp_path / "bad.yaml").write_text("""
facts:
  - id: x.one
    layer: L9
    subject: s
    predicate: p
    value: 1
    source: {title: t, url: not-a-url}
    admiralty: Z9
    status: maybe
    recorded_at: 2026-10-02
    derived_from: [x.missing]
  - id: x.one
    layer: L0
    subject: s
    predicate: p
    value: 2
    source: {title: t, url: https://example.org}
    admiralty: A1
    status: reviewed
    recorded_at: 2026-10-02
""", encoding="utf-8")
    kb = KnowledgeBase.load(tmp_path)
    text = "\n".join(kb.errors)
    for needle in ("duplicate id", "layer must be", "status must be", "admiralty grade", "source url",
                   "unknown fact x.missing"):
        assert needle in text


def test_verify_sources_with_fake_fetch(tmp_path):
    pages = {
        "https://www.constituteproject.org/constitution/United_States_of_America_1992?lang=en":
            "<p>The   Senate of the United States shall be composed of two Senators from each State</p>" + "<p>text</p>" * 100,
    }

    def fetch(url):
        if url not in pages:
            raise OSError("offline")
        return pages[url]

    results = verify_sources(KB, cache=tmp_path, fetch=fetch)
    assert results["us.senate.seats_per_state"] == "verified"
    assert results["us.senate.vp_tiebreak"] == "quote not found"
    assert results["tw.recall.passing_rule"].startswith("unreachable")
    assert results["us.house.majority"] == "no quote"


def test_a_block_page_is_unreachable_not_a_missing_quote(tmp_path):
    def fetch(url):  # a site that refuses this host's location answers 200 with a short notice
        return "<h1>Unavailable</h1><p>The site is temporarily inaccessible from your location</p>"

    results = verify_sources(KB, cache=tmp_path, fetch=fetch)
    assert results["us.senate.seats_per_state"].startswith("unreachable")
    assert not list(tmp_path.iterdir())  # nothing cached, so a later run tries again


def test_senate_thresholds_come_from_knowledge_base():
    assert control_thresholds(KB)[:2] == (51, 50)
    cfg = load_config()
    assert cfg.provenance["control_seats"] == ["us.senate.seats", "us.senate.vp_tiebreak", "us.vice_president"]


def test_disputed_facts_are_flagged():
    leader = KB.get("ir.leader.current")
    assert leader.status == "disputed" and leader.admiralty == "C3"


@pytest.mark.parametrize("fact_id,value", [
    ("us.house.majority", 218), ("il.knesset.majority", 61), ("tw.ly.majority", 57),
    ("us.election.2026_general", date(2026, 11, 3)), ("br.election.2026_runoff", date(2026, 10, 25)),
])
def test_derived_values(fact_id, value):
    assert KB.value(fact_id) == value


def test_senate_holdover_is_derived_from_terms():
    from pmpol.kb.derived import senate_holdover

    def sen(state, party, end, caucus=None):
        t = {"type": "sen", "state": state, "party": party, "end": end}
        if caucus:
            t["caucus"] = caucus
        return {"terms": [t]}
    rows = [sen("ME", "Independent", "2031-01-03", "Democrat"), sen("TX", "Republican", "2027-01-03"),
            sen("OH", "Republican", "2026-11-03"), sen("CA", "Democrat", "2029-01-03"),
            {"terms": [{"type": "rep", "state": "CA", "party": "Democrat", "end": "2027-01-03"}]}]
    assert senate_holdover(rows) == {"D": 2, "R": 0, "up": ["OH", "TX"]}


def test_missing_quotes_are_classed_by_what_a_quote_could_be():
    from pmpol.kb import Fact, Source, quote_kind

    def fact(url, note=""):
        return Fact("x", "L2", "s", "p", 1, Source("t", url), "B2", "proposed", date(2026, 10, 7), note=note)

    assert quote_kind(fact("https://github.com/bellafc/polymarket_politics/blob/x/reports/a.md")) == "computed"
    assert quote_kind(fact("https://alfred.stlouisfed.org/series?seid=UNRATE", "Computed by pmpol.diagnostics")) == "computed"
    assert quote_kind(fact("https://data.nber.org/cycles/business_cycle_dates.json")) == "dataset"
    assert quote_kind(fact("https://www.law.cornell.edu/uscode/text/2/7")) == "text"


def test_pdf_sources_need_a_text_extractor(monkeypatch):
    import shutil

    import pytest

    from pmpol.kb import pdf_text

    monkeypatch.setattr(shutil, "which", lambda name: None)
    with pytest.raises(ValueError, match="pdftotext"):
        pdf_text(b"%PDF-1.4 ...")
