from datetime import date

from pmpol.ground_truth import Resolved
from pmpol.ground_truth import words_deeds as wd
from pmpol.kb import KnowledgeBase


def _r(i, q, price, result, early=False):
    return Resolved("kalshi", f"m{i}", f"e{i // 2}", q, "Yes", "2026-01-01T00:00:00Z", "2026-01-01T00:00:00Z", early,
                    result, prices={"7": price, "30": price}, early_status="" if early else "on_schedule")


def test_questions_are_classed_by_fixed_word_lists():
    assert wd.classify("What will J.D. Vance say on Ingraham Angle?") == "words"
    assert wd.classify("Will Trump impose tariffs on Canada?") == "deeds"
    assert wd.classify("Will Trump announce and sign the bill?") is None  # both lists: left out
    assert wd.classify("Who will win the election?") is None


def test_summary_compares_yes_share_with_price_and_feeds_the_goal_proof(tmp_path):
    rows = [_r(i, "Will X impose sanctions?", 0.20, int(i % 10 == 0)) for i in range(60)]
    rows += [_r(100 + i, "Will X say tariff?", 0.30, int(i % 10 < 3)) for i in range(40)]
    rows.append(_r(999, "Will X impose sanctions?", 0.9, 1, early=True))  # an early close is left out
    out = {(r.cls, r.horizon): r for r in wd.summarize(rows, reps=200)}
    d = out[("deeds", "30")]
    assert d.n == 60 and d.events == 30 and abs(d.yes - 0.1) < 1e-9 and abs(d.gap + 0.1) < 1e-9 and d.ci[1] < 0
    assert abs(out[("words", "7")].gap) < 1e-9
    (tmp_path / "w.yaml").write_text(wd.kb_yaml(list(out.values()), date(2026, 10, 6), len(rows)), encoding="utf-8")
    kb = KnowledgeBase.load(tmp_path)
    assert kb.errors == [] and kb.facts[wd.FACT].value["deeds_30d"]["gap_ci95"][1] < 0

    from pmpol.goals import goal_proof, load_goals

    p = goal_proof(load_goals()[0], kb)
    alt = next(a for a in p.alternatives if a["hypothesis"].startswith("手段上的衝突只是口頭"))
    assert alt["verdict"] == "supports" and any(s.id == "deeds" for s in p.steps)
