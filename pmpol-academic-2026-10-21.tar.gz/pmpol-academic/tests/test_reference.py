from datetime import date

from pmpol import reference as ref
from pmpol.kb import KnowledgeBase

HOUSE = """<table><tr><th>Congress (Years)</th><th># of House Seats</th><th>Democrats</th><th>Republicans</th>
<th>Other</th><th>Del./Res.</th></tr>
<tr><td><a>115th (2017–2019)</a></td><td>435</td><td>194</td><td>241</td><td>0</td><td>5/1</td></tr>
<tr><td><a>116th (2019-2021)</a></td><td>435<sup>5</sup></td><td>235</td><td>199</td><td>0</td><td>5/1</td></tr>
<tr><td><a>117th (2021–2023)</a></td><td>435<sup>6</sup></td><td>222</td><td>212</td><td>Independent (1)</td><td>5/1</td></tr>
<tr><td><a>118th (2023–2025)</a></td><td>435</td><td>213</td><td>222</td><td>0</td><td>5/1</td></tr>
<tr><td><a>119th (2025–2027)</a></td><td>435</td><td>215</td><td>220</td><td>0</td><td>5/1</td></tr></table>"""

TERMS = """<table><tr><th>No.</th><th>President</th><th>Vice President</th><th>Years of Service</th><th>Congresses</th></tr>
<tr><td>45.</td><td>Donald J. Trump</td><td>Mike Pence</td><td>Jan. 20, 2017–Jan. 20, 2021</td><td>115, 116, 117</td></tr>
<tr><td>46.</td><td>Joseph R. Biden Jr.</td><td>Kamala D. Harris</td><td>Jan. 20, 2021–Jan. 20, 2025</td><td>117, 118, 119</td></tr>
<tr><td>47.</td><td>Donald J. Trump</td><td>James David (J.D.) Vance</td><td>Jan. 20, 2025–present</td><td>119</td></tr>
</table>"""

SENATE = """<p>Note: Statistics listed below reflect party division immediately following the election.</p>
<p><b>107th Congress (2001&ndash;2003)</b></p>
<p>Majority Party (Jan 3&ndash;20, 2001): Democrats (50 seats)</p><p>Minority Party: Republicans (50 seats)</p>
<p>Total Seats: 100</p><p>________</p>
<p>Majority Party (Jan 20&ndash;June 6, 2001): Republicans (50 seats)</p><p>Minority Party: Democrats (50 seats)</p>
<p>Total Seats: 100</p><p>Note: From January 3 to January 20, 2001, the Democrats held the majority.</p><p>-----------</p>
<p><b>115th Congress (2017&ndash;2019)</b></p><p>Majority Party: Republicans (51 seats)</p>
<p>Minority Party: Democrats (47 seats)</p><p>Other Parties: 2 Independents</p><p>Total Seats: 100</p><p>-----------</p>
<p><b>116th Congress (2019&ndash;2021)</b></p><p>Majority Party: Republicans (53 seats)</p>
<p>Minority Party: Democrats (45 seats)</p><p>Other Parties: 2 Independents</p><p>Total Seats: 100</p><p>-----------</p>
<p><b>117th Congress (2021&ndash;2023)</b></p><p>Majority Party: Democrats (48 seats)</p>
<p>Minority Party: Republicans (50 seats)</p><p>Other Parties: 2 Independents (all caucus with the Democrats)</p>
<p>Total Seats: 100</p><p>-----------</p>
<p><b>118th Congress (2023&ndash;2025)</b></p><p>Majority Party: Democrats (47 seats)</p>
<p>Minority Party: Republicans (49 seats)</p><p>Other Parties: 4 Independents</p><p>Total Seats: 100</p><p>-----------</p>
<p><b>119th Congress (2025&ndash;2027)</b></p><p>Majority Party: Republicans (53 seats)</p>
<p>Minority Party: Democrats (45 seats)</p><p>Other Parties: 2 Independents</p><p>Total Seats: 100</p>"""

PAGES = {ref.HOUSE_URL: HOUSE, ref.TERMS_URL: TERMS, ref.SENATE_URL: SENATE,
         ref.PARTY_URL.format(slug="trump"): "<dt>Political Party</dt> <dd>Republican</dd>",
         ref.PARTY_URL.format(slug="biden"): "<dt>Political Party</dt>\n<dd>Democrat</dd>"}


def test_house_table_drops_footnotes_and_reads_other_parties():
    h = ref.parse_house(HOUSE, since=2017)
    assert h[116] == {"years": "2019-2021", "seats": 435, "D": 235, "R": 199, "other": 0}
    assert h[117]["other"] == 1 and sorted(h) == [115, 116, 117, 118, 119]


def test_terms_parties_and_election_calendar():
    terms = ref.parse_terms(TERMS, since=2017)
    assert terms[-1] == {"president": "Donald J. Trump", "start": "2025-01-20", "end": None, "congresses": [119]}
    assert ref.election_day(2026) == date(2026, 11, 3) and ref.election_day(2022) == date(2022, 11, 8)
    assert ref.president_on(terms, ref.election_day(2018)) == "Donald J. Trump"
    assert ref.congress_elected(2026) == 120 and ref.congress_elected(1946) == 80
    assert ref.parse_party(PAGES[ref.PARTY_URL.format(slug="biden")]) == ("D", "Political Party Democrat")


def test_midterm_changes_and_outside_view(tmp_path):
    got = ref.build(get=PAGES.__getitem__, cache=tmp_path / "cache", pause=0)
    got.house = ref.parse_house(HOUSE, since=2017)
    got.terms = ref.parse_terms(TERMS, since=2017)
    assert [(r["year"], r["party"], r["change"]) for r in got.rows] == [(2018, "R", -42), (2022, "D", -9)]
    assert got.house_quote == "119th (2025–2027) 435 215 220"
    l1, l2 = ref.kb_yaml(got, date(2026, 10, 4))
    (tmp_path / "kb" / "L1").mkdir(parents=True)
    (tmp_path / "kb" / "L2").mkdir()
    (tmp_path / "kb" / "L1" / "h.yaml").write_text(l1, encoding="utf-8")
    (tmp_path / "kb" / "L2" / "r.yaml").write_text(l2, encoding="utf-8")
    (tmp_path / "kb" / "L1" / "s.yaml").write_text(ref.senate_kb_yaml(got, date(2026, 10, 4)), encoding="utf-8")
    kb = KnowledgeBase.load(tmp_path / "kb")
    assert kb.errors == [] and kb.facts[ref.MIDTERM_FACT].derived_from[:2] == (ref.HOUSE_FACT, ref.TERMS_FACT)
    v = ref.outside_view(kb, 2026)
    # R holds 220: it keeps the majority with a change of -2 or better; neither past midterm qualifies
    assert (v.president_party, v.seats, v.needed, v.keeps, v.n) == ("R", 220, -2, 0, 2)
    assert v.probability("D") == 1.0 and ref.outside_view(kb, 2028) is None
    lo, hi = ref.wilson(2, 20)
    assert 0.02 < lo < 0.03 and 0.29 < hi < 0.31


def test_outside_view_proof_sets_market_next_to_base_rate(tmp_path):
    from pmpol.universe import pipeline

    got = ref.build(get=PAGES.__getitem__, cache=tmp_path / "cache", pause=0)
    got.house, got.terms = ref.parse_house(HOUSE, since=2017), ref.parse_terms(TERMS, since=2017)
    l1, l2 = ref.kb_yaml(got, date(2026, 10, 4))
    (tmp_path / "kb").mkdir()
    (tmp_path / "kb" / "a.yaml").write_text(l1, encoding="utf-8")
    (tmp_path / "kb" / "b.yaml").write_text(l2, encoding="utf-8")
    (tmp_path / "kb" / "c.yaml").write_text(ref.senate_kb_yaml(got, date(2026, 10, 4)), encoding="utf-8")
    kb = KnowledgeBase.load(tmp_path / "kb")
    o = pipeline.OutsideViewRow("control(United States|house|2026)", ref.outside_view(kb, 2026),
                                {"D": (0.9, False)}, (0.0, 0.84))
    assert abs(o.market - 0.1) < 1e-9 and abs(o.gap - 0.1) < 1e-9
    p = pipeline.explain_outside_view(o, "2026-10-04T12:15", kb)
    assert p.grounded and [s.layer for s in p.steps][:4] == ["L1", "L1", "L1", "L2"]
    assert "midterm_reference_class" in p.result["assumptions"]
    assert p.result["base_rate"] == 0.0 and p.result["market"] == 0.1


def test_senate_table_and_its_outside_view(tmp_path):
    s = ref.parse_senate(SENATE, since=2001)
    assert s[107] == {"years": "2001-2003", "seats": 100, "D": 50, "R": 50, "other": 0,
                      "note": "From January 3 to January 20, 2001, the Democrats held the majority."}
    assert s[117]["other"] == 2 and s[118]["other"] == 4 and sorted(s) == [107, 115, 116, 117, 118, 119]
    got = ref.build(get=PAGES.__getitem__, cache=tmp_path / "cache", pause=0)
    got.terms = ref.parse_terms(TERMS, since=2017)
    assert [(r["year"], r["party"], r["change"]) for r in got.senate_rows] == [(2018, "R", 2), (2022, "D", -1)]
    assert got.senate_quote == "119th Congress (2025–2027) Majority Party: Republicans (53 seats)"
    l1, l2 = ref.kb_yaml(got, date(2026, 10, 5))
    kbdir = tmp_path / "kb"
    kbdir.mkdir()
    for name, text in (("h.yaml", l1), ("r.yaml", l2), ("s.yaml", ref.senate_kb_yaml(got, date(2026, 10, 5)))):
        (kbdir / name).write_text(text, encoding="utf-8")
    kb = KnowledgeBase.load(kbdir)
    assert kb.errors == [] and kb.facts[ref.SENATE_MIDTERM_FACT].derived_from[0] == ref.SENATE_FACT
    v = ref.outside_view(kb, 2026, "senate")
    # R holds 53 of 100 and the vice president breaks ties: 50 seats keep control, so a change of -3 or better
    assert (v.chamber, v.president_party, v.seats, v.needed, v.keeps, v.n) == ("senate", "R", 53, -3, 2, 2)
    from pmpol.universe import pipeline

    o = pipeline.OutsideViewRow("control(United States|senate|2026)", v, {"D": (0.64, False)}, ref.wilson(2, 2))
    p = pipeline.explain_outside_view(o, "2026-10-05T12:00", kb)
    assert p.grounded and "參議院" in p.steps[0].text and "fundamentals_p" not in p.result
    assert any("三分之一" in a["evidence"] for a in p.alternatives)
