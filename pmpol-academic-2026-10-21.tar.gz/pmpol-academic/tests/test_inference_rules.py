from collections import defaultdict

from pmpol.kb import KnowledgeBase
from pmpol.models import Event, Market
from pmpol.propositions import INF, Prop, Span, Var
from pmpol.propositions import derive as dv
from pmpol.propositions.rules import load, validate

KB = KnowledgeBase.load()


def _by_var(props):
    out = defaultdict(list)
    for p in props:
        out[p.var].append(p)
    return out


def test_every_rule_names_grounds_that_exist():
    book = load()
    assert validate(book, KB) == []
    assert {"same_set", "subset", "cover", "bridge_margin_winner", "bridge_person_party", "bridge_joint_marginal",
            "winner_implies_nominee", "seats_imply_control"} <= set(book.rules)
    assert all(r.grounds for r in book.rules.values())


def _person(subject, name):  # local identities are scoped to the contest: country|jurisdiction|office|year
    return frozenset({f"person:local:{'|'.join(subject.split('|')[:4])}|{name}"})


def test_winning_the_presidency_implies_the_nomination_of_the_one_party_listing_the_person():
    gen = "United States|US|president|2028|general"
    rep, dem = "United States|US|president|2028|primary/R", "United States|US|president|2028|primary/D"
    vp = "United States|US|president|2028|primary/vp/R"
    props = [Prop(Var("winner", gen), "kalshi:W-JV", "kalshi:W", "t", values=_person(gen, "jd vance")),
             Prop(Var("nominee", rep), "polymarket:N-JV", "polymarket:N", "t", values=_person(rep, "jd vance")),
             Prop(Var("nominee", vp), "polymarket:V-JV", "polymarket:V", "t", values=_person(vp, "jd vance")),
             # listed by both parties: left out
             Prop(Var("winner", gen), "kalshi:W-X", "kalshi:W", "t", values=_person(gen, "mark cuban")),
             Prop(Var("nominee", rep), "polymarket:N-X", "polymarket:N", "t", values=_person(rep, "mark cuban")),
             Prop(Var("nominee", dem), "polymarket:D-X", "polymarket:D", "t", values=_person(dem, "mark cuban")),
             # a suffix is a different person
             Prop(Var("winner", gen), "kalshi:W-T", "kalshi:W", "t", values=_person(gen, "donald trump jr")),
             Prop(Var("nominee", rep), "polymarket:N-T", "polymarket:N", "t", values=_person(rep, "donald trump"))]
    got = [(d.lhs, d.rhs, d.basis, d.kind) for d in dv._winner_nominee(_by_var(props))]
    assert got == [(["kalshi:W-JV"], ["polymarket:N-JV"], "winner_implies_nominee", "implies")]


def test_a_majority_of_seats_held_implies_control_of_the_chamber():
    senate_held = Var("seats", "United States|US|senate|2027|general", "D/held")
    control = Var("control", "United States|senate|2026")
    props = [Prop(senate_held, "kalshi:S-51", "kalshi:S", "t", spans=(Span(51, INF),)),  # 51+: majority of 100
             Prop(senate_held, "kalshi:S-50", "kalshi:S", "t", spans=(Span(50, INF),)),  # 50+: not enough for D
             Prop(Var("seats", "United States|US|senate|2026|general", "D/won"), "kalshi:W-51", "kalshi:W", "t",
                  spans=(Span(51, INF),)),  # seats won in one election are not seats held
             Prop(control, "polymarket:C-D", "polymarket:C", "t", values=frozenset({"party:D"})),
             Prop(control, "polymarket:C-R", "polymarket:C", "t", values=frozenset({"party:R"}))]
    ds = dv._seats_control(_by_var(props), KB)
    assert [(d.lhs, d.rhs, d.grounds) for d in ds] == [(["kalshi:S-51"], ["polymarket:C-D"], ["kb:us.senate.seats"])]
    assert dv._seats_control(_by_var(props), KnowledgeBase()) == []  # no chamber size in the KB: no rule


def test_the_margin_bridge_only_applies_where_the_most_votes_win():
    def race(state):
        subject = f"United States|{state}|senate|2026|general"
        return [Prop(Var("margin", subject, "R"), f"kalshi:M-{state}", f"kalshi:M{state}", "t",
                     spans=(Span(0, INF, False, False),)),
                Prop(Var("winner", subject), f"polymarket:W-{state}", f"polymarket:W{state}", "t",
                     values=frozenset({"party:R"}))]
    def gov(state):
        subject = f"United States|{state}|governor|2026|general"
        return [Prop(Var("margin", subject, "R"), f"kalshi:G-{state}", f"kalshi:G{state}", "t",
                     spans=(Span(0, INF, False, False),)),
                Prop(Var("winner", subject), f"polymarket:GW-{state}", f"polymarket:GW{state}", "t",
                     values=frozenset({"party:R"}))]
    by_var = _by_var(race("TX") + race("GA") + race("ME") + gov("ME"))
    got = {d.lhs[0]: d.grounds for d in dv._bridges(None, by_var, KB) if d.basis == "bridge_margin_winner"}
    # Georgia needs a majority (runoff); Maine ranks choices for federal offices but elects its governor by plurality
    assert got == {"kalshi:M-TX": [], "kalshi:G-ME": ["kb:us.election.method.me"]}
    assert not [d for d in dv._bridges(None, by_var, KnowledgeBase()) if d.basis == "bridge_margin_winner"]


def test_proofs_cite_the_rule_grounds():
    from pmpol.universe import pipeline

    def ev(venue, eid, title, rows, rules=""):
        return Event(venue, eid, title, mutually_exclusive=True, markets=[
            Market(venue, f"{eid}-{i}", eid, title, label, rules=rules, bid=b, ask=a, close_time="2028-11-08T00:00:00Z",
                   fee_rate=0.02) for i, (label, b, a) in enumerate(rows)])
    events = [ev("kalshi", "KXPRES-28", "2028 Presidential Election Winner",
                 [("JD Vance", 0.40, 0.42), ("Gavin Newsom", 0.20, 0.22)]),
              ev("polymarket", "republican-nominee-2028", "Republican Presidential Nominee 2028",
                 [("JD Vance", 0.30, 0.32), ("Marco Rubio", 0.20, 0.22)])]
    res = pipeline.run(events, depth=False, entities=False, observed_at="2026-10-02T12:00+00:00", kb=KB)
    nominee = [r for r in res.rule_relations if r.template.endswith(":winner_implies_nominee")]
    assert nominee, [r.template for r in res.rule_relations]
    sigs = [s for s in res.rule_signals if s.payload["id"].startswith("onto:winner:winner_implies_nominee")]
    assert sigs  # Vance: 40% to win the presidency vs 32% to be nominated is a violation
    p = res.proofs[sigs[0].payload["id"]]
    assert "winner_runs_as_listed_party_nominee" in p.result["assumptions"] and p.check() == [] and p.grounded
    assert any(st.id == "axiom:monotonicity" and st.layer == "L0" for st in p.steps)


def test_more_than_half_the_votes_implies_winning_a_directly_elected_office():
    from pmpol.universe.index import Universe

    race = "United States|VA|senate|2026|general"
    share = Var("vote_share", race, "m warner")
    events = [Event("kalshi", "S", "Virginia Senate election: Mark Warner vote percent", markets=[
                  Market("kalshi", f"S-{n}", "S", "q", f"At least {n}%") for n in (50, 52)]),
              Event("gemini", "W", "Virginia US Senate Winner", markets=[Market("gemini", "W-1", "W", "q", "Mark Warner")])]
    u = Universe.build(events)
    who = frozenset({"person:local:United States|VA|senate|2026|mark warner"})
    props = [Prop(share, "kalshi:S-50", "kalshi:S", "t", spans=(Span(50, INF),)),  # exactly 50% could be a tie
             Prop(share, "kalshi:S-52", "kalshi:S", "t", spans=(Span(52, INF),)),
             Prop(Var("winner", race), "gemini:W-1", "gemini:W", "t", values=who)]
    got = [(d.lhs, d.rhs) for d in dv._majority_wins(u, _by_var(props), KB)]
    assert got == [(["kalshi:S-52"], ["gemini:W-1"])]
    county = Var("vote_share", "United States|VA/Fairfax County|senate|2026|general", "m warner")
    props.append(Prop(county, "kalshi:C-60", "kalshi:C", "t", spans=(Span(60, INF),)))  # a county decides nothing
    assert [(d.lhs, d.rhs) for d in dv._majority_wins(u, _by_var(props), KB)] == got
