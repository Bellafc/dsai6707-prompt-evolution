from datetime import date

from pmpol import recession as rc
from pmpol.kb import KnowledgeBase
from pmpol.models import Event, Market

CSV = "observation_date,A191RL1Q225SBEA\n" + "\n".join(
    f"{1990 + i // 4}-{(i % 4) * 3 + 1:02d}-01,{v}" for i, v in enumerate(
        [2, 1, -1, -2, 1, 2, 3, -1, 1, 2, -0.5, -0.5, 2, 2, 2, 2]))  # pairs at 1990Q3-Q4 and 1992Q3-Q4

KALSHI = ("If there are two consecutive quarters of negative GDP growth in Q4 1993 through Q4 1994, according to the "
          "Bureau of Economic Analysis, then the market resolves to Yes.")
POLY = ("This market will resolve to “Yes” if either of the following conditions is met: 1. The seasonally adjusted "
        "annualized percent change in quarterly U.S. real GDP from the previous quarter is less than 0.0 for two "
        "consecutive quarters between Q2 1993 and Q2 1994 (inclusive), as reported by the Bureau of Economic Analysis "
        "2. The NBER announces a recession")


def _growth(tmp_path):
    return rc.fetch(cache=tmp_path, get=lambda url: CSV, today=date(2026, 10, 5))


def test_base_rates_count_completed_pairs_after_each_kind_of_quarter(tmp_path):
    g = _growth(tmp_path)
    assert g[0] == ("1990Q1", 2.0) and g[-1] == ("1993Q4", 2.0)
    assert rc.completes_pair([1, -1, -1], False) and rc.completes_pair([-1], True) and not rc.completes_pair([-1, 1, -1], False)
    rates = rc.base_rates(g, max_n=2)
    # after a negative quarter (1990Q3, 1991Q4, 1992Q3), the next quarter completes the pair 2 times of 3
    assert rates["neg"][1] == [2, 3]
    assert rates["pos"][1] == [0, rates["pos"][1][1]]  # one quarter cannot complete a pair after a positive one


def test_windows_are_read_from_the_rules_and_scored_against_what_is_published(tmp_path):
    w = rc.read_window(KALSHI)
    assert (rc.q_name(w.first), rc.q_name(w.last), w.wider) == ("1993Q4", "1994Q4", False)
    wp = rc.read_window(POLY)
    assert (rc.q_name(wp.first), rc.q_name(wp.last), wp.wider) == ("1993Q2", "1994Q2", True)
    assert rc.read_window("Japan's real GDP ... two consecutive quarters", "Japan recession") is None
    assert rc.read_window("If the NBER declares a recession") is None
    g = _growth(tmp_path)
    rates = rc.base_rates(g)
    o = rc.outlook(wp, g, rates)
    assert [q for q, _ in o.known] == ["1993Q2", "1993Q3", "1993Q4"] and o.unknown == 2 and not o.decided
    assert o.base_rate == rates["pos"][2][0] / rates["pos"][2][1]
    decided = rc.outlook(rc.Window(rc.q_index("1992Q1"), rc.q_index("1994Q4"), False), g, rates)
    assert decided.decided and decided.base_rate == 1.0


def test_the_outside_view_proof_puts_market_base_rate_and_model_side_by_side(tmp_path):
    from pmpol.universe import pipeline
    from pmpol.universe.index import Universe

    g = _growth(tmp_path)
    kbdir = tmp_path / "kb"
    kbdir.mkdir()
    (kbdir / "r.yaml").write_text(rc.kb_yaml(g, rc.base_rates(g), date(2026, 10, 5)), encoding="utf-8")
    kb = KnowledgeBase.load(kbdir)
    assert kb.errors == [] and rc.rates_from_kb(kb) == rc.base_rates(g) and rc.growth_from_kb(kb) == g
    m = Market("polymarket", "us-rec", "e", "US recession by mid 1994?", "", bid=0.10, ask=0.12, rules=POLY, active=True)
    u = Universe.build([Event("polymarket", "e", "US recession by mid 1994?", markets=[m])])
    (macro := tmp_path / "data" / "macro").mkdir(parents=True)
    (macro / "regimes.json").write_text('[{"title": "殖利率曲線推估的衰退機率（美國，未來 12 個月）", '
                                        '"result": {"probability": 0.14}}]', encoding="utf-8")
    (v,) = pipeline.recession_views(u, kb, tmp_path / "data")
    assert v.model == 0.14 and v.outlook.unknown == 2
    p = pipeline.explain_recession(v, "2026-10-05T12:00", kb)
    assert p.grounded and p.check() == [] and p.result["fundamentals_p"] == 0.14 and p.result["wider"]
    assert "technical_recession_reference_class" in p.result["assumptions"]
    assert "不低於技術性衰退的機率" in next(s.text for s in p.steps if s.id == "compare")
