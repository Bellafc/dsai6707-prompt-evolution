from datetime import date
from types import SimpleNamespace as NS

from pmpol import presidential as pr
from pmpol.kb import KnowledgeBase
from pmpol.universe.pipeline import explain_president_view, president_views

KB = KnowledgeBase.load()

CENSUS = """Table 402. Vote Cast for President by Major Political Party: 1952 to 2008
[In thousands (61,552 represents 61,552,000), except percent and electoral vote.]
1952. . . .    Stevenson. . . .         Eisenhower. . .              61,552            27,315        44.4            89     33,779        54.9                              442
1964. . . .    Johnson. . . . . .       Goldwater . . . .            70,098            42,825        61.1          486      27,147        38.7                               52
     Include votes for minor party candidates.
Table 403. Vote Cast for Leading Minority Party Candidates for President:
1968. . . .    Humphrey . . . .         Nixon. . . . . . . .         73,027            30,989        42.4          191      31,710        43.4                              301
"""

FEC = """                        2020 PRESIDENTIAL POPULAR VOTE SUMMARY
                 FOR ALL CANDIDATES LISTED ON AT LEAST ONE STATE BALLOT
Candidate (Party Label)                                                         Popular Vote Total    Percent of Popular Vote

Joseph R. Biden (Democrat, Working Families)                                            81,283,501                       51.31%
Donald J. Trump (Republican, Conservative)                                              74,223,975                       46.85%
Jo Jorgensen (Libertarian, Independent)                                                  1,865,535                        1.18%
"""

RESULTS = """         OFFICIAL 2024 PRESIDENTIAL GENERAL ELECTION RESULTS
STATE    ELECTORAL   ELECTORAL VOTES CAST FOR            ELECTORAL VOTES CAST FOR
           VOTES        DONALD J. TRUMP (R)                 KAMALA D. HARRIS (D)
AL             9                 9
Total:       538                   312                             226
STATE         EVERYLOVE   FRUIT       GARRITY               HARRIS      HUBER    KENNEDY
AL                                                           772,412               12,075
Total:           2,653     4,118          5,297            75,017,613    2,196    756,393
STATE          WEST     WOOD     NONE OF THESE           WRITE-IN VOTES   TOTAL VOTES
Total:         82,644    1,144          19,625               210,381       155,238,302
STATE          STODDEN     SUPREME                TERRY            TRUMP       WELLS
Total:            364         921                  41,294         77,302,580     359
"""


def test_parsers():
    c = pr.parse_census(CENSUS)
    assert sorted(c) == [1952, 1964]  # stops at the next table
    assert c[1952]["D"] == 27_315_000 and c[1952]["R_candidate"] == "Eisenhower" and c[1964]["D_ev"] == 486
    f = pr.parse_fec_summary(FEC)
    assert f["D"] == 81_283_501 and f["R"] == 74_223_975 and f["R_candidate"] == "Donald J. Trump"
    r = pr.parse_fec_results(RESULTS)
    assert r["D"] == 75_017_613 and r["R"] == 77_302_580 and r["R_candidate"] == "Donald J. Trump"


TERMS = [{"president": "A Smith", "start": "1993-01-20", "end": "2001-01-20"},
         {"president": "B Jones", "start": "2001-01-20", "end": "2005-01-20"},
         {"president": "B Jones", "start": "2005-01-20", "end": "2009-01-20"},
         {"president": "C Brown", "start": "2009-01-20", "end": None}]
PARTY = {"A Smith": "D", "B Jones": "R", "C Brown": "D"}


def test_record_and_base_rates():
    votes = {1996: {"D": 55, "R": 45, "D_candidate": "Smith", "R_candidate": "Dole"},  # 1989 unknown: terms_held None
             2000: {"D": 51, "R": 49, "D_candidate": "Gore", "R_candidate": "Jones"},
             2004: {"D": 48, "R": 52, "D_candidate": "Kerry", "R_candidate": "B. Jones"},
             2008: {"D": 53, "R": 47, "D_candidate": "Brown", "R_candidate": "McCain"}}
    rows = pr.record(votes, TERMS, PARTY)
    assert [(r["year"], r["party"], r["running"], r["terms_held"], r["kept"]) for r in rows] == [
        (1996, "D", True, None, True),
        (2000, "D", False, 2, False),  # A Smith's party since 1993
        (2004, "R", True, 1, True),
        (2008, "R", False, 2, False)]
    assert rows[1]["share"] == 51.0
    rates = pr.base_rates(rows)
    assert rates["all"]["kept"] == 2 and rates["first_term"] == {"kept": 1, "n": 1, "share": 1.0,
                                                                 "wilson95": rates["first_term"]["wilson95"]}
    assert rates["open_seat"]["n"] == 2


def test_fit_recovers_a_line():
    rows = [{"year": y, "share": 50 + 2 * g} for y, g in ((1960, 1.0), (1964, 2.0), (1968, 3.0), (1972, 0.5))]
    monthly = {}
    for y, g in ((1960, 1.0), (1964, 2.0), (1968, 3.0), (1972, 0.5)):
        for m in range(1, 9):
            monthly[f"{y - 1}-{m:02d}"] = 100.0
            monthly[f"{y}-{m:02d}"] = 100.0 * (1 + g / 100)
    rows[1]["share"] += 0.1  # a residual, so sigma > 0
    m = pr.fit(rows, monthly)
    assert abs(m.b - 2) < 0.2 and m.n == 4 and 0 < m.p_above_half(0.0) < 0.6 < m.p_above_half(2.0)


def test_outside_view_2028_and_proof():
    v = pr.outside_view(KB, 2028)
    assert v is not None and v.party == "R" and not v.eligible and v.first_term
    assert pr.outside_view(KB, 2026) is None
    mk = lambda o: NS(outcome=o, venue="cryptocom", market_id="x", question="Which party wins?")  # noqa: E731
    g = "winner(United States|US|president|2028|general)"
    rows = [NS(group=g, markets=[mk("Democratic")], recalibrated=None, pooled=0.55, disagree=True),
            NS(group=g, markets=[mk("JD Vance (R)")], recalibrated=0.2, pooled=0.2, disagree=False)]
    views = president_views(rows, KB)
    assert len(views) == 1 and views[0].markets == {"D": (0.55, True)} and abs(views[0].market - 0.45) < 1e-9
    p = explain_president_view(views[0], "2026-10-07T00:00:00Z", KB)
    assert not p.check() and p.grounded
    assert any(s.layer == "L0" for s in p.steps) and any(s.id == "both" and "2024" in s.text for s in p.steps)


def test_elected_times_counts_inaugurations_only():
    terms = [{"president": "X", "start": "1963-11-22", "end": "1965-01-20"},
             {"president": "X", "start": "1965-01-20", "end": "1969-01-20"}]
    assert pr.elected_times(terms, "X", date(1968, 11, 5)) == 1
