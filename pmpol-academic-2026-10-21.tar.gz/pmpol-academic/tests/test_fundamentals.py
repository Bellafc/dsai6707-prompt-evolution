from datetime import date

from pmpol import fundamentals as fm
from pmpol.kb import KnowledgeBase


def _monthly(growth_by_year: dict[int, float]) -> dict[str, float]:
    out, level = {}, 100.0
    for y in range(1960, 2027):
        level *= 1 + growth_by_year.get(y, 2.0) / 100
        for m in range(1, 13):
            out[f"{y}-{m:02d}"] = level
    return out


def test_income_growth_and_a_fixed_simple_model(tmp_path):
    mon = _monthly({2010: -1.0, 2014: 3.0})
    assert abs(fm.income_growth(mon, 2014) - 3.0) < 1e-9 and fm.income_growth(mon, 1950) is None
    pts = ((1962, 2.0), (1966, 4.0), (1970, 0.0), (1974, -2.0), (1978, 3.0), (1982, 1.0))
    rows = [{"year": y, "change": int(-30 + 5 * g) + (1 if i % 2 else -1)} for i, (y, g) in enumerate(pts)]
    mon = _monthly({1962: 2.0, 1966: 4.0, 1970: 0.0, 1974: -2.0, 1978: 3.0, 1982: 1.0})
    m = fm.fit(rows, mon)
    assert m.n == 6 and abs(m.b - 5) < 0.5 and m.r2 > 0.95
    assert m.p_at_least(4.0, -20) > 0.9 and m.p_at_least(-2.0, -20) < 0.1
    text = fm.kb_yaml(m, 2026, 1.0, -2, date(2026, 10, 5), "2026-08")
    (tmp_path / "f.yaml").write_text(text, encoding="utf-8")
    kb = KnowledgeBase.load(tmp_path)
    assert fm.FACT in kb.facts and kb.facts[fm.FACT].value["sample"] == "1962-1982, 6 midterms"


def test_fetch_reads_fred_csv_and_caches(tmp_path):
    csv = "observation_date,A229RX0\n2026-01-01,100\n2026-02-01,.\n"
    got = fm.fetch(tmp_path, get=lambda url: csv, today=date(2026, 10, 5))
    assert got == {"2026-01": 100.0}
    assert fm.fetch(tmp_path, get=lambda url: (_ for _ in ()).throw(AssertionError), today=date(2026, 10, 5)) == got
