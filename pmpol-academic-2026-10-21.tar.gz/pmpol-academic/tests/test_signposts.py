import json
import sqlite3
from datetime import date
from types import SimpleNamespace

import pytest

from pmpol import signposts as sp


def _conn(snaps):
    """snaps: [(ts, {subject: {market key: mid}})] as consensus signals."""
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE signals (ts TEXT, module TEXT, kind TEXT, subject TEXT, edge REAL, payload TEXT)")
    for ts, rows in snaps:
        for subject, mids in rows.items():
            conn.execute("INSERT INTO signals VALUES (?, 'consensus', 'estimate', ?, 0, ?)",
                         (ts, subject, json.dumps({"mids": mids})))
    return conn


def _moves(member_follows: bool, n: int = 40):
    a, b = {}, {}
    for i in range(n):
        d = 0.01 * ((i % 7) - 3)
        a[f"s{i}"] = {"polymarket:x": 0.5, "polymarket_us:x": 0.5, "kalshi:x": 0.5}
        b[f"s{i}"] = {"polymarket:x": 0.5 + d, "polymarket_us:x": 0.5 + (d if member_follows else 0.01 * ((i % 5) - 2)),
                      "kalshi:x": 0.5 + d / 2 + 0.003 * ((i % 3) - 1)}
    return [("2026-10-03T10:00+00:00", a), ("2026-10-03T10:30+00:00", a), ("2026-10-03T12:00+00:00", b)]


@pytest.mark.parametrize("follows,state", [(True, "ok"), (False, "triggered")])
def test_family_comovement_signpost(follows, state):
    ctx = sp.Context(date(2026, 10, 4), conn=_conn(_moves(follows)))
    s = sp.Signpost("fam", "venue_family", "family_change_corr", "<", 0.0, "m", "a",
                    {"family": "polymarket", "member": "polymarket_us", "other": "kalshi"})
    (r,) = sp.measure([s], ctx)
    assert r.state == state and "1 組快照配對" in r.detail  # the 30-minute pair is too close to count


def test_kb_age_dates_and_missing_readings(tmp_path):
    kb = SimpleNamespace(facts={"calibration.a": SimpleNamespace(id="calibration.a", recorded_at=date(2026, 8, 1)),
                                "calibration.b": SimpleNamespace(id="calibration.b", recorded_at=date(2026, 10, 1))})
    ctx = sp.Context(date(2026, 10, 4), kb, tmp_path)
    assert sp.kb_age_days(ctx, prefix="calibration.")[0] == 64.0
    assert sp.kb_age_days(ctx, fact="nope")[0] is None
    assert sp.days_since(ctx, "2026-11-10")[0] == -37.0
    s = sp.Signpost("gap", "midterm_reference_class", "outside_view_gap", ">", 0.25, "m", "a", {"group": "g"})
    (r,) = sp.measure([s], ctx)
    assert r.state == "no_data"


def test_readings_are_kept_with_the_previous_value_and_unconfigured_ones_dropped():
    conn = _conn([])
    s = sp.Signpost("d", "x", "days_since", ">", 0, "m", "act", {"date": "2026-10-01"})
    sp.record(conn, sp.measure([s], sp.Context(date(2026, 10, 4), conn=conn)), "2026-10-04T00:00")
    (r,) = sp.measure([s], sp.Context(date(2026, 10, 5), conn=conn))
    assert (r.previous, r.value, r.state) == (3.0, 4.0, "triggered")
    assert sp.latest(conn, {"d"})[0][:3] == ("d", "x", "triggered") and sp.latest(conn, {"other"}) == []
    text = sp.render([r], {"x": 150, "y": 120}, sp.uncovered([s], {"x": 150, "y": 120, "z": 5}), "now")
    assert "行動：act" in text and "`y`（120 份證明）" in text and "`z`" not in text


def test_shipped_signposts_load():
    assert {s.assumption for s in sp.load()} >= {"family_correlation", "venue_family"}


def test_persistence_hysteresis_and_state_changes_are_logged():
    conn = _conn([])
    s = sp.Signpost("g", "x", "days_since", ">", 0, "m", "a", {"date": "2026-10-05"}, persist=2, clear=-2)
    states = []
    for day in (4, 6, 7, 6, 4, 2):  # readings -1, 1, 2, 1, -1, -3
        (r,) = sp.measure([s], sp.Context(date(2026, 10, day), conn=conn))
        sp.record(conn, [r], f"2026-10-05T{len(states):02d}:00")  # in recording order
        states.append(r.state)
    # beyond once: watch; twice: triggered; back to -1: still triggered (clears only below -2); -3: ok
    assert states == ["ok", "watch", "triggered", "triggered", "triggered", "ok"]
    log = sp.events(conn)
    assert [(f, t) for _, _, _, f, t, _ in reversed(log)] == [("new", "ok"), ("ok", "watch"), ("watch", "triggered"),
                                                             ("triggered", "ok")]
    assert "狀態變化紀錄" in sp.render([r], {}, [], "now", log)


def test_a_clear_level_on_the_wrong_side_is_refused(tmp_path):
    p = tmp_path / "s.toml"
    p.write_text('[[signpost]]\nid = "a"\nassumption = "x"\nmetric = "days_since"\nargs = { date = "2026-01-01" }\n'
                 'op = ">"\nthreshold = 0\nclear = 1\nmeaning = "m"\naction = "a"\n', encoding="utf-8")
    with pytest.raises(ValueError):
        sp.load(p)
