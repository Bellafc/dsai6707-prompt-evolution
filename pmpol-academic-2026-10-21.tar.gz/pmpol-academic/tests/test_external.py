import json
from datetime import date, datetime, timezone

from pmpol import external, requirements

NOW = datetime(2026, 10, 6, 12, tzinfo=timezone.utc)
LAST_BET = int(datetime(2026, 10, 5, tzinfo=timezone.utc).timestamp() * 1000)
RAW = {"id": "abc", "slug": "pm-out", "question": "Will the PM cease to be PM during 2026?", "outcomeType": "BINARY",
       "probability": 0.29, "uniqueBettorCount": 70, "volume": 24455.0, "lastBetTime": LAST_BET,
       "isResolved": False, "token": "MANA", "creatorId": "u1", "creatorName": "A Person", "creatorUsername": "aperson",
       "creatorAvatarUrl": "https://img/x.png", "url": "https://manifold.markets/aperson/pm-out",
       "textDescription": "Resolves YES if the PM\nceases to be PM for 14 consecutive days."}
EVENTS = [{"venue": "polymarket", "event_id": "pm-out-by", "title": "PM out by...?", "markets": [
    {"venue": "polymarket", "market_id": "pm-out-dec-31", "event_id": "pm-out-by", "outcome": "December 31",
     "bid": 0.41, "ask": 0.42, "rules": "Resolves Yes if the PM ceases to be PM for any period;\nan announcement counts."}]}]


def _pair(**kw):
    base = dict(id="pm_2026", requirement="israel_2026", slug="pm-out", market="polymarket:pm-out-dec-31",
                differences="the market counts an announcement", broader="market")
    return external.Pair(**{**base, **kw})


def test_config_pairs_name_a_market_key_and_a_question():
    cfg = external.load()
    ids = {r.id for r in requirements.load()}
    assert cfg.pairs and cfg.views
    assert all(p.requirement in ids and ":" in p.market for p in cfg.pairs)
    assert all(v.requirement in ids and len(v.iso) == 3 for v in cfg.views)


def test_manifold_creator_data_is_dropped_on_read(tmp_path):
    m = external.manifold("pm-out", date(2026, 10, 6), get=lambda url: json.dumps(RAW), cache=tmp_path)
    stored = (tmp_path / "20261006_manifold_pm-out.json").read_text()
    assert "aperson" not in stored and "A Person" not in stored and "creatorId" not in stored and "u1" not in stored
    assert m["probability"] == 0.29 and m["rules"].startswith("Resolves YES if the PM ceases")
    # second read comes from the cache, no request
    assert external.manifold("pm-out", date(2026, 10, 6), get=None, cache=tmp_path) == m


def test_pair_proof_compares_and_checks_the_direction_the_definitions_predict():
    m = external.clean_manifold(RAW)
    event, market = external.find_market(EVENTS, "polymarket:pm-out-dec-31")
    p = external.pair_proof(_pair(), m, event, market, None, "2026-10-06T12:00+00:00", now=NOW)
    assert p.check() == [] and p.grounded
    assert p.result["gap"] == round(0.29 - 0.415, 4) and p.result["rules"] == "material"
    alt = {a["hypothesis"]: a["verdict"] for a in p.alternatives}
    assert alt["差距來自定義不同"] == "supports"  # the broader market is priced higher
    assert alt["Manifold 價格太舊或交易者太少"] == "against"
    assert p.confidence()[0] == "low"  # materially different rules
    assert "\n" not in "".join(s.text for s in p.steps)  # rule texts flattened for the tables
    # the narrower side priced higher contradicts the definitions
    q = external.pair_proof(_pair(broader="external"), m, event, market, None, "2026-10-06T12:00+00:00", now=NOW)
    assert {a["hypothesis"]: a["verdict"] for a in q.alternatives}["差距來自定義不同"] == "against"


def test_small_gaps_and_thin_or_missing_prices_are_not_overread():
    m = external.clean_manifold({**RAW, "probability": 0.405, "uniqueBettorCount": 12})
    event, market = external.find_market(EVENTS, "polymarket:pm-out-dec-31")
    p = external.pair_proof(_pair(), m, event, market, None, "2026-10-06T12:00+00:00", now=NOW)
    alt = {a["hypothesis"]: a["verdict"] for a in p.alternatives}
    assert alt["差距來自定義不同"] == "unchecked" and alt["Manifold 價格太舊或交易者太少"] == "supports"
    assert any("交易者少於" in c for c in p.caveats)
    gone = external.pair_proof(_pair(market="polymarket:nope"), m, None, None, None, "", now=NOW)
    assert gone.result["gap"] is None and gone.conclusion.startswith("比不了")


def test_multiple_choice_answers_and_consensus_rows():
    m = external.clean_manifold({**RAW, "probability": None, "outcomeType": "MULTIPLE_CHOICE",
                                 "answers": [{"text": "Democratic Party", "probability": 0.63, "userId": "u9"}]})
    assert external.manifold_p(m, "Democratic Party") == 0.63 and external.manifold_p(m, "Other") is None
    assert "u9" not in json.dumps(m)
    rows = [{"kind": "consensus", "id": "consensus:x", "markets": ["polymarket:pm-out-dec-31"], "proof": {"conclusion": "c"}}]
    assert external.consensus_for(rows, "polymarket:pm-out-dec-31")["id"] == "consensus:x"
    assert external.consensus_for(rows, "kalshi:y") is None


def test_views_latest_run_and_country_proof(tmp_path):
    assert external.latest_run(["fatalities002_2025_12_t01", "fatalities003_2026_08_t01", "fatalities003_2026_07_t01",
                                "predictors_fatalities003_0000_00", "r_2021_12_01"]) == "fatalities003_2026_08_t01"
    rows = [{"name": "Iran", "year": 2026, "month": m, "main_dich": d, "main_mean": n}
            for m, d, n in ((9, 0.99, 82.7), (10, 1.0, 125.1), (11, 1.0, 128.6), (12, 0.98, 140.0), (1, 0.5, 9.0))]
    rows[-1]["year"] = 2027

    def get(url):
        if url.endswith("/"):
            return json.dumps({"runs": ["fatalities003_2026_08_t01"]})
        assert "fatalities003_2026_08_t01/cm?iso=IRN" in url
        return json.dumps({"data": rows})

    run, data = external.views(["IRN"], date(2026, 10, 6), get=get, cache=tmp_path)
    c = external.ViewsCountry("IRN", "hormuz", "context")
    p = external.views_proof(c, run, data["IRN"], date(2026, 10, 6))
    assert [m["month"] for m in p.result["months"]] == ["2026-10", "2026-11", "2026-12"]  # from this month, three
    assert "98–100%" in p.conclusion and "125–140 人" in p.conclusion
    assert p.check() == [] and p.grounded


def test_export_feeds_the_requirements_external_line(tmp_path):
    m = external.clean_manifold(RAW)
    event, market = external.find_market(EVENTS, "polymarket:pm-out-dec-31")
    p = external.pair_proof(_pair(), m, event, market, None, "2026-10-06T12:00+00:00", now=NOW)
    data = tmp_path / "data"
    assert external.export([("pm_2026", "israel_2026", p)], data / "external.json") == 1
    row = json.loads((data / "external.json").read_text())["signals"][0]
    assert row["subject"] == "external:israel_2026" and row["markets"] == ["polymarket:pm-out-dec-31"]
    ev = requirements.gather(data)
    req = next(r for r in requirements.load() if r.id == "israel_2026")
    cov = requirements.cover(req, ev)
    assert cov.lines["external"] == 1 and "external" not in cov.gaps and cov.external
    assert "外部預測" in requirements.render([cov], (0, 0), "t")
    text = external.render([("pm_2026", "israel_2026", p)], "t")
    assert "| pm_2026 | israel_2026 | 29.0%（70 人） | 41.5% | -12.5 | 市場較寬 |" in text


def test_manifold_resolved_questions_keep_no_creator_and_flag_early_closes():
    import httpx

    from pmpol.ground_truth import manifold as mf

    DAY = mf.DAY_MS
    close = 1_790_000_000_000
    good = {"id": "a", "question": "Will X happen by October 5, 2026?", "resolution": "YES", "token": "MANA", "uniqueBettorCount": 40,
            "closeTime": close, "resolutionTime": close - 5 * DAY, "createdTime": close - 60 * DAY, "volume": 900,
            "creatorName": "Some Name", "creatorUsername": "someone", "creatorAvatarUrl": "x.png"}
    thin = {**good, "id": "b", "uniqueBettorCount": 5}
    cancel = {**good, "id": "c", "resolution": "CANCEL"}
    calls = []

    def get(path, params):
        calls.append((path, params))
        if path == "/search-markets":
            if params["offset"] >= 1000:  # the API refuses pages past its deepest offset
                raise httpx.HTTPStatusError("400", request=httpx.Request("GET", "x"), response=httpx.Response(400))
            return [good, thin, cancel] + [{**good, "id": f"z{i}", "uniqueBettorCount": 1} for i in range(997)]
        t = params["beforeTime"]
        return [{"probAfter": 0.9 if t > close - 6 * DAY else 0.6}]

    rows = mf.resolved(10, get=get, pause=0)
    assert [m["id"] for m in rows] == ["a"] and "creatorName" not in rows[0] and "creatorUsername" not in rows[0]
    r = mf.to_resolved(rows[0], get=get, pause=0)
    assert r.early and r.early_status == "early" and r.result == 1 and r.venue == "manifold"  # resolved 2026-09-16
    assert r.close_time.startswith("2026") and r.prices == {"1": 0.6, "7": 0.6, "30": 0.6}  # from the resolution
    assert "Some Name" not in json.dumps(r.to_dict())


def test_manifold_calibration_check_reads_the_fact():
    from types import SimpleNamespace as NS

    assert external.calibration_check(None)[0] == "unchecked"
    fact = NS(id="calibration.manifold.politics.h7", value={"slope_b": 0.7, "slope_b_se": 0.05, "n": 800,
                                                           "brier": 0.12}, recorded_at="2026-10-07")
    kb = NS(facts={fact.id: fact})
    verdict, text, fid = external.calibration_check(kb)
    assert verdict == "supports" and "過度自信" in text and fid == fact.id
    fact.value["slope_b"] = 0.95
    assert external.calibration_check(kb)[0] == "against"
    # against the paired real-money venue: both underconfident by about as much -> no play-money bias
    fact.value.update(slope_b=1.37, slope_b_se=0.165)
    ref = NS(id="calibration.polymarket.politics.h7", value={"slope_b": 1.29, "slope_b_se": 0.08}, recorded_at="x")
    kb.facts[ref.id] = ref
    assert external.calibration_check(kb)[0] == "supports"  # versus 1
    verdict, text, _ = external.calibration_check(kb, venue="polymarket")
    assert verdict == "against" and "polymarket" in text
    m = external.clean_manifold(RAW)
    event, market = external.find_market(EVENTS, "polymarket:pm-out-dec-31")
    p = external.pair_proof(_pair(), m, event, market, None, "2026-10-06T12:00+00:00", now=NOW, kb=kb)
    assert any(s.id == "ext_calibration" for s in p.steps) and p.check() == []


def test_manifold_dates_and_templates():
    from datetime import date

    from pmpol.ground_truth import manifold as mf

    assert mf.scheduled("Trump out before 2027?") == date(2026, 12, 31)
    assert mf.scheduled("Gas at $4.38 or more on October 5 2026?") == date(2026, 10, 5)
    assert mf.scheduled("Will Pappas win the 2026 primary?") is None  # names no deadline: not used
    ms = [{"id": "1", "question": "Gas at $4.38 or more on October 5 2026?", "uniqueBettorCount": 30},
          {"id": "2", "question": "Gas at $4.42 or more on October 5 2026?", "uniqueBettorCount": 50},
          {"id": "3", "question": "Will Pappas win the 2026 primary?", "uniqueBettorCount": 90}]
    assert [m["id"] for m in mf.pick(ms)] == ["2"]  # one per template, the one with most traders
    assert mf.pick(ms, {mf.template(ms[0]["question"])}) == []
