import json

from pmpol.entities import wd_peps
from pmpol.entities.wd_peps import Person
from pmpol.propositions.people import Label, identify, parse_name


def _lab(market, event, label, race, office, country="United States", jurisdiction=None, national=False):
    return Label(market, event, race, race, national, parse_name(label), country, office, jurisdiction or race.split("|")[1])


def test_office_evidence_links_a_qid_but_a_name_alone_does_not():
    wd = [Person("Q5607720", "Gretchen Whitmer", ["us"], "1971", positions=[{"name": "Governor of Michigan"}]),
          Person("Q6846094", "Mike Bouchard", ["us"], "1956",
                 positions=[{"name": "member of the State Senate of Michigan"}])]
    gov = "United States|MI|governor|2026|general"
    house = "United States|MI-10|house|2026|general"
    labels = [_lab("k:w", "e1", "Gretchen Whitmer", gov, "governor"),
              _lab("k:b", "e2", "Michael Bouchard Jr.", house, "house"),
              _lab("p:b", "e3", "Mike Bouchard (R)", house, "house")]
    ids = identify(labels, wd_people=wd)
    assert ids.of["k:w"] == "Q5607720"
    # Wikidata's Mike Bouchard (a former state senator, the father) is not the MI-10 candidate (the son) ...
    assert not ids.of["k:b"].startswith("Q")
    # ... but the two ways of writing the candidate are one person
    assert ids.of["k:b"] == ids.of["p:b"]


def test_father_and_son_stay_apart():
    wd = [Person("Q22686", "Donald Trump", ["us"], "1946", positions=[{"name": "President of the United States"}])]
    race = "United States|US|president|2028|primary/R|republican"
    labels = [_lab("a", "e1", "Donald Trump", race, "president", jurisdiction="US", national=True),
              _lab("b", "e2", "Donald Trump Jr.", race, "president", jurisdiction="US", national=True),
              _lab("c", "e3", "Donald J. Trump", "None|None|2028|primary|republican", None, jurisdiction="",
                   national=False),
              _lab("d", "e3x", "Donald J. Trump Jr.", "None|None|2028|primary|republican", None, jurisdiction="",
                   national=False)]
    ids = identify(labels, wd_people=wd)
    assert ids.of["a"] == "Q22686" and not ids.of["b"].startswith("Q")
    assert ids.of["c"] != ids.of["d"]  # different events, no QID here, but Jr. is a different person


def test_two_people_with_one_name_in_one_event():
    race = "United States|AK|senate|2026|general"
    labels = [_lab("k1", "K", "Dan Sullivan", race, "senate"), _lab("k2", "K", "Daniel J. Sullivan", race, "senate"),
              _lab("p1", "P", "Sen. Dan Sullivan", race, "senate"), _lab("p2", "P", "Daniel J. Sullivan Jr.", race, "senate"),
              _lab("g1", "G", "Dan Sullivan", race, "senate")]
    ids = identify(labels)
    assert ids.of["k1"] == ids.of["p1"] == ids.of["g1"]
    assert ids.of["k2"] == ids.of["p2"] != ids.of["k1"]


def test_congress_namesakes_need_the_state():
    # Wikidata's position "United States representative" has no state: a namesake from Pennsylvania must not
    # become South Carolina's candidate
    wd = [Person("Q6045035", "John E. Peterson", ["us"], "1938",
                 positions=[{"name": "United States representative"}])]
    ids = identify([_lab("x", "e", "John Peterson", "United States|SC-06|house|2026|general", "house")], wd_people=wd)
    assert not ids.of["x"].startswith("Q")


def test_national_races_accept_the_only_politician_of_that_name():
    wd = [Person("Q37181", "Luiz Inácio Lula da Silva", ["br"], "1945", positions=[{"name": "President of Brazil"}]),
          Person("Q999", "Ciro Gomes", ["br"], "1957", positions=[{"name": "federal deputy of Ceará"}])]
    race = "Brazil|Brazil|president|2026|general"
    ids = identify([_lab("c", "e", "Ciro Gomes", race, "president", "Brazil", "Brazil", national=True),
                    _lab("l", "e", "Luiz Inacio Lula da Silva", race, "president", "Brazil", "Brazil", national=True)],
                   wd_people=wd)
    assert ids.of["c"] == "Q999" and ids.of["l"] == "Q37181"


def test_spelling_variants_join_short_names_do_not():
    race = "Bulgaria|Bulgaria|president|2026|general"
    labels = [_lab("a", "e1", "Nataliya Kiselova", race, "president", "Bulgaria", "Bulgaria"),
              _lab("b", "e2", "Natalia Kiselova", race, "president", "Bulgaria", "Bulgaria"),
              _lab("c", "e1", "Dan Smith", race, "president", "Bulgaria", "Bulgaria"),
              _lab("d", "e2", "Don Smith", race, "president", "Bulgaria", "Bulgaria")]
    ids = identify(labels)
    assert ids.of["a"] == ids.of["b"] and ids.of["c"] != ids.of["d"]


def test_compact_extract(tmp_path):
    rows = [
        {"id": "Q1", "schema": "Person", "properties": {"name": ["Gretchen Whitmer"], "citizenship": ["us"],
                                                         "birthDate": ["1971-08-23"]}},
        {"id": "Q2", "schema": "Person", "properties": {"name": ["Someone Else"], "citizenship": ["us"]}},
        {"id": "P1", "schema": "Position", "properties": {"name": ["Governor of Michigan"], "country": ["us"]}},
        {"id": "O1", "schema": "Occupancy", "properties": {"holder": ["Q1"], "post": ["P1"], "startDate": ["2019"]}},
    ]
    raw = tmp_path / "wd.json"
    raw.write_text("\n".join(json.dumps(r, separators=(",", ":")) for r in rows))
    people = wd_peps.compact(raw, {"whitmer"}, str.lower)
    assert [p.qid for p in people] == ["Q1"]
    assert people[0].positions[0]["name"] == "Governor of Michigan" and people[0].birth == "1971-08-23"
    wd_peps.save(people, tmp_path / "c.json")
    assert wd_peps.load(tmp_path / "c.json")[0].name == "Gretchen Whitmer"


def test_a_candidacy_in_this_very_election_links_a_newcomer():
    from pmpol.entities import wikidata

    raw = {"results": {"bindings": [
        {"person": {"value": "http://www.wikidata.org/entity/Q1"}, "personLabel": {"value": "Wei Chia-hsien"},
         "election": {"value": "http://www.wikidata.org/entity/Q100"},
         "electionLabel": {"value": "2026 Hualien County magistrate election"}, "date": {"value": "2026-11-28T00:00:00Z"},
         "officeLabel": {"value": "Magistrate of Hualien County"}, "jurLabel": {"value": "Hualien County"}},
        {"person": {"value": "http://www.wikidata.org/entity/Q2"}, "personLabel": {"value": "Dan Osborn"},
         "election": {"value": "http://www.wikidata.org/entity/Q200"},
         "electionLabel": {"value": "2026 United States Senate election in Nebraska"},
         "date": {"value": "2026-11-03T00:00:00Z"}, "officeLabel": {"value": "United States senator"},
         "jurLabel": {"value": "Nebraska"}},
        {"person": {"value": "http://www.wikidata.org/entity/Q3"}, "personLabel": {"value": "Q3"},  # no label
         "election": {"value": "http://www.wikidata.org/entity/Q100"}, "date": {"value": "2026-11-28T00:00:00Z"}}]}}
    cands = wikidata.parse(raw)
    assert [c.qid for c in cands] == ["Q1", "Q2"] and cands[0].offices == ["Magistrate of Hualien County"]
    hualien = "Taiwan|Taiwan/Hualien|local|2026|general"
    labels = [_lab("p:w", "e1", "Wei Chia-hsien", hualien, "local", country="Taiwan", jurisdiction="Taiwan/Hualien"),
              _lab("k:o", "e2", "Dan Osborn", "United States|NE|senate|2026|general", "senate"),
              # the same name in another state's Senate race, or in the next cycle, is not this candidacy
              _lab("k:x", "e3", "Dan Osborn", "United States|IA|senate|2026|general", "senate"),
              _lab("k:y", "e4", "Wei Chia-hsien", "Taiwan|Taiwan/Hualien|local|2030|general", "local",
                   country="Taiwan", jurisdiction="Taiwan/Hualien")]
    ids = identify(labels, candidacies=cands)
    assert ids.of["p:w"] == "Q1" and "candidate in this election" in ids.how["p:w"]
    assert ids.of["k:o"] == "Q2"
    assert not ids.of["k:x"].startswith("Q") and not ids.of["k:y"].startswith("Q")
    # two living people of one name standing in one election: no identity from the candidacy
    twin = wikidata.Candidacy("Q9", "Wei Chia-hsien", "Q100", "x", 2026, ["Magistrate of Hualien County"], [])
    fresh = _lab("p:w", "e1", "Wei Chia-hsien", hualien, "local", country="Taiwan", jurisdiction="Taiwan/Hualien")
    assert not identify([fresh], candidacies=cands + [twin]).of["p:w"].startswith("Q")


def test_candidacy_refresh_stops_on_a_refusal(tmp_path):
    import pytest

    from pmpol.entities import wikidata

    path = tmp_path / "c.json"
    path.write_text("[]")

    def refuse(query):
        raise RuntimeError("403 Please respect our robot policy")

    with pytest.raises(RuntimeError):
        wikidata.refresh(path, get=refuse)
    assert path.read_text() == "[]"  # the previous file stays
    assert wikidata.load(tmp_path / "missing.json") == []
