import numpy as np

from pmpol.senate.config import load_config
from pmpol.senate.model import ClusterSeatModel, RaceInput, SeatModel, census_divisions

CFG = load_config()


def _races():
    rng = np.random.default_rng(1)
    return [RaceInput(r.state, (lambda p: {"D": p, "I": 0.0, "R": 1 - p})(float(rng.uniform(0.1, 0.9))), 1.0)
            for r in CFG.races]


def test_divisions_cover_every_state():
    d = census_divisions()
    assert len(d) == 51 and d["MI"] == d["OH"] == "east_north_central" and d["ME"] == "new_england"
    assert all(r.state in d for r in CFG.races)


def test_cluster_model_reduces_to_one_factor_and_adds_within_group_dependence():
    races = _races()
    one = SeatModel(CFG, races, 0.3)
    two = ClusterSeatModel(CFG, races, 0.3, 0.0, census_divisions())
    assert abs(one.prob_control("D") - two.prob_control("D")) < 1e-3
    assert abs(one.prob_all_of(["MI", "GA"], "D") - two.prob_all_of(["MI", "GA"], "D")) < 1e-6
    c = ClusterSeatModel(CFG, races, 0.1, 0.4, census_divisions())
    flat = SeatModel(CFG, races, 0.1)
    # same division (MI, IL): more joint wins than the national factor alone; different divisions: unchanged
    assert c.prob_all_of(["MI", "IL"], "D") > flat.prob_all_of(["MI", "IL"], "D") + 0.01
    assert abs(c.prob_all_of(["MI", "GA"], "D") - flat.prob_all_of(["MI", "GA"], "D")) < 1e-3
    assert abs(c.joint.sum() - 1) < 1e-9


def test_education_loadings_and_batched_fetch(tmp_path):
    from pmpol.senate import demographics as dm

    calls = []

    def get(url):
        ids = url.split("id=")[1].split(",")
        calls.append(len(ids))
        head = "observation_date," + ",".join(ids)
        vals = ",".join(str(65.5 if i.endswith("DC") else 30 + (hash(i[-2:]) % 15)) for i in ids)
        return f"{head}\n2023-01-01,{vals}\n2024-01-01,{vals}\n"

    shares = dm.fetch(tmp_path, get)
    assert len(shares) == 51 and max(calls) <= dm.BATCH
    ld = dm.loadings(shares)
    assert "DC" not in ld and max(abs(v) for v in ld.values()) == 1.0


def test_loading_model_reduces_to_one_factor_and_signs_matter():
    from pmpol.senate.model import LoadingSeatModel

    races = _races()
    one = SeatModel(CFG, races, 0.3)
    zero = LoadingSeatModel(CFG, races, 0.3, 0.0, {})
    assert abs(one.prob_control("D") - zero.prob_control("D")) < 1e-3
    flat = SeatModel(CFG, races, 0.1)
    m = LoadingSeatModel(CFG, races, 0.1, 0.5, {"MI": 1.0, "GA": 1.0, "WV": -1.0})
    assert m.prob_all_of(["MI", "GA"], "D") > flat.prob_all_of(["MI", "GA"], "D") + 0.02  # alike: together
    assert m.prob_all_of(["MI", "WV"], "D") < flat.prob_all_of(["MI", "WV"], "D") - 0.02  # opposite loadings
