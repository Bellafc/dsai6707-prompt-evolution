import json
from datetime import date, timedelta

from pmpol.models import Event, Market
from pmpol.osint.portwatch import parse
from pmpol.settlement import decide, read
from pmpol.settlement import report as settle_report


def _m(venue, outcome, rules, mid=0.5, strike=None, stype=None):
    return Market(venue, f"{venue}-{outcome}", "e", "q", outcome, rules=rules, bid=mid - 0.01, ask=mid + 0.01,
                  floor_strike=strike, strike_type=stype)


def _daily(start: date, values):
    return {start + timedelta(days=i): v for i, v in enumerate(values)}


K_SUM = ("If the number of transit calls through the Strait of Hormuz as reported by the IMF PortWatch is above 20 "
         "from Sep 21, 2026 to Sep 27, 2026, then the market resolves to Yes. The total is calculated by summing daily counts.")
PM_WEEK = ("This market will resolve according to the total number of transit calls that IMF Portwatch reports for the "
           "Strait of Hormuz for all days from September 28, 2026, through October 4, 2026, inclusive.")
PM_NORMAL = ("This market will resolve to “Yes” if IMF Portwatch publishes a 7-day moving average of transit calls "
             "(“Arrivals of Ships”) for the Strait of Hormuz equal to or above 60 for any date between market "
             "creation and December 31, 2026.")
K_MONTH = ("If the highest daily number of transit calls through the Strait of Hormuz as reported by the IMF PortWatch "
           "is at least 5 in Sep 2026, then the market resolves to Yes.")


def test_reading_and_deciding_on_published_days():
    daily = _daily(date(2026, 1, 1), [70] * 59 + [3] * 211)  # normal until Feb, then the strait almost closes
    assert max(daily) == date(2026, 9, 27)
    c = read(_m("kalshi", "Above 20", K_SUM, strike=20.0, stype="greater"))
    assert c.stat == "sum" and c.lo == 20 and c.lo_open and c.end == date(2026, 9, 27)
    d = decide(c, daily)
    assert d.state == "yes" and d.value == 21 and d.complete  # 7 x 3 = 21 > 20
    # next week's buckets: nothing published yet -> open
    wk = read(_m("polymarket", "20-24", PM_WEEK))
    assert (wk.lo, wk.hi) == (20, 24) and decide(wk, daily).state == "open"
    # a month high already reached in the published part is decided before the month ends
    mh = decide(read(_m("kalshi", "At least 5", K_MONTH, strike=5.0, stype="greater_or_equal")),
                {**daily, date(2026, 9, 10): 8})
    assert mh.state == "yes" and not mh.complete


def test_unknown_creation_date_never_decides_yes_from_old_data():
    daily = _daily(date(2026, 1, 1), [70] * 59 + [3] * 211)  # 7-day average was >= 60 in January
    c = read(_m("polymarket", "", PM_NORMAL))
    assert c.start is None and c.stat == "max_ma7" and c.lo == 60
    assert decide(c, daily).state == "open"  # January would say YES; the market did not exist then


def test_report_flags_prices_against_decided_data(tmp_path):
    daily_json = json.dumps({"features": [{"attributes": {"date": f"2026-09-{d:02d}", "portname": "Strait of Hormuz",
                                                          "n_total": 3, "n_tanker": 1}} for d in range(1, 28)]})
    assert len(parse(daily_json, "hormuz")) == 27
    ev = Event("kalshi", "KXHORMUZ", "Traffic through the Strait of Hormuz? (9/21 - 9/27)", markets=[
        _m("kalshi", "Above 20", K_SUM, mid=0.30, strike=20.0, stype="greater")])
    checks, data, unread = settle_report.run([ev], fetch_text=lambda url: daily_json, cache=tmp_path)
    (ch,) = checks
    assert ch.decision.state == "yes" and ch.decision.value == 21 and round(ch.mismatch, 2) == 0.70
    page = settle_report.render(checks, data, unread, "t")
    assert "已確定但價格偏離 ≥ 5 點：**1**" in page
    p = settle_report.explain(ch, "t")
    assert p.check() == [] and p.grounded and any("International Monetary Fund" in c for c in p.caveats)


EIA_HTML = ("<tr> <td class='B6'>&nbsp;&nbsp;2026-Sep</td> <td class='B5'>09/18&nbsp;</td> <td class='B3'>284,552&nbsp;</td>"
            " <td class='B5'>09/25&nbsp;</td> <td class='B3'>283,767&nbsp;</td> <td class='B5'>&nbsp;</td>"
            " <td class='B3'>&nbsp;</td></tr>")
K_CRUDE = ("If U.S. commercial crude oil inventories for the week ending Sep 25, 2026 are strictly above 422 million barrels, "
           "then the market resolves to Yes. The Underlying is the U.S. Commercial Crude Oil (Excl. Lease Stock) inventory "
           "level reported by the U.S. Energy Information Administration (EIA) for the week ending Sep 25, 2026.")
PM_SPR = ("This market will resolve to “Yes” if the U.S. Energy Information Administration publishes a weekly figure "
          "for U.S. Ending Stocks of Crude Oil in the Strategic Petroleum Reserve less than or equal to the specified value "
          "after market creation for any week ending on or before October 30, 2026.")


def test_eia_weekly_markets(tmp_path):
    from pmpol.macro.eia import parse

    assert parse(EIA_HTML) == {date(2026, 9, 18): 284552.0, date(2026, 9, 25): 283767.0}
    evs = [Event("kalshi", "KXCRUDE", "US crude oil inventories for the week ending September 25, 2026", markets=[
        _m("kalshi", "Above 422 million barrels", K_CRUDE, mid=0.40, strike=422.0, stype="greater")]),
        Event("polymarket", "spr", "Will US crude oil reserves fall to __ by October 30?", markets=[
            _m("polymarket", "280M", PM_SPR, mid=0.74), _m("polymarket", "290M", PM_SPR, mid=0.97)])]
    html = EIA_HTML.replace("283,767", "427,320")  # the commercial-stocks page
    checks, data, _ = settle_report.run(evs, fetch_text=lambda url: html if "WCESTUS1" in url else EIA_HTML,
                                        cache=tmp_path)
    by = {ch.market.outcome: ch for ch in checks}
    crude = by["Above 422 million barrels"]
    assert crude.condition.stat == "value" and crude.decision.state == "yes" and round(crude.mismatch, 2) == 0.60
    # SPR: the window starts at market creation, so even 290M (already below) is not decided YES
    assert by["290M"].condition.hi == 290000 and by["290M"].decision.state == "open"
    assert by["280M"].decision.state == "open"


K_FRED = ("If the United States Consumer Price Index for All Urban Consumers: Shelter in U.S. City Average for August 2026 "
          "is above 429.7, then the market resolves to Yes. This market uses FRED series CUSR0000SAH1: Consumer Price "
          "Index for All Urban Consumers: Shelter in U.S. City Average, which is published monthly.")
K_TEMP = ("If All Employees, Temporary Help Services for August 2026 is above 2.420 million, according to FRED series "
          "TEMPHELPS, then the market resolves to Yes.")


def test_fred_month_values_and_unit_guard(tmp_path):
    csv = {"CUSR0000SAH1": "observation_date,CUSR0000SAH1\n2026-07-01,428.9\n2026-08-01,430.2\n",
           "TEMPHELPS": "observation_date,TEMPHELPS\n2026-08-01,2415\n"}
    evs = [Event("kalshi", "S", "US shelter CPI in August", markets=[
        _m("kalshi", "Above 429.7", K_FRED, mid=0.20, strike=429.7, stype="greater")]),
        Event("kalshi", "T", "Temporary-help employment in August", markets=[
            _m("kalshi", "Above 2.420 million", K_TEMP, mid=0.5, strike=2.42, stype="greater")])]
    checks, data, unread = settle_report.run(evs, fetch_text=lambda url: csv[url.rsplit("=", 1)[1]], cache=tmp_path)
    (ch,) = checks  # temp-help: strike in millions, series in thousands -> not read
    assert ch.condition.rule == "kalshi_fred_month" and ch.decision.state == "yes" and ch.decision.value == 430.2
    assert round(ch.mismatch, 2) == 0.80 and any("單位對不上" in k for k in unread)


def test_transformed_fred_markets_annual_totals_growth_and_touches():
    from datetime import date

    from pmpol.models import Market
    from pmpol.settlement import decide, read

    def mk(rules, outcome="Yes"):
        return Market("kalshi", "X", "E", "q", outcome, rules=rules)

    c = read(mk("If U.S. imports of goods by customs basis from China (FRED series IMPCH) in calendar year 2026 are "
                "below $220 billion, then the market resolves to Yes."))
    assert (c.series, c.stat, c.hi, c.hi_open) == ("fred:IMPCH", "sum", 220000.0, True)
    months = {date(2026, m, 1): 30000.0 for m in range(1, 9)}  # 240 bn by August: already past 220 bn
    assert decide(c, months).state == "no"
    g = read(mk("If the M2 money-supply growth for December 2026 is between 5.0% and 5.4%, then the market resolves "
                "to Yes. ... the year-over-year percent change ... calculated using FRED series M2SL."))
    assert (g.series, g.lo, g.hi, g.start) == ("fred:M2SL|yoy", 5.0, 5.4, date(2026, 12, 1))
    t = read(mk("If the real-time Sahm Rule Recession Indicator for any monthly observation from Issuance through "
                "December 2026 is At least 0.50, then the market resolves to Yes. ... FRED series SAHMREALTIME."))
    assert (t.stat, t.start, t.lo) == ("max", None, 0.5)
    assert decide(t, {date(2026, 3, 1): 0.6, date(2026, 8, 1): 0.1}).state == "open"  # issuance unknown: never YES
    assert read(mk("If FRED series ABCD in calendar year 2026 is above 5 widgets, then Yes.")) is None  # unknown unit
