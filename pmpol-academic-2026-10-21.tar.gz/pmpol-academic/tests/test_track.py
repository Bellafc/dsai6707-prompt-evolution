from pathlib import Path

from pmpol import track
from pmpol.models import Event, Market, Relation
from pmpol.universe.index import Universe
from pmpol.universe.pipeline import consensus_signal


def _ev(venue, d_mid, spread=0.02, race="NY02"):
    eid = f"{venue}-{race}"
    t = f"{race} House Election Winner 2026"
    return Event(venue, eid, t, mutually_exclusive=True, markets=[
        Market(venue, f"{eid}-D", eid, t, "Democratic Party", bid=d_mid - spread / 2, ask=d_mid + spread / 2,
               close_time="2026-11-04T00:00:00Z")])


def _rel(race="NY02"):
    return Relation("equivalent", [f"kalshi:kalshi-{race}-D"], [f"polymarket:polymarket-{race}-D"],
                    "cross_venue_winner", race, "rule")


def test_gap_convergence_and_who_moved():
    a = Universe.build([_ev("kalshi", 0.50), _ev("polymarket", 0.60), _ev("kalshi", 0.40, race="NY03"),
                        _ev("polymarket", 0.30, race="NY03")])
    b = Universe.build([_ev("kalshi", 0.51), _ev("polymarket", 0.52), _ev("kalshi", 0.40, race="NY03")])
    r = track.evaluate_pair((a, [_rel(), _rel("NY03")]), b, "2026-10-03T10:00+00:00", "2026-10-03T16:00+00:00")
    g = {("NY02" if "NY02" in o.relation else "NY03"): o for o in r.gaps}
    assert r.hours == 6 and g["NY02"].converged and g["NY03"].converged is None  # polymarket NY03 not observed
    moved = g["NY02"].closed_by()
    assert round(moved["polymarket"], 2) == 0.08 and round(moved["kalshi"], 2) == 0.01  # polymarket followed
    (o,) = [x for x in r.outliers if x.venue == "polymarket" and "NY02" in x.market]
    assert o.outlier_share > 0.5
    s = track.summarize([r], track.load_registry())
    assert s["cross_venue_gap_closes"]["n"] == 1 and s["cross_venue_gap_closes"]["not_observed"] == 1
    assert s["cross_venue_gap_closes"]["supported"] is None  # below min_n: no verdict
    assert s["cross_venue_gap_closes"]["prospective"] == 1  # snapshot taken on the registration day
    assert s["cross_venue_gap_closes"]["prospective_value"] == 1.0 and s["cross_venue_gap_closes"]["prospective_supported"] is None
    lead = track.leaders([r])[("kalshi", "polymarket")]
    assert lead["n"] == 1 and lead["polymarket"] > lead["kalshi"]
    page = track.render([r], track.load_registry(), "t")
    assert "樣本不足" in page and "誰往誰靠" in page and "等待結算" in page


def test_pairs_and_registry():
    snaps = [(t, Path(t)) for t in ("2026-10-02T10:00+00:00", "2026-10-02T10:30+00:00", "2026-10-02T12:00+00:00",
                                     "2026-10-02T20:00+00:00")]
    assert track.pick_pairs(snaps) == [(0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    claims = {c.id: c for c in track.load_registry()}
    assert {"cross_venue_gap_closes", "outlier_moves_to_consensus", "consensus_beats_best_venue"} <= set(claims)
    assert all(c.registered_at and c.supported_if for c in claims.values())


def test_consensus_estimate_is_storable():
    from pmpol.universe import consensus

    u = Universe.build([_ev("kalshi", 0.58, 0.10), _ev("polymarket", 0.60, 0.01)])
    (c,) = consensus.run(u, [_rel()], None)
    s = consensus_signal(c)
    assert s.module == "consensus" and s.payload["pooled"] and set(s.payload["mids"]) == {m.key for m in c.markets}


def test_silent_leads_are_followed_up_after_72_hours(tmp_path):
    from datetime import datetime, timezone

    from pmpol import store
    from pmpol.movers.diff import Move
    from pmpol.movers.news import NewsResult
    from pmpol.proof import Proof
    from pmpol.track import leads

    mv = Move("polymarket:m", "polymarket:e", "polymarket", "Next Mayor of Mangaung (Bloemfontein)?", "Werner Pretorius",
              "q", 0.41, 0.275, 0.02, 0.02, "2026-10-02T20:46:00+00:00", "2026-10-03T01:11:00+00:00", "political")
    silent, loud = Proof("a", "b", result={"silent": True}), Proof("a", "b", result={"silent": False})
    conn = store.connect(tmp_path / "db.sqlite")
    store.save_signals(conn, leads.lead_signals([(mv, silent), (mv, loud)]))
    calls = []

    def search(query, start, end, pad_hours=24):
        calls.append((query, start, end, pad_hours))
        if len(calls) == 1:
            return NewsResult(query, start, end, None, error="GDELT 429")  # not observed: must be retried
        return NewsResult(query, start, end, 2, articles=[{"title": "Mangaung council elects new mayor", "domain": "x"}],
                          source="gdelt")

    early = datetime(2026, 10, 4, 12, tzinfo=timezone.utc)
    assert leads.follow_up(conn, early, search) == {"due": 0, "checked": 0, "failed": 0}  # under 72 hours
    late = datetime(2026, 10, 6, 2, tzinfo=timezone.utc)
    assert leads.follow_up(conn, late, search)["failed"] == 1 and leads.summary(conn)["checked"] == 0
    assert leads.follow_up(conn, late, search)["checked"] == 1
    assert calls[-1][2].startswith("2026-10-06T01:11") and calls[-1][3] == 0  # window: the 72 hours after the move
    s = leads.summary(conn)
    assert s["leads"] == 1 and s["with_news"] == 1 and s["share"] == 1.0
    page = track.render([], track.load_registry(), "t", s)
    assert "沉默異動的後續" in page and "Mangaung council" in page and "待人工稽核" in page


def test_gap_half_lives_follow_the_chain_and_censor_what_is_not_seen():
    def u(k, p, k3=None, p3=None):
        evs = [_ev("kalshi", k), _ev("polymarket", p)]
        if k3 is not None:
            evs.append(_ev("kalshi", k3, race="NY03"))
        if p3 is not None:
            evs.append(_ev("polymarket", p3, race="NY03"))
        return Universe.build(evs), [_rel(), _rel("NY03")]

    chain = [("2026-10-03T00:00+00:00", u(0.50, 0.50, 0.40, 0.48)),  # NY03 open from the start (left-censored)
             ("2026-10-03T06:00+00:00", u(0.50, 0.60, 0.40, 0.47)),  # NY02 opens
             ("2026-10-03T12:00+00:00", u(0.50, 0.58, 0.40)),  # NY03's polymarket leg disappears: censored at 6h
             ("2026-10-04T00:00+00:00", u(0.50, 0.54, 0.40, 0.40))]  # NY02 halves after 18h; NY03 reopens? no gap
    sp = {s.relation.split("|")[0][:40]: s for s in track.spells(chain)}
    (ny02,) = [s for s in sp.values() if "NY02" in s.relation]
    (ny03,) = [s for s in sp.values() if "NY03" in s.relation]
    assert ny02.halved and ny02.hours == 18 and not ny02.left_censored
    assert not ny03.halved and ny03.hours == 6 and ny03.left_censored
    curve = track.kaplan_meier(list(sp.values()))
    assert curve == [(18.0, 0.0, 1)]  # NY03 left the risk set at 6h, before NY02 halved
    assert track.median_half_life(curve) == 18.0 and track.survival_at(curve, 12) == 1.0
    page = track.render([], track.load_registry(), "t", None, list(sp.values()))
    assert "半衰期中位數：18.0 小時" in page


def test_sign_tests_and_holm_correction():
    assert abs(track.binom_sf(8, 10) - 56 / 1024) < 1e-12 and track.binom_sf(0, 0) == 1.0
    adj = track.holm({"a": 0.01, "b": 0.04, "c": 0.03})
    assert adj == {"a": 0.03, "c": 0.06, "b": 0.06}  # step-down, kept monotone


def test_pre_news_drift_from_the_price_path(tmp_path):
    from datetime import datetime, timedelta, timezone

    from pmpol import store
    from pmpol.movers.diff import Move
    from pmpol.movers.news import NewsResult
    from pmpol.proof import Proof
    from pmpol.track import leads

    a = datetime(2026, 10, 2, 20, tzinfo=timezone.utc)
    news = a + timedelta(hours=10)
    path = [(int((a + timedelta(hours=h)).timestamp()), p) for h, p in ((0, 0.40), (5, 0.30), (10, 0.25), (30, 0.20))]
    assert leads.drift(path, a, news)[3] == 0.75  # 15 of the 20 points came before the first article
    assert leads.drift([(int(a.timestamp()), 0.4), (int(news.timestamp()), 0.41)], a, news)[3] is None  # too small

    mv = Move("polymarket:m", "polymarket:e", "polymarket", "T", "Yes", "q", 0.40, 0.30, 0.02, 0.02,
              a.isoformat(), (a + timedelta(hours=5)).isoformat(), "political")
    conn = store.connect(tmp_path / "db.sqlite")
    store.save_signals(conn, leads.lead_signals([(mv, Proof("a", "b", result={"silent": True}))]))

    def search(query, start, end, pad_hours=24):
        return NewsResult(query, start, end, 1, articles=[{"title": "x", "seendate": news.strftime("%Y%m%dT%H%M%SZ")}],
                          source="gdelt")

    def get(url, params):
        if "gamma" in url:
            return [{"clobTokenIds": '["tok1", "tok2"]'}]
        assert params["market"] == "tok1"
        return {"history": [{"t": t, "p": p} for t, p in path]}

    assert leads.follow_up(conn, a + timedelta(days=5), search, get)["checked"] == 1
    s = leads.summary(conn)
    assert s["drift"] == {"n": 1, "median": 0.75, "mostly_before": 1} and s["rows"][0]["pre_news_share"] == 0.75
    assert s["by_venue"] == {"polymarket": [1, 1]}
