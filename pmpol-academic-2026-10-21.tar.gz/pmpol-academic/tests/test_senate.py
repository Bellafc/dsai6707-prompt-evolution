import numpy as np
import pytest

from pmpol.fourier import convolve_outcomes
from pmpol.models import Event, Market
from pmpol.senate.config import load_config
from pmpol.senate.model import RaceInput, SeatModel
from pmpol.senate.observables import parse_count_label
from pmpol.senate.races import classify, race_quote

CFG = load_config()


def test_config_registry_is_complete():
    assert len(CFG.races) == 35
    assert CFG.race("KY").kalshi == "SENATELA-26"  # Kalshi's ticker naming trap
    assert CFG.race("LA").kalshi == "KXSENATELA-26NOV"
    assert sum(r.held_by == "D" for r in CFG.races) == 13


@pytest.mark.parametrize("label,values,expected", [
    ("Below 45", [44, 45], [True, False]),
    ("Above 52", [52, 53], [False, True]),
    ("At least 17", [16, 17], [False, True]),
    ("≤47", [47, 48], [True, False]),
    ("57+", [56, 57], [False, True]),
    ("50", [49, 50, 51], [False, True, False]),
])
def test_count_labels(label, values, expected):
    pred = parse_count_label(label)
    assert list(pred(np.array(values))) == expected


def test_unknown_label_is_not_guessed():
    assert parse_count_label("Democratic Party") is None


def _m(venue, mid, outcome, question="", bid=0.4, ask=0.42):
    return Market(venue=venue, market_id=mid, event_id="E", question=question, outcome=outcome, bid=bid, ask=ask)


def test_classify_outcomes():
    ne, ak = CFG.race("NE"), CFG.race("AK")
    assert classify(_m("kalshi", "SENATENE-26-DOSB", "Dan Osborn"), ne) == "I"
    assert classify(_m("kalshi", "SENATENE-26-R", "Pete Ricketts"), ne) == "R"
    assert classify(_m("polymarket", "x", "Independent", "Will an independent win the Nebraska Senate race?"), ne) == "I"
    assert classify(_m("polymarket", "x", "Jim Risch (R)", "Will the Republicans win"), CFG.race("ID")) == "R"
    assert classify(_m("polymarket", "x", "Mary Peltola", "Will Mary Peltola win"), ak) == "D"
    assert classify(_m("polymarket", "x", "Ann Diener", "Will Ann Diener win"), ak) == "O"


def test_race_quote_normalises_and_drops_other():
    ak = CFG.race("AK")
    ev = Event("polymarket", "alaska", "AK", markets=[
        _m("polymarket", "a", "Mary Peltola", bid=0.70, ask=0.72),
        _m("polymarket", "b", "Sen. Dan Sullivan", bid=0.28, ask=0.30),
        _m("polymarket", "c", "Ann Diener", bid=0.0, ask=0.002),
    ])
    q = race_quote(ev, ak)
    assert q.probs["D"] == pytest.approx(0.71 / 1.0)
    assert sum(q.probs.values()) == pytest.approx(1.0)
    assert q.dropped == pytest.approx(0.001)


def _model(rho, probs=None):
    probs = probs or [0.5] * 35
    races = [RaceInput(r.state, {"D": p, "I": 0.0, "R": 1 - p}, 0.5) for r, p in zip(CFG.races, probs)]
    return SeatModel(CFG, races, rho)


def test_independent_model_matches_poisson_binomial():
    rng = np.random.default_rng(1)
    p = rng.uniform(0.02, 0.98, 35)
    model = _model(0.0, list(p))
    pb = convolve_outcomes([[((1,), q), ((0,), 1 - q)] for q in p])
    expected = pb[CFG.d_control_seats - CFG.d_holdover:].sum()
    assert model.prob_control("D") == pytest.approx(expected, abs=1e-9)


def test_seat_totals_are_consistent():
    model = _model(0.3)
    assert model.joint.sum() == pytest.approx(1.0)
    # With no independents, every seat goes to D or R.
    assert model.prob(model.d_total + model.r_total == 100) == pytest.approx(1.0)
    assert model.prob_control("D") + model.prob_control("R") == pytest.approx(1.0)


def test_joint_probability_rises_with_correlation():
    probs = [0.6] * 35
    lo, hi = _model(0.0, probs), _model(0.7, probs)
    states = ["GA", "MI", "NC", "ME"]
    assert lo.prob_all_of(states, "D") == pytest.approx(0.6 ** 4, abs=1e-9)
    assert hi.prob_all_of(states, "D") > lo.prob_all_of(states, "D") + 0.1


def test_t_copula_keeps_marginals_and_fattens_joint_tails():
    races = [RaceInput(r.state, {"D": 0.85, "I": 0.0, "R": 0.15}, 0.5) for r in CFG.races]
    g, t = SeatModel(CFG, races, 0.3), SeatModel(CFG, races, 0.3, nu=4)
    # each race's own probability is the market's under both copulas
    marg = np.einsum("k,kjc->jc", t.weights, t._cond)
    assert np.allclose(marg[:, 0], 0.85, atol=2e-3) and t.joint.sum() == pytest.approx(1.0)
    states = ["GA", "MI", "NC", "ME"]
    # the unlikely sweep (the underdog wins all four) is half again as likely at the same rho
    assert t.prob_all_of(states, "R") > 1.4 * g.prob_all_of(states, "R")
    # tail dependence even at rho = 0: one shared scale moves every race
    t0 = SeatModel(CFG, races, 0.0, nu=4)
    assert t0.prob_all_of(states, "R") > 1.5 * 0.15 ** 4


def test_analytic_spectrum_matches_the_fft_convolution_with_independents():
    from pmpol.copula import conditional_probs

    rng = np.random.default_rng(3)
    races = []
    for j, r in enumerate(CFG.races[:12]):
        i = 0.2 if j in (2, 5) else 0.0
        d = rng.uniform(0.1, 0.8) * (1 - i)
        races.append(RaceInput(r.state, {"D": d, "I": i, "R": 1 - d - i}, 0.7))
    m = SeatModel(CFG, races, 0.4, n_nodes=16)
    shape = m.joint.shape
    expected = np.zeros(shape)
    for z, w in zip(m.nodes, m.weights):
        trials = []
        for r in races:
            pd, pi, pr = conditional_probs([r.probs[c] for c in ("D", "I", "R")], 0.4, z)
            trials.append([((1, 0, 0), pd), ((0, 1, 0), pr), ((0, 0, 1), pi * r.caucus_d), ((0, 0, 0), pi * (1 - r.caucus_d))])
        expected += w * convolve_outcomes(trials, shape)
    assert np.allclose(m.joint, expected / expected.sum(), atol=1e-10)


def test_tail_fits_report_the_skew(monkeypatch):
    from pmpol.senate import analyze

    fits = iter([(0.2, 3.0), (0.3, 2.0)])
    monkeypatch.setattr(analyze, "fit_rho", lambda cfg, rows, priced, nu=None: next(fits))
    pm = lambda key, var: type("PM", (), {"market": type("M", (), {"key": key})(),  # noqa: E731
                                          "observable": type("O", (), {"variable": var})()})()
    priced = [pm("a", "all_of"), pm("b", "control"), pm("c", "d_total")]
    imp = iter([{"a": 0.7, "b": 0.2, "c": 0.3}, {"a": 0.7, "b": 0.3, "c": 0.3}])
    monkeypatch.setattr(analyze, "implied_rhos", lambda cfg, rows, priced, nu=None: next(imp))
    g, t = analyze.tail_fits(None, [], priced, nus=(None, 5.0))
    assert g.skew == pytest.approx(0.45) and t.skew == pytest.approx(0.4) and t.nu == 5.0 and t.loss == 2.0


def test_sweep_bounds_need_no_model():
    from pmpol.senate import analyze

    rows = [analyze.RaceRow(st, {}, {"D": p, "I": 0.0, "R": 1 - p}, 0.5)
            for st, p in (("GA", 0.96), ("MI", 0.73), ("NC", 0.97), ("ME", 0.57))]
    obs = type("O", (), {"variable": "all_of", "party": "D", "states": ["GA", "MI", "NC", "ME"]})()
    pm = type("PM", (), {"observable": obs, "market": type("M", (), {"key": "k:x", "mid": 0.51})()})()
    (b,) = analyze.sweep_bounds(rows, [pm])
    assert b.independent == pytest.approx(0.96 * 0.73 * 0.97 * 0.57) and b.lockstep == pytest.approx(0.57)
    assert b.position == pytest.approx((0.51 - b.independent) / (0.57 - b.independent))
