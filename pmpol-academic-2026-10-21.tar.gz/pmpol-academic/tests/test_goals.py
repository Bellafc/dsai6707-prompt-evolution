from datetime import date

from pmpol.goals import Goal, MarketRule, goal_proof, load_goals, match_markets
from pmpol.kb import KnowledgeBase
from pmpol.macro.regimes import MacroData
from pmpol.macro.sources import Fetched, Observation, SeriesSpec, parse_imf_sdmx
from pmpol.models import Event, Market

KB = KnowledgeBase.load()


def _ev(title, outcomes, venue="kalshi"):
    return Event(venue, title, title, markets=[
        Market(venue, f"{title}-{o}", title, title, o, bid=p - 0.01, ask=p + 0.01, close_time=c)
        for o, p, c in outcomes])


def test_config_rules_sign_markets_and_keep_others_out():
    (goal,) = [g for g in load_goals() if g.id == "usd_role"]
    events = [
        _ev("Will Trump try to fire Lisa Cook again?", [("Before Jan 1, 2027", 0.46, "2027-01-01")]),
        _ev("USD share of Swift international payments in December 2026", [("Above 57.0%", 0.94, "2027-01-21")]),
        _ev("Fed decision in Dec 2026?", [("Hike 25bps", 0.71, "2026-12-16")]),
        _ev("EU debt downgrade before 2027?", [("Yes", 0.1, "2027-01-01")]),
        _ev("Bank of Canada Rate Hike in 2026?", [("Yes", 0.3, "2027-01-01")]),
        _ev("Canadian counter-tariff rate on U.S. EVs at the end of 2026", [("Above 50%", 0.5, "2027-01-01")]),
        _ev("Golden Dome funded by 2027?", [("Yes", 0.5, "2027-01-01")]),
    ]
    signs = {e.title: r.sign for e, r in match_markets(goal, events)}
    assert signs == {"Will Trump try to fire Lisa Cook again?": -1,
                     "USD share of Swift international payments in December 2026": 1,
                     "Fed decision in Dec 2026?": 0}


def test_goal_proof_cites_stances_counterviews_indicators_and_markets():
    (goal,) = [g for g in load_goals() if g.id == "usd_role"]
    spec = SeriesSpec("us.usd_reserve_share", "imf_sdmx", "COFER", unit="%")
    macro = MacroData.from_fetched([Fetched(spec, "u", "2026-10-02T00:00:00", [
        Observation(spec.id, spec.ref, date(2025, 4, 1), 57.8), Observation(spec.id, spec.ref, date(2026, 4, 1), 56.7)])])
    events = [_ev("Kevin Warsh out as Fed chair?", [("Before Jan 1, 2027", 0.02, "2027-01-01"),
                                                    ("Before Jan 1, 2031", 0.78, "2031-01-01")])]
    p = goal_proof(goal, KB, events, macro, "2026-10-03T13:29")
    assert p.grounded and p.check() == []
    texts = "\n".join(s.text for s in p.steps)
    assert "反方觀點" in texts and "us.usd_reserve_share" in texts and "下降" in texts
    assert any(s.ref == "goal.usd_role.stance.white_house_genius" for s in p.steps)
    # Deadline ladders report the nearest deadline (2%), not the far one a term-end makes likely (78%).
    assert "Before Jan 1, 2027 2%" in texts and "78%" not in texts
    assert p.result["weaken"] == 1 and p.caveats


def test_rule_exclusions():
    r = MarketRule(pattern=r"\bgold\b", sign=0, exclude="golden")
    assert r.matches("What will gold hit by December?") and not r.matches("Golden Dome gold funding")
    assert match_markets(Goal("g", "g", markets=[r]), [_ev("Gold price", [("Above $5,000", 0.3, "x")])])


def test_parse_imf_sdmx():
    text = ('{"data":{"dataSets":[{"series":{"0:0:0:0:0":{"observations":{"0":["58.41",null],"1":["56.70",null]}}}}],'
            '"structures":[{"dimensions":{"observation":[{"id":"TIME_PERIOD","values":[{"value":"2024-Q4"},'
            '{"value":"2026-Q2"}]}]}}]}}')
    assert parse_imf_sdmx(text) == [(date(2024, 10, 1), 58.41), (date(2026, 4, 1), 56.70)]


def test_signposts_read_series_and_markets():
    from pmpol.goals import Signpost
    spec = SeriesSpec("us.usd_reserve_share", "imf_sdmx", "COFER", unit="%")
    macro = MacroData.from_fetched([Fetched(spec, "u", "t", [Observation(spec.id, spec.ref, date(2026, 4, 1), 54.0)])])
    g = Goal("usd_role", "x", signposts=[
        Signpost("share < 55", "series:us.usd_reserve_share", "<", 55.0),
        Signpost("swift > 57 below 50%", "market:usd share of swift", "<", 0.5, outcome="above 57"),
        Signpost("no data", "series:missing", ">", 1.0)])
    ev = _ev("USD share of Swift international payments in December 2026",
             [("Above 55.0%", 0.99, "2027-01-21"), ("Above 57.0%", 0.40, "2027-01-21")])
    p = goal_proof(g, KB, [ev], macro, "2026-10-03T13:29")
    assert p.result["signposts_crossed"] == 2 and p.result["signposts_checked"] == 2  # uses the 57% outcome, not 55%
    assert p.check() == [] and "預警指標 2 / 2 個觸發" in p.conclusion


def test_us_china_goal_sorts_red_lines_summits_and_means():
    from pmpol.goals import load_goals

    g = next(g for g in load_goals() if g.id == "us_china")
    sign = {t: next((r.sign for r in g.markets if r.matches(t)), None) for t in (
        "Will China invade Taiwan by end of 2026?", "US x China Military clash before 2027?",
        "Will the U.S. enact a free trade agreement with China?", "U.S. tariff rate on China on December 31, 2026?",
        "Will China unban Bitcoin by 2027?")}
    assert list(sign.values()) == [-1, -1, 1, 0, None]
    assert {s.source for s in g.signposts} >= {"market:invade taiwan", "market:us x china military clash"}


def test_markets_moving_together_against_a_goal_become_a_lead():
    from pmpol.goals import comovement, comovement_proof, load_goals
    from pmpol.models import Event, Market

    g = next(g for g in load_goals() if g.id == "us_china")

    def snap(shift):
        titles = ["Will China invade Taiwan by end of 2026?", "Will China blockade Taiwan in 2026?",
                  "US x China Military clash before 2027?", "Will the U.S. enact a free trade agreement with China?"]
        return [Event("polymarket", f"e{i}", t, markets=[Market("polymarket", f"m{i}", f"e{i}", t, "Yes",
                                                                bid=0.10 + (shift if i < 3 else 0), ask=0.12 + (shift if i < 3 else 0),
                                                                active=True)]) for i, t in enumerate(titles)]

    cm = comovement(g, snap(0.0), snap(0.03))
    assert cm.weaken == 3 and cm.strengthen == 0 and cm.direction == -1  # three red-line markets up 3 points
    p = comovement_proof(cm, None, "2026-10-04T00:00", "2026-10-04T12:00")
    assert p.grounded and p.check() == [] and p.result["markets"] == 3 and "沒有查新聞" in p.conclusion
    assert comovement(g, snap(0.0), snap(0.0)).direction == 0
