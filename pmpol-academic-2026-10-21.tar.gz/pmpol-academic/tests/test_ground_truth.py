import numpy as np
import pytest

from pmpol.ground_truth import Resolved, load, save
from pmpol.ground_truth.calibration import calibrate, recalibration
from pmpol.ground_truth.kalshi import candle_price, to_resolved as kalshi_resolved
from pmpol.ground_truth.polymarket import history_price, resolution, to_resolved as pm_resolved
from pmpol.ground_truth.report import kb_yaml, render


def test_candle_price_prefers_tight_mid_then_last_trade():
    candles = [
        {"end_period_ts": 100, "yes_bid": {"close": "0.40"}, "yes_ask": {"close": "0.44"}, "price": {"close": "0.41"}},
        {"end_period_ts": 200, "yes_bid": {"close_dollars": "0.10"}, "yes_ask": {"close_dollars": "0.60"},
         "price": {"close_dollars": "0.30"}},
    ]
    assert candle_price(candles, 150) == (0.42, "mid")  # historical schema
    assert candle_price(candles, 250) == (0.30, "last")  # live schema, spread too wide for a mid
    assert candle_price(candles, 50) == (None, "")


def test_kalshi_record_flags_early_close():
    m = {"ticker": "KXIRAN-X", "event_ticker": "KXIRAN", "result": "yes", "close_time": "2026-03-08T21:44:24Z",
         "expected_expiration_time": "2045-01-01T15:00:00Z", "can_close_early": True, "title": "Will X lead Iran?",
         "yes_sub_title": "X", "volume_fp": "38056.00"}
    day = 86400
    close = 1773006264
    candles = [{"end_period_ts": close - 2 * day, "yes_bid": {"close": "0.6"}, "yes_ask": {"close": "0.7"}}]
    r = kalshi_resolved(m, {"category": "Elections", "title": "Next Supreme Leader of Iran"}, candles)
    assert r.result == 1 and r.early and r.prices["1"] == 0.65 and r.prices["30"] is None
    assert kalshi_resolved({**m, "result": ""}, {}, candles) is None


def test_polymarket_resolution_and_record():
    base = {"outcomes": '["Yes", "No"]', "umaResolutionStatus": "resolved", "slug": "s", "question": "[Single Market] Q?",
            "closedTime": "2024-07-18 00:10:37.491895+00", "endDate": "2024-09-10T00:00:00Z",
            "events": [{"slug": "ev", "title": "Republican Nominee 2024"}], "volumeNum": 5000}
    assert resolution({**base, "outcomePrices": '["1", "0"]'}) == 1
    assert resolution({**base, "outcomePrices": '["0", "1"]'}) == 0
    assert resolution({**base, "outcomePrices": '["0.5", "0.5"]'}) is None
    assert resolution({**base, "outcomes": '["Trump", "Biden"]', "outcomePrices": '["1", "0"]'}) is None
    r = pm_resolved({**base, "outcomePrices": '["0", "1"]'}, {"1": 0.01, "7": 0.03, "30": None})
    assert r.result == 0 and r.early and r.question == "Q?" and r.close_time.startswith("2024-07-18T00:10")
    assert history_price([{"t": 10, "p": 0.2}, {"t": 20, "p": 0.3}, {"t": 30, "p": 0.9}], 25) == 0.3


def test_recalibration_recovers_a_known_slope():
    rng = np.random.default_rng(0)
    p = rng.uniform(0.02, 0.98, 20000)
    logit = np.log(p / (1 - p))
    true = 1 / (1 + np.exp(-(0.0 + 1.5 * logit)))  # prices compressed toward 50%: b = 1.5
    y = (rng.uniform(size=p.size) < true).astype(float)
    a, b, sa, sb = recalibration(p, y)
    assert b == pytest.approx(1.5, abs=4 * sb) and abs(a) < 4 * sa + 0.05


def test_calibration_summary_and_longshot_bias():
    p = [0.05] * 100 + [0.5] * 100 + [0.95] * 100
    y = [0] * 99 + [1] + [0] * 50 + [1] * 50 + [1] * 100
    c = calibrate(p, y)
    assert c.n == 300 and c.longshot_return == pytest.approx(0.01 - 0.05)
    assert c.favourite_return == pytest.approx(0.05) and c.skill > 0.5
    assert [b["n"] for b in c.bins] == [100, 100, 100]


def test_report_and_kb_yaml(tmp_path):
    import yaml
    rows = [Resolved("kalshi", f"m{i}", "e", "q", "o", "2026-01-01T00:00:00Z", "2026-01-01T00:00:00Z", False,
                     int(i % 3 == 0), 5000, "Politics", "elections_us", {"1": 0.33, "7": 0.3 + 0.001 * (i % 50),
                                                                         "30": 0.4}, {})
            for i in range(300)]
    save(rows, tmp_path / "k.jsonl")
    assert load(tmp_path / "k.jsonl")[5] == rows[5]
    text = render(rows, "now")
    assert "校準斜率" in text and "Kalshi" in text
    from datetime import date
    facts = yaml.safe_load(kb_yaml(rows, date(2026, 10, 3)))["facts"]
    assert facts and facts[0]["layer"] == "L2" and facts[0]["status"] == "proposed"


def test_refine_early_separates_backstops_from_real_early_closes():
    from pmpol.ground_truth import Resolved, refine_early

    def r(mid, eid, close, due, topic="us_government", early=True):
        return Resolved("kalshi", mid, eid, "q", "o", close, due, early, 0, topic=topic)

    rows = [
        # weekly series with a fixed 90-day backstop: on schedule
        r("w1", "KXHORMUZW-26OCT01", "2026-10-01T00:00:00Z", "2026-12-30T00:00:00Z"),
        r("w2", "KXHORMUZW-26OCT08", "2026-10-08T00:00:00Z", "2027-01-06T00:00:00Z"),
        # "out by" series: one market closed months before the others' gap -> early
        r("o1", "KXOUT-A", "2026-03-01T00:00:00Z", "2026-12-31T00:00:00Z"),
        r("o2", "KXOUT-B", "2026-12-01T00:00:00Z", "2026-12-31T00:00:00Z"),
        # single-event election, all options closed together when called -> on schedule
        r("e1", "KXGOV-26", "2026-11-04T05:00:00Z", "2026-12-15T00:00:00Z", "elections_us"),
        r("e2", "KXGOV-26", "2026-11-04T05:00:00Z", "2026-12-15T00:00:00Z", "elections_us"),
        # single-event, non-election: cannot tell
        r("u1", "KXALONE-26", "2026-05-01T00:00:00Z", "2026-12-31T00:00:00Z"),
        r("n1", "KXNOFLAG-1", "2026-05-01T00:00:00Z", "2026-12-31T00:00:00Z", early=False),
    ]
    counts = refine_early(rows)
    st = {x.market_id: x.early_status for x in rows}
    assert st["w1"] == st["w2"] == "on_schedule" and st["o1"] == "early" and st["e1"] == "on_schedule"
    assert st["u1"] == "unknown" and st["n1"] == "" and not rows[-1].early
    assert counts == {"early": 1, "on_schedule": 5, "unknown": 1}
    assert {x.market_id for x in rows if x.early} == {"o1", "u1"}  # unknown stays out of the clean sample
