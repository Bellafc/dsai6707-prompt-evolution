import subprocess
from datetime import datetime, timezone

from pmpol.kb import history

FACT = """facts:
  - id: us.house.majority
    layer: L0
    subject: House
    predicate: majority_seats
    value: {value}
    source: {{title: t, url: https://example.org}}
    admiralty: A1
    status: {status}
    recorded_at: 2026-10-02
"""


def _commit(repo, value, status, when):
    (repo / "kb" / "L0").mkdir(parents=True, exist_ok=True)
    (repo / "kb" / "L0" / "us.yaml").write_text(FACT.format(value=value, status=status))
    env = {"GIT_AUTHOR_DATE": when, "GIT_COMMITTER_DATE": when, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
           "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t", "PATH": "/usr/bin:/bin"}
    subprocess.run(["git", "add", "-A"], cwd=repo, check=True, env=env)
    subprocess.run(["git", "commit", "-qm", "kb"], cwd=repo, check=True, env=env)


def test_versions_and_past_states_come_from_git(tmp_path, monkeypatch):
    subprocess.run(["git", "init", "-q"], cwd=tmp_path, check=True)
    _commit(tmp_path, 218, "proposed", "2026-10-02T10:00:00+00:00")
    _commit(tmp_path, 218, "reviewed", "2026-10-03T10:00:00+00:00")
    _commit(tmp_path, 217, "reviewed", "2026-10-04T10:00:00+00:00")
    monkeypatch.setattr(history, "REPO", tmp_path)
    vs = history.versions("us.house.majority")
    assert [(v.change, v.value, v.status) for v in vs] == [("added", 218, "proposed"), ("changed", 218, "reviewed"),
                                                         ("changed", 217, "reviewed")]
    kb, sha = history.as_of(datetime(2026, 10, 3, 12, tzinfo=timezone.utc))
    assert kb.facts["us.house.majority"].status == "reviewed" and kb.facts["us.house.majority"].value == 218
    empty, none = history.as_of(datetime(2026, 10, 1, tzinfo=timezone.utc))
    assert empty.facts == {} and none is None
