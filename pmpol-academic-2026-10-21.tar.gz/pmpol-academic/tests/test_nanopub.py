import pytest

from pmpol import nanopub

ROW = {"id": "consensus:x", "proof": {
    "title": "跨平台共識｜X", "conclusion": "共識機率 61.0%\n第二行 \"引號\"", "layer": "L5", "grounded": True,
    "analytic_confidence": "moderate", "result": {"pooled": 0.61, "recalibrated": 0.6},
    "steps": [{"id": "", "layer": "L0", "kind": "rule", "text": "規則", "ref": "us.house.majority", "as_of": "",
               "inputs": []},
              {"id": "q", "layer": "L4", "kind": "data", "text": "報價 a b", "ref": "https://example.org/m?x=1 2",
               "as_of": "2026-10-04T12:15+00:00", "inputs": []},
              {"id": "calc", "layer": "L5", "kind": "logic", "text": "計算", "ref": "", "as_of": "", "inputs": ["q"]}]}}


def test_nanopub_has_four_graphs_and_keeps_the_layers():
    text = nanopub.document([ROW], {"us.house.majority"}, "2026-10-07T00:00:00Z", "abc123")
    assert text.count("np:hasAssertion") == 1 and 'pmpol:knowledgeLayer "L5"' in text
    assert 'pmpol:probability "0.6000"^^xsd:decimal' in text  # the recalibrated value first
    assert "kb#us.house.majority" in text and "%20" in text  # facts by id, URLs escaped
    rdflib = pytest.importorskip("rdflib")
    g = rdflib.Dataset()
    g.parse(data=text, format="trig")
    names = {str(c.identifier).rsplit("#", 1)[-1] for c in g.graphs() if "#" in str(c.identifier)}
    assert {"Head", "assertion", "provenance", "pubinfo"} <= names
    # the assertion derives from the steps no other step uses (the rule and the calculation, not the quote)
    q = """SELECT ?s WHERE { GRAPH ?g { ?a <http://www.w3.org/ns/prov#wasDerivedFrom> ?s } FILTER(STRENDS(STR(?a), "#assertion")) }"""
    fed = {str(r[0]).rsplit("#", 1)[-1] for r in g.query(q)}
    assert fed == {"step_s0", "step_calc"}


def test_the_iri_changes_with_the_content():
    a = nanopub.nanopub(ROW, set(), "2026-10-07T00:00:00Z")
    changed = {**ROW, "proof": {**ROW["proof"], "conclusion": "共識機率 62.0%"}}
    b = nanopub.nanopub(changed, set(), "2026-10-07T00:00:00Z")
    assert a.split("Head>")[0] != b.split("Head>")[0]
