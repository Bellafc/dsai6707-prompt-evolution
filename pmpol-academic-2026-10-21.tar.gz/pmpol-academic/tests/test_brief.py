import json

from pmpol import brief, store
from pmpol.models import Signal


def test_brief_reports_new_violations_silent_moves_and_track(tmp_path):
    conn = store.connect(tmp_path / "db.sqlite")
    old = [Signal("relations", "cross_venue_winner", "NY-02", 0.05, {"id": "w:1"}),
           Signal("relations", "cross_venue_winner", "NY-03", 0.04, {"id": "w:2"})]
    new = [Signal("relations", "cross_venue_winner", "NY-02", 0.06, {"id": "w:1"}),
           Signal("relations", "cross_venue_margin", "IN-01", 0.20, {"id": "m:9"})]
    store.save_signals(conn, old, observed_at="2026-10-03T01:11+00:00")
    store.save_signals(conn, new, observed_at="2026-10-03T09:19+00:00")
    latest, prev, fresh, gone = brief.new_violations(conn)
    assert latest.startswith("2026-10-03T09:19") and [sid for *_, sid in fresh] == ["m:9"] and gone == 1
    data = tmp_path / "data"
    data.mkdir()
    (data / "proofs.json").write_text(json.dumps({"signals": [
        {"id": "m:9", "title": "cross_venue_margin｜IN-01", "venues": ["K", "P"], "edge": 0.2}]}))
    (data / "movers.json").write_text(json.dumps({"signals": [
        {"kind": "silent_move", "title": "價格異動｜La Prairie", "proof": {"conclusion": "沉默異動"}}]}))
    reports = tmp_path / "reports"
    reports.mkdir()
    (reports / "2026-10-03_track.md").write_text(
        "## 1. 登記的主張\n| `x` | 1 | registry row |\n## 2. 結果\n| `cross_venue_gap_closes` | 759 | 5.7% |\n## 3. 配對\n")
    (reports / "2026-10-03_propositions.md").write_text(
        "有效市場 100 個，讀成命題的 74 個（74%）。\n現有模板產生 10 條關係。本體推出相同結論的 **9**（90.0%），"
        "結論不同的 **1**，本體還讀不懂的 0。\n共 50 條；其中**直接關係 20 條**。\n### 扣費後按可執行價計算的違反：3 條\n")
    page = brief.render(conn, reports, data)
    assert "手寫模板（交叉驗證）：一致 9（90.0%），不同 1（不同的每一條都要查" in page and "違反 3 條" in page
    assert "新出現 1 條、消失 1 條" in page and "IN-01" in page and "La Prairie" in page
    assert "| `cross_venue_gap_closes` | 759" in page and "registry row" not in page


def test_brief_with_no_earlier_snapshot_does_not_call_everything_new(tmp_path):
    conn = store.connect(tmp_path / "db.sqlite")
    from pmpol.models import Signal

    store.save_signals(conn, [Signal("relations", "x", "race", 0.1, {"id": "a"})], observed_at="2026-10-04T04:28+00:00")
    page = brief.render(conn, tmp_path / "reports", tmp_path / "data")
    assert "沒有上一個快照可比" in page and "新出現 1 條" not in page


def test_brief_leaves_out_cycle_steps(tmp_path):
    # the brief runs inside the cycle, which records its steps only at the end: a step row is the previous cycle's
    conn = store.connect(tmp_path / "db.sqlite")
    store.save_signals(conn, [Signal("relations", "x", "race", 0.1, {"id": "a"})], observed_at="2026-10-04T04:28+00:00")
    from pmpol import runs

    runs.health(conn)  # creates the tables
    conn.executemany("INSERT INTO source_health VALUES (?,?,?,?,?,?,?)",
                     [("r1", "step:people", 0, 0, 1.0, "exit code 1", "2026-10-04T04:27:00+00:00"),
                      ("r1", "macro:bcb", 0, 0, 1.0, "timeout", "2026-10-04T04:27:00+00:00")])
    page = brief.render(conn, tmp_path / "reports", tmp_path / "data")
    assert "`macro:bcb`" in page and "step:people" not in page
