from pmpol.constraints import check_deadlines, check_ladder, check_sums, threshold
from pmpol.models import Event, Market


def mk(mid, outcome, bid, ask, venue="kalshi", rules="", **kw):
    return Market(venue=venue, market_id=mid, event_id="E", question=outcome, outcome=outcome,
                  rules=rules, bid=bid, ask=ask, **kw)


def test_sum_bid_violation_on_exclusive_event():
    e = Event("kalshi", "E", "who wins", mutually_exclusive=True,
              markets=[mk("A", "A", 0.60, 0.62), mk("B", "B", 0.45, 0.47)])
    (s,) = check_sums(e)
    assert s.kind == "sum_bid" and abs(s.edge - 0.05) < 1e-9


def test_sum_ask_needs_tradeable_catch_all():
    legs = [mk("A", "A", 0.40, 0.45, venue="polymarket"), mk("B", "B", 0.30, 0.35, venue="polymarket")]
    no_other = Event("polymarket", "E", "who wins", mutually_exclusive=True, markets=legs)
    assert check_sums(no_other) == []
    other = mk("O", "Other", 0.05, 0.10, venue="polymarket")
    with_other = Event("polymarket", "E", "who wins", mutually_exclusive=True, markets=legs + [other])
    (s,) = check_sums(with_other)
    assert s.kind == "sum_ask" and abs(s.edge - 0.10) < 1e-9


def test_fees_reduce_margin():
    legs = [mk("A", "A", 0.60, 0.62, fee_rate=0.07), mk("B", "B", 0.45, 0.47, fee_rate=0.07)]
    e = Event("kalshi", "E", "who wins", mutually_exclusive=True, markets=legs)
    (s,) = check_sums(e)
    assert s.edge < 0.05


def test_threshold_units_and_structured_strikes():
    assert threshold(mk("x", "Above 1.10M", 0, 0)) == 1.10e6
    assert threshold(mk("x", "Above 620K", 0, 0)) == 620e3
    assert threshold(mk("x", "Above $1.2 billion", 0, 0)) == 1.2e9
    assert threshold(mk("x", "California Senate", 0, 0, strike_type="greater_or_equal", floor_strike=27)) == 27
    assert threshold(mk("x", "Between 3 and 4", 0, 0, strike_type="between", floor_strike=3)) is None


def test_ladder_only_within_same_underlying():
    rule = "If turnout is above {} then Yes."
    ladder = [mk("a", "Above 600K", 0.80, 0.82, rules=rule.format(600000)),
              mk("b", "Above 1.1M", 0.85, 0.90, rules=rule.format(1100000))]
    (s,) = check_ladder(Event("kalshi", "E", "turnout", markets=ladder))
    assert s.kind == "ladder" and abs(s.edge - 0.03) < 1e-9

    different = [mk("a", "CA", 0.07, 0.08, rules="If CA seats held is at least 27 then Yes.",
                    strike_type="greater_or_equal", floor_strike=27),
                 mk("b", "CO", 0.97, 0.98, rules="If CO seats held is at least 24 then Yes.",
                    strike_type="greater_or_equal", floor_strike=24)]
    assert check_ladder(Event("kalshi", "E", "supermajorities", markets=different)) == []


def test_deadline_ladder():
    early = mk("a", "June 30", 0.30, 0.32, venue="polymarket", close_time="2026-06-30T00:00:00Z")
    late = mk("b", "Dec 31", 0.20, 0.25, venue="polymarket", close_time="2026-12-31T00:00:00Z")
    (s,) = check_deadlines(Event("polymarket", "E", "X happens by ...?", markets=[early, late]))
    assert s.kind == "deadline" and abs(s.edge - 0.05) < 1e-9
