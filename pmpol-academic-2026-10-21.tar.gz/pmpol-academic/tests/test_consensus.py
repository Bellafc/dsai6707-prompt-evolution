import pytest

from pmpol.kb import Fact, KnowledgeBase, Source
from pmpol.models import Event, Market, Relation
from pmpol.universe import consensus
from pmpol.universe.index import Universe


def _ev(venue, d_mid, spread=0.02):
    eid = f"{venue}-NY02"
    t = "NY-02 House Election Winner 2026"
    return Event(venue, eid, t, mutually_exclusive=True, markets=[
        Market(venue, f"{eid}-D", eid, t, "Democratic Party", bid=d_mid - spread / 2, ask=d_mid + spread / 2,
               close_time="2026-11-04T00:00:00Z"),
        Market(venue, f"{eid}-R", eid, t, "Republican Party", bid=1 - d_mid - spread / 2, ask=1 - d_mid + spread / 2,
               close_time="2026-11-04T00:00:00Z")])


def _kb(b=1.2, a=-0.3):
    from datetime import date
    facts = {}
    for venue in ("polymarket", "kalshi"):
        fid = f"calibration.{venue}.politics.h30"
        facts[fid] = Fact(fid, "L2", f"{venue} political markets", "calibration_30d_before_close",
                          {"n": 1000, "slope_b": b, "intercept_a": a, "slope_b_se": 0.1}, Source("t", "https://x"),
                          "B2", "proposed", date(2026, 10, 2))
    return KnowledgeBase(facts=facts)


def _rels():
    return [Relation("equivalent", [f"polymarket:polymarket-NY02-{p}"], [f"kalshi:kalshi-NY02-{p}"],
                     "cross_venue_winner", "NY-02", "rule") for p in ("D", "R")] + [
        Relation("equivalent", ["polymarket:polymarket-NY02-D"], ["smarkets:x"], "cross_venue_winner", "NY-02",
                 "surname")]  # surname matches are left out


def test_pooling_weights_tight_books_and_keeps_two_outcomes_coherent():
    u = Universe.build([_ev("polymarket", 0.60, spread=0.01), _ev("kalshi", 0.57, spread=0.10)])
    cs = consensus.run(u, _rels(), _kb(), "2026-10-02T20:46:00+00:00")
    assert len(cs) == 2 and all(len(c.markets) == 2 for c in cs)
    d = next(c for c in cs if c.markets[0].outcome == "Democratic Party")
    r = next(c for c in cs if c.markets[0].outcome == "Republican Party")
    assert not d.disagree and 0.595 <= d.pooled <= 0.605  # pulled toward, and clipped into, the tight book
    assert d.horizon == 30 and d.params == pytest.approx((-0.3, 1.2))
    assert 1 < d.slope < 1.2  # shrunk toward 1 (n = 1000, n0 = 200)
    assert d.recalibrated > d.pooled  # b > 1 extremizes away from 50%
    assert d.interval[0] < d.recalibrated < d.interval[1]
    assert d.recalibrated + r.recalibrated == pytest.approx(1.0, abs=1e-9)  # slope-only keeps the race coherent


def test_no_point_estimate_when_venues_disagree_after_fees():
    u = Universe.build([_ev("polymarket", 0.60), _ev("kalshi", 0.50)])
    (c, _) = consensus.run(u, _rels(), _kb(), "2026-10-02T20:46:00+00:00")
    assert c.disagree and c.recalibrated is None and c.interval is None
    p = consensus.explain(c, _kb(), "t")
    assert p.grounded and p.check() == [] and "不給點估計" in p.conclusion and p.result["pooled"] is None


def test_logit_weights_do_not_over_trust_tail_quotes_and_families_count_once():
    from pmpol.universe.consensus import _sigma

    tail = Market("k", "a", "e", "q", "x", bid=0.025, ask=0.035)
    mid = Market("k", "b", "e", "q", "x", bid=0.495, ask=0.505)
    assert _sigma(tail) > 2 * _sigma(mid)  # the same 1-point spread is much wider in logit terms at 3%
    evs = [_ev("polymarket", 0.60, 0.02), _ev("polymarket_us", 0.60, 0.02), _ev("kalshi", 0.58, 0.02)]
    rels = [Relation("equivalent", [f"{v}:{v}-NY02-D"], ["kalshi:kalshi-NY02-D"], "cross_venue_winner", "NY-02", "rule")
            for v in ("polymarket", "polymarket_us")]
    (c,) = consensus.run(Universe.build(evs), rels, None, "")
    w = {m.venue: c.weights[m.key] for m in c.markets}
    assert w["polymarket"] + w["polymarket_us"] == pytest.approx(w["kalshi"], rel=0.05)  # one family, one vote
    assert 0.585 < c.pooled < 0.595


def test_proof_and_no_recalibration_without_base_rates():
    u = Universe.build([_ev("polymarket", 0.60), _ev("kalshi", 0.59)])
    (c, _) = consensus.run(u, _rels(), KnowledgeBase(), "2026-10-02T20:46:00+00:00")
    assert c.recalibrated is None and not c.disagree
    p = consensus.explain(c, KnowledgeBase(), "t")
    assert p.grounded and p.check() == [] and any("沒有校準資料" in x for x in p.caveats)
    u2 = Universe.build([_ev("polymarket", 0.60), _ev("kalshi", 0.50)])
    p2 = consensus.explain(consensus.run(u2, _rels(), _kb(), "2026-10-02T20:46:00+00:00")[0], _kb(), "t")
    assert any(s.layer == "L2" for s in p2.steps) and any("截距" in x for x in p2.caveats)
    assert any("偏離共識" in a["hypothesis"] for a in p2.alternatives)  # 10-point gap between venues


def test_consensus_proofs_cite_the_floor_and_spread_cut_as_assumptions():
    u = Universe.build([_ev("polymarket", 0.60), _ev("kalshi", 0.59)])
    (c, _) = consensus.run(u, _rels(), KnowledgeBase(), "2026-10-02T20:46:00+00:00")
    p = consensus.explain(c, KnowledgeBase(), "t")
    assert {"consensus_quote_floor", "consensus_max_spread"} <= set(p.result["assumptions"])


def test_identity_and_label_matches_join_classes_and_lower_the_confidence():
    from pmpol.confidence import assess

    u = Universe.build([_ev("polymarket", 0.60), _ev("kalshi", 0.60)])
    rels = [Relation("equivalent", ["polymarket:polymarket-NY02-D"], ["kalshi:kalshi-NY02-D"], "onto:winner:same_set",
                     "NY-02", "entity"),
            Relation("equivalent", ["polymarket:polymarket-NY02-R"], ["kalshi:kalshi-NY02-R"],
                     "onto:winner:bridge_person_party", "NY-02", "name")]  # a person-party bridge: not one contract
    got = consensus.classes(u, rels)
    assert [(ks, m) for _, ks, m in got] == [(["kalshi:kalshi-NY02-D", "polymarket:polymarket-NY02-D"], "entity")]
    assert consensus.classes(u, rels, admit=("rule",)) == []  # the family-correlation estimate keeps structural only
    (c,) = consensus.run(u, rels, _kb(), "2026-10-02T20:46:00+00:00")
    p = consensus.explain(c, _kb(), "t")
    assert c.match == "entity" and p.result["confidence"] == "entity" and any("Wikidata" in x for x in p.caveats)
    assert assess(p)[0] != "high"
    rels[1] = Relation("equivalent", ["polymarket:polymarket-NY02-R"], ["kalshi:kalshi-NY02-R"],
                       "onto:winner:same_set", "NY-02", "label")
    rels.append(Relation("equivalent", ["polymarket:polymarket-NY02-R"], ["kalshi:kalshi-NY02-R"],
                         "onto:winner:same_set", "NY-02", "rule"))
    assert sorted(m for _, _, m in consensus.classes(u, rels)) == ["entity", "label"]  # the weakest link counts
