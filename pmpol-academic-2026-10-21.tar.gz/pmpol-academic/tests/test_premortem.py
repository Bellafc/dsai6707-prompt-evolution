from types import SimpleNamespace

from pmpol import premortem as pm

A = {"weak": SimpleNamespace(status="unsupported", falsified_if="下限不是 0.10", check="交叉驗證"),
     "fam": SimpleNamespace(status="caveated", falsified_if="不一起動", check="相關係數"),
     "ok": SimpleNamespace(status="solid", falsified_if="", check="")}


def _row(kind="consensus", **res):
    steps = [{"layer": "L4", "text": "K Yes：買 40／賣 42（權重 75%）", "ref": "u1", "id": "quote:k"},
             {"layer": "L4", "text": "P Yes：買 41／賣 43（權重 25%）", "ref": "u2", "id": "quote:p"},
             {"layer": "L2", "text": "校準", "ref": "cal.k", "id": "cal"},
             {"layer": "L1", "text": "日期", "ref": "date.fact", "id": "d"}]
    return {"id": "consensus:k", "kind": kind, "proof": {
        "title": "跨平台共識｜g｜Yes", "conclusion": "共識 41%", "analytic_confidence": "low", "steps": steps,
        "result": {"assumptions": ["weak", "fam", "ok"], **res},
        "alternatives": [{"hypothesis": "報價過時", "verdict": "supports", "evidence": "5 份"},
                         {"hypothesis": "真的定價不一致", "verdict": "unchecked", "evidence": ""},
                         {"hypothesis": "手續費", "verdict": "against", "evidence": ""}]}}


def test_failures_are_ranked_and_name_the_step_they_break():
    ctx = pm.Context(A, {"cal.k": "proposed", "date.fact": "legacy"}, {"fam": "0.04 對 0.30"})
    p = pm.challenge(_row(disagree=True, horizon_days=400), ctx, "why")
    levels = [f.level for f in p.failures]
    assert levels == sorted(levels, key=pm.LEVELS.index)
    by = {f.attacks: f for f in p.failures}
    assert "路標已經觸發" in by["assumption:fam"].reason and by["assumption:fam"].level == "high"
    assert by["assumption:weak"].level == "high" and "assumption:ok" not in by
    assert by["cal.k"].level == "medium" and by["date.fact"].level == "low"
    assert by["band"].level == "high" and any("75%" in f.reason for f in p.failures)
    assert any("所有平台一起錯" in f.reason for f in p.failures) and any("400 天" in f.reason for f in p.failures)
    alts = [f.reason for f in p.failures if f.attacks == "alternatives"]
    assert alts == ["競爭假設有資料支持：報價過時（5 份）"]  # not the judgment itself, not a refuted one


def test_model_wide_weak_points_fold_into_one_line():
    ctx = pm.Context(A, {"cal.k": "proposed"}, {"fam": "x"}, shared={"weak", "fam", "cal.k"})
    p = pm.challenge(_row(rules="material", confidence="title"), ctx, "why")
    model = [f for f in p.failures if f.attacks == "model"]
    assert len(model) == 1 and "「weak」" in model[0].reason and "路標已觸發的：fam" in model[0].reason
    assert {"rules", "match"} <= {f.attacks for f in p.failures}
    assert p.failures[0].attacks != "model"  # case-specific points come before shared ones of the same level


def test_selection_and_render():
    rows = [_row(), {"id": "v1", "kind": "onto:winner:same_set", "edge": 0.05, "proof": {"title": "v1"}},
            {"id": "v2", "kind": "onto:margin:cover", "edge": -0.2, "proof": {"title": "v2"}}]
    picked = pm.select(rows, {"誰贏？": "consensus:k", "沒答案": "missing"}, top=1)
    assert [r["id"] for r, _ in picked] == ["consensus:k", "v2"] and "誰贏？" in picked[0][1]
    text = pm.render([pm.challenge(r, pm.Context(A, {}), w) for r, w in picked], "now")
    assert "假設三個月後這個判斷錯了" in text and "找不到結構性的弱點" in text
