import json

from pmpol.models import Event, Market
from pmpol.movers.diff import diff, snapshot_time
from pmpol.movers.explain import equivalents, explain_move, political
from pmpol.movers.news import query_for, search
from pmpol.universe.index import Universe


def _ev(venue, d_bid, eid="NY02", title="NY-02 House Election Winner 2026", spread=0.02):
    return Event(venue, f"{venue}-{eid}", title, mutually_exclusive=True, markets=[
        Market(venue, f"{venue}-{eid}-D", f"{venue}-{eid}", title, "Democratic Party", bid=d_bid, ask=d_bid + spread),
        Market(venue, f"{venue}-{eid}-R", f"{venue}-{eid}", title, "Republican Party", bid=1 - d_bid - spread,
               ask=1 - d_bid)])


def test_snapshot_time_and_diff():
    from pathlib import Path
    assert snapshot_time(Path("universe_20261002T1530Z.json.gz")) == "2026-10-02T15:30:00+00:00"
    a, b = [_ev("kalshi", 0.30)], [_ev("kalshi", 0.45)]
    (mv,) = diff(a, b, "t0", "t1")
    assert abs(mv.delta - 0.15) < 1e-9 and mv.event_key == "kalshi:kalshi-NY02"  # one move per event
    assert diff([_ev("kalshi", 0.30, spread=0.3)], b, "t0", "t1") == []  # wide book: not a move


def test_query_for_uses_names_not_thresholds():
    assert query_for("Texas Senate Election: Denton County Winner", "Ken Paxton (R)") == \
        '"Ken Paxton" Texas "Denton County"'
    assert query_for("How many presidential actions will Trump take this week", "At least 5") == "Trump"
    assert query_for("Generic congressional ballot on Oct 3, 2026?", "8.7%") == ""
    assert query_for("Next White House Press Secretary?", "Anna Kelly") == '"Anna Kelly" "White House Press Secretary"'


def test_search_caches_json_and_reports_failures(tmp_path):
    calls = []

    def fetch(params):
        calls.append(params)
        return json.dumps({"articles": [{"title": "Paxton leads", "url": "https://x", "domain": "x.com",
                                         "seendate": "20261002T120000Z", "language": "English"}]})

    r = search('"Ken Paxton"', "2026-10-01T15:30:00+00:00", "2026-10-02T20:46:00+00:00", fetch=fetch, cache=tmp_path)
    assert r.count == 1 and r.articles[0]["domain"] == "x.com" and calls[0]["startdatetime"] == "20260930153000"
    search('"Ken Paxton"', "2026-10-01T15:30:00+00:00", "2026-10-02T20:46:00+00:00", fetch=fetch, cache=tmp_path)
    assert len(calls) == 1  # second call served from cache

    def broken(params):
        return "Please limit requests to one every 5 seconds"

    def rss(params):
        assert "after:2026-09-29" in params["q"] and "before:2026-10-03" in params["q"]
        return ("<rss><channel>"
                "<item><title>Spain calls election</title><link>https://y</link>"
                "<pubDate>Fri, 02 Oct 2026 10:00:00 GMT</pubDate><source url='https://y'>El País</source></item>"
                "<item><title>Old story</title><link>https://z</link>"
                "<pubDate>Mon, 28 Sep 2026 10:00:00 GMT</pubDate></item></channel></rss>")
    r2 = search("Spain", "2026-10-01T15:30:00+00:00", "2026-10-02T20:46:00+00:00", fetch=broken, cache=tmp_path,
                rss_fetch=rss)
    assert r2.source == "google_news" and r2.count == 1 and r2.articles[0]["domain"] == "El País"  # window filter
    assert "GDELT failed" in r2.error
    assert not any("limit requests" in p.read_text() for p in tmp_path.iterdir())  # the error page was not cached


def test_silent_move_needs_no_news_and_no_confirmation():
    a = [_ev("kalshi", 0.30), _ev("polymarket", 0.30)]
    b = [_ev("kalshi", 0.45), _ev("polymarket", 0.31)]
    ua, ub = Universe.build(a), Universe.build(b)
    moves = [m for m in diff(a, b, "2026-10-01T15:30:00+00:00", "2026-10-02T20:46:00+00:00") if political(ub, m)]
    k = next(m for m in moves if m.venue == "kalshi")
    conf = equivalents(ub, ua, [k])[k.key]
    assert conf and conf[0]["venue"] == "polymarket"

    from pmpol.movers.news import NewsResult
    empty = NewsResult("q", "s", "e", 0)
    p = explain_move(k, empty, conf, ub.markets[k.key])
    assert p.result["silent"] and p.grounded and p.check() == []
    assert any(a["hypothesis"].startswith("有人比市場先知道") and a["verdict"] == "unchecked" for a in p.alternatives)
    p2 = explain_move(k, NewsResult("q", "s", "e", 3), conf, ub.markets[k.key])
    assert not p2.result["silent"] and "3 篇新聞" in p2.conclusion


def test_classification_labels_moves_but_never_drops_them(tmp_path):
    from pmpol.movers import report
    from pmpol.universe.pipeline import save_snapshot

    def single(eid, title, bid):
        return Event("polymarket", eid, title, markets=[
            Market("polymarket", f"{eid}-y", eid, title, "Yes", bid=bid, ask=bid + 0.02, close_time="2027-06-01")])

    titles = {"pol": "NY-02 House Election Winner 2026", "odd": "Will the Loch Ness monster be found?",
              "eco": "Core PCE inflation YoY above 3% in September 2026?", "cnt": "How many tweets will Elon post this week?"}
    a = [single(k, t, 0.30) for k, t in titles.items()]
    b = [single(k, t, 0.45) for k, t in titles.items()]
    pa, pb = tmp_path / "universe_20261002T1530Z.json.gz", tmp_path / "universe_20261002T2046Z.json.gz"
    save_snapshot(a, pa)
    save_snapshot(b, pb)
    moves, rows, *_ , near = report.run(pa, pb, news=False)
    lanes = {m.event_key.split(":")[1]: m.lane for m in moves}
    assert lanes == {"pol": "political", "odd": "unclassified", "eco": "economy_media", "cnt": "count"}
    assert {mv.event_key.split(":")[1] for mv, _ in rows} == {"pol", "odd"}  # unclassified is checked too
    odd = next(p for mv, p in rows if mv.lane == "unclassified")
    assert any("未分類" in c for c in odd.caveats)
    page = report.render(moves, rows, "2026-10-02T15:30", "2026-10-02T20:46", near)
    assert "1b. 其他主題的異動（2 個" in page and "Loch Ness" in page
