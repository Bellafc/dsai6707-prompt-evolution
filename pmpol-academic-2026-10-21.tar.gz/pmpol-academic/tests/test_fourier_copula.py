import itertools

import numpy as np
import pytest

from pmpol.copula import conditional_probs, gauss_hermite_normal
from pmpol.fourier import convolve_outcomes, convolve_outcomes_direct, grid_shape_for


def _random_trials(rng, n, dims=2):
    trials = []
    for _ in range(n):
        k = rng.integers(2, 4)
        p = rng.dirichlet(np.ones(k))
        incs = [tuple(int(x) for x in rng.integers(0, 2, size=dims)) for _ in range(k)]
        trials.append(list(zip(incs, p)))
    return trials


def test_fft_matches_direct_convolution():
    rng = np.random.default_rng(0)
    trials = _random_trials(rng, 30, dims=3)
    fft = convolve_outcomes(trials)
    direct = convolve_outcomes_direct(trials)
    assert fft.shape == grid_shape_for(trials)
    np.testing.assert_allclose(fft, direct, atol=1e-12)
    assert fft.sum() == pytest.approx(1.0)


def test_fft_matches_brute_force_enumeration():
    trials = [
        [((1, 0), 0.6), ((0, 1), 0.4)],
        [((1, 0), 0.2), ((0, 1), 0.7), ((0, 0), 0.1)],
        [((1, 0), 0.5), ((0, 1), 0.5)],
    ]
    expected = np.zeros(grid_shape_for(trials))
    for combo in itertools.product(*trials):
        idx = tuple(sum(inc[d] for inc, _ in combo) for d in range(2))
        expected[idx] += np.prod([p for _, p in combo])
    np.testing.assert_allclose(convolve_outcomes(trials), expected, atol=1e-14)


def test_poisson_binomial_mean():
    p = np.linspace(0.05, 0.95, 35)
    trials = [[((1,), q), ((0,), 1 - q)] for q in p]
    pmf = convolve_outcomes(trials)
    assert (np.arange(pmf.size) * pmf).sum() == pytest.approx(p.sum())


def test_conditional_probs_integrate_to_marginals():
    nodes, weights = gauss_hermite_normal(80)
    probs = [0.3, 0.1, 0.6]
    for rho in (0.0, 0.3, 0.8):
        avg = sum(w * conditional_probs(probs, rho, z) for z, w in zip(nodes, weights))
        np.testing.assert_allclose(avg, probs, atol=1e-6)


def test_correlation_fattens_tails():
    nodes, weights = gauss_hermite_normal(80)
    probs = [[0.5, 0.5]] * 20

    def pmf(rho):
        out = 0
        for z, w in zip(nodes, weights):
            trials = [[((1,), c[0]), ((0,), c[1])] for c in (conditional_probs(p, rho, z) for p in probs)]
            out = out + w * convolve_outcomes(trials)
        return out

    indep, corr = pmf(0.0), pmf(0.5)
    assert corr[:5].sum() > 10 * indep[:5].sum()
