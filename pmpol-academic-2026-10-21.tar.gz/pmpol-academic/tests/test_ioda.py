import json
from datetime import date

from pmpol.models import Market
from pmpol.osint import ioda


def test_levels_and_proxy_proof(tmp_path):
    vals = [100.0] * 30 + [2.0] * 12 + [90.0] * 10 + [None, None]  # half-hour steps: six hours at 2%
    raw = {"data": [[{"datasource": "gtr", "from": 1791000000, "step": 1800, "values": vals},
                     {"datasource": "gtr-sarima", "from": 1791000000, "step": 1800, "values": [[{}]]}]]}
    got = ioda.fetch("ir", today=date(2026, 10, 6), get=lambda url: json.dumps(raw), cache=tmp_path)
    (lv,) = ioda.levels(got)
    assert lv.signal == "gtr" and lv.latest == 0.9 and abs(lv.floor6h - 0.02) < 1e-9
    m = Market("polymarket", "x", "e", "q", "December 31", bid=0.2, ask=0.24, active=True,
               rules="... according to Cloudflare Radar data for Iran ...")
    p = ioda.proof(m, "Total Internet Blackout in Iran by...?", "ir", [lv], "2026-10-06T00:00")
    assert p.grounded and p.check() == [] and p.result["proxy"] and "不是結算來源" in p.conclusion
