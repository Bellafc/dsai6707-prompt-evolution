from pmpol import constraints
from pmpol.models import Event, Market
from pmpol.universe.index import Universe
from pmpol.universe.outcomes import combo_cell, surname
from pmpol.universe.relations import build_relations, check
from pmpol.universe.taxonomy import tag_event
from pmpol.venues import FRONT_ENDS, VENUES, info, one_of
from pmpol.venues import gemini, polymarket_us

PU_EVENT = {
    "slug": "ushr-ny-02-2026-11-03", "title": "NY-02 House Election Winner", "category": "politics",
    "tags": [{"slug": "politics"}, {"slug": "midterms"}],
    "markets": [
        {"slug": "ushrewc-ushr-ny-02-2026-11-03-rep", "question": "NY-02 House Election Winner",
         "title": "Andrew Garbarino (R)", "description": "Resolves Yes if the Republican wins NY-02.",
         "endDate": "2027-01-15T00:00:00Z", "active": True, "closed": False, "status": "MARKET_STATUS_OPEN",
         "feeCoefficient": 0.0695, "outcomes": "[\"No\",\"Yes\"]",
         "marketSides": [{"description": "Yes", "long": True}, {"description": "No", "long": False}],
         "bestBidQuote": {"value": "0.8800"}, "bestAskQuote": {"value": "0.8900"}},
        {"slug": "ushrewc-ushr-ny-02-2026-11-03-dem", "question": "NY-02 House Election Winner",
         "title": "Patrick Halpin (D)", "description": "", "endDate": "2027-01-15T00:00:00Z",
         "active": True, "closed": False, "status": "MARKET_STATUS_OPEN", "feeCoefficient": 0.0695,
         "marketSides": [{"description": "Yes", "long": True}], "bestAskQuote": {"value": "0.1300"}},
        {"slug": "resolved", "question": "q", "title": "x", "active": True, "closed": True,
         "status": "MARKET_STATUS_RESOLVED", "marketSides": [{"description": "Yes", "long": True}]},
    ],
}

GEMINI_EVENT = {
    "ticker": "HOUSE26NY-02", "title": "New York-02 House Winner", "type": "categorical",
    "subcategory": {"slug": "politics_midterms_house"},
    "contracts": [
        {"label": "Andrew Garbarino", "instrumentSymbol": "GEMI-HOUSE26NY-02-AG", "status": "active",
         "marketState": "open", "expiryDate": "2026-11-10T01:00:00.000Z",
         "prices": {"bestBid": "0.93", "bestAsk": "0.95", "lastTradePrice": "0.94"},
         "description": {"nodeType": "document", "content": [
             {"nodeType": "text", "value": "Resolves Yes if Andrew Garbarino wins. This event is mutually exclusive."}]}},
        {"label": "Patrick Halpin", "instrumentSymbol": "GEMI-HOUSE26NY-02-PH", "status": "active",
         "marketState": "open", "expiryDate": "2026-11-10T01:00:00.000Z",
         "prices": {"bestBid": "0.05", "bestAsk": "0.07"}, "description": {}},
    ],
}


def test_registry_covers_crawled_venues_and_flags_licences():
    assert {"kalshi", "polymarket", "polymarket_us", "gemini"} <= VENUES.keys()
    assert not VENUES["kalshi"].commercial
    assert info("nowhere").exhaustive_rule == "other"
    # Front ends route to a venue we read (or one queued for an adapter), never to themselves.
    assert FRONT_ENDS["Binance Wallet"] == "predict.fun" and FRONT_ENDS["OKX Web3 Wallet"] == "polymarket"


def test_polymarket_us_parse():
    e = polymarket_us.parse_event(PU_EVENT)
    assert e.venue == "polymarket_us" and e.event_id == "ushr-ny-02-2026-11-03" and e.mutually_exclusive
    rep, dem, gone = e.markets
    assert (rep.outcome, rep.bid, rep.ask, rep.fee_rate) == ("Andrew Garbarino (R)", 0.88, 0.89, 0.0695)
    assert dem.bid == 0.0 and dem.ask == 0.13  # missing bid quote = empty bid side
    assert rep.active and not gone.active
    short_yes = {**PU_EVENT["markets"][0], "marketSides": [{"description": "No", "long": True}]}
    assert not polymarket_us.parse_market(short_yes, "e").active  # long side is not YES: left out


def test_gemini_parse():
    e = gemini.parse_event(GEMINI_EVENT)
    assert e.venue == "gemini" and e.event_id == "HOUSE26NY-02" and e.mutually_exclusive
    ag, ph = e.markets
    assert (ag.market_id, ag.bid, ag.ask, ag.last) == ("GEMI-HOUSE26NY-02-AG", 0.93, 0.95, 0.94)
    assert "mutually exclusive" in ag.rules and ph.rules == ""
    assert ag.taker_fee(0.5) == 0.07 * 0.25
    assert e.category == "politics_midterms_house"


def test_one_of_is_conservative():
    assert one_of("NY-02 House Election Winner", ["A (R)", "B (D)"])
    assert one_of("Next White House Press Secretary?", ["A", "B", "C"])
    assert not one_of("Alaska Senate Election: Turnout", ["Above 260K", "Above 320K"])
    assert not one_of("Trump Resigns?", ["By December 31, 2027", "By December 31, 2026"])
    assert not one_of("Who will be arrested in 2026?", ["A", "B"])
    assert not one_of("NY-02 House Election Winner", ["A (R)"])


def test_polymarket_us_combo_and_control_parse():
    q = "Texas Senate and Governor Combo"

    def mk(o):
        return Market("polymarket_us", o, "e", q, o)
    assert combo_cell(mk("Reps sweep")) == ("R", "R")
    assert combo_cell(mk("Reps win Gov, Dems win Senate")) == ("R", "D")
    # Multi-state Senate combos are not Governor/Senate cells.
    assert combo_cell(Market("polymarket_us", "x", "e", "Senate Combo: Texas, Michigan, Maine", "Dems sweep")) is None
    t = tag_event(Event("polymarket_us", "usho", "U.S House Midterm Winner", markets=[
        Market("polymarket_us", "d", "usho", "U.S House Midterm Winner", "Democratic Party")]))
    assert (t.office, t.measure, t.jurisdiction) == ("house", "control", "US")


def test_surname_ignores_labels_about_someone_else():
    assert surname("a party founded by Elon Musk") is None
    assert surname("Dominique de Villepin") == "villepin"


def test_cross_venue_relations_cover_every_venue_pair():
    events = [polymarket_us.parse_event(PU_EVENT), gemini.parse_event(GEMINI_EVENT)]
    kalshi = Event("kalshi", "KXHOUSERACE-NY02-26", "NY-02 House winner?", mutually_exclusive=True, markets=[
        Market("kalshi", "KXHOUSERACE-NY02-26-R", "KXHOUSERACE-NY02-26", "Will Republicans win NY-02?",
               "Andrew Garbarino", bid=0.80, ask=0.82, fee_rate=0.07)])
    u = Universe.build(events + [kalshi])
    rels = [r for r in build_relations(u) if r.template == "cross_venue_winner"]
    pairs = {tuple(sorted({k.split(":")[0] for k in r.lhs + r.rhs})) for r in rels}
    assert pairs == {("gemini", "polymarket_us"), ("kalshi", "polymarket_us"), ("gemini", "kalshi")}
    # Gemini bids 0.93 for Garbarino, Kalshi asks 0.82: a gap that survives both venues' fees.
    gk = next(r for r in rels if {k.split(":")[0] for k in r.lhs + r.rhs} == {"gemini", "kalshi"})
    s = check(u, gk)
    assert s is not None and s.edge > 0.05


def test_exhaustiveness_rule_comes_from_registry():
    e = Event("gemini", "E", "Winner", mutually_exclusive=True, markets=[
        Market("gemini", "a", "E", "q", "A", bid=0.6, ask=0.62), Market("gemini", "b", "E", "q", "B", bid=0.2, ask=0.22)])
    # No "Other" bucket on a venue that needs one: buying every YES is not a guaranteed payout.
    assert not constraints._is_exhaustive(e, e.markets)


def test_gemini_district_titles():
    def tag(title):
        return tag_event(Event("gemini", "x", title, markets=[Market("gemini", "m", "x", title, "A")]))
    assert tag("Montana-01 House Winner").jurisdiction == "MT-01"
    assert tag("Alaska-At-Large House Winner").jurisdiction == "AK-AL"
    nm = tag("New Mexico-02 House Winner")
    assert (nm.topic, nm.jurisdiction) == ("elections_us", "NM-02")
    assert tag("North Carolina-01 Winner").office == "house"


# --- second batch: Smarkets, PredictIt, Crypto.com, Opinion, Limitless ---------------------

from pmpol.venues import cryptocom, limitless, opinion, predictit, smarkets  # noqa: E402


def test_smarkets_parse_named_and_yes_no():
    event = {"id": "1", "name": "Michigan Senate Election", "special_rules": "Dead heat rules apply",
             "start_datetime": "2026-11-04T01:00:00Z", "full_slug": "/politics/us/michigan-senate-election"}
    market = {"id": "10", "event_id": "1", "name": "Michigan Senate Election Winner", "state": "open",
              "winner_count": 1, "description": ""}
    contracts = [{"id": "a", "market_id": "10", "name": "Mike Rogers", "state_or_outcome": "open"},
                 {"id": "b", "market_id": "10", "name": "Haley Stevens", "state_or_outcome": "open"}]
    quotes = {"a": {"bids": [{"price": 4100, "quantity": 20000}, {"price": 3900, "quantity": 5}],
                    "offers": [{"price": 4300, "quantity": 50000}]},
              "b": {"bids": [], "offers": [{"price": 6000, "quantity": 10000}]}}
    e = smarkets.parse_event(market, event, contracts, quotes)
    assert e.mutually_exclusive and e.title == "Michigan Senate Election Winner" and e.event_id == "10"
    rogers, stevens = e.markets
    assert (rogers.bid, rogers.ask, rogers.bid_size, rogers.ask_size) == (0.41, 0.43, 2.0, 5.0)
    assert stevens.bid == 0.0 and stevens.ask == 0.6
    assert abs(rogers.taker_fee(0.41) - 0.02 * 0.59) < 1e-12  # commission on the larger possible profit
    yes_no = smarkets.parse_event({**market, "winner_count": 1}, event,
                                  [{"id": "y", "name": "Yes", "state_or_outcome": "open"},
                                   {"id": "n", "name": "No", "state_or_outcome": "open"}],
                                  {"y": {"bids": [{"price": 3000, "quantity": 1}], "offers": [{"price": 4000, "quantity": 1}]},
                                   "n": {"bids": [{"price": 6500, "quantity": 1}], "offers": [{"price": 6800, "quantity": 1}]}})
    (m,) = yes_no.markets
    # YES bid improves to 1 - 0.68 = 0.32; YES ask improves to 1 - 0.65 = 0.35.
    assert m.outcome == "Yes" and round(m.bid, 4) == 0.32 and round(m.ask, 4) == 0.35 and not yes_no.mutually_exclusive


def test_predictit_parse():
    m = {"id": 7589, "name": "Which party will win the 2026 US House election in Washington's 3rd District?",
         "status": "Open", "contracts": [
             {"id": 1, "name": "Democratic", "status": "Open", "dateEnd": "N/A", "bestBuyYesCost": 0.55,
              "bestSellYesCost": 0.52, "bestBuyNoCost": 0.47, "bestSellNoCost": 0.44, "lastTradePrice": 0.53},
             {"id": 2, "name": "Republican", "status": "Open", "dateEnd": "NA", "bestBuyYesCost": 0.48,
              "bestSellYesCost": None, "bestBuyNoCost": None, "bestSellNoCost": 0.5}]}
    e = predictit.parse_event(m)
    assert e.mutually_exclusive
    d, r = e.markets
    assert (d.bid, d.ask, d.close_time) == (0.53, 0.55, None)  # 1 - bestBuyNo beats bestSellYes
    assert (r.bid, r.ask) == (0.0, 0.48)
    assert abs(d.taker_fee(0.55) - 0.10 * 0.55) < 1e-12


def test_cryptocom_parse():
    e = cryptocom.parse_event({"id": "x", "title": "PA-01 House Election Winner 2026", "kind": "ELECT",
                               "status": "active", "contracts": [
        {"symbol": "ELECT-PA01-Democratic-O11_270131-0500_1_PM.NPO", "title": "Democratic Party", "status": "active",
         "yes": "0.42", "no": "0.69"},
        {"symbol": "ELECT-PA01-Republican-O11_270131-0500_1_PM.NPO", "title": "Republican Party", "status": "active",
         "yes": "", "no": "0.39"}]})
    d, r = e.markets
    assert e.mutually_exclusive and (d.bid, d.ask) == (0.31, 0.42) and d.close_time.startswith("2027-01-31")
    assert (r.bid, r.ask) == (0.61, None)
    assert d.taker_fee(0.3) == 0.02  # flat assumed fee


def test_opinion_and_limitless_parse():
    parent = {"marketId": 135, "marketTitle": "Which party will win the U.S. House in 2026?", "marketType": 1,
              "statusEnum": "Activated", "cutoffAt": 1793664000, "rules": "House control", "labels": ["Politics"],
              "childMarkets": [{"marketId": 2210, "marketTitle": "Democratic Party", "yesTokenId": "t1",
                                "statusEnum": "Activated"},
                               {"marketId": 2211, "marketTitle": "Republican Party", "yesTokenId": "t2",
                                "statusEnum": "Activated"}]}
    books = {"t1": {"bids": [{"price": "0.9", "size": "10"}, {"price": "0.85", "size": "5"}],
                    "asks": [{"price": "0.93", "size": "7"}]}}
    e = opinion.parse_event(parent, books)
    d, r = e.markets
    assert e.mutually_exclusive and (d.bid, d.ask, d.bid_size, d.token_id) == (0.9, 0.93, 10.0, "t1")
    assert r.bid is None and r.ask is None and d.rules == "House control"

    group = {"slug": "which-party-house", "title": "Which party will win the House in 2026?", "categories": ["Politics"],
             "expirationTimestamp": 1793768340000, "markets": [
                 {"slug": "dem", "title": "Democratic Party", "negRiskRequestId": "r", "status": "FUNDED",
                  "expired": False, "description": "<p>Resolves <b>Yes</b></p>"},
                 {"slug": "oth", "title": "x", "isOther": True, "negRiskRequestId": "r", "status": "FUNDED",
                  "expired": False}]}
    g = limitless.parse_event(group, {"dem": {"bids": [{"price": 0.935, "size": 300_000_000}],
                                              "asks": [{"price": 0.995, "size": 1_000_000_000}]}})
    dem, other = g.markets
    assert g.mutually_exclusive and (dem.bid, dem.ask, dem.bid_size) == (0.935, 0.995, 300.0)
    assert dem.rules == "Resolves Yes" and other.outcome == "Other"


def test_any_other_label_makes_event_exhaustive():
    e = Event("smarkets", "E", "Winner", mutually_exclusive=True, markets=[
        Market("smarkets", "a", "E", "q", "Labour", bid=0.6, ask=0.62),
        Market("smarkets", "b", "E", "q", "Any Other Result", bid=0.1, ask=0.12)])
    assert constraints._is_exhaustive(e, e.markets)


def test_every_registered_venue_has_a_crawler():
    from pmpol.universe import pipeline
    import inspect
    src = inspect.getsource(pipeline._crawl_venue)
    for name in VENUES:
        assert f'"{name}"' in src, name


def test_label_swap_guard_drops_relations_of_a_swapped_venue():
    from pmpol.universe import pipeline

    def race(venue, d, r, eid=None):
        eid = eid or f"{venue}-SC01"
        return Event(venue, eid, "SC-01 House Election Winner 2026", mutually_exclusive=True, markets=[
            Market(venue, f"{eid}-D", eid, "SC-01 House Election Winner 2026", "Democratic Party", bid=d - 0.01,
                   ask=d + 0.01),
            Market(venue, f"{eid}-R", eid, "SC-01 House Election Winner 2026", "Republican Party", bid=r - 0.01,
                   ask=r + 0.01)])
    events = [race("polymarket_us", 0.26, 0.74), race("gemini", 0.25, 0.75), race("smarkets", 0.27, 0.73),
              race("cryptocom", 0.75, 0.27)]
    res = pipeline.run(events, depth=False, entities=False)
    assert list(res.suspects) == ["cryptocom:cryptocom-SC01"]
    assert res.dropped and not any("cryptocom" in k for r in res.rule_relations for k in r.lhs + r.rhs)
    assert any("polymarket_us" in r.lhs[0] for r in res.rule_relations)  # the other venues stay linked


def test_one_of_rejects_threshold_ladders():
    assert not one_of("2026 Midterms: Republican House Seats?", ["180+", "185+", "190+"])
    assert not one_of("How many seats?", ["5% or more", "10% or more"])
    assert one_of("How many seats?", ["180-184", "185-189", "190+"])  # a single "+" is just the top bucket
