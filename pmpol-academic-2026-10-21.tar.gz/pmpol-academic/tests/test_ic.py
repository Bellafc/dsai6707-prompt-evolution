import math
from types import SimpleNamespace as NS

import numpy as np

from pmpol.track import ic


def _u(mids: dict[str, float]):
    return NS(markets={k: NS(mid=v, spread=0.02) for k, v in mids.items()})


def _logit(p):
    return math.log(p / (1 - p))


def test_reverting_prices_give_a_negative_ic_that_fades():
    rng = np.random.default_rng(0)
    keys = [f"k:{i}" for i in range(60)]
    base = {k: float(rng.uniform(0.2, 0.8)) for k in keys}
    dev = {k: float(rng.normal(0, 0.3)) for k in keys}
    start = {k: 1 / (1 + math.exp(-(_logit(base[k]) + dev[k]))) for k in keys}
    # 2 hours later half the deviation is gone; 40 hours later the prices are noise around where they started
    soon = {k: 1 / (1 + math.exp(-(_logit(base[k]) + 0.5 * dev[k]))) for k in keys}
    late = {k: 1 / (1 + math.exp(-(_logit(start[k]) + rng.normal(0, 0.3)))) for k in keys}
    chain = [("2026-10-08T00:00+00:00", _u(start)), ("2026-10-08T02:00+00:00", _u(soon)),
             ("2026-10-09T16:00+00:00", _u(late))]
    obs = ic.observations(chain, {0: {"outlier": dev, "coherence": {}}})
    assert {round(o.hours) for o in obs["outlier"]} == {2, 40}
    rows = {r.bucket: r for r in ic.table(obs, "2026-10-07") if r.signal == "outlier"}
    near, far = rows[(0.5, 3.0)], rows[(30.0, 72.0)]
    assert near.ic < -0.9 and near.hi < 0 and near.prospective == 60
    assert abs(far.ic) < 0.4 and far.lo < 0 < far.hi
    assert rows[(3.0, 12.0)].ic is None  # no pair at that horizon
    assert "2c." in "\n".join(ic.render(list(rows.values())))


def test_wide_books_are_left_out():
    a = _u({"k:1": 0.5})
    b = NS(markets={"k:1": NS(mid=0.6, spread=0.5)})
    obs = ic.observations([("2026-10-08T00:00+00:00", a), ("2026-10-08T05:00+00:00", b)], {0: {"outlier": {"k:1": 1.0}}})
    assert obs["outlier"] == []
