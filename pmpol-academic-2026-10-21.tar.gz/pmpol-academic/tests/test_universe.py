import pytest

from pmpol.models import Event, Market, Relation
from pmpol.universe.cluster import text_relations
from pmpol.universe.geo import find_countries, find_states, sub_jurisdiction
from pmpol.universe.index import Universe
from pmpol.universe.outcomes import (Interval, combo_cell, count_interval, kalshi_margin_rung, margin_bucket,
                                     party_of, surname)
from pmpol.universe.relations import _exact_cover, build_relations, check
from pmpol.universe.taxonomy import tag_event


def mk(venue, mid, outcome, question="", bid=0.4, ask=0.42, **kw):
    kw.setdefault("fee_rate", 0.07 if venue == "kalshi" else 0.0)
    return Market(venue=venue, market_id=mid, event_id="E", question=question, outcome=outcome, bid=bid, ask=ask, **kw)


def ev(venue, eid, title, markets, me=True):
    for m in markets:
        m.event_id = eid
    return Event(venue, eid, title, mutually_exclusive=me, markets=markets)


# --- geo and taxonomy -------------------------------------------------------------

def test_geo_disambiguation():
    assert find_states("Georgia Senate winner") == ["GA"]
    assert find_countries("Georgia Senate winner") == []
    assert find_countries("Will Jim Jordan be Speaker?") == []
    assert sub_jurisdiction("Rivers, Nigeria Governor Election Winner", "Nigeria") == "Nigeria/Rivers"
    assert sub_jurisdiction("Amazonas Senate Election: 1st Place", "Brazil") == "Brazil/Amazonas"


@pytest.mark.parametrize("title,eid,venue,expected", [
    ("TX-18 House winner?", "KXHOUSERACE-TX18-26", "kalshi", ("elections_us", "house", "winner", "TX-18", 2026)),
    ("Texas's 18th District margin of victory", "KXMIDTERMMOV-TX18D", "kalshi",
     ("elections_us", "house", "margin", "TX-18", 2026)),
    ("Oregon 03 House General Election: voter turnout", "KXMIDTERMVOTETURN-OR03", "kalshi",
     ("elections_us", "house", "turnout", "OR-03", 2026)),
    ("Maine Governor-Senate combo", "KXMESENGOVCOMBO-26NOV", "kalshi", ("elections_us", "governor", "combo", "ME", 2026)),
    ("Texas Senate Election: Tarrant County Winner", "x", "polymarket",
     ("elections_us", "senate", "county", "TX", None)),
    ("Who will John Cornyn endorse in the Texas Senate Election?", "x", "polymarket",
     ("elections_us", "senate", "prop", "TX", None)),
    ("Amazonas Senate Election: 1st Place", "x", "polymarket",
     ("elections_intl", "senate", "winner", "Brazil/Amazonas", None)),
    ("Will Russia capture Sloviansk by...?", "x", "polymarket", ("geopolitics", None, "by_date", "Russia", None)),
    # Rules added from the residual monitor (2026-10-03)
    ("Taichung mayoral election winner?", "x", "kalshi", ("elections_intl", "mayor", "winner", "Taiwan/taichung", None)),
    ("Yilan County Magistrate Election Winner", "x", "polymarket",
     ("elections_intl", "local", "winner", "Taiwan/Yilan", None)),
    ("Schleswig-Holstein state election winner?", "x", "kalshi", ("elections_intl", "parliament", "winner", "Germany/Schleswig-Holstein", None)),
    ("CPI core year-over-year in Dec 2026", "x", "kalshi", ("economy_policy", None, "binary", None, None)),
    ("Bank of Japan rate decision in December", "x", "kalshi", ("economy_policy", None, "binary", "Japan", None)),
    ("Who will be the next DNC Chair?", "x", "kalshi", ("us_government", None, "binary", None, None)),
    ("Who will the next Pope be?", "x", "kalshi", ("geopolitics", None, "binary", "Vatican City", None)),
    ("Which of these African leaders will leave office next?", "x", "kalshi", ("geopolitics", None, "binary", None, None)),
    # A referendum is a government question, not a contest: two referendums in one state must not share a race key.
    ("Arizona Traffic Camera Ban Referendum", "x", "polymarket", ("us_government", "ballot", "binary", "AZ", None)),
])
def test_tagging(title, eid, venue, expected):
    close = "2027-01-04T00:00:00Z"
    t = tag_event(ev(venue, eid, title, [mk(venue, eid + "-X", "x", close_time=close)]))
    got = (t.topic, t.office, t.measure, t.jurisdiction, t.year)
    assert got[:4] == expected[:4]
    if expected[4]:
        assert got[4] == expected[4]


def test_variants_split_different_questions():
    most = tag_event(ev("polymarket", "a", "Israel election 2026: most seats", [mk("polymarket", "a1", "Shas")]))
    third = tag_event(ev("kalshi", "KXISRAEL3RD-26OCT27", "Israel election: 3rd place", [mk("kalshi", "k1", "Shas")]))
    assert most.office == third.office == "parliament" and most.year == third.year == 2026
    anyseat = tag_event(ev("kalshi", "KXISRAELANYSEAT-26OCT27", "Which parties will win seats in Israel election?",
                           [mk("kalshi", "k2", "Shas")]))
    assert len({most.race_key, third.race_key, anyseat.race_key}) == 3


# --- outcome parsing ----------------------------------------------------------------

def test_outcome_parsers():
    assert party_of(mk("kalshi", "KXHOUSERACE-TX18-26-D", "Christian Menefee")) == "D"
    assert party_of(mk("polymarket", "x", "Ronald Whitfield (R)")) == "R"
    assert party_of(mk("polymarket", "x", "x", "Will the Democratic Party win the TX-18 House seat?")) == "D"
    assert party_of(mk("polymarket", "x", "Elon Musk")) is None
    assert surname("Sen. Dan Sullivan (R)") == "sullivan"
    assert count_interval("12–13") == Interval(12, 13)
    assert count_interval("<8") == Interval(float("-inf"), 7)
    b = margin_bucket(mk("polymarket", "x", "Democrat 70-75%"))
    assert (b.party, b.lo, b.hi) == ("D", 70, 75)
    assert margin_bucket(mk("polymarket", "x", "Republican Wins")).hi == float("inf")
    rung = mk("kalshi", "x", "Menefee, 49+ pts", "Will the margin of victory for Democrats in ... be at least 49",
              strike_type="greater_or_equal", floor_strike=49.0)
    assert kalshi_margin_rung(rung) == ("D", 49.0)
    assert combo_cell(mk("polymarket", "x", "", "Will Democrats sweep the Maine Senate and Governor elections?")) == ("D", "D")


def test_exact_cover():
    parts = {"a": Interval(float("-inf"), 44), "b": Interval(45, 45), "c": Interval(46, 46), "d": Interval(47, 47),
             "e": Interval(48, 48)}
    assert _exact_cover(Interval(float("-inf"), 47), parts) == ["a", "b", "c", "d"]
    assert _exact_cover(Interval(46, 48), parts) == ["c", "d", "e"]
    assert _exact_cover(Interval(46, 49), parts) is None


# --- relations ----------------------------------------------------------------------

def _house_universe():
    kw = ev("kalshi", "KXHOUSERACE-TX18-26", "TX-18 House winner?", [
        mk("kalshi", "KXHOUSERACE-TX18-26-D", "Menefee", bid=0.94, ask=0.95),
        mk("kalshi", "KXHOUSERACE-TX18-26-R", "Whitfield", bid=0.04, ask=0.06)])
    pw = ev("polymarket", "tx-18-house-election-winner", "TX-18 House Election Winner", [
        mk("polymarket", "pd", "Christian Menefee (D)", bid=0.97, ask=0.98),
        mk("polymarket", "pr", "Ronald Whitfield (R)", bid=0.01, ask=0.02)])
    pm = ev("polymarket", "tx-18-house-margin-of-victory-2026", "TX-18 House Election Margin of Victory", [
        mk("polymarket", "b1", "Democrat 0-50%", bid=0.30, ask=0.31),
        mk("polymarket", "b2", "Democrat 50%+", bid=0.60, ask=0.61),
        mk("polymarket", "b3", "Republican Wins", bid=0.01, ask=0.02)])
    km = ev("kalshi", "KXMIDTERMMOV-TX18D", "Texas's 18th District margin of victory", [
        mk("kalshi", "m50", "Menefee, 50+ pts", "Will the margin of victory for Democrats in TX-18 be at least 50",
           bid=0.50, ask=0.52, strike_type="greater_or_equal", floor_strike=50.0)], me=False)
    for e in (kw, pw, pm, km):
        for m in e.markets:
            m.close_time = "2026-11-04T00:00:00Z"
    return Universe.build([kw, pw, pm, km])


def test_templates_link_race_across_events_and_venues():
    u = _house_universe()
    rels = build_relations(u)
    templates = {r.template for r in rels}
    assert {"cross_venue_winner", "margin_sum_winner", "margin_implies_winner", "cross_venue_margin"} <= templates
    xm = next(r for r in rels if r.template == "cross_venue_margin")
    assert xm.lhs == ["kalshi:m50"] and xm.rhs == ["polymarket:b2"]


def test_check_finds_cross_venue_gap_net_of_fees():
    u = _house_universe()
    rel = next(r for r in build_relations(u) if r.template == "cross_venue_margin")
    s = check(u, rel)
    # sell Polymarket 50%+ at 0.60, buy Kalshi 50+ at 0.52
    assert s is not None and 0.05 < s.edge < 0.08  # 0.08 gap less Kalshi fee 0.07 * 0.52 * 0.48
    assert s.payload["trade"] == "sell rhs / buy lhs"


def test_implies_is_one_sided():
    u = _house_universe()
    sub = u.markets["kalshi:m50"]
    rel = Relation("implies", ["kalshi:m50"], ["kalshi:KXHOUSERACE-TX18-26-D"], "t", "g")
    assert check(u, rel) is None  # 0.50 bid below 0.95 ask: consistent
    sub.bid = 0.99
    assert check(u, rel).edge > 0.03


def test_text_relations_respect_deadlines():
    a = ev("kalshi", "KXGAS", "Will the federal gas tax be suspended?",
           [mk("kalshi", "g1", "Before Jan 1, 2027", close_time="2027-01-01T00:00:00Z")], me=False)
    b = ev("polymarket", "gas", "Federal Gas Tax Suspended by...?",
           [mk("polymarket", "g2", "November 2", close_time="2026-11-02T00:00:00Z")], me=False)
    u = Universe.build([a, b])
    (r,) = text_relations(u, [(a.key, b.key, 0.9)])
    assert r.kind == "implies" and r.lhs == ["polymarket:g2"] and r.rhs == ["kalshi:g1"]


def test_individual_event_people_pair_with_the_main_event():
    from pmpol.models import Event, Market
    from pmpol.universe.index import Universe
    from pmpol.universe.relations import cross_venue_winner

    def m(venue, mid, eid, outcome):
        return Market(venue, mid, eid, f"Will {outcome} win?", outcome, bid=0.5, ask=0.52)

    k = Event("kalshi", "KXCAELECTION-2640", "CA-40 House winner?",
              markets=[m("kalshi", "K-KCAL", "KXCAELECTION-2640", "Ken Calvert"),
                       m("kalshi", "K-YKIM", "KXCAELECTION-2640", "Young Kim")])
    p = Event("polymarket", "ca-40-ind", "CA-40 House Election Winner (Individual)",
              markets=[m("polymarket", "p-kcal", "ca-40-ind", "Ken Calvert"),
                       m("polymarket", "p-ykim", "ca-40-ind", "Young Kim")])
    u = Universe.build([k, p])
    assert u.tags[p.key].race_key != u.tags[k.key].race_key  # a different variant ...
    pairs = {(r.lhs[0], r.rhs[0]) for r in cross_venue_winner(u)}
    # ... but the same people
    assert ("polymarket:p-kcal", "kalshi:K-KCAL") in pairs and ("polymarket:p-ykim", "kalshi:K-YKIM") in pairs


def test_local_races_abroad_are_placed_by_evidence_not_assumed_us():
    from pmpol.models import Event, Market
    from pmpol.universe.index import Universe
    from pmpol.universe.taxonomy import tag_event

    def ev(venue, eid, title, category="", rules=""):
        return Event(venue, eid, title, category, True, [Market(venue, eid + "-m", eid, "Who wins?", "A", rules=rules)])

    # the title's province code; "Barrie, ON" is Canada, "Montgomery County, TX" stays in the U.S.
    t = tag_event(ev("polymarket", "barrie", "Barrie, ON Mayoral Election Winner"))
    assert (t.country, t.jurisdiction, t.place) == ("Canada", "Canada/barrie", "title")
    # the venue's own tag
    t = tag_event(ev("polymarket", "zilina", "Žilina Mayoral Election Winner", "mayoral,politics,slovakia"))
    assert (t.country, t.jurisdiction, t.place) == ("Slovakia", "Slovakia/žilina", "category")
    # the rules: "Richmond, British Columbia" vs "Reno, Nevada"
    t = tag_event(ev("kalshi", "KXR-26", "Richmond mayoral election winner?",
                     rules="If X wins the 2026 Richmond, British Columbia mayoral election, then ..."))
    assert (t.country, t.place) == ("Canada", "rules")
    t = tag_event(ev("kalshi", "KXRENO-26", "Reno mayoral election winner?",
                     rules="If X wins the 2026 Reno, Nevada mayoral election, then ..."))
    assert (t.country, t.jurisdiction, t.place) == ("United States", "reno", "rules")
    t = tag_event(ev("polymarket", "hobart", "Hobart Lord Mayor Election Winner",
                     rules="Local government elections are scheduled to be held across Tasmania on October 27."))
    assert (t.country, t.jurisdiction) == ("Australia", "Australia/hobart")
    # a name shared with U.S. places is not guessed; the same city and year on another venue decides
    hamilton = ev("kalshi", "KXHAMILTONMAYOR-26OCT26", "Hamilton mayoral election winner?",
                  rules="If X wins the 2026 Hamilton mayoral election, then ...")
    assert tag_event(hamilton).place == ""
    u = Universe.build([hamilton, ev("polymarket", "hamilton-2026", "Hamilton Mayoral Election",
                                     rules="The 2026 Hamilton, ON mayoral election is scheduled ...")])
    t = u.tags[hamilton.key]
    assert (t.country, t.jurisdiction, t.place) == ("Canada", "Canada/hamilton", "cross-venue")
    # but not across years: the 2028 London (UK) race does not follow London, ON's 2026 race
    london = ev("kalshi", "KXLONDONMAYOR-28", "2028 London mayoral election winner?")
    u = Universe.build([london, ev("polymarket", "london-on", "London, ON Mayoral Election Winner",
                                   rules="The 2026 London, Ontario mayoral election ...")])
    assert u.tags[london.key].country == "United States" and u.tags[london.key].place == ""
    # city names: a leading year, an en dash, "LA", PredictIt's wording
    from pmpol.universe.taxonomy import _city
    assert _city("2026 Louisville Mayoral Election Winner") == "louisville"
    assert _city("Waratah–Wynyard Mayoral Election Winner") == "waratah-wynyard"
    assert _city("LA Mayoral Election Winner") == "los angeles"
    assert _city("Who will be elected Greater Manchester mayor in 2026?") == "greater manchester"
    # a case caption is not a local race
    t = tag_event(Event("kalshi", "KXSCOTUS-28", "Will SCOTUS bar unpled affirmative defenses?", "", True,
                        [Market("kalshi", "m", "KXSCOTUS-28", "Will the Supreme Court rule in favor of Y in Y v. Fulton Judicial "
                                "Circuit District Attorney's Office", "Yes")]))
    assert t.office is None


def test_next_mayor_questions_and_vp_nominations_are_elections():
    from pmpol.models import Event, Market
    from pmpol.universe.taxonomy import tag_event

    def ev(venue, eid, title, category=""):
        return Event(venue, eid, title, category, True, [Market(venue, eid + "-m", eid, title, "A")])
    t = tag_event(ev("polymarket", "tshwane", "Next Mayor of Tshwane (Pretoria)?", "south-africa,politics"))
    assert (t.topic, t.country, t.jurisdiction, t.office) == ("elections_intl", "South Africa",
                                                               "South Africa/tshwane", "mayor")
    t = tag_event(ev("kalshi", "KXBERLIN-26", "Next Governing Mayor of Berlin?"))
    assert t.jurisdiction == "Germany/berlin"
    t = tag_event(ev("cryptocom", "vp", "Democratic VP Nominee 2028"))
    assert (t.office, t.stage, t.variant, t.jurisdiction) == ("president", "primary", "vp/D", "US")


def test_clusters_survive_titles_of_stop_words_only():
    from pmpol.models import Event, Market
    from pmpol.universe.cluster import build_clusters
    from pmpol.universe.index import Universe

    evs = [Event("kalshi", f"E{i}", t, markets=[Market("kalshi", f"M{i}", f"E{i}", t, "")])
           for i, t in enumerate(("Will the", "Who will win?", "Will it happen?", "Will it rain in Lima?"))]
    u = Universe.build(evs)
    build_clusters(u)
    assert len(u.clusters) == 4


@pytest.mark.parametrize("title,question,office,jurisdiction", [
    ("Welsh Local Elections winner?", "", "local", "United Kingdom/welsh local elections"),
    ("City of Edinburgh Council election winner?", "Will Labour win the most seats? (United Kingdom)", "local",
     "United Kingdom/city of edinburgh council"),
    ("Kolkata Municipal Election Winner", "Will the AITC win the Kolkata election in India?", "local",
     "India/kolkata municipal"),
    ("Swiss Federal Council by-election winner?", "", "parliament", "Switzerland"),
])
def test_foreign_local_elections_are_not_national(title, question, office, jurisdiction):
    from pmpol.models import Event, Market
    from pmpol.universe.taxonomy import tag_event

    t = tag_event(Event("kalshi", "E", title, markets=[Market("kalshi", "M", "E", question or title, "Labour")]))
    assert t.office == office and t.jurisdiction == jurisdiction
