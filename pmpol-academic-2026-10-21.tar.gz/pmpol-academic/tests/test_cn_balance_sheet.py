from pmpol import cn_balance_sheet as cb

ZH = "<p>前八个月人民币贷款增加10.44万亿元。分部门看，住户贷款减少1.03万亿元，其中，短期贷款减少1.05万亿元，中长期贷款增加188亿元；企（事）业单位贷款增加</p>"
ZH7 = "<p>分部门看，住户贷款减少8271亿元，其中，短期贷款减少9281亿元，中长期贷款增加1010亿元；</p>"
ZH25 = "<p>分部门看，住户贷款增加7110亿元，其中，短期贷款减少3725亿元，中长期贷款增加1.08万亿元；</p>"
EN25 = ("By sector, household loans increased by RMB680.7 billion, with short-term loans falling by RMB383.0 billion "
        "and medium and long-term (MLT) loans rising by RMB1.06 trillion; loans to enterprises")
LIST = ('<a href="/diaochatongjisi/116219/116225/a/index.html">2026年8月金融统计数据报告</a>'
        '<a href="/x/index.html">2026年上半年金融统计数据报告</a><a href="/y/index.html">2025年金融统计数据报告</a>'
        '<a href="/z/index.html">2025年8月社会融资规模存量统计数据报告</a>')


def test_discover_maps_titles_to_months():
    d = cb.discover(LIST)
    assert d[(2026, 8)].endswith("/a/index.html") and (2026, 6) in d and (2025, 12) in d and len(d) == 3


def test_household_flows_match_the_published_figures_with_rounding():
    ytd = {(2026, 8): cb.parse_household(ZH), (2026, 7): cb.parse_household(ZH7),
           (2025, 8): cb.parse_household(ZH25), (2025, 7): cb.parse_household(EN25)}
    assert ytd[(2025, 7)]["short"].value == -3830 and ytd[(2026, 8)]["total"].unc == 50
    r = cb.pbc_readings(ytd, 2026, 8)
    assert r["household_total"].value == -2029 and r["household_short"].value == -1219
    assert r["household_long"].value == -822
    yoy = r["household_short_loans_yoy"]
    assert yoy.value == -1324 and yoy.unc == 51.5  # 50 + 0.5 (2026) and 0.5 + 0.5 (2025)


def test_lights_with_ranges_uncertainty_and_derived_spread():
    cfg = cb.load()
    readings = dict(cfg.readings)
    cb.derived(readings)
    assert readings["rent_mortgage_spread"].value == -0.82
    light = {lt.id: lt for lt in cfg.lights}
    assert cb.status(light["rent_spread"], readings["rent_mortgage_spread"]) == "not met"
    assert cb.status(light["prepayment"], readings["mortgage_prepayment_rate"]) == "at the threshold"  # 10-15 vs <= 10
    near = cb.Reading("household_short_loans_yoy", "x", 30.0, "億元", "2026-09", "pbc", unc=50.0)
    assert cb.status(light["short_loans_yoy"], near) == "at the threshold"
    assert cb.status(light["short_loans_yoy"], None) == "no reading"
    p = cb.proof(cfg, readings)
    assert p.check() == [] and p.result["met"] == 0
    # supplied readings are opinions until checked; official ones are L1
    assert all(s.layer == "L3" for s in p.steps if s.id == "r:rent_spread")
