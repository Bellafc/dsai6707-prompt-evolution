import json

from pmpol import geo
from pmpol.models import Event, Market


def _cia(tmp_path):
    rows = [{"id": "NK-1", "schema": "Person", "last_seen": "2026-10-04T00:00:00",
             "properties": {"name": ["XI Jinping"], "citizenship": ["cn"], "position": ["President"],
                            "sourceUrl": ["https://www.cia.gov/resources/world-leaders/foreign-governments/china"]}},
            {"id": "NK-2", "schema": "Person", "last_seen": "2026-10-04T00:00:00",
             "properties": {"name": ["Somebody ELSE"], "citizenship": ["cn"], "position": ["Commissioner of Police - Hong Kong"],
                            "sourceUrl": ["x"]}}]
    p = tmp_path / "cia.json"
    p.write_text("\n".join(json.dumps(r) for r in rows), encoding="utf-8")
    return p


def _wd(tmp_path):
    rows = [{"id": "pos1", "schema": "Position", "properties": {"name": ["member of the Politburo of the Chinese Communist Party"], "country": ["cn"]}},
            {"id": "occ1", "schema": "Occupancy", "properties": {"holder": ["Q15031"], "post": ["pos1"], "status": ["current"], "startDate": ["2007-10-22"]}},
            {"id": "occ2", "schema": "Occupancy", "properties": {"holder": ["Q9"], "post": ["pos1"], "status": ["current"], "startDate": ["2022-10-23"]}},
            {"id": "Q15031", "schema": "Person", "properties": {"name": ["Xi Jinping"]}},
            {"id": "Q9", "schema": "Person", "properties": {"name": ["Cai Qi"]}}]
    p = tmp_path / "wd.json"
    p.write_text("\n".join(json.dumps(r, separators=(",", ":")) for r in rows), encoding="utf-8")
    return p


def test_graph_edges_rest_on_sources_and_people_merge_only_on_identical_names(tmp_path):
    theme = geo.Theme("t", "t", countries=["cn"], offices="^President$", bodies="Politburo", markets=r"Xi Jinping|purge")
    ev = Event("polymarket", "e1", "Who will Xi Jinping purge in 2026?", markets=[
        Market("polymarket", "m1", "e1", "q", "Cai Qi", bid=0.05, ask=0.07, active=True),
        Market("polymarket", "m2", "e1", "q", "Nobody Known", bid=0.01, ask=0.02, active=True)])
    unrelated = Event("polymarket", "e2", "Who wins the purge of the cup?", markets=[
        Market("polymarket", "m3", "e2", "q", "Team", bid=0.5, ask=0.6, active=True)])
    g = geo.build(theme, [ev, unrelated], None, cia=_cia(tmp_path), raw=_wd(tmp_path))
    persons = {n.label: n for n in g.nodes.values() if n.type == "person"}
    assert set(persons) == {"XI Jinping", "Cai Qi"}  # the Hong Kong office is left out; Xi merged across sources
    assert persons["XI Jinping"].attrs["wikidata"] == "Q15031"
    kinds = {(e.type, e.confidence) for e in g.edges}
    assert ("holds_office", "confirmed") in kinds and ("member_of", "reported") in kinds and ("bears_on", "inferred") in kinds
    assert "market:polymarket:e2" not in g.nodes  # a market that names nothing in the graph is dropped
    on = {g.nodes[e.target].label for e in g.edges if e.source == "market:polymarket:e1"}
    assert on == {"XI Jinping", "Cai Qi"}
    out = geo.page([g], tmp_path / "geo.html", "now")
    html = out.read_text(encoding="utf-8")
    blob = html.split('<script id="data" type="application/json">', 1)[1].split("</script>", 1)[0]
    assert json.loads(blob.replace("<\\/", "</"))["graphs"][0]["theme"] == "t"


def test_shipped_themes_load():
    assert {t.id for t in geo.load_themes()} >= {"hormuz", "china_elite"}


def test_csis_purge_ladder_and_conflicting_sources_side_by_side(tmp_path):
    csv = tmp_path / "csis.csv"
    csv.write_text(
        "Name,Name_CN,Rank,Position,Status,Status_Detail,Status Confidence,Date Under Investigation,"
        "Date Suspended/Removed ,Date Dismissed/Replaced,Date Expelled from CCP,Date Potentially Purged,Latest Recorded Event\n"
        "Cai Qi,蔡奇,Gen,CMC Member,Purged,Expelled,Confirmed,1/2/25,,,3/4/25,,2025-03\n"
        "Wu Guohua,吴国华,Gen,Deputy Commander,Potentially Purged,Missing,Unconfirmed,,,,,6/1/24,2024-06\n",
        encoding="utf-8")
    theme = geo.Theme("t", "t", countries=["cn"], offices="^President$", bodies="Politburo", purges="csis")
    g = geo.build(theme, [], None, cia=_cia(tmp_path), raw=_wd(tmp_path), csis=csv)
    cai = next(n for n in g.nodes.values() if n.label == "Cai Qi")
    assert cai.attrs["name_cn"] == "蔡奇" and cai.attrs["ladder"] == "調查 2025-01-02 → 開除黨籍 2025-03-04"
    edge = next(e for e in g.edges if e.source == cai.id and e.type == "purge_status")
    assert edge.confidence == "reported" and "Wikidata 仍列為現任" in edge.note  # both kept, not resolved
    wu = next(n for n in g.nodes.values() if n.label == "Wu Guohua")
    assert wu.id.startswith("person:csis:") and wu.attrs["csis_status"] == "可能被整肅"
    assert geo.fetch_csis(tmp_path / "none", get=lambda u: (_ for _ in ()).throw(RuntimeError("403"))) is None


def test_pinyin_spellings_share_a_key_and_mentions_need_consecutive_words():
    assert geo.name_keys("Zhang Youxia") & geo.name_keys("ZHANG You-xia") & geo.name_keys("Youxia Zhang") \
        & geo.name_keys("Zhang You Xia")
    assert geo.name_keys("Chen Min'er") & geo.name_keys("Chen Miner")
    assert not geo.name_keys("Li Jun") & geo.name_keys("Li Qiang")
    options = "Who will Xi Jinping purge in 2026? Wang Yi Li Qiang Dong Jun Zhang Shengmin"
    assert not geo.mentions("Li Jun", options)  # "Li" and "Jun" from two different people
    assert geo.mentions("XI Jinping", "Who will be named as Xi Jinping's successor?")
    assert geo.mentions("Zhang Youxia", "Will Zhang You-xia be removed?")
    assert not geo.surname_ok(options, "zhang", "ZHANG Guoqing")  # Zhang Shengmin is someone else
    assert geo.surname_ok("Iran leader end of 2026? Masoud Pezeshkian", "pezeshkian", "Masud PEZESHKIAN")
    assert geo.surname_ok("Will Pezeshkian resign?", "pezeshkian", "Masud PEZESHKIAN")


def test_csis_officers_with_one_name_stay_apart(tmp_path):
    csv = tmp_path / "csis.csv"
    csv.write_text(
        "Name,Name_CN,Rank,Position,Status,Status_Detail,Status Confidence,Latest Recorded Event\n"
        "Li Jun,李军,Lt Gen,Deputy Director of the Joint Operation Command Center,Potentially Purged,Missing,Unconfirmed,2025-01\n"
        "Li Jun,李军,Lt Gen,Director of the Political Work Department of the PAP,Potentially Purged,Missing,Unconfirmed,2025-02\n",
        encoding="utf-8")
    theme = geo.Theme("t", "t", countries=["cn"], offices="^President$", bodies="Politburo", purges="csis",
                      markets="Li Jun")
    ev = Event("polymarket", "e1", "Will Li Jun be purged?", markets=[
        Market("polymarket", "m1", "e1", "q", "Yes", bid=0.1, ask=0.2, active=True)])
    g = geo.build(theme, [ev], None, cia=_cia(tmp_path), raw=_wd(tmp_path), csis=csv)
    lis = [n for n in g.nodes.values() if n.type == "person" and n.label.startswith("Li Jun")]
    assert len(lis) == 2 and all(n.attrs["ambiguous_name"] for n in lis)
    assert "market:polymarket:e1" not in g.nodes  # an ambiguous name is not linked to either officer
