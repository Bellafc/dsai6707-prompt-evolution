import json

from pmpol import crosslink
from pmpol.movers.diff import Move
from pmpol.proof import Proof


def _move(key, a, b):
    return Move(key, "e", key.split(":")[0], f"T {key}", "Yes", "q", a, b, 0.01, 0.01, "2026-10-07T10:00:00+00:00",
                "2026-10-07T16:00:00+00:00")


def test_links_go_both_ways(tmp_path):
    path = tmp_path / "proofs.json"
    path.write_text(json.dumps({"observed_at": "2026-10-07T16:00:00+00:00", "signals": [
        {"id": "v1", "group": "rule", "kind": "k", "subject": "s", "edge": 0.05, "markets": ["kalshi:A", "polymarket:B"],
         "title": "v one", "rules": "unverified"},
        {"id": "v2", "group": "rule", "kind": "k", "subject": "s", "edge": 0.09, "markets": ["kalshi:A", "kalshi:C"],
         "title": "v two", "rules": "material"},  # rules differ materially: not linked
        {"id": "c", "group": "consensus", "markets": ["kalshi:A"]}]}))
    observed, vs = crosslink.load_violations(path)
    assert [v.id for v in vs] == ["v1"]
    moves = [_move("polymarket:B", 0.40, 0.48), _move("kalshi:Z", 0.1, 0.2)]
    links = crosslink.link(moves, vs, observed)
    assert list(links.by_market) == ["polymarket:B"] and links.moved[0][0].id == "v1"
    p = Proof("t", "c")
    crosslink.add_to_proof(p, moves[0], links, "2026-10-07T16:00:00+00:00")
    assert p.result["violations"] == ["v1"] and "快照" not in p.steps[-1].text and not p.check()
    crosslink.add_to_proof(p2 := Proof("t", "c"), moves[0], links, "2026-10-07T20:00:00+00:00")
    assert "不是這次異動的快照" in p2.steps[-1].text  # violations from another snapshot are labelled
    crosslink.add_to_proof(p3 := Proof("t", "c"), moves[1], links, "2026-10-07T16:00:00+00:00")
    assert not p3.steps
    assert "v one" in "\n".join(crosslink.render(links))
