import gzip
import json

import pytest

from pmpol import requirements as rq


def _data(tmp_path):
    signals = [
        {"kind": "consensus", "subject": "control(United States|house|2026)", "title": "共識｜control(United States|house|2026)｜D",
         "proof": {"conclusion": "共識機率 91%", "analytic_confidence": "low", "result": {"pooled": 0.91}}},
        {"kind": "consensus", "subject": "control(United States|house|2026)", "title": "共識｜control(United States|house|2026)｜R",
         "proof": {"conclusion": "共識機率 9%", "analytic_confidence": "low", "result": {"pooled": 0.09}}},
        {"kind": "consensus", "subject": "seats(United States|CA|house|2026|general, D/won)", "title": "共識｜seats｜44",
         "proof": {"conclusion": "1%", "analytic_confidence": "low", "result": {"pooled": 0.01}}},
        {"kind": "outside_view", "subject": "control(United States|house|2026)", "title": "外部視角｜control(United States|house|2026)",
         "proof": {"conclusion": "基準率 10%", "analytic_confidence": "moderate", "result": {"base_rate": 0.1}}},
        {"kind": "onto:winner:same_set", "subject": "winner(Brazil|Brazil|president|2026|general)", "title": "t",
         "proof": {"conclusion": "c", "analytic_confidence": "high"}},
    ]
    (tmp_path / "proofs.json").write_text(json.dumps({"signals": signals}), encoding="utf-8")
    (tmp_path / "macro").mkdir()
    (tmp_path / "macro" / "regimes.json").write_text(json.dumps([{"title": "薩姆規則（美國）", "conclusion": "未觸發"}]),
                                                     encoding="utf-8")
    (tmp_path / "snapshots").mkdir()
    with gzip.open(tmp_path / "snapshots" / "universe_20261004T1215Z.json.gz", "wt", encoding="utf-8") as f:
        json.dump([{"venue": "kalshi", "title": "Which party will win the House in 2026?"},
                   {"venue": "kalshi", "title": "Recession this year?"},
                   {"venue": "polymarket", "title": "TX-35 House winner"}], f)
    return rq.gather(tmp_path)


REQ = rq.Requirement("house", "誰控制眾議院？", 1, "why",
                     ['^control\\(United States\\|house\\|2026\\)$', '^seats\\(United States\\|[^|]*\\|house\\|2026'],
                     markets="(?=.*\\bHouse\\b)(?=.*(2026|midterm))(?=.*(control|majority|which party|win the House))",
                     lines=["market", "consensus", "reference", "ratings", "polls"])


def test_coverage_answers_lines_and_gaps(tmp_path):
    c = rq.cover(REQ, _data(tmp_path))
    assert c.markets == {"kalshi": 1}  # the district race is not about control
    assert c.lines["consensus"] == 3 and c.lines["reference"] == 1 and c.lines["market"] == 1
    assert c.gaps == ["ratings", "polls"]
    # the headline subject first: its outside view, then its likeliest outcome; the seat ladder after
    assert [a[1] for a in c.answers] == ["基準率 10%", "共識機率 91%", "共識機率 9%", "1%"]
    assert c.confidence == {"low": 3, "moderate": 1}


def test_residue_and_render(tmp_path):
    ev = _data(tmp_path)
    recession = rq.Requirement("rec", "衰退？", 2, "why", ["recession"], markets="recession", macro="薩姆",
                               lines=["market", "macro", "fundamentals"])
    assert rq.residue([REQ, recession], ev) == (1, 5)  # only the Brazil violation answers no question
    c = rq.cover(recession, ev)
    assert c.lines["macro"] == 1 and c.gaps == ["fundamentals"]
    text = rq.render([rq.cover(REQ, ev), c], rq.residue([REQ, recession], ev), "now")
    assert "缺口（要蒐集的）**：專家評級、民調" in text and "1 / 5（20%）" in text


def test_the_shipped_requirements_load_and_name_known_lines(tmp_path):
    reqs = rq.load()
    assert reqs and reqs[0].priority == 1 and all(r.lines for r in reqs)
    bad = tmp_path / "requirements.toml"
    bad.write_text('[[requirement]]\nid = "x"\nquestion = "q"\npriority = 1\nwhy = "w"\nsubjects = []\n'
                   'lines = ["tea leaves"]\n', encoding="utf-8")
    with pytest.raises(ValueError):
        rq.load(bad)
