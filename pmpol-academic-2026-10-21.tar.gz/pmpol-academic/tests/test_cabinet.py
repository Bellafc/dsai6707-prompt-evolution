from pmpol.models import Event, Market
from pmpol.propositions import Parsed
from pmpol.propositions.cabinet import key, parse_cabinet, resolve
from pmpol.propositions.derive import _cabinet, derive
from pmpol.universe.index import Universe

K_RULE = ("If a coalition that includes {p} make up the next elected ruling government of Sweden before Jan 1, 2028, "
          "then the market resolves to Yes. A party is considered to be part of government if one or more of its "
          "representatives hold at least one ministerial or cabinet-level position (including junior ministers or "
          "equivalent executive roles, if applicable) in the new government.")
P_MEMBER = ("This market will resolve to “Yes” if the listed political party is included in the first Swedish "
            "government formed after the 2026 Swedish parliamentary elections. A party will only be considered part of "
            "the government if it provides at least one cabinet minister.")
P_COAL = ("This market will resolve to the first ruling coalition of parties that forms after the 2026 Swedish "
          "parliamentary election. A party will only be considered part of the ruling coalition if it provides at "
          "least one cabinet minister.")


def _m(venue, mid, eid, outcome, rules, bid=0.4, ask=0.42):
    return Market(venue, mid, eid, "q", outcome, bid=bid, ask=ask, rules=rules, active=True)


def _events():
    k = Event("kalshi", "KXSWEDENGOVT", "Who will be a part of the next government of Sweden?", markets=[
        _m("kalshi", f"K-{p[:3]}", "KXSWEDENGOVT", p, K_RULE.format(p=p)) for p in ("Liberals", "Centre Party", "Greens")])
    p = Event("polymarket", "sweden-parties", "Which parties will be in next Swedish Government?", markets=[
        _m("polymarket", f"p-{a}", "sweden-parties", f"{n} ({a})", P_MEMBER)
        for n, a in (("Liberals", "L"), ("Centre Party", "C"), ("Green Party", "MP"), ("Moderate Party", "M"),
                     ("Christian Democrats", "KD"), ("Swedish Social Democratic Party", "S"))])
    c = Event("polymarket", "sweden-coalition", "Which coalition will form the next Swedish government?", markets=[
        _m("polymarket", f"c-{i}", "sweden-coalition", lab, P_COAL, bid=b, ask=b + 0.01)
        for i, (lab, b) in enumerate((("M + KD + L", 0.10), ("M + KD + L + C", 0.10), ("S + MP", 0.30),
                                      ("S + XY", 0.05), ("Other", 0.02)))])
    return k, p, c


def test_names_resolve_across_venues_and_abbreviations():
    assert key("Centre Party (C)") == key("Centre Party") == "centre"
    assert key("Hadash–Ta'al") == "hadash taal" and key("Shas") == "shas"
    out = Parsed()
    for e in _events():
        assert parse_cabinet(e, out)
    props = resolve(out.props, out.unparsed)
    vals = {p.market: next(iter(p.values)) for p in props}
    assert vals["kalshi:K-Gre"] == vals["polymarket:p-MP"] == "has:green"  # "Greens" / "Green Party (MP)"
    assert vals["kalshi:K-Lib"] == vals["polymarket:p-L"] == "has:liberals"
    assert vals["polymarket:c-0"] == "is:christian democrats+liberals+moderate"
    assert vals["polymarket:c-2"] == "is:green+swedish social democratic"
    # a member nobody lists is not guessed; "Other" is not a coalition
    assert "polymarket:c-3" not in vals and "not identified" in out.unparsed["polymarket:c-3"]
    assert "polymarket:c-4" in out.unparsed


def test_coalitions_that_include_a_party_add_up_to_no_more_than_its_membership():
    k, p, c = _events()
    u = Universe.build([k, p, c])
    out = Parsed()
    for e in (k, p, c):
        parse_cabinet(e, out)
    props = resolve(out.props, out.unparsed)
    rels = derive(u, props)
    same = {(tuple(r.lhs), tuple(r.rhs)) for r in rels if r.basis == "same_set"}
    assert (("kalshi:K-Lib",), ("polymarket:p-L",)) in same or (("polymarket:p-L",), ("kalshi:K-Lib",)) in same
    sums = [r for r in _cabinet({props[0].var: props}) if r.rhs == ["polymarket:p-L"]]
    assert sums and sums[0].basis == "coalitions_contain_party"
    assert set(sums[0].lhs) == {"polymarket:c-0", "polymarket:c-1"} and sums[0].kind == "implies"


def test_rules_without_a_ministerial_test_are_left_unread():
    e = Event("polymarket", "berlin", "Which parties will be in the next Berlin state government?", markets=[
        _m("polymarket", "b-cdu", "berlin", "CDU", "Resolves Yes if CDU is part of the next government.")])
    out = Parsed()
    assert parse_cabinet(e, out) and not out.props and "ministerial" in out.unparsed["polymarket:b-cdu"]
