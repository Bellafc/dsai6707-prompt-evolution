import numpy as np

from pmpol.kb import KnowledgeBase
from pmpol.models import Event, Market
from pmpol.universe import consensus as cons
from pmpol.universe import family_corr as fc


def _gaps(rho, n=4000, seed=0):
    """Gaps simulated from the consensus model with a known rho: d ~ N(0, sf^2 + sg^2 - 2 rho sf sg)."""
    rng = np.random.default_rng(seed)
    out = []
    for i in range(n):
        af, ag = rng.uniform(0, 0.5, 2)
        sf, sg = af + cons.SIGMA0, ag + cons.SIGMA0
        d = rng.normal(0, np.sqrt(sf ** 2 + sg ** 2 - 2 * rho * sf * sg))
        out.append(fc.Gap(i // 4, "s", "kalshi-polymarket", float(d), float(af), float(ag)))
    return out


def test_coverage_rho_recovers_the_simulated_correlation():
    for rho in (0.0, 0.4, 0.8):
        gaps = _gaps(rho)
        assert abs(fc.coverage_rho(gaps) - rho) < 0.12
        assert abs(fc.coverage(gaps, rho) - 0.95) < 0.015
    (lo, hi), noise_ci, shift_ci = fc.bootstrap(_gaps(0.4), reps=50)
    assert lo < 0.4 < hi and noise_ci == {} and shift_ci == {}


def test_gaps_wider_than_the_model_allows_hit_the_boundary():
    wide = [fc.Gap(i, "s", "kalshi-predictit", 5.0 * (-1) ** i, 0.0, 0.0) for i in range(100)]
    assert fc.coverage_rho(wide) == -1.0


def _market(venue, mid, spread=0.02):
    return Market(venue, f"{venue}-m", f"{venue}-e", "Will X win?", "X", bid=mid - spread / 2, ask=mid + spread / 2,
                  active=True)


def test_collect_pools_a_family_once_and_uses_the_consensus_filters():
    k, p, pu = _market("kalshi", 0.40), _market("polymarket", 0.44), _market("polymarket_us", 0.46)
    wide = _market("smarkets", 0.60, spread=0.30)  # spread above 10 points: left out, as in the consensus
    events = [Event(m.venue, m.event_id, "t", markets=[m]) for m in (k, p, pu, wide)]
    gaps = fc.collect([("g", [k.key, p.key, pu.key, wide.key])], [("snap", events)])
    assert [g.pair for g in gaps] == ["kalshi-polymarket"]
    assert -0.3 < gaps[0].d < -0.2  # logit 0.40 minus the pooled Polymarket family (0.44 and 0.46)


def test_consensus_reads_the_estimated_rho_and_cites_it(tmp_path):
    (tmp_path / "f.yaml").write_text(
        "facts:\n  - id: consensus.family_correlation\n    layer: L2\n    subject: s\n    predicate: p\n"
        "    value: {rho: 0.44, ci_low: 0.34, ci_high: 0.53, n_contracts: 1309}\n"
        "    source: {title: t, url: https://example.org}\n    admiralty: B3\n    status: proposed\n"
        "    recorded_at: 2026-10-04\n")
    kb = KnowledgeBase.load(tmp_path)
    assert cons.family_rho(kb) == (0.44, "consensus.family_correlation")
    assert cons.family_rho(None) == (cons.RHO, None)


def _noisy_gaps(rho, extra, n=6000, seed=2):
    """Kalshi-Polymarket gaps from the model, plus PredictIt gaps with extra noise in probability units."""
    rng = np.random.default_rng(seed)
    out = []
    for i in range(n):
        pi = i % 2 == 0
        p = float(rng.uniform(0.02, 0.98))
        af, ag = rng.uniform(0, 0.3, 2)
        sf = af + cons.SIGMA0
        sg = ag + cons.SIGMA0 + (extra / (p * (1 - p)) if pi else 0.0)
        d = rng.normal(0, np.sqrt(sf ** 2 + sg ** 2 - 2 * rho * sf * sg))
        pair = "kalshi-predictit" if pi else "kalshi-polymarket"
        out.append(fc.Gap(i // 4, "s", pair, float(d), float(af), float(ag), p, p))
    return out


def test_fit_recovers_rho_from_clean_pairs_and_the_noisy_venues_extra_noise():
    gaps = _noisy_gaps(0.5, 0.012)
    rho, noise = fc.fit(gaps, ("predictit",))
    assert abs(rho - 0.5) < 0.12 and abs(noise["predictit"] - 0.012) < 0.004
    # one rho for everything is pulled down by the noisy venue, and undercovers its pairs
    single = fc.coverage_rho(gaps)
    assert single < rho
    pi = [g for g in gaps if g.pair == "kalshi-predictit"]
    assert fc.coverage(pi, single) < fc.coverage(pi, rho, noise)
    assert fc.fit_noise([g for g in gaps if g.pair == "kalshi-polymarket"], "predictit", rho) == 0.0


def test_estimate_reports_the_direction_of_the_noisy_venues_gaps():
    gaps = _noisy_gaps(0.5, 0.012, n=2000)
    e = fc.estimate(gaps, ("predictit",), reps=20)
    assert set(e.noise) == {"predictit"} and e.noise_ci["predictit"][0] <= e.noise["predictit"]
    assert [lv[0] for lv in e.levels["predictit"]][0] == (0, 0.05)
    page = fc.render(e, "now")
    assert "PredictIt 的偏離" in page and "另加" in page
    yaml_text = fc.kb_yaml(e, __import__("datetime").date(2026, 10, 4))
    assert "consensus.venue_noise.predictit" in yaml_text


def test_consensus_uses_the_venue_noise_to_down_weight_the_venue(tmp_path):
    from pmpol.universe.index import Universe

    (tmp_path / "f.yaml").write_text(
        "facts:\n  - id: consensus.venue_noise.predictit\n    layer: L2\n    subject: s\n    predicate: p\n"
        "    value: {extra: 0.012, ci_low: 0.009, ci_high: 0.015}\n"
        "    source: {title: t, url: https://example.org}\n    admiralty: B3\n    status: proposed\n"
        "    recorded_at: 2026-10-04\n")
    kb = KnowledgeBase.load(tmp_path)
    assert cons.venue_noise(kb) == {"predictit": (0.012, "consensus.venue_noise.predictit")}
    k, pi = _market("kalshi", 0.03), _market("predictit", 0.06)
    u = Universe.build([Event(m.venue, m.event_id, "t", markets=[m]) for m in (k, pi)])
    plain = cons.estimate(u, [k.key, pi.key], "g", None, None)
    noisy = cons.estimate(u, [k.key, pi.key], "g", kb, None)
    assert noisy.weights[pi.key] < plain.weights[pi.key] and noisy.pooled < plain.pooled
    assert noisy.noise_from == ["consensus.venue_noise.predictit"]


def test_directional_shift_is_estimated_removed_and_applied_in_the_consensus(tmp_path):
    rng = np.random.default_rng(5)
    gaps = []
    for i in range(3000):  # PredictIt pressed 1 point toward 50%, plus noise
        p = float(rng.uniform(0.02, 0.98))
        q = min(max(p - 0.01 * np.tanh((p - 0.5) / cons.SHIFT_WIDTH) + rng.normal(0, 0.005), 0.005), 0.995)
        gaps.append(fc.Gap(i // 3, "s", "kalshi-predictit", cons._logit(p) - cons._logit(q), 0.05, 0.05, p, q))
    shift = fc.fit_shift(gaps, "predictit")
    assert abs(shift - 0.01) < 0.002
    after = fc.unshift(gaps, {"predictit": shift})
    assert abs(np.mean([g.p_g - g.p_f for g in after if g.p_f < 0.1])) < 0.003  # the longshot premium is gone
    assert fc.unshift(gaps[:5], {}) == gaps[:5]
    # the consensus moves PredictIt's quote back toward the extreme before pooling, and says so
    (tmp_path / "f.yaml").write_text(
        "facts:\n  - id: consensus.venue_shift.predictit\n    layer: L2\n    subject: s\n    predicate: p\n"
        "    value: {shift: 0.01, ci_low: 0.008, ci_high: 0.012, width: 0.1}\n"
        "    source: {title: t, url: https://example.org}\n    admiralty: B3\n    status: proposed\n"
        "    recorded_at: 2026-10-05\n")
    kb = KnowledgeBase.load(tmp_path)
    from pmpol.models import Relation
    from pmpol.universe.index import Universe

    k, pi = _market("kalshi", 0.05), _market("predictit", 0.06)
    u = Universe.build([Event(m.venue, m.event_id, "t", markets=[m]) for m in (k, pi)])
    rel = Relation("equivalent", [k.key], [pi.key], "x", "g", "rule")
    with_shift = cons.run(u, [rel], kb)[0]
    without = cons.run(u, [rel], None)[0]
    assert with_shift.pooled < without.pooled and with_shift.shift_from == ["consensus.venue_shift.predictit"]
    p = cons.explain(with_shift, kb, "t")
    assert any("壓向 50%" in s.text for s in p.steps) and p.check() == []
    assert with_shift.markets[1].mid == 0.06  # the venue's own quote is reported as it was


def test_the_shift_never_reaches_the_extremes():
    assert cons.unshift_p(0.003, 0.01) == 0.0015 and cons.unshift_p(0.999, 0.01) == 0.9995
    assert cons.unshift_p(0.5, 0.01) == 0.5 and abs(cons.unshift_p(0.2, 0.01) - 0.19) < 1e-3
