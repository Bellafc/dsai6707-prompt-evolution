import json

from pmpol.movers import flow as fl
from pmpol.proof import Proof

A, B = "0xAAAA000000000000000000000000000000000001", "0xBBBB000000000000000000000000000000000002"


def _trade(addr, ts, price, size, side="BUY", event="ev"):
    return {"proxyWallet": addr, "name": "Some Name", "pseudonym": "Nick", "bio": "about me", "profileImage": "x.png",
            "side": side, "price": price, "size": size, "timestamp": ts, "outcomeIndex": 0, "eventSlug": event,
            "transactionHash": "0xhash"}


def _fake(start):
    def get(url, params):
        if url.endswith("/markets"):
            return [{"conditionId": "0xcond"}]
        if url.endswith("/closed-positions"):  # A: 25 closed, 20 with a profit; B: 5 closed
            n, wins = (25, 20) if params["user"] == A else (5, 5)
            return [{"proxyWallet": params["user"], "name": "Some Name", "realizedPnl": 1.0 if i < wins else -1.0}
                    for i in range(n)]
        if "user" in params:  # wallet histories: A is new and trades one event, B is old and trades many
            if params["user"] == A:
                return [_trade(A, start - 86400, 0.1, 10)]
            return [_trade(B, start - 400 * 86400 + i, 0.5, 1, event=f"e{i}") for i in range(20)]
        if params.get("offset", 0) > 0:
            return []
        return [_trade(A, start + 100, 0.10, 9000), _trade(B, start + 200, 0.60, 100), _trade(B, start - 10, 0.6, 5)]
    return get


def test_flow_features_are_aggregate_and_nothing_personal_is_kept(tmp_path):
    start = 1_791_100_000
    client = fl.Client(get=_fake(start), cache=tmp_path, pause=0)
    from datetime import datetime, timezone

    ts = lambda t: datetime.fromtimestamp(t, timezone.utc).isoformat()  # noqa: E731
    f = fl.for_move("some-slug", ts(start), ts(start + 3600), news_first=ts(start + 150), client=client)
    assert f.trades == 2 and f.wallets == 2 and f.volume_usd == 960.0  # the trade before the window is left out
    assert f.top_share == 0.9375 and f.longshot_buy_share == 0.9375  # A bought 900 USD at 10 cents
    assert f.new_wallet_share == 0.9375 and f.single_event_share == 0.9375 and f.before_news_share == 0.9375
    assert f.dormant_share == 0.0625  # B last traded 400 days before the window
    assert f.skilled_share == 0.9375  # A: 20 of 25 closed positions in profit; B has too few
    stored = " ".join(p.read_text() for p in tmp_path.iterdir())
    for secret in (A.lower(), B.lower(), "Some Name", "Nick", "about me", "x.png", "0xhash"):
        assert secret.lower() not in stored.lower()
    p = Proof("t", "c")
    fl.add_to_proof(p, f, "some-slug", ts(start + 3600))
    text = json.dumps(p.to_dict(), ensure_ascii=False)
    assert A.lower() not in text.lower() and "Some Name" not in text and p.check() == []
    assert any(a["verdict"] == "supports" for a in p.alternatives)


def test_cached_trades_reread_addresses_only_in_memory(tmp_path):
    start = 1_791_100_000
    from datetime import datetime, timezone

    ts = lambda t: datetime.fromtimestamp(t, timezone.utc).isoformat()  # noqa: E731
    fl.for_move("s", ts(start), ts(start + 3600), client=fl.Client(get=_fake(start), cache=tmp_path, pause=0))
    again = fl.Client(get=_fake(start), cache=tmp_path, pause=0)  # a new run: trades come from the cache
    f = fl.for_move("s", ts(start), ts(start + 3600), client=again)
    assert f.profiled == 2 and set(again.addresses.values()) == {A, B}


def test_dormant_needs_a_history():
    start = 1_000_000_000
    assert fl.dormant({"ts": [start - 90 * 86400], "complete": True}, start) is True
    assert fl.dormant({"ts": [start - 5 * 86400], "complete": True}, start) is False
    assert fl.dormant({"ts": [], "complete": True}, start) is False  # new, not reactivated
    assert fl.dormant({"ts": [start + 10], "complete": False}, start) is None  # history cut off
    assert fl.dormant({"trades": 3}, start) is None  # profile cached before timestamps were kept
