from datetime import date

from pmpol import realtime as rtm


def test_sahm_indicator_and_episodes():
    flat = [4.0] * 14 + [4.0, 4.6, 4.9]
    assert abs(rtm.sahm(flat) - 0.5) < 1e-9 and rtm.sahm([4.0] * 10) is None
    assert rtm.episodes({"2020-01": 0.1, "2020-02": 0.6, "2020-03": 0.7, "2020-04": 0.2, "2020-05": 0.5}) == \
        ["2020-02", "2020-05"]


def test_signals_are_scored_against_recession_starts():
    usrec = {m: 0.0 for m in rtm.months("2000-01", "2010-12")}
    for m in rtm.months("2008-01", "2009-06"):
        usrec[m] = 1.0
    rows = rtm.score(["2007-03", "2008-04", "2003-07"], usrec)
    assert [(r["outcome"], r["recession_start"], r["months_after_start"]) for r in rows] == [
        ("hit", "2008-01", -10), ("hit", "2008-01", 3), ("false_alarm", None, None)]


def test_vintages_are_read_as_published_and_never_see_later_months(tmp_path):
    def get(url):
        dates = url.split("vintage_date=")[1].split(",")
        head = "observation_date," + ",".join(f"UNRATE_{d.replace('-', '')}" for d in dates)
        # each vintage knows the months up to its own date; later vintages revise 2020-01 from 4.0 to 4.1
        rows = []
        for m in rtm.months("2019-01", "2020-03"):
            cells = []
            for d in dates:
                known = f"{m}-01" < d[:8] + "01"
                cells.append(("4.1" if m == "2020-01" and d >= "2020-03-15" else "4.0") if known else "")
            rows.append(f"{m}-01," + ",".join(cells))
        return "\n".join([head, *rows])

    v = rtm.fetch_vintages(["2020-01", "2020-02"], cache=tmp_path, get=get, pause=0)
    assert v["2020-01"][-1] == 4.0 and v["2020-02"][-2] == 4.1 and len(v["2020-02"]) == len(v["2020-01"]) + 1
    assert list(tmp_path.iterdir())  # cached


def test_record_and_fact(tmp_path):
    from pmpol.kb import KnowledgeBase

    ms = rtm.months("1990-01", "1993-12")
    revised = {m: (5.0 if m < "1991-03" else 6.0) for m in ms}
    vintages = {m: [revised[x] for x in ms if x <= m] for m in ms}
    usrec = {m: (1.0 if "1991-01" <= m <= "1991-06" else 0.0) for m in ms}
    rec = rtm.record(vintages, revised, usrec, start="1990-01")
    assert rec["real_time"]["hits"] == 1 and rec["real_time"]["missed"] == [] and rec["recession_starts"] == ["1991-01"]
    (tmp_path / "r.yaml").write_text(rtm.kb_yaml(rec, date(2026, 10, 6)), encoding="utf-8")
    kb = KnowledgeBase.load(tmp_path)
    assert kb.errors == [] and kb.facts[rtm.FACT].value["real_time"]["triggers"][0]["outcome"] == "hit"
