import io
import sqlite3
import zipfile
from datetime import datetime, timedelta, timezone

import pytest

from pmpol.osint import gdelt_files as gd

TOPIC = gd.Topic("taiwan_strait", "taiwan_strait", "台海", [frozenset({"CHN", "TWN"})])


def _row(eid, a1, a2, quad, code="190", articles=1, url="https://example.org/a"):
    r = [""] * 61
    r[0], r[6], r[7], r[16], r[17], r[26], r[29], r[33], r[60] = eid, a1, a1, a2, a2, code, quad, str(articles), url
    return "\t".join(r)


def _zip(stamp: str, rows: list[str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(f"{stamp}.export.CSV", "\n".join(rows) + "\n")
    return buf.getvalue()


def test_stamps_are_quarter_hours():
    s = gd.stamps(datetime(2026, 10, 7, 16, 37, tzinfo=timezone.utc), 1)
    assert s == ["20261007154500", "20261007160000", "20261007161500", "20261007163000"]


def test_parse_counts_pairs_in_either_order():
    rows = [_row("1", "CHN", "TWN", "4", articles=5), _row("2", "TWN", "CHN", "4", articles=9),
            _row("3", "CHN", "TWN", "3"), _row("4", "CHN", "USA", "4"), _row("5", "CHN", "TWN", "1")]
    fc = gd.parse("20261007160000", _zip("20261007160000", rows), [TOPIC])
    assert fc.total == 5
    assert fc.counts["taiwan_strait"] == {"verbal": 1, "material": 2}
    assert [e["event_id"] for e in fc.examples["taiwan_strait"]] == ["2", "1"]  # most articles first


def test_reading_needs_history_before_calling_elevated():
    conn = sqlite3.connect(":memory:")
    end = datetime(2026, 10, 7, 16, 0)
    for i in range(4 * 24 * 3):  # three days of files
        stamp = (end - timedelta(minutes=15 * i)).strftime("%Y%m%d%H%M%S")
        recent = i < 16
        n_mat = 5 if recent else (1 if i % 4 == 0 else 0)
        rows = [_row(f"{i}-{k}", "CHN", "TWN", "4") for k in range(n_mat)] + \
            [_row(f"{i}-x{k}", "USA", "GBR", "1") for k in range(100 - n_mat)]
        gd.save(conn, gd.parse(stamp, _zip(stamp, rows), [TOPIC]))
    r = gd.reading(conn, TOPIC)
    assert r.recent_total == 1600 and r.recent_material == 80
    assert len(r.blocks) >= gd.MIN_BLOCKS and r.rank == 0 and r.ratio > 2 and r.elevated
    p = gd.proof(r)
    assert not p.check() and p.result["elevated"] is True

    short = sqlite3.connect(":memory:")
    for i in range(20):
        stamp = (end - timedelta(minutes=15 * i)).strftime("%Y%m%d%H%M%S")
        gd.save(short, gd.parse(stamp, _zip(stamp, [_row(str(i), "CHN", "TWN", "4")]), [TOPIC]))
    assert gd.reading(short, TOPIC).elevated is None  # not enough history


def test_ingest_skips_stored_and_missing_files():
    import httpx

    conn = sqlite3.connect(":memory:")
    newest = "20261007163000"
    body = _zip(newest, [_row("1", "CHN", "TWN", "4")])
    import hashlib

    def get(url):
        if url.endswith("lastupdate.txt"):
            return f"1 {hashlib.md5(body).hexdigest()} http://data.gdeltproject.org/gdeltv2/{newest}.export.CSV.zip\n".encode()
        if "20261007161500" in url:
            raise httpx.HTTPStatusError("404", request=httpx.Request("GET", url), response=httpx.Response(404))
        return body if newest in url else _zip("x", [_row("2", "USA", "GBR", "1")])

    got = gd.ingest(conn, [TOPIC], 1, get=get, pause=0)
    assert got["fetched"] == 3 and got["missing"] == ["20261007161500"]
    assert gd.ingest(conn, [TOPIC], 1, get=get, pause=0)["fetched"] == 0  # already stored

    def bad(url):
        return b"1 deadbeef http://x/20261007163000.export.CSV.zip\n" if url.endswith("lastupdate.txt") else body

    with pytest.raises(ValueError):
        gd.ingest(sqlite3.connect(":memory:"), [TOPIC], 0.25, get=bad, pause=0)


def test_topics_config_loads():
    topics = gd.load_topics()
    assert {t.id for t in topics} >= {"taiwan_strait", "hormuz"}
    assert all(len(d) == 2 for t in topics for d in t.dyads)
