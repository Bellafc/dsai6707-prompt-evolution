import math

import pytest

from pmpol import diagnostics as dg


def _months(start_year, n):
    return [f"{start_year + i // 12}-{i % 12 + 1:02d}" for i in range(n)]


def test_hypothesis_window_and_undated_tail():
    ms = _months(2000, 36)
    usrec = {m: (1.0 if m in ("2001-06", "2001-07") else 0.0) for m in ms}
    h = dg.hypothesis(usrec, lead=12)
    assert h["2000-06"] and h["2001-07"] and not h["2000-05"] and not h["2001-08"]
    assert max(h) == "2001-12"  # later months' 12-month windows run past the dated sample


def test_likelihood_ratios_and_posterior():
    ms = _months(1970, 240)
    hyp = {m: (int(m[:4]) % 5 == 0) for m in ms}  # one year in five
    # on in 60% of H months and 10% of the others
    sig = {m: (int(m[5:7]) <= 7.2 if hyp[m] else int(m[5:7]) <= 1.2) for m in ms}
    r = dg.likelihood_ratios("sahm_real_time", sig, hyp)
    assert r.tpr == pytest.approx(7 / 12) and r.fpr == pytest.approx(1 / 12)
    assert r.lr_pos == pytest.approx(7.0) and r.lr_neg == pytest.approx((5 / 12) / (11 / 12))
    assert r.lr_pos_ci[0] <= r.lr_pos <= r.lr_pos_ci[1]
    prior = r.base_rate
    assert r.posterior(True) == pytest.approx(prior * 7 / (prior * 7 + (1 - prior)))
    assert r.posterior(False) < prior < r.posterior(True)
    assert dg.likelihood_ratios("x", {m: True for m in ms[:50]}, hyp) is None  # too few months
    text = dg.kb_yaml([r], __import__("datetime").date(2026, 10, 7))
    assert "macro.sahm_rule.diagnosticity" in text and "lr_pos: 7.00" in text


def test_a_signal_that_never_fires_outside_h_has_an_infinite_ratio():
    ms = _months(1980, 144)
    hyp = {m: m[:4] in ("1982", "1985") for m in ms}
    r = dg.likelihood_ratios("yield_curve_inverted", {m: hyp[m] for m in ms}, hyp)
    assert math.isinf(r.lr_pos) and r.lr_neg == 0.0 and "∞" in dg.render([r])


def test_macro_proof_weighs_the_reading(monkeypatch):
    from types import SimpleNamespace as NS

    from pmpol.macro.regimes import _diagnostic
    from pmpol.proof import Proof

    fact = NS(id="macro.sahm_rule.diagnosticity", recorded_at="2026-10-07",
              value={"sample": "1970-01..2025-09", "tpr": 0.43, "fpr": 0.17, "lr_pos": 2.51, "lr_pos_90": [1.47, 4.55],
                     "lr_neg": 0.69, "lr_neg_90": [0.5, 0.88], "base_rate": 0.25, "lead_months": 12})
    kb = NS(facts={fact.id: fact})
    p = Proof("t", "c")
    _diagnostic(p, kb, fact.id, False, "薩姆規則")
    assert p.result["diagnostic"][fact.id]["posterior"] == pytest.approx(0.25 / 0.75 * 0.69 / (1 + 0.25 / 0.75 * 0.69), abs=1e-4)
    assert p.alternatives[0]["verdict"] == "against" and p.check() == []
