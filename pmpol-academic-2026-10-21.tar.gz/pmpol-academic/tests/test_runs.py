import json
import sqlite3
from datetime import date, datetime, timezone

import pytest

from pmpol import contracts, runs, store
from pmpol.models import Event, Market, Signal


def _events(venue="kalshi", rules="r1", bid=0.4, ask=0.42, n=3):
    return [Event(venue, f"E{i}", f"Event {i}", markets=[
        Market(venue, f"M{i}", f"E{i}", "q", "Yes", rules=rules, bid=bid, ask=ask, close_time="2026-11-04T00:00:00Z")])
        for i in range(n)]


def test_venue_contract_flags_bad_prices_duplicates_and_shrinking_feeds():
    evs = _events(n=4)
    evs[0].markets[0].ask = 1.4
    evs[1].markets.append(Market("kalshi", "M1", "E1", "q", "No", bid=0.6, ask=0.5))
    got = {c.name: c for c in contracts.venue_checks("kalshi", evs, previous_n=10)}
    assert not got["prices_in_unit_interval"].ok and "kalshi:M0" in got["prices_in_unit_interval"].detail
    assert not got["unique_market_ids"].ok and not got["uncrossed_books"].ok
    assert not got["count_vs_previous_run"].ok and got["count_vs_previous_run"].severity == "warn"
    assert all(c.ok for c in contracts.venue_checks("kalshi", _events(), previous_n=3))


def test_macro_contract_freshness_depends_on_frequency():
    from pmpol.macro.sources import Fetched, Observation, SeriesSpec

    spec = SeriesSpec("us.x", "fred", "X")
    monthly = [Observation("us.x", "fred:X", date(2026, m, 1), 1.0) for m in range(1, 5)]
    quarterly = [Observation("us.x", "fred:X", date(2025, m, 1), 1.0) for m in (1, 4, 7, 10)]
    old, q = (contracts.macro_checks([Fetched(spec, "u", "t", obs)], date(2026, 10, 3))
              for obs in (monthly, quarterly))
    assert [c.ok for c in old if c.name == "fresh"] == [False]  # April data in October: monthly series is stale
    assert [c.ok for c in q if c.name == "fresh"] == [False]
    assert "quarterly" in q[1].observed


def test_quotes_are_keyed_by_observation_time_so_replays_add_nothing(tmp_path):
    conn = store.connect(tmp_path / "db.sqlite")
    assert store.save_events(conn, _events(), observed_at="2026-10-02T20:46+00:00") == 3
    assert store.save_events(conn, _events(), observed_at="2026-10-02T20:46+00:00") == 0
    assert store.save_events(conn, _events(rules="r2"), observed_at="2026-10-03T08:00+00:00") == 3
    versions = conn.execute("SELECT market_id, first_seen, last_seen FROM market_versions WHERE market_id='M0' "
                            "ORDER BY first_seen").fetchall()
    assert [v[1][:10] for v in versions] == ["2026-10-02", "2026-10-03"]  # the rules edit is kept, not overwritten
    sig = [Signal("relations", "gap", "NY-02", 0.05)]
    assert store.save_signals(conn, sig, observed_at="t1") == 1 and store.save_signals(conn, sig, observed_at="t1") == 0


def test_legacy_database_replays_are_removed_on_connect(tmp_path):
    path = tmp_path / "old.sqlite"
    old = sqlite3.connect(path)
    old.execute("CREATE TABLE quotes (ts TEXT, venue TEXT, market_id TEXT, bid REAL, ask REAL, last REAL, "
                "bid_size REAL, ask_size REAL, volume REAL)")
    rows = [("k", f"M{i}", 0.4, 0.42, None, None, None, None) for i in range(3)]
    for ts in ("2026-10-02T10:00", "2026-10-02T12:00"):  # the second batch is a replay of the first
        old.executemany("INSERT INTO quotes VALUES (?,?,?,?,?,?,?,?,?)", [(ts, *r) for r in rows])
    old.executemany("INSERT INTO quotes VALUES (?,?,?,?,?,?,?,?,?)",  # a later live crawl with new prices
                    [("2026-10-02T14:00", "k", f"M{i}", 0.5, 0.52, None, None, None, None) for i in range(3)])
    old.execute("INSERT INTO quotes VALUES ('2026-10-02T14:00','k','M0',0.5,0.52,NULL,NULL,NULL,NULL)")
    old.commit()
    old.close()
    conn = store.connect(path)
    assert conn.execute("SELECT ts, COUNT(*) FROM quotes GROUP BY ts").fetchall() == [
        ("2026-10-02T10:00", 3), ("2026-10-02T14:00", 3)]


def test_run_manifest_lineage_and_health(tmp_path):
    db, rd = tmp_path / "db.sqlite", tmp_path / "runs"
    out = tmp_path / "report.md"
    with runs.track("universe", {"venues": "kalshi"}, db=db, runs_dir=rd) as run:
        run.source("venue:kalshi", True, 4752, 3.2)
        run.source("venue:opinion", False, 0, 1.0, "503 Service Unavailable")
        out.write_text("x")
        run.wrote(out, rows=1, licence=runs.licence_terms(["kalshi", "polymarket"]))
        run.check(contracts.venue_checks("kalshi", _events()))
    m = json.loads((rd / f"{run.id}.json").read_text())
    assert m["status"] == "ok" and m["code"]["git_sha"] is not None and "dirty" in m["code"]
    assert m["outputs"][0]["sha256"] and m["outputs"][0]["licence"] == [
        "Kalshi: Kalshi data terms: personal research; no redistribution of compiled data"]
    with pytest.raises(RuntimeError):
        with runs.track("macro", db=db, runs_dir=rd) as r2:
            r2.source("macro:bcb", False, 0, error="502 Bad Gateway")
            raise RuntimeError("boom")
    conn = store.connect(db)
    assert conn.execute("SELECT status, error FROM runs WHERE command='macro'").fetchone()[0] == "failed"
    later = datetime.now(timezone.utc).replace(year=2030)
    hs = {h.source: h for h in runs.health(conn)}
    assert hs["venue:kalshi"].failures_in_a_row == 0 and not hs["venue:kalshi"].stale
    assert hs["venue:opinion"].failures_in_a_row == 1 and hs["venue:opinion"].stale  # never succeeded
    assert all(h.stale for h in runs.health(conn, later))
    assert runs.previous_counts(conn) == {"venue:kalshi": 4752}
    page = runs.render_status(conn)
    assert "這次看不到什麼" in page and "`venue:opinion`" in page and "macro:bcb" in page


def test_code_and_module_versions():
    v = runs.code_version()
    assert set(v) >= {"git_sha", "dirty", "diff_sha256"}
    assert runs.module_version("pmpol.universe") == runs.module_version("pmpol.universe")
    assert runs.module_version("pmpol.universe") != runs.module_version("pmpol.macro")


def test_unobserved_venue_is_not_a_silent_move():
    from pmpol.movers.diff import Move
    from pmpol.movers.explain import explain_move
    from pmpol.movers.news import NewsResult

    mv = Move("kalshi:M", "kalshi:E", "kalshi", "Who wins NY-02?", "Democratic Party", "q", 0.4, 0.5, 0.02, 0.02,
              "2026-10-02T15:30+00:00", "2026-10-02T20:46+00:00")
    news = NewsResult("q", "a", "b", 0)
    assert explain_move(mv, news, []).result["silent"]
    p = explain_move(mv, news, [], unobserved=("polymarket",))
    assert not p.result["silent"] and p.result["unobserved_venues"] == ["polymarket"] and "不能確定" in p.conclusion


def test_stale_macro_inputs_are_carried_into_proofs():
    from pmpol.macro.regimes import MacroData
    from pmpol.macro.sources import Fetched, Observation, SeriesSpec
    from pmpol.proof import Proof

    spec = SeriesSpec("br.cpi_yoy", "bcb", "433")
    f = Fetched(spec, "u", "t", [Observation(spec.id, spec.ref, date(2026, 8, 1), 5.1)],
                stale_since="2026-10-02T15:27:00")
    data = MacroData.from_fetched([f])
    p = Proof("x", "y")
    p.add("L1", "巴西 CPI", spec.ref, "2026-08")
    data.mark_stale(p)
    assert p.result["stale_inputs"] == [spec.ref] and "2026-10-02T15:27" in p.caveats[0]


def test_assumptions_are_cited_and_counted():
    from pmpol import assumptions
    from pmpol.proof import Proof

    reg = assumptions.load()
    assert all(a.status in assumptions.STATUS_ZH and a.falsified_if and a.review_by for a in reg.values())
    p = Proof("x", "y")
    ids = assumptions.cite(p, "family_correlation", "kalshi_close_backstop")
    assumptions.cite(p, "family_correlation")  # citing twice adds one step
    assert ids == ["assumption:family_correlation", "assumption:kalshi_close_backstop"]
    assert p.result["assumptions"] == ["family_correlation", "kalshi_close_backstop"]
    assert len(p.caveats) == 1 and p.check() == []  # only the unsupported one becomes a caveat
    counts = assumptions.impact([{"proof": p.to_dict()}, p.to_dict()])
    assert counts["family_correlation"] == 2 and counts["venue_family"] == 0
    page = assumptions.render([p.to_dict()], date(2030, 1, 1))
    assert "已過期" in page and "`family_correlation`" in page


def test_consensus_and_relation_proofs_cite_their_assumptions():
    from tests.test_consensus import _ev, _kb, _rels
    from pmpol.universe import consensus
    from pmpol.universe.index import Universe

    u = Universe.build([_ev("polymarket", 0.60, spread=0.01), _ev("kalshi", 0.57, spread=0.10)])
    p = consensus.explain(consensus.run(u, _rels(), _kb(), "2026-10-02T20:46:00+00:00")[0], _kb(), "t")
    assert {"family_correlation", "kalshi_close_backstop", "calibration_transfers"} <= set(p.result["assumptions"])
    assert "venue_family" not in p.result["assumptions"] and p.check() == []


def test_cycle_runs_steps_in_order_and_skips_dependents_of_a_failure(monkeypatch):
    from contextlib import contextmanager

    from pmpol import cli

    calls = []

    def fake_main(argv):
        calls.append(argv[0])
        if argv[0] == "universe":
            raise RuntimeError("venue down")
        return 0

    @contextmanager
    def fake_track(command, args=None):
        yield runs.Run(command)

    monkeypatch.setattr(cli, "main", fake_main)
    monkeypatch.setattr(runs, "track", fake_track)
    args = type("A", (), {"skip": "viewer", "no_news": True})()
    assert cli.cmd_cycle(args) == 1
    # movers, track, assumptions, prov depend on universe
    assert calls == ["people", "candidates", "baseline", "universe", "macro", "status", "newswatch", "gdelt", "cn-household"]


def test_several_signals_of_one_kind_in_one_race_are_all_kept(tmp_path):
    conn = store.connect(tmp_path / "db.sqlite")
    sigs = [Signal("relations", "cross_venue_margin", "IN-01", 0.2, {"id": "a"}),
            Signal("relations", "cross_venue_margin", "IN-01", 0.1, {"id": "b"})]
    assert store.save_signals(conn, sigs, observed_at="t1") == 2
    assert store.save_signals(conn, sigs, observed_at="t1") == 0  # a replay still adds nothing
    no_id = [Signal("constraints", "sum_bid", "e", 0.1, {"legs": [1]}), Signal("constraints", "sum_bid", "e", 0.2, {"legs": [2]})]
    assert store.save_signals(conn, no_id, observed_at="t1") == 2  # without an id, the payload tells them apart


def test_signal_id_survives_price_moves():
    from pmpol.universe.explain import signal_id

    a = Signal("relations", "cross_venue_margin", "IN-01", 0.2, {"trade": "sell rhs / buy lhs",
               "sell": [["p:x", "Democrat 15-20%", 0.31, 50]], "buy": [["k:y", "Mrvan, 15+ pts", 0.47, 200]]})
    b = Signal("relations", "cross_venue_margin", "IN-01", 0.1, {"trade": "sell rhs / buy lhs",
               "sell": [["p:x", "Democrat 15-20%", 0.35, 10]], "buy": [["k:y", "Mrvan, 15+ pts", 0.44, 90]]})
    flipped = Signal("relations", "cross_venue_margin", "IN-01", 0.1, {"trade": "sell lhs / buy rhs",
                     "sell": [["k:y", "", 0.5, 1]], "buy": [["p:x", "", 0.2, 1]]})
    assert signal_id(a) == signal_id(b) != signal_id(flipped)
