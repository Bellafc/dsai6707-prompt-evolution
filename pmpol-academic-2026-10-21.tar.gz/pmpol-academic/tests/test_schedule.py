import json
import os
import subprocess
import time
from datetime import datetime, timezone

from pmpol import schedule


class Done:
    def __init__(self, code, out):
        self.returncode, self.stdout, self.stderr = code, out, ""


def test_lock_is_exclusive(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    a, b = schedule.Lock(), schedule.Lock()
    assert a.acquire() and not b.acquire()
    a.release()
    assert b.acquire()
    b.release()


def test_a_run_records_its_outcome_and_notifies_on_failure(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    sent = []
    monkeypatch.setattr(schedule, "notify", lambda url, text, post=None: sent.append((url, text)))
    out = "[cycle] universe: ok\n[cycle] macro: FAILED exit code 1\n[cycle] status: ok\n"
    code = schedule.run(runner=lambda argv, **kw: Done(1, out), notify_url="https://hooks.example/x")
    rec = json.loads((tmp_path / "data/logs/last_run.json").read_text())
    assert code == 1 and rec["failed_steps"] == ["macro"] and not rec["timed_out"]
    assert sent and "macro" in sent[0][1]
    assert (tmp_path / rec["log"]).read_text() == out
    # a clean run sends nothing
    sent.clear()
    assert schedule.run(runner=lambda argv, **kw: Done(0, "[cycle] universe: ok\n"), notify_url="u") == 0
    assert not sent


def test_timeout_is_recorded(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    def slow(argv, **kw):
        raise subprocess.TimeoutExpired(argv, kw["timeout"], output="[cycle] universe: ok\n")
    assert schedule.run(runner=slow, timeout_min=0.01) == 124
    rec = schedule.last_run()
    assert rec["timed_out"] and rec["exit_code"] == 124


def test_a_second_run_skips_while_the_first_holds_the_lock(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    held = schedule.Lock()
    assert held.acquire()
    called = []
    assert schedule.run(runner=lambda argv, **kw: called.append(1) or Done(0, "")) == 0
    assert not called
    held.release()


def test_old_logs_are_pruned(tmp_path):
    old, new = tmp_path / "cycle_old.log", tmp_path / "cycle_new.log"
    old.write_text("x")
    new.write_text("y")
    t = time.time() - 40 * 86400
    os.utime(old, (t, t))
    assert schedule.prune_logs(tmp_path, 30, datetime.now(timezone.utc)) == 1
    assert new.exists() and not old.exists()


def test_cloud_profile_keeps_its_reports_apart(monkeypatch):
    from pmpol import cli, runs

    calls = []
    monkeypatch.setattr(cli, "main", lambda argv: calls.append(argv) or 0)

    class _Run:
        counts = {}

        def source(self, *a, **k):
            pass

    from contextlib import contextmanager

    @contextmanager
    def fake_track(command, args=None):
        yield _Run()
    monkeypatch.setattr(runs, "track", fake_track)
    args = type("A", (), {"skip": "", "no_news": False, "profile": "cloud"})()
    assert cli.cmd_cycle(args) == 0
    names = [a[0] for a in calls]
    assert "movers" not in names and "track" not in names  # they need history
    reports = [a[a.index("--report") + 1] for a in calls if "--report" in a]
    assert reports and all(r.startswith("reports/cloud/") for r in reports)
