from datetime import date, datetime, timezone

import pytest

from pmpol import store
from pmpol.kb import KnowledgeBase
from pmpol.macro import regimes
from pmpol.macro.markets import match
from pmpol.macro.regimes import MacroData
from pmpol.macro.report import render
from pmpol.macro.sources import (Fetched, Observation, SeriesSpec, _ssl_context, build, fetch_all, load_specs,
                                 parse_bcb, parse_cbc_rate, parse_dgbas, parse_dgbas_wide, parse_fred_csv, parse_imf,
                                 parse_ons, parse_sdmx_csv, period, to_monthly, yoy)
from pmpol.models import Event, Market
from pmpol.proof import Proof

KB = KnowledgeBase.load()
NOW = datetime(2026, 10, 2, 12, tzinfo=timezone.utc)


@pytest.mark.parametrize("text,expected", [
    ("2026-08-01", date(2026, 8, 1)), ("2026-08", date(2026, 8, 1)), ("2026-Q2", date(2026, 4, 1)),
    ("2026 Q3", date(2026, 7, 1)), ("2026 AUG", date(2026, 8, 1)), ("2026", date(2026, 1, 1)),
    ("04/11/2026", date(2026, 11, 4)), ("2026M09", date(2026, 9, 1)), ("2026Q2", date(2026, 4, 1)),
])
def test_period(text, expected):
    assert period(text) == expected


def test_parsers():
    assert parse_fred_csv("observation_date,UNRATE\n2026-08-01,4.1\n2026-09-01,.\n") == [(date(2026, 8, 1), 4.1)]
    sdmx = "REF_AREA,TIME_PERIOD,OBS_VALUE\nGBR,2026-08,3.3\nGBR,2026-07,\nGBR,2026-06,3.4\n"
    assert parse_sdmx_csv(sdmx) == [(date(2026, 6, 1), 3.4), (date(2026, 8, 1), 3.3)]
    assert parse_bcb('[{"data":"01/08/2026","valor":"4.22"}]') == [(date(2026, 8, 1), 4.22)]
    ons = '{"years":[{"date":"2025","value":"3.0"}],"months":[{"date":"2026 AUG","value":"3.1"}],"quarters":[]}'
    assert parse_ons(ons) == [(date(2026, 8, 1), 3.1)]
    imf = '{"values":{"PCPIPCH":{"IRN":{"2025":40.1,"2026":68.9},"USA":{"2025":2.7}}}}'
    assert parse_imf(imf, "PCPIPCH", "IRN") == [(date(2025, 1, 1), 40.1), (date(2026, 1, 1), 68.9)]


def test_transforms():
    daily = [(date(2026, 9, 1), 1.0), (date(2026, 9, 15), 2.0), (date(2026, 10, 1), 5.0)]
    assert to_monthly(daily, "mean") == [(date(2026, 9, 1), 1.5), (date(2026, 10, 1), 5.0)]
    assert to_monthly(daily, "last")[0] == (date(2026, 9, 1), 2.0)
    assert yoy([(date(2025, 8, 1), 100.0), (date(2026, 8, 1), 103.0)]) == [(date(2026, 8, 1), 3.0)]


def test_build_drops_forward_rows_before_aggregating_and_marks_projections():
    selic = SeriesSpec("br.policy_rate", "bcb", "432", monthly="last")
    text = '[{"data":"30/09/2026","valor":"13.75"},{"data":"01/10/2026","valor":"13.75"},' \
           '{"data":"05/11/2026","valor":"13.25"}]'
    f = build(selic, text, "u", NOW)
    assert f.dropped_future == 1 and [o.value for o in f.observations] == [13.75, 13.75]
    imf = SeriesSpec("ir.inflation_annual", "imf", "PCPIPCH/IRN")
    f = build(imf, '{"values":{"PCPIPCH":{"IRN":{"2025":40.1,"2027":30.0}}}}', "u", NOW)
    assert [(o.period.year, o.layer) for o in f.observations] == [(2025, "L1"), (2027, "L3")]


def test_fetch_all_records_failures_and_caches_only_parseable(tmp_path):
    specs = [SeriesSpec("us.unemployment", "fred", "UNRATE"), SeriesSpec("br.cpi_yoy", "bcb", "13522")]

    def fetch(url):
        if "fred" in url:
            return "observation_date,UNRATE\n2026-09-01,4.2\n"
        return "<html>Requisição inválida!</html>"

    out = fetch_all(specs, fetch=fetch, cache=tmp_path, now=NOW)
    assert out[0].observations[-1].value == 4.2 and not out[0].error
    assert out[1].error and not out[1].observations
    assert len(list(tmp_path.iterdir())) == 1  # the HTML error page was not cached


def test_config_series_are_well_formed():
    specs = load_specs()
    assert len(specs) >= 50
    for s in specs:
        assert s.source in ("fred", "oecd", "bis", "bcb", "ons", "imf", "imf_sdmx", "dgbas", "dgbas_wide",
                            "cbc_rate") and s.licence, s.id
        assert s.country in ("us", "uk", "br", "cn", "il", "ru", "ir", "tw"), s.id


def _data(series: dict[str, list[tuple[date, float]]], recorded: str = "2026-10-02T12:00:00+00:00") -> MacroData:
    fetched = [Fetched(SeriesSpec(sid, "fred", sid.upper()), "u", recorded,
                       [Observation(sid, f"fred:{sid.upper()}", p, v) for p, v in rows])
               for sid, rows in series.items()]
    return MacroData.from_fetched(fetched)


def _months(start: date, values: list[float]) -> list[tuple[date, float]]:
    out, y, m = [], start.year, start.month
    for v in values:
        out.append((date(y, m, 1), v))
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def test_sahm_rule_triggers_on_a_rise_in_unemployment():
    flat = _data({"us.unemployment": _months(date(2025, 1, 1), [4.0] * 15)})
    assert not regimes.sahm_rule(flat, KB).result["triggered"]
    rising = _data({"us.unemployment": _months(date(2025, 1, 1), [4.0] * 12 + [4.4, 4.6, 4.8])})
    p = regimes.sahm_rule(rising, KB)
    assert p.result["triggered"] and p.result["gap"] == pytest.approx(0.6)
    assert p.grounded and {s.layer for s in p.steps} >= {"L1", "L3"}


def test_yield_curve_probability_uses_the_last_complete_month():
    d = _data({"us.yield_curve_10y3m": [(date(2026, 9, 1), -1.0), (date(2026, 10, 1), 3.0)]})
    p = regimes.yield_curve_recession(d, KB)
    assert p.result["spread"] == -1.0 and p.result["inverted"]
    assert p.result["probability"] == pytest.approx(0.5398, abs=1e-3)  # Phi(-0.5333 + 0.6330)


@pytest.mark.parametrize("cli,cpi,phase", [
    ([100.0] * 6 + [101.0], [2.0] * 12 + [3.0], "overheat"),
    ([100.0] * 6 + [101.0], [3.0] * 12 + [2.0], "recovery"),
    ([101.0] * 6 + [100.0], [2.0] * 12 + [3.0], "stagflation"),
    ([101.0] * 6 + [100.0], [3.0] * 12 + [2.0], "reflation"),
])
def test_investment_clock_quadrants(cli, cpi, phase):
    d = _data({"us.cli": _months(date(2026, 2, 1), cli), "us.cpi_yoy": _months(date(2025, 8, 1), cpi)})
    p = regimes.investment_clock(d, KB, "us")
    assert p.result["phase"] == phase
    assert any(s.layer == "L2" for s in p.steps) and p.caveats  # base rate cited, hindsight caveat shown


def test_cli_phase_and_conflicts():
    d = _data({"us.cli": [(date(2026, 7, 1), 99.0), (date(2026, 8, 1), 98.5)]})
    assert regimes.cli_phase(d, KB, "us").result["phase"] == "slowdown"
    two = MacroData.from_fetched([
        Fetched(SeriesSpec("uk.cpi_yoy", "ons", "d7g7"), "u", "t", [Observation("uk.cpi_yoy", "ons:d7g7", date(2026, 8, 1), 3.1)]),
        Fetched(SeriesSpec("uk.cpi_yoy", "oecd", "GBR"), "u", "t", [Observation("uk.cpi_yoy", "oecd:GBR", date(2026, 8, 1), 3.3)]),
    ])
    ((sid, p, vals),) = regimes.conflicts(two)
    assert sid == "uk.cpi_yoy" and sorted(v for _, v in vals) == [3.1, 3.3]
    assert two.series("uk.cpi_yoy")[0].source == "ons"  # first configured source is primary


def test_proof_without_grounding_is_labelled():
    p = Proof("x", "y").add("L5", "model says so")
    assert not p.grounded and "無根推論" in p.markdown()[0]


def test_macro_markets_are_matched_by_country_and_concept():
    def ev(title):
        return Event("polymarket", title, title, markets=[Market("polymarket", title, title, title, "Yes")])
    events = [ev("Fed Decision in December?"), ev("Kevin Warsh out as Fed chair?"), ev("Eurozone GDP growth in Q3"),
              ev("US GDP growth in Q3 2026?"), ev("Brazil Annual Inflation 2026"), ev("China Annual Inflation 2026")]
    assert [e.title for e in match(events, "us", "policy_rate")] == ["Fed Decision in December?"]
    assert [e.title for e in match(events, "us", "gdp")] == ["US GDP growth in Q3 2026?"]
    assert [e.title for e in match(events, "br", "inflation")] == ["Brazil Annual Inflation 2026"]


def test_store_keeps_revisions_bitemporally(tmp_path):
    conn = store.connect(tmp_path / "t.sqlite")
    spec = SeriesSpec("us.unemployment", "fred", "UNRATE")
    first = Fetched(spec, "u", "2026-10-02T00:00:00", [Observation(spec.id, spec.ref, date(2026, 8, 1), 4.1)])
    again = Fetched(spec, "u", "2026-10-03T00:00:00", [Observation(spec.id, spec.ref, date(2026, 8, 1), 4.1)])
    revised = Fetched(spec, "u", "2026-11-06T00:00:00", [Observation(spec.id, spec.ref, date(2026, 8, 1), 4.2)])
    assert store.save_macro(conn, [first]) == (1, 0)
    assert store.save_macro(conn, [again]) == (0, 0)
    assert store.save_macro(conn, [revised]) == (0, 1)
    assert store.load_macro(conn, "2026-10-31")[0][3] == 4.1  # what we knew then
    assert store.load_macro(conn)[0][3] == 4.2


def test_report_renders_offline():
    spec = SeriesSpec("us.unemployment", "fred", "UNRATE", unit="%", licence="public domain")
    f = Fetched(spec, "u", "2026-10-02T12:00:00+00:00",
                [Observation(spec.id, spec.ref, p, v) for p, v in _months(date(2025, 1, 1), [4.0] * 21)])
    text = render([f], KB, "2026-10-02")
    assert "薩姆規則" in text and "康波" in text and "Korotayev" in text


def test_failed_fetch_falls_back_to_stored_data(tmp_path):
    conn = store.connect(tmp_path / "t.sqlite")
    spec = SeriesSpec("br.cpi_yoy", "bcb", "13522")
    good = Fetched(spec, "u", "2026-10-02T00:00:00", [Observation(spec.id, spec.ref, date(2026, 8, 1), 4.22)])
    store.save_macro(conn, [good])
    down = Fetched(spec, "u", "2026-10-03T00:00:00", error="502 Bad Gateway")
    assert store.fill_failed_macro(conn, [down]) == 1
    assert down.observations[0].value == 4.22 and "stored data recorded 2026-10-02" in down.error


def test_taiwan_parsers():
    long = ("\ufeff<?xml version=\"1.0\" encoding=\"utf-8\"?><DataSet>"
            "<Obs><Item>總指數(民國110年=100)</Item><TIME_PERIOD>2026M08</TIME_PERIOD><FREQ>M</FREQ>"
            "<TYPE>年增率(%)</TYPE><Item_VALUE>2.10</Item_VALUE></Obs>"
            "<Obs><Item>總指數(民國110年=100)</Item><TIME_PERIOD>2026M09</TIME_PERIOD><FREQ>M</FREQ>"
            "<TYPE>年增率(%)</TYPE><Item_VALUE>2.73</Item_VALUE></Obs>"
            "<Obs><Item>總指數(民國110年=100)</Item><TIME_PERIOD>2026M09</TIME_PERIOD><FREQ>M</FREQ>"
            "<TYPE>原始值</TYPE><Item_VALUE>110.5</Item_VALUE></Obs>"
            "<Obs><Item>食物類</Item><TIME_PERIOD>2026M09</TIME_PERIOD><FREQ>M</FREQ>"
            "<TYPE>年增率(%)</TYPE><Item_VALUE>3.0</Item_VALUE></Obs></DataSet>")
    assert parse_dgbas(long, "總指數", "年增率(%)") == [(date(2026, 8, 1), 2.1), (date(2026, 9, 1), 2.73)]
    wide = ("<DataCollection><失業率><年月別_Year_and_month>2025</年月別_Year_and_month><總計_Total_百分比>3.38"
            "</總計_Total_百分比></失業率><失業率><年月別_Year_and_month>2026M08</年月別_Year_and_month>"
            "<總計_Total_百分比>3.41</總計_Total_百分比></失業率></DataCollection>")
    assert parse_dgbas_wide(wide, "總計_Total_百分比") == [(date(2026, 8, 1), 3.41)]
    csv = "調整日期,重貼現率,擔保放款融通利率\n2026/06/19,2.000,2.375\n2026/03/20,2.125,2.500\n"
    rows = parse_cbc_rate(csv, "重貼現率", date(2026, 7, 15))
    assert rows == [(date(2026, 3, 1), 2.125), (date(2026, 4, 1), 2.125), (date(2026, 5, 1), 2.125),
                    (date(2026, 6, 1), 2.0), (date(2026, 7, 1), 2.0)]


def test_extra_intermediate_only_for_its_host():
    import ssl

    assert _ssl_context("https://fred.stlouisfed.org/x") is True
    ctx = _ssl_context("https://ws.dgbas.gov.tw/001/Upload/x.xml")
    assert isinstance(ctx, ssl.SSLContext) and ctx.verify_mode == ssl.CERT_REQUIRED and ctx.check_hostname
