from pmpol.confidence import assess, describe
from pmpol.proof import Proof


def test_confidence_is_the_weakest_link_with_every_downgrade_explained():
    p = Proof("t", "c", result={"rules": "equivalent", "confidence": "rule"})
    p.add("L0", "plurality", "us.house.majority")  # a reviewed fact
    assert assess(p) == ("high", [])
    p.result["assumptions"] = ["venue_family"]  # caveated
    assert assess(p)[0] == "moderate"
    p.result["rules"] = "material"
    level, why = assess(p)
    assert level == "low" and why[0] == "結算條件有實質差異" and any("venue_family" in w for w in why)
    p2 = Proof("t", "c", result={"confidence": "title"})
    p2.add("L0", "proposed fact", "us.election.general_plurality")
    level, why = assess(p2)
    assert level == "low" and "配對方式是標題" in why and any("提議中" in w for w in why)
    assert describe("high", []).startswith("分析信心：高")
    d = p.to_dict()
    assert d["analytic_confidence"] == "low" and d["confidence_reasons"]
