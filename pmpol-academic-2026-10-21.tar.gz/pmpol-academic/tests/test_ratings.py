from pmpol.entities.ratings import Rating, compare, median_band, parse

WIKI = """== District 35 ==
=== General election ===
==== Predictions ====
{| class="wikitable" style="text-align:center"
!Source
!Ranking
!As of
|-
| align=left | [[Decision Desk HQ]]<ref name="x">{{cite web |title=t |url=https://e.org}}</ref>
| {{USRaceRating|Lean|R|Flip}}
|July 14, 2026
|-
| align=left | [[The Cook Political Report]]<ref name="Cook Initial"/>
| {{USRaceRating|Tossup}}
|September 25, 2025
|-
| style="text-align: left;" |[[Silver Bulletin]]<ref name=":Silver"/>
| {{US political race rating|Likely|R}}
|August 20, 2026
|}
== District 36 ==
"""


def test_ratings_are_read_with_rater_category_party_and_date():
    rs = parse(WIKI, "United States|TX-35|house|2026|general", "p", "District 35")
    assert [(r.rater, r.category, r.party, r.as_of) for r in rs] == [
        ("Decision Desk HQ", "lean", "R", "July 14, 2026"), ("The Cook Political Report", "tossup", "", "September 25, 2025"),
        ("Silver Bulletin", "likely", "R", "August 20, 2026")]
    assert rs[0].band("R") == (0.65, 0.85) and rs[0].band("D") == (0.15, 0.35) and rs[1].band("D") == (0.35, 0.65)


def test_markets_outside_the_raters_band_are_listed_side_by_side():
    race = "United States|TX-35|house|2026|general"
    rs = [Rating(race, "A", "lean", "R", "", "p"), Rating(race, "B", "lean", "R", "", "p"),
          Rating(race, "C", "likely", "R", "", "p")]
    assert median_band(rs, "R") == (0.65, 0.85)
    (d,) = compare({(race, "R"): 0.38, (race, "D"): 0.62, ("other", "R"): 0.5}, {race: rs})[:1]
    assert d.party in ("R", "D") and round(abs(d.gap), 2) == 0.27
    assert compare({(race, "R"): 0.70}, {race: rs}) == []  # inside the band: no divergence
