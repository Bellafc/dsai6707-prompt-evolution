import json

import numpy as np

from pmpol import backtest as bt
from pmpol.ground_truth import Resolved, save


def _rows(n=1200, slope=1.4, seed=0):
    """Prices too compressed toward 50% (true logit = slope * logit price), half before and half after the split."""
    rng = np.random.default_rng(seed)
    out = []
    for i in range(n):
        p = float(rng.uniform(0.03, 0.97))
        q = 1 / (1 + np.exp(-slope * np.log(p / (1 - p))))
        close = "2025-01-15T00:00:00Z" if i % 2 else "2026-01-15T00:00:00Z"
        out.append(Resolved("kalshi", f"M{i}", f"E{i // 3}", "q", "Yes", close, close, False, int(rng.random() < q),
                            prices={"1": p, "7": p, "30": None}))
    return out


def test_freeze_and_verify(tmp_path):
    path = tmp_path / "k.jsonl"
    save(_rows(60), path)
    m = bt.freeze([path])
    assert m["files"][0]["rows"] == 60 and bt.verify(m) == []
    path.write_text(path.read_text() + json.dumps(_rows(1)[0].to_dict()) + "\n")
    assert "changed" in bt.verify(m)[0]
    assert "沒有執行" in bt.render(m, [], bt.verify(m))


def test_calibration_slope_helps_out_of_sample_when_prices_are_compressed():
    rows = _rows()
    t = bt.calibration_test(rows, "kalshi", 1)
    assert t.n_train == 600 and t.n_test == 600 and t.b > 1.1
    assert t.loss["slope N0=200"] < t.loss["raw"] and t.gain["slope N0=200"][1] > 0  # interval above zero
    assert bt.calibration_test(rows, "kalshi", 30) is None  # no prices at 30 days
    s = bt.summary([t])
    assert s["tests"] == 1 and s["slope_better"] == (1, 0)


def test_the_split_never_trains_on_the_test_period():
    rows = _rows()
    for r in rows:  # the test period resolves the other way: a model fitted on it would differ
        if r.close_time.startswith("2026"):
            r.result = 1 - r.result
    t = bt.calibration_test(rows, "kalshi", 1)
    assert t.b > 1.1  # fitted on the 2025 half only
    assert t.loss["slope N0=200"] > t.loss["raw"]  # and it fails on the reversed future, as it should
