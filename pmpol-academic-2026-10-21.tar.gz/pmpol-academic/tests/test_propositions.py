from pmpol.models import Event, Market, Relation
from pmpol.propositions import INF, Span, normalize, subset
from pmpol.propositions.derive import compare, derive, parse_universe
from pmpol.propositions.parse import deadline_span, name_key, number_span
from pmpol.universe.index import Universe


def test_span_algebra():
    a = normalize([Span(10, 15), Span(15, 20), Span(0, 5)])
    assert a == (Span(0, 5), Span(10, 20))
    assert subset((Span(25, 30),), (Span(20, INF),)) and not subset((Span(20, INF, False),), (Span(20, 30),))
    assert Span(20, INF, True).contains(Span(20, INF, False)) and not Span(20, INF, False).contains(Span(20, INF))


def test_labels():
    assert number_span("2.2M-2.4M") == Span(2.2e6, 2.4e6)
    assert number_span("Above 1.25M") == Span(1.25e6, INF, False)
    assert number_span("<3.25%") == Span(-INF, 3.25, False) and number_span("5.5%+") == Span(5.5, INF)
    before, _ = deadline_span("Before Jan 1, 2027", "")
    by, _ = deadline_span("December 31", "Netanyahu out by December 31, 2026?")
    assert before == by  # "before Jan 1" and "by Dec 31" are the same deadline
    assert name_key("A. Ocasio-Cortez") == name_key("Alexandria Ocasio-Cortez")
    assert name_key("John N. Kennedy") != name_key("Robert F. Kennedy Jr.")
    assert name_key("Donald Trump Jr.") != name_key("Donald J. Trump") and name_key("Democratic Party") is None


def _m(venue, mid, outcome, q, **kw):
    return Market(venue, mid, kw.pop("eid", "e"), q, outcome, bid=kw.pop("bid", 0.4), ask=kw.pop("ask", 0.42), **kw)


def _universe():
    k_rule = "If the margin of victory for Republicans in the Montana Senate race ..."
    kal = Event("kalshi", "KXMARGIN-MT", "Montana Senate margin of victory", markets=[
        _m("kalshi", "MT-R20", "Alme, 20+ pts", "Will the margin of victory for Republicans in the Senate race in "
           "Montana be at least 20?", eid="KXMARGIN-MT", strike_type="greater_or_equal", floor_strike=20.0,
           rules=k_rule, bid=0.30, ask=0.32)])
    pm_rule = "If the reported value falls exactly between two brackets, it resolves to the higher range bracket."
    pm = Event("polymarket_us", "mt-margin", "Montana Senate Election Margin of Victory", markets=[
        _m("polymarket_us", f"mt-{lo}", f"Republican {lo}-{lo + 5}%" if lo < 30 else "Republican 30%+",
           "Montana Senate Election Margin of Victory", eid="mt-margin", rules=pm_rule,
           bid=0.45 if lo == 20 else 0.05, ask=0.47 if lo == 20 else 0.07) for lo in (0, 5, 10, 15, 20, 25, 30)])
    win = Event("polymarket_us", "mt-win", "Montana Senate Election Winner", mutually_exclusive=True, markets=[
        _m("polymarket_us", "mt-win-r", "Steve Daines (R)", "Montana Senate Election Winner", eid="mt-win"),
        _m("polymarket_us", "mt-win-d", "Reilly Neill (D)", "Montana Senate Election Winner", eid="mt-win")])
    pres = [Event(v, f"{v}-pres28", "Presidential Election Winner 2028", markets=[
        _m(v, f"{v}-k", name, "Presidential Election Winner 2028", eid=f"{v}-pres28")])
        for v, name in (("polymarket", "John N. Kennedy"), ("smarkets", "Robert F. Kennedy Jr."))]
    turnout = [Event("kalshi", "TO", "Iowa Senate General Election: voter turnout", markets=[
        _m("kalshi", "to1", "Above 1.2M", "q", eid="TO", strike_type="greater", floor_strike=1.2e6)]),
        Event("polymarket", "to-pct", "Iowa Senate Election: Turnout", markets=[
            _m("polymarket", "to2", "60%+", "q", eid="to-pct")])]
    return Universe.build([kal, pm, win, *pres, *turnout])


def test_relations_from_set_algebra_and_bridges():
    u = _universe()
    props = parse_universe(u).props
    assert {p.var.qualifier for p in props if p.var.kind == "turnout"} == {"votes", "percent"}  # units differ
    ds = derive(u, props)
    pairs = {(d.basis, tuple(d.lhs), tuple(d.rhs)) for d in ds}
    # PU bucket [20, 25) implies Kalshi ">= 20"
    assert ("subset", ("polymarket_us:mt-20",), ("kalshi:MT-R20",)) in pairs
    # PU 20-25 + 25-30 + 30+ tile Kalshi ">= 20"
    cover = [d for d in ds if d.basis == "cover" and d.rhs == ["kalshi:MT-R20"]]
    assert cover and set(cover[0].lhs) == {"polymarket_us:mt-20", "polymarket_us:mt-25", "polymarket_us:mt-30"}
    # margin >= 20 for R implies "Daines (R) wins"; all R buckets together equal it
    assert ("bridge_margin_winner", ("kalshi:MT-R20",), ("polymarket_us:mt-win-r",)) in pairs
    assert not any(d.var.startswith("turnout") for d in ds)  # a vote count is never compared with a percentage
    # templates that pair different people with one surname are flagged
    bad = Relation("equivalent", ["polymarket:polymarket-k"], ["smarkets:smarkets-k"], "cross_venue_winner",
                   "United States|US|president|2028|general", "surname")
    c = compare(u, [bad], props, ds)
    assert len(c.disagree) == 1 and "kennedy" in c.disagree[0][1]


def test_role_and_county_are_part_of_the_variable():
    from pmpol.propositions.parse import parse_event
    from pmpol.universe.taxonomy import tag_event

    maj, mino = (Event("kalshi", f"KXSEN{r[:3].upper()}-27", f"120th Congress: Who will be Senate {r} Leader?", "Elections",
                       markets=[_m("kalshi", f"KXSEN{r[:3].upper()}-27-JTHU", "John Thune", "Who will win the U.S. "
                                   f"Senate {r} Leader election for the 120th Congress?", eid=f"KXSEN{r[:3].upper()}-27")])
                 for r in ("Majority", "Minority"))
    vs = [parse_event(e, tag_event(e)).props for e in (maj, mino)]
    assert vs[0] and vs[1] and vs[0][0].var != vs[1][0].var
    county = Event("kalshi", "KXVOTECOUNTY-X", "Harris County, Texas: James Talarico vote percent", markets=[
        _m("kalshi", "c1", "At least 54%", "Will James Talarico receive at least 54% of the popular vote in the 2026 "
           "U.S. Senate election in Harris County?", eid="KXVOTECOUNTY-X", strike_type="greater_or_equal",
           floor_strike=54.0)])
    state = Event("kalshi", "KXVOTE-X", "Texas Senate election: James Talarico vote percent", markets=[
        _m("kalshi", "s1", "At least 50%", "Will James Talarico receive at least 50% of the popular vote in the 2026 "
           "Texas U.S. Senate election?", eid="KXVOTE-X", strike_type="greater_or_equal", floor_strike=50.0)])
    a, b = (parse_event(e, tag_event(e)).props for e in (county, state))
    assert a and b and a[0].var != b[0].var


def test_surname_template_keeps_different_people_apart():
    from pmpol.universe.relations import cross_venue_winner

    evs = [Event(v, f"{v}-pres", "Presidential Election Winner 2028", markets=[
        _m(v, f"{v}-a", a, "Presidential Election Winner 2028", eid=f"{v}-pres"),
        _m(v, f"{v}-b", b, "Presidential Election Winner 2028", eid=f"{v}-pres")])
        for v, a, b in (("polymarket", "John N. Kennedy", "Alexandria Ocasio-Cortez"),
                        ("smarkets", "Robert F. Kennedy Jr.", "A. Ocasio-Cortez"))]
    rels = list(cross_venue_winner(Universe.build(evs)))
    notes = {r.note for r in rels}
    assert "candidate ocasio-cortez" in notes and "candidate kennedy" not in notes


def test_joint_variables_bridge_to_their_marginals():
    from pmpol.propositions.parse import balance_cell

    assert balance_cell("Republican Senate + Democrats House") == ("D", "R")
    assert balance_cell("Dem. House & Senate") == ("D", "D") and balance_cell("Other") is None
    t = "2026 Midterms: Congress Balance of Power?"
    cells = {"Democrats sweep": 0.62, "D-House, R-Senate": 0.29, "R-House, D-Senate": 0.01, "Republicans sweep": 0.08}
    bal = Event("kalshi", "BAL", t, markets=[_m("kalshi", f"bal-{i}", o, t, eid="BAL", bid=p - 0.005, ask=p + 0.005)
                                             for i, (o, p) in enumerate(cells.items())])
    house = Event("smarkets", "H", "Which party will control the House after the midterm elections?",
                  markets=[_m("smarkets", "h-d", "Democratic Party", "Which party will control the House after the "
                              "2026 midterm elections?", eid="H", bid=0.90, ask=0.92)])
    u = Universe.build([bal, house])
    props = parse_universe(u).props
    joint = [p for p in props if p.var.kind == "joint"]
    assert len(joint) == 4 and {next(iter(p.values)) for p in joint} >= {"party:D,party:R"}
    ds = [d for d in derive(u, props) if d.basis == "bridge_joint_marginal"]
    assert any(set(d.lhs) == {"kalshi:bal-0", "kalshi:bal-1"} and d.rhs == ["smarkets:h-d"] for d in ds)


def test_event_descriptors_standardise_wording():
    from pmpol.propositions.describe import complete, describe

    assert describe("Will Trump be impeached by...?").key == describe("Trump Impeached?").key == "impeach(trump)"
    assert describe("Will President Trump be impeached during his term?").key == "impeach(trump)"
    # every non-boilerplate word stays: "impeached and removed" is another variable
    assert describe("Will Trump be impeached and removed from office?").key != "impeach(trump)"
    # direction is kept for directed actions, not for symmetric ones
    assert describe("Will Russia invade Ukraine?").key != describe("Will Ukraine invade Russia?").key
    assert describe("When will Putin and Zelenskyy meet?").key == describe("Will Putin meet with Zelenskyy?").key
    assert describe("Howard Lutnick out as Commerce Secretary?").key == \
        describe("Howard Lutnick out as Secretary of Commerce by December 31?").key
    assert describe("Will Putin visit the U.S. in 2026?").key == describe("Putin visits US by December 31, 2026?").key
    assert describe("Who will Trump meet with in 2026?") is None  # the options are the arguments
    assert describe("Bab el-Mandeb Strait effectively closed by...?") is None  # no known action: not guessed
    # a short bag is completed only by a unique longer bag that adds a capitalised first word
    descs = {"k": describe("Kevin Warsh out as Fed chair?"), "p": describe("Warsh out as Fed Chair by…?")}
    done = complete(descs)
    assert done["k"] == done["p"]
    descs = {"a": describe("Ali Khamenei out?"), "m": describe("Mojtaba Khamenei out?"), "s": describe("Khamenei out?")}
    assert complete(descs)["s"] == "leave_office(@khamenei)"


def test_deadlines_from_rules_and_questions():
    from datetime import date

    from pmpol.propositions.parse import window_start

    end_2026 = Span(-INF, date(2027, 1, 1).toordinal(), False, False)
    # "December 31" with no year anywhere but the rules
    assert deadline_span("December 31", "Will Warsh be out as Fed Chair by December 31?",
                         "... by December 31, 2026, 11:59 PM ET.")[0] == end_2026
    # ... or the close time (11:59 PM ET is the next day in UTC)
    assert deadline_span("December 31", "US strike on Mexico by...?", "", "2027-01-01T04:59:00Z")[0] == end_2026
    assert deadline_span("", "Will Trump resign before 2027?")[0] == end_2026
    assert deadline_span("", "Kristi Noem impeached in 2026?", "... by December 31, 2026, 11:59 PM ET.")[0] == end_2026
    # the rules say the window is something else: not read
    assert deadline_span("", "Will X happen in 2026?", "... before June 30, 2027 ...") is None
    assert deadline_span("Before his term ends", "Will President Trump resign before his term is up?")[1] == "trump_term"
    assert deadline_span("Xi Jinping", "Will Donald Trump meet Xi Jinping in 2026?") is None  # an option label
    m = Market("kalshi", "k", "e", "q", "Before Jan 1, 2027",
               rules="... Visits that began before market issuance do not count.")
    assert window_start(m) == "window start: market creation"
    m = Market("polymarket", "p", "e", "q", "", rules="if the WHO declares a pandemic between January 1, 2026 and ...")
    assert window_start(m) == "window start: january 1, 2026"


def test_rule_differences_are_listed():
    from pmpol.propositions.report import rule_differences

    assert rule_differences(["window start: market creation", "window start: not stated in the rules",
                             "time zone of the deadline not compared"]) == \
        "計算窗起點不同（market creation / not stated in the rules）"
    assert rule_differences(["window start: market creation"]) == ""


def test_direct_relations_drop_ladder_consequences():
    from pmpol.propositions import Prop, Var
    from pmpol.propositions.derive import Derived, direct

    v = Var("margin", "race", "R")
    a20 = Prop(v, "k:20", "E1", "r", spans=(Span(20, INF),))
    a10 = Prop(v, "k:10", "E1", "r", spans=(Span(10, INF),))
    b5 = Prop(v, "p:5", "E2", "r", spans=(Span(5, INF),))
    b0 = Prop(v, "p:0", "E2", "r", spans=(Span(0, INF),))
    rel = [Derived("implies", [x.market], [y.market], "v", "subset", True) for x in (a20, a10) for y in (b5, b0)]
    kept = direct(rel, [a20, a10, b5, b0])
    # only the loosest source and the tightest target of each event pair remain: >=10 => >=5
    assert [(d.lhs, d.rhs) for d in kept] == [(["k:10"], ["p:5"])]


def test_individual_variant_is_the_same_winner_variable():
    from pmpol.propositions.parse import parse_event

    k = Event("kalshi", "KXCAELECTION-2640", "CA-40 House winner?",
              markets=[_m("kalshi", "K-KCAL", "Ken Calvert", "Will Ken Calvert win?", eid="KXCAELECTION-2640")])
    p = Event("polymarket", "ca-40-ind", "CA-40 House Election Winner (Individual)",
              markets=[_m("polymarket", "p-kcal", "Ken Calvert", "Will Ken Calvert win?", eid="ca-40-ind")])
    u = Universe.build([k, p])
    vk = parse_event(k, u.tags[k.key]).props[0]
    vp = parse_event(p, u.tags[p.key]).props[0]
    assert vk.var == vp.var and vk.values == vp.values


def test_indicators_on_the_publication_grid():
    from pmpol.propositions.indicators import identify, label_span

    rule = "... the Consumer Price Index ... according to the monthly Bureau of Labor Statistics (BLS) report"
    k = Event("kalshi", "KXCPICORE-26SEP", "CPI core in September", markets=[
        _m("kalshi", "K-T0.1", "Above 0.1%", "q", eid="KXCPICORE-26SEP", strike_type="greater", floor_strike=0.1,
           close_time="2026-10-14T12:25:00Z")])
    p = Event("polymarket", "core-cpi-mom-sep", "Core CPI MoM - September 2026", markets=[
        _m("polymarket", f"p-{x}", x, "q", eid="core-cpi-mom-sep", rules=rule) for x in ("0.1%", "0.2%", "0.6%+", "≤0.0%")])
    (sk, per_k), (sp, per_p) = identify(k), identify(p)
    assert sk == sp and per_k == per_p == "2026-09"  # the year comes from the close time on Kalshi
    # "Above 0.1%" on a 0.1 grid is "0.2% or more"
    assert label_span(k.markets[0], sk) == Span(2, INF)
    assert [label_span(m, sp) for m in p.markets] == [Span(1, 2), Span(2, 3), Span(6, INF), Span(-INF, 1)]
    # another country's CPI is another series
    other = Event("polymarket", "x", "Japan Core CPI YoY in 2026", markets=p.markets)
    assert identify(other) is None
    # Fed decisions: both venues' wordings land on the same 25 bp steps
    kf = Event("kalshi", "KXFEDDECISION-26OCT", "Fed decision in Oct 2026?", markets=[
        _m("kalshi", "K-H0", "Fed maintains rate", "q", eid="KXFEDDECISION-26OCT")])
    pf = Event("polymarket", "fed-oct", "Fed Decision in October?", markets=[
        _m("polymarket", "p-nc", "No change", "q", eid="fed-oct", close_time="2026-10-29T03:59:00Z")])
    assert identify(kf)[1] == identify(pf)[1] == "2026-10"
    assert label_span(kf.markets[0], identify(kf)[0]) == label_span(pf.markets[0], identify(pf)[0]) == Span(0, 1)


def test_brazil_ipca_only_where_both_venues_name_the_measure():
    from pmpol.propositions.indicators import _notes, identify, label_span

    k_rule = "If the 12-month inflation rate in Brazil is above 4.00% in Dec 2026, then the market resolves to Yes."
    p_rule = ("This is a market about the variation of consumer prices in Brazil over the 12-month period ending "
              "December 2026, as reported by the Brazilian Institute of Geography and Statistics (IBGE).\n"
              "This market will resolve according to the percentage change in the Extended National Consumer Price "
              "Index (IPCA)")
    k = Event("kalshi", "KXBRAZILINF-25DEC", "What will inflation in Brazil be in Dec 2026?", markets=[
        _m("kalshi", "K-T4.00", "Above 4.00%", "q", eid="KXBRAZILINF-25DEC", strike_type="greater", floor_strike=4.0,
           rules=k_rule)])
    p = Event("polymarket", "brazil-annual-inflation-2026", "Brazil Annual Inflation 2026", markets=[
        _m("polymarket", f"p-{x}", x, "q", eid="b", rules=p_rule) for x in ("4.00-4.49%", "<3.00%", "7.00%+")])
    (sk, per_k), (sp, per_p) = identify(k), identify(p)
    assert sk.key == sp.key == "br_ipca_12m" and per_k == per_p == "2026-12"  # a year's inflation ends in December
    assert label_span(k.markets[0], sk) == Span(401, INF)  # above 4.00 on IBGE's 0.01 grid
    assert [label_span(m, sp) for m in p.markets] == [Span(400, 450), Span(-INF, 300), Span(700, INF)]
    assert any("without naming IPCA" in n for n in _notes(k.markets[0], sk)) and not _notes(p.markets[0], sp)[1:]
    # Kalshi's rules are checked too for this series; an "annual" that is not the 12 months ending December is out
    vague = Event("kalshi", "x", k.title, markets=[_m("kalshi", "K-1", "Above 4.00%", "q", eid="x",
                                                      strike_type="greater", floor_strike=4.0, rules="Brazil CPI")])
    avg = Event("polymarket", "y", p.title, markets=[_m("polymarket", "p-y", "4.00-4.49%", "q", eid="y",
                                                         rules="average annual IPCA reported by IBGE")])
    assert identify(vague) is None and identify(avg) is None


def test_bracket_ranges_follow_the_rules():
    from pmpol.propositions.indicators import identify, label_span

    rule = "... BEA Advance Estimate ... If the reported value falls exactly between two brackets, then this market " \
           "will resolve to the higher range bracket."
    p = Event("polymarket", "gdp-q3", "US GDP growth in Q3 2026?", markets=[
        _m("polymarket", f"p-{x}", x, "q", eid="gdp-q3", rules=rule) for x in ("0.5–1.0%", "1.0–1.5%", "≥3.0%")])
    s, period = identify(p)
    assert period == "2026-Q3"
    assert [label_span(m, s) for m in p.markets] == [Span(5, 10), Span(10, 15), Span(30, INF)]  # 1.0 is in one bracket


def test_list_names_identify_but_never_separate():
    from pmpol.propositions.derive import _verdict
    from pmpol.propositions.parse import parse_event

    k = Event("kalshi", "KXISRAEL", "Israeli legislative election winner?",
              markets=[_m("kalshi", "K-LIK", "Likud", "q", eid="KXISRAEL"), _m("kalshi", "K-BC", "BC NDP", "q", eid="KXISRAEL")])
    p = Event("polymarket", "israel", "Israel Parliamentary Election Winner",
              markets=[_m("polymarket", "p-lik", "Likud", "q", eid="israel"), _m("polymarket", "p-ndp", "NDP", "q", eid="israel")])
    u = Universe.build([k, p])
    props = {x.market: x for e in (k, p) for x in parse_event(e, u.tags[e.key]).props}
    assert props["kalshi:K-LIK"].values == props["polymarket:p-lik"].values == {"name:likud"}
    assert props["kalshi:K-BC"].values == {"name:bc ndp"}  # an abbreviation is not a person's name
    same = _verdict(Relation("equivalent", ["kalshi:K-LIK"], ["polymarket:p-lik"], "t", "g"), props, {})
    unsure = _verdict(Relation("equivalent", ["kalshi:K-BC"], ["polymarket:p-ndp"], "t", "g"), props, {})
    assert same[0] == "agree" and unsure[0] == "not_covered"


def test_two_people_with_one_name_are_kept_apart():
    k = Event("kalshi", "KXAKSENATE", "Alaska Senate winner? (Person)", markets=[
        _m("kalshi", "K-DSUL", "Dan Sullivan", "q", eid="KXAKSENATE"),
        _m("kalshi", "K-DJSUL", "Daniel J. Sullivan", "q", eid="KXAKSENATE"),
        _m("kalshi", "K-PEL", "Mary Peltola", "q", eid="KXAKSENATE")])
    g = Event("gemini", "SEN26AK", "Alaska US Senate Winner", markets=[
        _m("gemini", "G-DS", "Dan Sullivan", "q", eid="SEN26AK"), _m("gemini", "G-MP", "Mary Peltola", "q", eid="SEN26AK")])
    p = Event("polymarket", "ak", "Alaska Senate Election Winner", markets=[
        _m("polymarket", "P-DJS", "Daniel J. Sullivan Jr.", "q", eid="ak"),
        _m("polymarket", "P-DS", "Sen. Dan Sullivan", "q", eid="ak")])
    u = Universe.build([k, g, p])
    who = {x.market: next(iter(x.values)) for x in parse_universe(u).props}
    # one person written three ways ...
    assert who["kalshi:K-DSUL"] == who["gemini:G-DS"] == who["polymarket:P-DS"]
    assert who["kalshi:K-DJSUL"] == who["polymarket:P-DJS"]  # Jr. ignored, same middle initial
    # ... and a different person with a similar name
    assert who["kalshi:K-DJSUL"] != who["kalshi:K-DSUL"]
    pairs = {frozenset(d.lhs + d.rhs) for d in derive(u, parse_universe(u).props)}
    assert frozenset({"kalshi:K-DJSUL", "gemini:G-DS"}) not in pairs


def test_nicknames_and_suffixes_join_unless_a_middle_initial_differs():
    from pmpol.propositions.derive import candidate_parties

    def ev(venue, eid, title, labels):
        return Event(venue, eid, title, markets=[_m(venue, f"{eid}-{i}", x, "q", eid=eid) for i, x in enumerate(labels)])
    p = ev("polymarket", "mi10", "MI-10 House Election Winner", ["Mike Bouchard (R)", "Tom Sanders (D)"])
    k = ev("kalshi", "KXMI10", "MI-10 House winner?", ["Michael Bouchard Jr.", "Tom Sanders"])
    u = Universe.build([p, k])
    props = [x for x in parse_universe(u).props if x.var.kind == "winner"]
    kb = next(x for x in props if x.market == "kalshi:KXMI10-0")
    assert candidate_parties(u, props).get(next(iter(kb.values))) == "R"  # Mike = Michael, Jr. ignored
    p2 = ev("polymarket", "ak", "Alaska Senate Election Winner", ["Dan Sullivan (R)", "Mary Peltola (D)"])
    k2 = ev("kalshi", "KXAK", "Alaska Senate winner?", ["Daniel J. Sullivan Jr.", "Mary Peltola"])
    u2 = Universe.build([p2, k2])
    props2 = [x for x in parse_universe(u2).props if x.var.kind == "winner"]
    dj = next(x for x in props2 if x.market == "kalshi:KXAK-0")
    assert next(iter(dj.values)) not in candidate_parties(u2, props2)  # a middle initial: maybe someone else


def test_announcement_rule_is_read():
    from pmpol.propositions.parse import announcement_rule

    pm = Market("polymarket", "p", "e", "q", "", rules="An announcement of Pete Hegseth's resignation/removal before "
                "this market's end date will immediately resolve this market to Yes, regardless of when ...")
    k = Market("kalshi", "k", "e", "q", "Before Dec 1, 2026",
               rules="Pete Hegseth must have an actual departure date and vacate the role within the time period.")
    assert announcement_rule(pm) == "announcement: counts"
    assert announcement_rule(k).startswith("announcement: does not count")
    assert announcement_rule(Market("kalshi", "x", "e", "q", "", rules="If X visits Y.")) is None


def test_seat_conjunctions_are_boxes_on_the_two_chamber_grid():
    from pmpol.kb import KnowledgeBase
    from pmpol.propositions.parse import _seat_chambers, _seat_sentence, seat_box

    assert _seat_chambers("≤47 and 218-232") == {"senate": (0, 48), "house": (218, 233)}
    assert _seat_chambers("≥53 and 208–222") == {"senate": (53, INF), "house": (208, 223)}
    assert _seat_sentence("hold 218 or more seats in the House after the 2026 midterms AND hold 49 or more "
                          "seats in the Senate") == {"house": (218, INF), "senate": (49, INF)}
    t = "How many House and Senate seats will Dems control after the 2026 midterms?"
    rows = {"≤50 and ≤217": 0.05, "≤50 and ≥218": 0.30, "≥51 and ≤217": 0.02, "≥51 and ≥218": 0.63}
    grid = Event("predictit", "G", t, markets=[_m("predictit", f"g{i}", o, t, eid="G", bid=p - 0.005, ask=p + 0.005)
                                               for i, (o, p) in enumerate(rows.items())])
    wave_q = "Blue wave in 2026?"
    wave = Event("polymarket", "W", wave_q, markets=[Market(
        "polymarket", "w", "W", wave_q, "", rules="This market will resolve to Yes if both of the following conditions "
        "are met as a result of the 2026 midterm elections: Democrats have a seat count of 218 or more in the House; "
        "Democrats have a seat count of 49 or more in the Senate", bid=0.70, ask=0.72)])
    t3 = "2026 Midterms: Congress Balance of Power?"
    sweep = Event("kalshi", "BAL", t3, markets=[_m("kalshi", "bal-0", "Democrats sweep", t3, eid="BAL", bid=0.55,
                                                   ask=0.56)])
    u = Universe.build([grid, wave, sweep])
    props = parse_universe(u).props
    boxes = {p.market: seat_box(p) for p in props if p.rule == "seat_box"}
    assert len(boxes) == 5 and boxes["polymarket:w"] == (Span(49, INF), Span(218, INF))
    assert len({p.var for p in props if p.rule == "seat_box"}) == 1  # both read D seats after the 2026 election
    ds = derive(u, props, kb=KnowledgeBase.load())
    by = {(d.basis, tuple(sorted(d.lhs)), tuple(sorted(d.rhs))) for d in ds}
    # the cell >=51 x >=218 lies inside the wave box; the wave box meets two cells
    assert ("box_cells", ("predictit:g3",), ("polymarket:w",)) in by
    assert ("box_cells", ("polymarket:w",), ("predictit:g1", "predictit:g3")) in by
    # both chambers at a majority imply the sweep
    assert ("seats_imply_control", ("predictit:g3",), ("kalshi:bal-0",)) in by
    assert ("seats_imply_control", ("polymarket:w",), ("kalshi:bal-0",)) not in by  # 49 Senate seats are not 51


def test_people_in_event_descriptors_are_entities():
    from types import SimpleNamespace

    from pmpol.entities.graph import EntityIndex
    from pmpol.entities.sources import Entity, name_variants
    from pmpol.propositions.derive import people_names, with_people
    from pmpol.propositions.describe import describe

    def ent(eid, name, sources, **kw):
        return Entity(id=eid, kind="person", name=name, aliases=name_variants(name), sources=set(sources), **kw)

    idx = EntityIndex.build([("t", [
        ent("Q22686", "Donald Trump", {"seed"}, wikidata="Q22686", country="us", prominent=True),
        ent("m1", "Ivanka Trump", {"markets"}, country="us"),
        ent("os:Q16194176", "Howard Lutnick", {"opensanctions:us_plum_book"}, country="us", prominent=True),
        ent("m2", "Elon Musk", {"markets"}, country="us"),
        ent("os:Q1", "Ali Khamenei", {"opensanctions:us_cia_world_leaders"}, country="ir", prominent=True),
        ent("os:Q2", "Mojtaba Khamenei", {"opensanctions:us_cia_world_leaders"}, country="ir", prominent=True)])])
    none = SimpleNamespace(country=None, jurisdiction=None)
    titles = {"a": "Trump Impeached?", "b": "Will President Donald Trump be impeached during his term?",
              "c": "Howard Lutnick out as Commerce Secretary?", "d": "Will Elon Musk visit Mars?",
              "e": "Khamenei out?"}
    titled = {k: (describe(t), t, none) for k, t in titles.items()}
    names = people_names(titled, idx)
    got = {k: with_people(d, names, idx)[0].key for k, (d, _, _) in titled.items()}
    # the surname of the one prominent Trump, with the verb in lower case, and the full name: one entity
    assert got["a"] == got["b"] == "impeach(q:Q22686)"
    assert got["c"] == "leave_office(@q:Q16194176, role:commerce_secretary)"  # OpenSanctions ids are QIDs
    assert got["d"] == describe(titles["d"]).key  # a name seen only in market labels stays as written
    assert got["e"] == "leave_office(@khamenei)"  # two prominent Khameneis: not linked


def test_action_entailments_compare_the_same_arguments_only():
    from pmpol.propositions.describe import describe, entails

    k = lambda t: describe(t).key  # noqa: E731
    assert entails(k("Will Trump be impeached and removed from office?"), k("Will Trump be impeached?"))[0] == \
        "removed_is_impeached"
    assert entails(k("Will Trump resign?"), k("Trump out?"))[0] == "resign_is_out"
    assert entails(k("Pete Hegseth out as Secretary of Defense?"),
                   k("Pete Hegseth Announced Out as Secretary of Defense?"))[0] == "out_is_announced"
    assert entails(k("Will Russia capture all of Lyman?"), k("Will Russia capture Lyman?"))[0] == "all_is_captured"
    # never the other way, never with other arguments, never an action with itself
    assert entails(k("Will Trump be impeached?"), k("Will Trump be impeached and removed from office?")) is None
    assert entails(k("Trump out?"), k("Will Trump resign?")) is None
    assert entails(k("Will Tim Walz resign?"), k("Tim Walz out as Governor of Minnesota?")) is None
    assert entails(k("Will Trump be impeached?"), k("Will Trump be impeached?")) is None
    # derived only when the first deadline is no later than the second
    t1, t2 = "Will Russia capture all of Lyman by December 31, 2026?", "Will Russia capture Lyman by June 30, 2027?"
    early = Event("polymarket", "A", t1, markets=[_m("polymarket", "a", "December 31", t1, eid="A", bid=0.02, ask=0.03)])
    late = Event("polymarket", "B", t2, markets=[_m("polymarket", "b", "June 30", t2, eid="B", bid=0.05, ask=0.06)])
    u = Universe.build([early, late])
    ds = [d for d in derive(u, parse_universe(u).props) if d.basis == "action_entails"]
    assert [(d.lhs, d.rhs) for d in ds] == [(["polymarket:a"], ["polymarket:b"])]


def test_sets_defined_by_the_rules_give_geographic_containment():
    from pmpol.propositions.describe import place_key

    assert place_key("Kostyantynivka") == place_key("Kostiantynivka")
    oblast_rules = ("This market will resolve to Yes if Russia captures the entirety of Donetsk Oblast by December 31, "
                    "2026. The relevant municipalities in Donetsk Oblast that must be simultaneously captured in their "
                    "entirety are: Kramatorsk, Sloviansk, Kostiantynivka, and Sviatohirsk.  The boundaries ...")
    latam_rules = ("This market will resolve to Yes if the United States commences a military offensive by December 31, "
                   "2026, 11:59 PM ET. Qualifying Latin America countries: Mexico, Colombia, Venezuela,, Cuba, Haiti  The "
                   "resolution source")

    def ev(eid, title, label, rules="", bid=0.1, ask=0.12):
        return Event("polymarket", eid, title, markets=[_m("polymarket", eid.lower(), label, title, eid=eid, rules=rules,
                                                         bid=bid, ask=ask)])
    events = [ev("D", "Will Russia capture all of Donetsk Oblast by December 31, 2026?", "December 31", oblast_rules),
              ev("S", "Will Russia capture Sloviansk by December 31, 2026?", "December 31"),
              ev("K", "Will Russia capture all of Kostyantynivka by June 30, 2027?", "June 30"),
              ev("V", "Will Russia capture Serhiivka by December 31, 2026?", "December 31"),  # not in the list
              ev("L", "Will the U.S. invade a Latin American country in 2026?", "", latam_rules),
              ev("C", "Will the U.S. invade Cuba in 2026?", ""),
              ev("G", "Will the U.S. invade Greenland in 2026?", "")]
    u = Universe.build(events)
    ds = [d for d in derive(u, parse_universe(u).props) if d.basis == "defined_members"]
    pairs = {(d.lhs[0], d.rhs[0]) for d in ds}
    assert pairs == {("polymarket:d", "polymarket:s"), ("polymarket:d", "polymarket:k"), ("polymarket:c", "polymarket:l")}
    assert all("data:rules:" in g for d in ds for g in d.grounds)


def test_argument_roles_follow_the_voice():
    from pmpol.propositions.describe import describe, entails

    k = lambda t: describe(t).key  # noqa: E731
    # passive: the subject is the patient; only the House impeaches, so naming it adds nothing
    assert k("Trump Impeached?") == k("Will Trump be impeached by...?") == k("Will the House impeach Trump?") == \
        "impeach(trump)"
    assert k("Kupiansk captured by Russia by December 31?") == k("Will Russia capture Kupiansk by...?") == \
        "capture(@russia, kupiansk)"
    assert k("Will Russia invade Ukraine?") != k("Will Ukraine invade Russia?")
    assert k("Has Russia invaded Poland?") == k("Will Russia invade Poland?")  # perfect tense is active
    assert k("Will Congress confirm a Supreme Court justice?") == k("Will a Supreme Court justice be confirmed?")
    assert k("Lutnick out as Commerce Secretary?") == "leave_office(@lutnick, role:commerce_secretary)"
    # a named agent implies an unnamed one; removal makes the patient the one who leaves
    assert entails(k("Trump abolishes the Department of Education?"), k("Department of Education abolished?"))[0] == \
        "agent_unspecified"
    assert entails(k("Department of Education abolished?"), k("Trump abolishes the Department of Education?")) is None
    assert entails(k("Will Trump be impeached and removed from office?"), k("Trump out?"))[0] == "removed_is_out"


def test_questions_whose_options_are_the_arguments():
    from pmpol.propositions.describe import complete, describe, option_sentence

    assert option_sentence("Who will Donald Trump meet in 2026?", "Vladimir Putin") == \
        "Will Donald Trump meet Vladimir Putin in 2026"
    assert option_sentence("Which leaders will leave office in 2026?", "Mark Carney") == \
        "Will Mark Carney leave office in 2026"
    assert option_sentence("Who will be arrested in 2026?", "Gavin Newsom") == "Will Gavin Newsom be arrested in 2026"
    assert describe(option_sentence("Which countries will have a recession before 2027?", "China")).key == "recession(@china)"
    # orderings, counts and nouns are not one event per option
    assert option_sentence("Which G7 leader will leave office next?", "Mark Carney") is None
    assert option_sentence("How many states will Trump visit in 2026?", "At least 6") is None
    assert option_sentence("Who will dissent at the October Fed meeting?", "Kevin Warsh") is None
    # New Mexico is not Mexico, and Mexico is not completed into New Mexico
    nm, mx = describe("Will Trump visit New Mexico in 2026?"), describe("Will Trump visit Mexico in 2026?")
    assert nm.key != mx.key and len(set(complete({"a": nm, "b": mx}).values())) == 2
    t = "Who will be arrested in 2026?"
    kal = Event("kalshi", "A", t, markets=[_m("kalshi", "a1", "Gavin Newsom", t, eid="A", bid=0.03, ask=0.04),
                                           _m("kalshi", "a2", "Bill Clinton", t, eid="A", bid=0.05, ask=0.06)])
    t2 = "Will Gavin Newsom be arrested in 2026?"
    pm = Event("polymarket", "B", t2, markets=[_m("polymarket", "b", "", t2, eid="B", bid=0.02, ask=0.03)])
    u = Universe.build([kal, pm])
    props = {p.market: p for p in parse_universe(u).props}
    assert props["kalshi:a1"].var == props["polymarket:b"].var and props["kalshi:a2"].var != props["polymarket:b"].var


def test_other_central_banks_on_the_decision_grid():
    t1, t2 = "Bank of Japan rate decision in December", "Bank of Japan Decision in December?"
    kal = Event("kalshi", "K", t1, markets=[
        _m("kalshi", "k1", "Maintain current rate", t1, eid="K", close_time="2026-12-19T00:00:00Z"),
        _m("kalshi", "k2", "Hike 1-25bps", t1, eid="K", close_time="2026-12-19T00:00:00Z")])
    pm = Event("polymarket", "P", t2, markets=[
        _m("polymarket", "p1", "No change", t2, eid="P", close_time="2026-12-19T00:00:00Z"),
        _m("polymarket", "p2", "25 bps increase", t2, eid="P", close_time="2026-12-19T00:00:00Z")])
    u = Universe.build([kal, pm])
    props = {p.market: p for p in parse_universe(u).props}
    assert props["kalshi:k1"].var.subject == "boj_change|2026-12"
    assert props["kalshi:k1"].spans == props["polymarket:p1"].spans and props["kalshi:k2"].spans == props["polymarket:p2"].spans
    ds = {(d.basis, d.lhs[0], d.rhs[0]) for d in derive(u, list(props.values()))}
    assert ("same_set", "kalshi:k1", "polymarket:p1") in ds or ("same_set", "polymarket:p1", "kalshi:k1") in ds


def test_more_rule_phrasings_are_read():
    from pmpol.propositions.resolution import _boundary, _rounding, attributes

    assert _boundary("each margin range is inclusive of its lower bound and exclusive of its upper bound.") == "[lo, hi)"
    assert _boundary("this market will resolve to the higher margin bracket.") == "[lo, hi)"
    assert _rounding("no rounding shall be applied to the calculated margin.") == "none"
    m = Market("kalshi", "x", "e", "q", "Democratic party",
               rules="If a representative of the Democratic party is sworn in as a Senator of Georgia")
    assert attributes(m, "winner")["runoff"] == "included"


def test_a_foreign_election_reads_its_own_parties_years_and_seat_counts():
    from pmpol.propositions.relations import confidence

    def ev(venue, eid, title, outcomes, **kw):
        return Event(venue, eid, title, mutually_exclusive=True, markets=[
            _m(venue, f"{eid}-{i}", o, title, eid=eid, close_time=kw.get("close", "2026-10-28T00:00:00Z"))
            for i, o in enumerate(outcomes)])

    pm = ev("polymarket", "isr", "Israeli Legislative Election Winner", ["Likud", "The Democrats"])
    seats_k = ev("kalshi", "KXLIKUDCOUNT-26OCT27", "Israeli legislative election: how many seats will Likud win?",
                 ["Above 20"])
    seats_p = ev("polymarket", "likud-seats", "Israel Election: Likud # of seats?", ["20-24"])
    share = ev("polymarket", "dem-share", "Israel Election: The Democrats vote share?", ["5-6%"])
    pm_pm = ev("polymarket", "pm26", "Prime Minister of Israel after the 2026 election?", ["Naftali Bennett"])
    nxt = ev("gemini", "pm-next", "Who will be the next Prime Minister of Israel after the next election?",
             ["Naftali Bennett"], close="2028-12-31T00:00:00Z")
    cabinet = ev("kalshi", "KXDEFMIN-26", "Who will be Israeli defense minister after the election?", ["Israel Katz"])
    u = Universe.build([pm, seats_k, seats_p, share, pm_pm, nxt, cabinet])
    parsed = parse_universe(u)
    by = {p.market: p for p in parsed.props}
    assert not any(v.startswith("party:") for v in by["polymarket:isr-1"].values)  # not the U.S. Democratic Party
    assert by["kalshi:KXLIKUDCOUNT-26OCT27-0"].var == by["polymarket:likud-seats-0"].var  # one seat-count variable
    assert by["polymarket:dem-share-0"].var.qualifier == "the democrats"  # a party list, not "T. Democrats"
    assert by["gemini:pm-next-0"].var == by["polymarket:pm26-0"].var  # "next election" takes the year others name
    assert "cabinet post" in parsed.unparsed["kalshi:KXDEFMIN-26-0"]
    from pmpol.propositions.derive import Derived

    d = Derived("equivalent", ("polymarket:pm26-0",), ("gemini:pm-next-0",), "winner(x)", "same_set", True)
    p0 = by["polymarket:pm26-0"]
    q = type(p0)(p0.var, p0.market, p0.event, p0.rule, values=frozenset({"person:Q39318"}))
    assert confidence(d, {"polymarket:pm26-0": q, "gemini:pm-next-0": q}) == "entity"
    assert confidence(d, {"polymarket:pm26-0": p0, "gemini:pm-next-0": p0}) == "name"
