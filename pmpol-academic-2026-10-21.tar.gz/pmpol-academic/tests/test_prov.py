from pmpol import prov
from pmpol.proof import Proof


def _proof():
    p = Proof("t", "c", result={})
    p.add("L1", "seats", "us.house.majority", "2026-10-01", id="a")
    p.add("L4", "quote", "https://kalshi.com/x", "2026-10-05T12:00", id="b")
    p.add("L5", "compare", kind="logic", id="c", inputs=("a", "b"))
    return p


def test_a_proof_becomes_prov_entities_with_derivations_back_to_its_sources():
    rows = [{"id": "sig1", "title": "t", "proof": _proof().to_dict(), "observed_at": "2026-10-05T12:00"}]
    doc = prov.document(rows, {"us.house.majority"}, "abc")
    assert prov.check(doc) == []
    e = doc["entity"]
    assert e["pmpol:proof/0"]["pmpol:grounded"] and e["kb:us.house.majority"]["prov:type"] == "pmpol:Fact"
    assert e["pmpol:step/0/b"]["pmpol:asOf"] == "2026-10-05T12:00"
    pairs = {(r["prov:generatedEntity"], r["prov:usedEntity"]) for r in doc["wasDerivedFrom"].values()}
    assert ("pmpol:step/0/c", "pmpol:step/0/a") in pairs and ("pmpol:proof/0", "pmpol:step/0/c") in pairs
    assert ("pmpol:step/0/a", "kb:us.house.majority") in pairs
    assert ("pmpol:proof/0", "pmpol:step/0/a") not in pairs  # a step another step uses does not feed the conclusion
    assert doc["agent"]["pmpol:system"]["pmpol:commit"] == "abc"
    assert doc["activity"]["pmpol:inference/0"]["prov:endTime"] == "2026-10-05T12:00"


def test_check_finds_dangling_relations_and_ungrounded_claims():
    p = Proof("t", "c")
    p.add("L5", "only an inference", kind="logic", id="x")
    doc = prov.document([{**p.to_dict(), "grounded": True}])  # claims to be grounded but is not
    assert any("reaches no L0-L4 step" in m for m in prov.check(doc))
    doc["wasDerivedFrom"]["_:bad"] = {"prov:generatedEntity": "pmpol:nowhere", "prov:usedEntity": "pmpol:step/0/x"}
    assert any("unknown node pmpol:nowhere" in m for m in prov.check(doc))
