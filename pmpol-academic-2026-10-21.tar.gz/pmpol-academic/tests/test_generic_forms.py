from pmpol.models import Event, Market
from pmpol.propositions.derive import derive, parse_universe
from pmpol.propositions.parse import title_key
from pmpol.universe.index import Universe


def _ev(venue, eid, title, labels, close="2026-12-31T23:59:00Z", excl=True, question=None):
    return Event(venue, eid, title, mutually_exclusive=excl, markets=[
        Market(venue, f"{eid}-{i}", eid, question or title, lab, bid=0.2, ask=0.22, close_time=close)
        for i, lab in enumerate(labels)])


def test_title_key_is_a_word_bag_that_keeps_years():
    assert title_key("2026 Nobel Peace Prize winner") == title_key("Nobel Peace Prize Winner 2026?")
    assert title_key("Italy's budget balance in 2026") != title_key("Italy's budget balance in 2027")


def _props(events):
    u = Universe.build(events)
    parsed = parse_universe(u)
    return u, parsed, {p.market: p for p in parsed.props}


def test_options_numbers_and_separate_questions_get_generic_forms():
    u, parsed, prop = _props([
        _ev("polymarket", "nobel", "2026 Nobel Peace Prize winner", ["Yulia Navalnaya", "UNHCR"]),
        _ev("polymarket", "budget", "Italy budget balance in 2026", ["Above 3%", "2-3%"]),
        _ev("polymarket", "palestine", "Which countries will recognize Palestine before 2027?", ["France", "Japan"],
            excl=False)])
    assert prop["polymarket:nobel-0"].var.kind == "choice"
    assert prop["polymarket:budget-0"].var.kind == "quantity" and prop["polymarket:budget-0"].spans
    t = prop["polymarket:palestine-0"]
    assert t.var.kind == "event_time" and t.var.subject.endswith("| france")


def test_generic_relations_need_two_venues_and_one_occasion():
    weekly = [_ev("polymarket", "w1", "2026 Nobel Peace Prize winner", ["UNHCR", "WFP"], close="2026-10-10T00:00:00Z"),
              _ev("limitless", "w2", "Nobel Peace Prize Winner 2026", ["UNHCR", "WFP"], close="2026-10-11T00:00:00Z"),
              _ev("smarkets", "w3", "Nobel Peace Prize 2026 winner", ["UNHCR", "WFP"], close="2026-12-01T00:00:00Z"),
              _ev("polymarket", "w4", "Nobel Peace Prize 2026 Winner", ["UNHCR", "WFP"], close="2026-10-10T00:00:00Z")]
    u, parsed, _ = _props(weekly)
    pairs = {tuple(sorted((d.lhs[0].split("-")[0], d.rhs[0].split("-")[0]))) for d in derive(u, parsed.props)}
    # Polymarket-Limitless within a week: related; Smarkets closes seven weeks later; two Polymarket events never
    assert pairs == {("limitless:w2", "polymarket:w1"), ("limitless:w2", "polymarket:w4")}
