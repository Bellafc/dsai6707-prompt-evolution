from pmpol.audit import grounding
from pmpol.kb import KnowledgeBase
from pmpol.models import Relation


def test_relations_are_counted_by_their_weakest_ground():
    rels = [Relation("equivalent", ["a"], ["b"], "onto:winner:same_set", "g"),
            Relation("implies", ["a"], ["b"], "onto:seats:seats_imply_control", "g", grounds=("kb:us.senate.seats",)),
            Relation("equivalent", ["a"], ["b"], "onto:margin:bridge_margin_winner", "g"),
            Relation("equivalent", ["a"], ["b"], "onto:winner:bridge_person_party", "g",
                     grounds=("assumption:labels_identify_party_candidate",)),
            Relation("equivalent", ["a"], ["b"], "cross_venue_text", "g")]  # not an ontology relation
    got = grounding(rels, kb=KnowledgeBase.load())
    assert got == {"axioms": 1, "kb_fact": 1, "kb_fact_proposed": 1, "assumption_unsupported": 1}
