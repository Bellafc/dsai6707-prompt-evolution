import sqlite3

from pmpol import residual
from pmpol.models import Event, Market
from pmpol.universe.index import Universe


def _ev(eid, title, outcome="Yes"):
    return Event("polymarket", eid, title, markets=[Market("polymarket", f"{eid}-m", eid, title, outcome, bid=0.4, ask=0.42)])


def test_new_unread_questions_are_grouped_and_reported():
    old = [_ev("ny02", "NY-02 House Election Winner 2026", "Democratic Party")]
    new = old + [_ev("kharg", "Kharg Island no longer under Iranian control by...?"),
                 _ev("tunb", "Greater Tunb Island no longer under Iranian control by...?"),
                 _ev("nessie", "Will the Loch Ness monster be found?")]
    u = Universe.build(new)
    parsed = {"polymarket:ny02-m"}  # only the House market was read as a proposition
    r = residual.compute(u, {"polymarket:nessie-m": "measure 'binary' not modelled"}, parsed,
                         {e.key for e in old}, "2026-10-02T20:46")
    assert len(r.new_events) == 3 and len(r.new_unread) == 3
    assert r.counts()["residual_new_unread"] == 3 and 0 < r.unparsed_share < 1
    groups = dict(residual.themes([u.events[k].title for k in r.new_unread]))
    assert any(len(ts) == 2 for ts in groups.values()) and ("iranian" in groups or "island" in groups)
    page = "\n".join(residual.render(u, r, [("run1", {**r.counts(), "observed_at": "2026-10-03T01:11"})]))
    assert "殘差監測" in page and "新出現、讀不懂的題目" in page and "Loch Ness" in page and "趨勢" in page


def test_trend_reads_universe_runs_only_with_residual_counts():
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE runs (id TEXT, command TEXT, started_at TEXT, finished_at TEXT, status TEXT, git_sha TEXT,"
                 " args TEXT, counts TEXT, error TEXT)")
    rows = [("a", "universe", "1", '{"residual_unparsed_share": 0.3, "residual_unclassified_share": 0.08}'),
            ("b", "universe", "2", '{"events": 5}'), ("c", "macro", "3", '{"residual_unparsed_share": 0.1}')]
    conn.executemany("INSERT INTO runs VALUES (?,?,?,'', 'ok','', '', ?, '')", rows)
    assert [rid for rid, _ in residual.trend(conn)] == ["a"]
    assert residual.trend(sqlite3.connect(":memory:")) == []  # no runs table yet
