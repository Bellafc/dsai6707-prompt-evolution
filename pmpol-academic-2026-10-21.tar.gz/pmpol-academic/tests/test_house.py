import numpy as np
import pytest

from pmpol import house
from pmpol.fourier import convolve_outcomes
from pmpol.models import Event, Market
from pmpol.propositions import INF, Prop, Var
from pmpol.universe.index import Universe


def test_district_keys():
    assert house.district_key("MI-7") == "MI-07" and house.district_key("AK") == "AK-AL"
    assert house.district_key("WY-AL") == "WY-AL" and house.district_key("Michigan") is None


def _u_and_props():
    ev = [Event("kalshi", "K1", "MI-07", markets=[
              Market("kalshi", "K1-D", "K1", "q", "Democratic", bid=0.58, ask=0.62, active=True),
              Market("kalshi", "K1-R", "K1", "q", "Republican", bid=0.38, ask=0.42, active=True)]),
          Event("polymarket", "P1", "MI-07", markets=[
              Market("polymarket", "P1-D", "P1", "q", "Yes", bid=0.50, ask=0.54, active=True)]),  # one party, yes/no
          Event("kalshi", "K2", "MI-08", markets=[
              Market("kalshi", "K2-D", "K2", "q", "Democratic", bid=0.10, ask=0.90, active=True)])]  # too wide
    u = Universe.build(ev)
    v7, v8 = Var("winner", "United States|MI-07|house|2026|general"), Var("winner", "United States|MI-08|house|2026|general")
    props = [Prop(v7, "kalshi:K1-D", ev[0].key, "r", values=frozenset({"party:D"})),
             Prop(v7, "kalshi:K1-R", ev[0].key, "r", values=frozenset({"party:R"})),
             Prop(v7, "polymarket:P1-D", ev[1].key, "r", values=frozenset({"party:D"})),
             Prop(v8, "kalshi:K2-D", ev[2].key, "r", values=frozenset({"party:D"}))]
    return u, props


def test_district_probabilities_blend_venues_and_skip_empty_books():
    u, props = _u_and_props()
    ds, left = house.district_probs(u, props)
    d = ds["MI-07"]
    # Kalshi 0.60/0.40 (spread 4) and Polymarket 0.52/0.48 (spread 4): equal weights
    assert d.probs["D"] == pytest.approx(0.56) and d.probs["R"] == pytest.approx(0.44)
    assert d.venues == ["kalshi", "polymarket"] and "MI-08" in left


def test_independent_house_model_is_a_poisson_binomial():
    rng = np.random.default_rng(2)
    p = rng.uniform(0.05, 0.95, 40)
    ds = [house.District(f"XX-{i:02d}", {"D": q, "O": 0.0, "R": 1 - q}, ["k"]) for i, q in enumerate(p)]
    m = house.HouseModel(ds, 0.0)
    pb = convolve_outcomes([[((1,), q), ((0,), 1 - q)] for q in p])
    assert np.allclose(m.d_pmf, pb, atol=1e-10)
    # correlation widens the distribution but keeps the mean
    c = house.HouseModel(ds, 0.4)
    k = np.arange(len(pb))
    assert (c.d_pmf * k).sum() == pytest.approx((pb * k).sum(), abs=1e-6)
    assert (c.d_pmf * k ** 2).sum() > (pb * k ** 2).sum()


def test_calibration_pulls_safe_seat_longshots_down():
    class KB:
        facts = {"calibration.kalshi.politics.h30": type("F", (), {"id": "calibration.kalshi.politics.h30",
                                                                   "value": {"slope_b": 1.2, "n": 5000}})()}
    ds = {"GA-09": house.District("GA-09", {"D": 0.05, "O": 0.0, "R": 0.95}, ["kalshi"], weights={"kalshi": 1.0})}
    out, used = house.recalibrate(ds, KB())
    assert used == ["calibration.kalshi.politics.h30"] and out["GA-09"].probs["D"] < 0.04


def test_aggregate_targets_and_edge_groups():
    t = house.Target("kalshi:X", "At least 218", "national D/won", "D", "", 218, INF, 0.9, 0.02)
    ds = [house.District(f"XX-{i:03d}", {"D": 0.6, "O": 0.0, "R": 0.4}, ["k"]) for i in range(435)]
    m = house.HouseModel(ds, 0.2)
    assert t.price(m, 218) == pytest.approx(house.HouseModel.prob(m.d_pmf, 218, np.inf))
    f = house.Fit("calibrated", ds, 0.2, 1.0, m, {"control": 0.0, "national D/won": 0.95, "AL D/won": 0.0,
                                                  "PA D/won": 0.8})
    assert f.edge_groups() == ["AL D/won"] and set(f.state_rhos()) == {"AL D/won", "PA D/won"}


def test_incomplete_coverage_runs_no_model():
    u, props = _u_and_props()
    res = house.run(u, props)
    assert not res.complete and not res.fits and "1 / 435" in house.render(res, "t")
    assert house.export(res, None, "", "/nonexistent/x.json") == 0


def _two_states():
    rng = np.random.default_rng(5)
    return [house.District(f"{st}-{i:02d}", {"D": q, "O": 0.0, "R": 1 - q}, ["k"])
            for st in ("AA", "BB") for i, q in enumerate(rng.uniform(0.2, 0.8, 6))]


def test_two_level_model_reduces_to_one_factor_without_a_state_factor():
    ds = _two_states()
    one, two = house.HouseModel(ds, 0.3, n_nodes=32), house.TwoLevelModel(ds, 0.3, 0.0, n_z=32, n_w=8)
    assert np.allclose(one.d_pmf, two.d_pmf, atol=1e-8) and np.allclose(one.r_pmf, two.r_pmf, atol=1e-8)
    assert np.allclose(one.state_pmf("AA"), two.state_pmf("AA"), atol=1e-8)


def test_a_state_factor_widens_states_but_keeps_means():
    ds = _two_states()
    flat, lumpy = house.TwoLevelModel(ds, 0.1, 0.0), house.TwoLevelModel(ds, 0.1, 0.5)
    k = np.arange(7)
    mean = sum(d.probs["D"] for d in ds if d.key.startswith("AA"))
    for m in (flat, lumpy):
        assert (m.state_pmf("AA") * k).sum() == pytest.approx(mean, abs=1e-6)
    var = lambda p: (p * k ** 2).sum() - (p * k).sum() ** 2  # noqa: E731
    assert var(lumpy.state_pmf("AA")) > var(flat.state_pmf("AA")) + 0.2


def test_per_state_factor_loadings():
    ds = _two_states()
    same = house.TwoLevelModel(ds, 0.1, {"AA": 0.4, "BB": 0.4})
    flat = house.TwoLevelModel(ds, 0.1, 0.4)
    assert np.allclose(same.d_pmf, flat.d_pmf, atol=1e-10)
    mixed = house.TwoLevelModel(ds, 0.1, {"AA": 0.6}, default_s=0.0)  # BB falls back to the default
    assert np.allclose(mixed.state_pmf("BB"), house.TwoLevelModel(ds, 0.1, 0.0).state_pmf("BB"), atol=1e-10)
    # a state's own rho is found from its delegation market alone
    truth = house.TwoLevelModel(ds, 0.1, {"AA": 0.6, "BB": 0.0})
    pa = truth.state_pmf("AA", "D")
    tg = [house.Target("k:a", "4+", "AA D/won", "D", "AA", 4, np.inf, float(pa[4:].sum()), 0.01),
          house.Target("k:b", "0-1", "AA D/won", "D", "AA", 0, 2, float(pa[:2].sum()), 0.01)]
    assert abs(house.fit_state_rhos(ds, tg, 0.1)["AA"] - 0.6) <= 0.04
