from pathlib import Path

from pmpol.models import Market
from pmpol.universe.relations import RecordedBooks, depth_path


class Live:
    def __init__(self):
        self.calls = 0

    def size_at(self, m, side, price):
        self.calls += 1
        return 120.0


def test_books_recorded_during_a_crawl_replay_without_the_venues(tmp_path):
    m = Market("polymarket", "m1", "e1", "q", "Yes", bid=0.4, ask=0.42)
    live = Live()
    books = RecordedBooks(live)
    assert books.size_at(m, "ask", 0.42) == 120.0 and books.size_at(m, "ask", 0.42) == 120.0 and live.calls == 1
    path = depth_path(tmp_path / "universe_20261003T1329Z.json.gz")
    assert path.name == "depth_20261003T1329Z.json.gz"  # not matched by the universe_*.json.gz snapshot glob
    books.save(path)
    replay = RecordedBooks.load(path)
    assert replay.size_at(m, "ask", 0.42) == 120.0
    assert replay.size_at(m, "bid", 0.40) is None and replay.misses == 1  # unrecorded: unknown, never read live
    assert not list(Path(tmp_path).glob("universe_*.json.gz"))
