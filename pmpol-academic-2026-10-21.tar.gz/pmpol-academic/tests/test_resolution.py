from pmpol.models import Market
from pmpol.propositions.resolution import attributes, compare

KALSHI = ("If a representative of the Republican party is sworn in as a Senator of Georgia for the term beginning in "
          "2027, then the market resolves to Yes. This market is eligible for accelerated determination after a "
          "consensus of media organizations project the winner.")
POLY = ("This market will resolve according to the winner of the 2026 midterm Georgia U.S. Senate election, inclusive "
        "of any run-offs. A candidate shall be considered to represent a party in the event that he or she is the "
        "nominee of the party in question. Candidates who run as independents will not be encompassed by the "
        "“Democrat” or “Republican” options. In the event that any named candidate is replaced as the "
        "nominee of their respective party prior to election day, the name in the contract will be updated. The "
        "resolution source for this market is the Associated Press, Fox News, and NBC.")
PU = ("This market will settle to Yes if the Democratic Party nominee wins the 2026 midterm election for US Senator "
      "from Georgia. Outcome sourced from relevant government authorities. The determination of the winner includes "
      "any runoff, tiebreak, or other relevant procedure.")
GEMINI = ("If Jon Ossoff wins the 2026 U.S. Senate election in Georgia, then this market resolves to Yes. Outcome should "
          "be verified from the applicable state election authority.")


def _m(venue, outcome, rules):
    return Market(venue, "x", "e", "q", outcome, rules=rules)


def test_election_attributes():
    k = attributes(_m("kalshi", "Mike Collins", KALSHI), "winner")
    p = attributes(_m("polymarket", "Jon Ossoff (D)", POLY), "winner")
    g = attributes(_m("gemini", "Jon Ossoff", GEMINI), "winner")
    assert k["decided_by"] == "sworn in" and k["candidate"] == "party nominee"
    assert p == {"decided_by": "media call", "runoff": "included", "candidate": "party nominee",
                 "independents": "not a party"}
    assert g["candidate"] == "named person" and g["decided_by"] == "election authorities"
    assert attributes(_m("smarkets", "Democrat", ""), "winner")["runoff"] == "rules not held"
    # "If Liberal Party wins ..." names a party, not a person
    assert attributes(_m("kalshi", "Liberal Party", "If Liberal Party wins the next election"), "winner")[
        "candidate"] != "named person"


def test_comparison_levels():
    p = attributes(_m("polymarket", "Jon Ossoff (D)", POLY), "winner")
    pu = attributes(_m("polymarket_us", "Jon Ossoff (D)", PU), "winner")
    g = attributes(_m("gemini", "Jon Ossoff", GEMINI), "winner")
    s = attributes(_m("smarkets", "Democrat", ""), "winner")
    # a named person vs the party's nominee: if the nominee is replaced, the two pay differently
    assert compare([("polymarket", p), ("gemini", g)]).status == "material"
    # media call vs election authorities only: a detail
    c = compare([("polymarket", p), ("polymarket_us", pu)])
    assert c.status == "minor" and "runoff" in c.same and "candidate" in c.same
    # no rules held: never a difference, just unverified
    assert compare([("polymarket", p), ("smarkets", s)]).status == "unverified"
    # nothing compared equal is not "equivalent"
    n1 = attributes(_m("kalshi", "JD Vance", "If JD Vance is the nominee"), "nominee")
    n2 = attributes(_m("polymarket", "JD Vance", "Resolves to the nominee."), "nominee")
    assert compare([("kalshi", n1), ("polymarket", n2)]).status == "unverified"


def test_deadline_attributes():
    a = attributes(_m("polymarket", "", "An announcement of X's resignation before the end date will immediately "
                                        "resolve this market to Yes. Between market creation and Dec 31, 11:59 PM ET."),
                   "event_time")
    b = attributes(_m("kalshi", "Before Dec 1, 2026", "X must have an actual departure date and vacate the role."),
                   "event_time")
    c = compare([("polymarket", a), ("kalshi", b)])
    assert c.status == "material" and dict(c.differs)["announcement"]
