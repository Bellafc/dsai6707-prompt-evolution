import json

import pytest

from pmpol.classify import TASKS, Example, Prediction, baselines, datasets, labeling, metrics
from pmpol.classify.client import SystemOneClient
from pmpol.classify.splits import gold_sample, grouped_split, holdout_venues
from pmpol.models import Event, Market, Relation


def ev(venue, eid, title, outcomes, rules="", category=""):
    ms = [Market(venue, f"{eid}-{i}", eid, title, o, rules=rules, bid=0.4, ask=0.6) for i, o in enumerate(outcomes)]
    return Event(venue, eid, title, category=category, mutually_exclusive=len(ms) > 1, markets=ms)


AP = "If the Associated Press calls the race for the candidate, the market resolves Yes. Runoffs are included."
CERT = "Resolves to the candidate certified by the Secretary of State as the winner of the general election."


def test_rules_examples_carry_regex_weak_labels_and_groups():
    a = ev("kalshi", "GOV-TX", "Texas Governor winner?", ["Abbott", "Allred"], AP)
    b = ev("polymarket_us", "tx-gov", "Texas Governor Election Winner", ["Greg Abbott", "Colin Allred"], CERT)
    rel = Relation("equivalent", [a.markets[0].key], [b.markets[0].key], "onto:winner:same_set", "race:tx-gov")
    ds = datasets.build([a, b], [rel], tasks=("decided_by", "runoff", "office"))
    d = {x.id: x for x in ds["decided_by"]}
    assert d[a.markets[0].key].weak == "media call" and d[b.markets[0].key].weak == "certification"
    assert all(x.group == "race:tx-gov" for x in ds["decided_by"])
    r = {x.id: x for x in ds["runoff"]}
    assert r[a.markets[0].key].weak == "included" and r[b.markets[0].key].weak == "not stated"
    offices = {x.id: x.weak for x in ds["office"]}
    assert offices[a.key] == "governor" and offices[b.key] == "governor"


def test_save_and_load_round_trip(tmp_path):
    rows = [Example("k:1", "office", "Event: x", "none", "g1", "kalshi")]
    datasets.save({"office": rows}, "snap.json.gz", tmp_path)
    snap, back = datasets.load("office", tmp_path)
    assert snap == "snap.json.gz" and back[0] == rows[0]


def rows(n=60):
    out = []
    for i in range(n):
        lab = ["media call", "certification", "not stated"][i % 3]
        out.append(Example(f"m{i}", "decided_by", f"text {lab} {i}", lab, f"race{i // 4}", "kalshi" if i % 2 else "gemini"))
    return out


def test_grouped_split_keeps_groups_apart_and_gold_sample_is_stable():
    train, test = grouped_split(rows(), 0.3)
    assert {r.group for r in train}.isdisjoint({r.group for r in test}) and train and test
    s1, s2 = gold_sample(rows(), 20), gold_sample(rows(), 20)
    assert [r.id for r in s1] == [r.id for r in s2] and 15 <= len(s1) <= 36
    assert {(r.venue, r.weak) for r in s1} == {(r.venue, r.weak) for r in rows()}
    tr, te = holdout_venues(rows(), ("gemini",))
    assert all(r.venue == "gemini" for r in te) and all(r.venue == "kalshi" for r in tr)


def test_metrics_on_known_predictions():
    gold = {"a": "x", "b": "x", "c": "y", "d": "y"}
    preds = [Prediction("a", "x", {"x": 0.9, "y": 0.1}, 0.9), Prediction("b", "y", {"x": 0.4, "y": 0.6}, 0.6),
             Prediction("c", "y", {"x": 0.2, "y": 0.8}, 0.8), Prediction("d", "y", {"x": 0.3, "y": 0.7}, 0.7)]
    assert metrics.accuracy(preds, gold) == 0.75
    assert metrics.macro_f1(preds, gold) == pytest.approx((2 / 3 + 0.8) / 2)
    assert 0 <= metrics.ece(preds, gold) <= 1 and 0 <= metrics.brier(preds, gold) <= 2
    sel = {s["threshold"]: s for s in metrics.selective(preds, gold)}
    assert sel[0.8]["coverage"] == 0.5 and sel[0.8]["accuracy"] == 1.0
    other = [Prediction(p.id, gold[p.id], {gold[p.id]: 1.0}) for p in preds]
    mc = metrics.mcnemar(other, preds, gold)
    assert mc["a_only_right"] == 1 and mc["b_only_right"] == 0
    lo, hi = metrics.bootstrap_ci(preds, gold, n=200)
    assert 0 <= lo <= 0.75 <= hi <= 1


def test_kappa_and_gold_from_two_annotators(tmp_path):
    a = {"1": "x", "2": "x", "3": "y", "4": "?"}
    b = {"1": "x", "2": "y", "3": "y", "4": "x"}
    k, n = labeling.kappa(a, b)
    assert n == 3 and -1 <= k <= 1
    for name, labs in (("ann_a", a), ("ann_b", b)):
        labeling.path("decided_by", name, tmp_path).parent.mkdir(exist_ok=True, parents=True)
        labeling.path("decided_by", name, tmp_path).write_text(
            "\n".join(json.dumps({"id": i, "label": l, "annotator": name, "task": "decided_by"}) for i, l in labs.items()))
    g = labeling.agreement("decided_by", ("ann_a", "ann_b"), tmp_path)
    assert g["gold"] == {"1": "x", "3": "y"} and set(g["disputed"]) == {"2", "4"}
    labeling.path("decided_by", "judge", tmp_path).write_text(json.dumps({"id": "2", "label": "y"}))
    assert labeling.gold_labels("decided_by", ("ann_a", "ann_b"), "judge", tmp_path) == {"1": "x", "3": "y", "2": "y"}


def test_annotate_resumes_and_accepts_numbers(tmp_path):
    answers = iter(["1", "", "?", "", "q"])
    sample = rows(3)
    n = labeling.annotate("decided_by", sample, "me", tmp_path, ask=lambda _: next(answers), out=open(tmp_path / "o", "w"))
    assert n == 2
    saved = labeling.read(labeling.path("decided_by", "me", tmp_path))
    assert saved["m0"]["label"] == "media call" and saved["m1"]["label"] == "?"
    answers = iter(["certification", "", "q"])
    labeling.annotate("decided_by", sample, "me", tmp_path, ask=lambda _: next(answers), out=open(tmp_path / "o", "w"))
    assert labeling.read(labeling.path("decided_by", "me", tmp_path))["m2"]["label"] == "certification"


def test_baselines_and_learning_curve():
    rs = rows(90)
    assert all(p.label == "media call" for p in baselines.majority(rs))  # ties: first seen
    cv = baselines.tfidf_lr_cv(rs, folds=3)
    gold_w = {r.id: r.weak for r in rs}
    assert metrics.accuracy(cv, gold_w) > 0.9  # the label word is in the text
    curve = baselines.learning_curve(rs, gold_w, sizes=(10, 40))
    assert [c["n_train"] for c in curve] == [10, 40]


def test_client_replays_fixtures_offline(tmp_path):
    ex = rows(1)[0]
    c = SystemOneClient("http://127.0.0.1:1", "vega", fixtures=tmp_path, replay_only=True)
    with pytest.raises(FileNotFoundError):
        c.ask(ex)
    body = c.body(ex)
    assert body["questions"]["decided_by"]["criteria"] == TASKS["decided_by"].labels and body["model"] == "vega"
    (tmp_path / f"{c._key(body)}.json").write_text(json.dumps({"response": {"model": "vega", "answers": {
        "decided_by": {"type": "choice", "choice": "media call", "confidence": 0.81,
                       "probabilities": {"media call": 0.9, "certification": 0.1}}}}, "seconds": 0.3}))
    p = c.ask(ex)
    assert p.label == "media call" and p.confidence == 0.81 and p.system == "vega" and p.seconds == 0.3
