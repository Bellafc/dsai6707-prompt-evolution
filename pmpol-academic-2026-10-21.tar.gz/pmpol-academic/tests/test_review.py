from collections import Counter
from datetime import date

import pytest

from pmpol import review
from pmpol.kb import KnowledgeBase

YAML = """# hand-written
facts:
  - id: x.rule
    layer: L0
    subject: Somewhere
    predicate: decision_rule
    value: plurality
    source:
      title: t
      url: https://example.org/a
    admiralty: A2
    status: proposed
    recorded_at: 2026-10-04
  - id: x.base
    layer: L2
    subject: Somewhere
    predicate: base_rate
    value: 0.1
    source:
      title: t
      url: https://example.org/b
    admiralty: B2
    status: reviewed
    recorded_at: 2026-10-04
    derived_from: [x.rule]
"""


def _kb(tmp_path):
    (tmp_path / "f.yaml").write_text(YAML, encoding="utf-8")
    return KnowledgeBase.load(tmp_path)


def test_machines_and_proposers_cannot_review(tmp_path):
    kb = _kb(tmp_path)
    who = {"x.rule": "Ana", "x.base": "Claude"}
    for name in ("Claude", "pmpol reference --write-kb", "github-actions[bot]", "renovate bot"):
        assert review.is_machine(name)
        with pytest.raises(PermissionError):
            review.decide(kb, "x.rule", "approve", name, root=tmp_path, who=who)
    with pytest.raises(PermissionError, match="two-person"):
        review.decide(kb, "x.rule", "approve", "ana", root=tmp_path, who=who)
    assert not (tmp_path / "reviews.yaml").exists()


def test_approval_is_a_record_and_sets_the_status(tmp_path):
    kb = _kb(tmp_path)
    who = {"x.rule": "Ana", "x.base": "Claude"}
    r = review.decide(kb, "x.rule", "approve", "Ben", "quote checked", today=date(2026, 10, 5), root=tmp_path, who=who)
    assert r.hash == review.fact_hash(kb.facts["x.rule"])
    kb2 = KnowledgeBase.load(tmp_path)
    assert kb2.facts["x.rule"].status == "reviewed" and kb2.facts["x.base"].status == "reviewed"  # only x.rule changed
    st = review.state(kb2, review.load_reviews(tmp_path / "reviews.yaml"), who, Counter({"x.base": 3}))
    assert st.bucket(st.items["x.rule"]) == "reviewed" and st.bucket(st.items["x.base"]) == "legacy"
    assert st.errors == [] and [it.fact.id for it in st.queue()] == ["x.base"]
    assert st.items["x.rule"].dependents == 1


def test_a_change_after_review_makes_the_review_stale(tmp_path):
    kb = _kb(tmp_path)
    who = {"x.rule": "Ana"}
    review.decide(kb, "x.rule", "approve", "Ben", root=tmp_path, who=who)
    path = tmp_path / "f.yaml"
    path.write_text(path.read_text(encoding="utf-8").replace("value: plurality", "value: majority"), encoding="utf-8")
    st = review.state(KnowledgeBase.load(tmp_path), review.load_reviews(tmp_path / "reviews.yaml"), who)
    assert st.items["x.rule"].stale and st.queue()[0].fact.id == "x.rule"
    assert any("changed after its review" in e for e in st.errors)


def test_records_that_break_the_rule_are_errors_and_ignored(tmp_path):
    kb = _kb(tmp_path)
    h = review.fact_hash(kb.facts["x.rule"])
    recs = [review.Review("x.rule", h, "Claude", "approve", "2026-10-05"),
            review.Review("x.rule", h, "Ana", "approve", "2026-10-05"),
            review.Review("x.gone", h, "Ben", "approve", "2026-10-05")]
    st = review.state(kb, recs, {"x.rule": "Ana"})
    assert len(st.errors) == 3 and st.items["x.rule"].reviews == []
    assert st.bucket(st.items["x.rule"]) == "proposed"


def test_reject_keeps_the_fact_proposed_and_dispute_marks_it(tmp_path):
    kb = _kb(tmp_path)
    who = {"x.rule": "Ana", "x.base": "Ana"}
    review.decide(kb, "x.rule", "reject", "Ben", "no source quote", root=tmp_path, who=who)
    review.decide(kb, "x.base", "dispute", "Ben", root=tmp_path, who=who)
    kb2 = KnowledgeBase.load(tmp_path)
    assert kb2.facts["x.rule"].status == "proposed" and kb2.facts["x.base"].status == "disputed"
    st = review.state(kb2, review.load_reviews(tmp_path / "reviews.yaml"), who)
    assert st.bucket(st.items["x.rule"]) == "rejected" and st.queue() == []
    assert "審核佇列" in review.render(st, {}, "now")
