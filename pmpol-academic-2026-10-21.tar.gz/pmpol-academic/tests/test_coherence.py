from pmpol import coherence as C
from pmpol.models import Event, Market
from pmpol.track import CoherenceObs, PairResult, load_registry, summarize
from pmpol.universe.index import Universe


def test_projection_splits_the_disagreement_by_precision():
    imp = [C.from_relation("implies", ["a"], ["b"], "t")]
    r = C.project({"a": (0.6, 0.05), "b": (0.4, 0.05)}, imp)
    assert abs(r.q["a"] - 0.5) < 1e-6 and abs(r.q["b"] - 0.5) < 1e-6
    r = C.project({"a": (0.6, 0.01), "b": (0.4, 0.10)}, imp)  # the tight quote barely moves
    assert abs(r.q["a"] - 0.6) < 0.01 and r.q["b"] > 0.59 and r.z("b") > 1.5 and r.binding["b"] == ["t"]
    cons = [C.from_relation("equivalent", ["x", "y"], ["z"], "cover"), C.Constraint({"x": 1, "y": 1}, 1, False, "ex")]
    r = C.project({"x": (0.5, 0.02), "y": (0.4, 0.02), "z": (0.7, 0.02)}, cons)
    assert C._check(r, cons) < 1e-6 and abs(r.q["z"] - (0.7 + 0.2 / 3)) < 1e-4
    # a satisfied relation moves nothing; unpriced legs drop the constraint
    r = C.project({"a": (0.3, 0.05), "b": (0.6, 0.05)}, imp + [C.from_relation("implies", ["a"], ["c"], "t")])
    assert r.q == r.mid and len(r.components) == 1


def test_pipeline_helper_uses_quotes_and_exclusive_events():
    m = lambda k, bid, ask: Market("kalshi", k, "E", "q", k, bid=bid, ask=ask)  # noqa: E731
    u = Universe.build([Event("kalshi", "E", "t", mutually_exclusive=True,
                              markets=[m("a", 0.60, 0.62), m("b", 0.55, 0.57), m("wide", 0.1, 0.9)])])
    prices = C.prices_from(u, ["kalshi:a", "kalshi:b", "kalshi:wide"])
    assert set(prices) == {"kalshi:a", "kalshi:b"}  # a 80-point book carries no information
    (ex,) = C.exclusive_constraints(u, set(prices))
    r = C.project(prices, [ex])
    assert abs(r.q["kalshi:a"] + r.q["kalshi:b"] - 1) < 1e-6


def test_coherence_pull_claim_is_scored():
    claims = [c for c in load_registry() if c.id == "coherence_pull"]
    pr = PairResult("2026-10-05T00:00", "2026-10-05T06:00", 6.0, coherence=[
        CoherenceObs("a", 4.0, 0.10, 0.02), CoherenceObs("b", -3.5, -0.08, -0.08), CoherenceObs("c", 1.0, 0.01, 0.0)])
    d = summarize([pr] * 20, claims)["coherence_pull"]
    assert d["n"] == 40 and d["value"] == 0.5 and d["prospective"] == 40  # c is under 3 sigma
