from datetime import date

from pmpol import baseline as bl
from pmpol.models import Event, Market
from pmpol.propositions import INF, Span

# a rate that moves up 0.1 every month from 1990, so every k-month change is +0.1 k
CSV = "observation_date,UNRATE\n" + "\n".join(f"{1990 + i // 12}-{i % 12 + 1:02d}-01,{4.0 + 0.1 * i:.1f}"
                                               for i in range(24))


def test_published_figures_follow_bls_definitions():
    idx = {"2025-01": 100.0, "2025-02": 100.3, "2026-01": 102.9, "2026-02": 103.0}
    assert bl.derived(idx, "yoy") == {"2026-01": 2.9, "2026-02": 2.7}
    assert bl.derived(idx, "mom") == {"2025-02": 0.3, "2026-02": 0.1}
    assert bl.derived({"2026-01": 4.25}, "level") == {"2026-01": 4.2}
    assert bl.period_of("us_unemployment|2026-11") == "2026-11" and bl.period_of("us_real_gdp_qoq_saar|2027-Q2") is None


def test_outlook_adds_historical_changes_to_the_last_value(tmp_path):
    path = bl.fetch("UNRATE", cache=tmp_path, get=lambda u: CSV, today=date(2026, 10, 6))
    values = bl.derived(bl.monthly(path.read_text()), "level")
    o = bl.outlook("us_unemployment", "1992-02", values)  # last published 1991-12: two months ahead
    assert o.horizon == 2 and o.last_value == 6.3 and set(o.outcomes) == {6.5} and len(o.outcomes) == 22
    assert o.probability([Span(65, INF, True, False)]) == 1.0 and o.probability([Span(-INF, 65, False, False)]) == 0.0
    done = bl.outlook("us_unemployment", "1991-06", values)
    assert done.published and done.outcomes == [values["1991-06"]]


def test_baseline_proof_sets_each_interval_next_to_the_market(tmp_path):
    from pmpol.propositions import Prop, Var
    from pmpol.universe import pipeline
    from pmpol.universe.index import Universe

    bl.fetch("UNRATE", cache=tmp_path / "fundamentals", get=lambda u: CSV, today=date(2026, 10, 6))
    ev = Event("kalshi", "U", "Unemployment in February", markets=[
        Market("kalshi", f"U-{k}", "U", "q", f"Above {k}%", bid=0.40, ask=0.44, active=True) for k in ("6.4", "6.6")])
    u = Universe.build([ev])
    var = Var("indicator", "us_unemployment|1992-02", "pct, step 0.1")
    props = [Prop(var, "kalshi:U-6.4", ev.key, "r", spans=(Span(65, INF, True, False),)),
             Prop(var, "kalshi:U-6.6", ev.key, "r", spans=(Span(67, INF, True, False),))]
    (b,) = pipeline.baselines(u, props, tmp_path)
    assert b.outlook.horizon == 2 and abs(b.worst - 0.58) < 1e-9  # "above 6.6%": market 42%, history 0%
    p = pipeline.explain_baseline(b, "2026-10-06T00:00")
    assert p.grounded and p.check() == [] and "indicator_change_reference_class" in p.result["assumptions"]
    assert [r["historical"] for r in p.result["rows"]] == [1.0, 0.0]


def _sidra(rates: dict[str, float]) -> str:
    import json

    rows = [{"V": "Valor", "D3C": "Mês (Código)"}] + [{"V": f"{v:.2f}", "D3C": m.replace("-", "")}
                                                       for m, v in sorted(rates.items())]
    rows.append({"V": "...", "D3C": "202609"})  # not yet available
    return json.dumps(rows)


def test_ipca_12_month_rate_keeps_base_effects(tmp_path):
    # 2000-2024: every month 0.4% except September-December 0.1%; 2025 the same; 2026 known through August at 0.5%
    rates = {f"{y}-{m:02d}": (0.1 if m >= 9 else 0.4) for y in range(2000, 2026) for m in range(1, 13)}
    rates.update({f"2026-{m:02d}": 0.5 for m in range(1, 9)})
    path = bl.fetch("IPCA_MOM", cache=tmp_path, get=lambda u: _sidra(rates), today=date(2026, 10, 6))
    raw = bl.monthly(path.read_text())
    assert max(raw) == "2026-08" and path.suffix == ".json"
    twelve = bl.derived(raw, "compound12")
    assert twelve["2025-12"] == round(100 * (1.004 ** 8 * 1.001 ** 4 - 1), 2)
    o = bl.outlook("br_ipca_12m", "2026-12", raw)
    # eight known months fixed, four from the same months of each year 2000-2025: all equal here
    assert o.method == "calendar" and o.horizon == 4 and len(o.outcomes) == 26
    assert set(o.outcomes) == {round(100 * (1.005 ** 8 * 1.001 ** 4 - 1), 2)}
    assert o.last_value == round(100 * (1.005 ** 8 * 1.001 ** 4 - 1), 2)  # Sep-Dec 2025 + Jan-Aug 2026
    v = round(100 * o.outcomes[0])  # in 0.01 steps
    assert o.probability([Span(v, v + 1)]) == 1.0 and o.probability([Span(v + 1, INF)]) == 0.0
    done = bl.outlook("br_ipca_12m", "2025-12", raw)
    assert done.published and done.outcomes == [twelve["2025-12"]]

