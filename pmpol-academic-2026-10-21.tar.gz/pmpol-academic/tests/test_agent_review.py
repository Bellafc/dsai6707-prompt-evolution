from collections import Counter

from pmpol import agent_review as ar
from pmpol import review
from pmpol.kb import KnowledgeBase

YAML = """facts:
  - id: a.rule
    layer: L0
    subject: Somewhere
    predicate: decision_rule
    value: plurality
    source: {title: t, url: "https://example.org/a", quote: "most votes"}
    admiralty: A2
    status: proposed
    recorded_at: 2026-10-04
  - id: b.count
    layer: L1
    subject: Somewhere
    predicate: seats
    value: 100
    source: {title: t, url: "https://example.org/b"}
    admiralty: A1
    status: reviewed
    recorded_at: 2026-10-04
"""


def _kb(tmp_path):
    (tmp_path / "f.yaml").write_text(YAML, encoding="utf-8")
    return KnowledgeBase.load(tmp_path)


def _results(verdicts):
    return [{"role": role, "reviews": [{"fact": fid, "verdict": v, "reasons": f"{role} {v}", "evidence": ["u"]}
                                       for fid, v in rows.items()]} for role, rows in verdicts.items()]


def test_export_and_ingest_bind_verdicts_to_the_content(tmp_path):
    kb = _kb(tmp_path)
    exported = ar.export(kb)
    assert [e["id"] for e in exported] == ["a.rule", "b.count"] and exported[0]["hash"] == review.fact_hash(kb.facts["a.rule"])
    path = tmp_path / "agent_reviews.yaml"
    res = _results({"source": {"a.rule": "pass", "b.count": "fail", "x.gone": "pass"},
                    "consistency": {"a.rule": "pass", "b.count": "pass"}, "adversary": {"a.rule": "maybe"}})
    res.append({"role": "oracle", "reviews": []})
    n, problems = ar.ingest(res, exported, "run1", "2026-10-05T00:00", path)
    assert n == 4 and len(problems) == 3  # unknown fact, bad verdict, unknown role
    recs = ar.load(path)
    assert recs[0].reviewer == "pmpol agent source" and review.is_machine(recs[0].reviewer)
    assert KnowledgeBase.load(tmp_path).errors == []  # the record file does not disturb the knowledge base


def test_summary_states_side_by_side_and_staleness(tmp_path):
    kb = _kb(tmp_path)
    path = tmp_path / "agent_reviews.yaml"
    ar.ingest(_results({"source": {"a.rule": "pass", "b.count": "fail"}, "consistency": {"a.rule": "pass", "b.count": "pass"},
                        "adversary": {"a.rule": "pass", "b.count": "uncertain"}}), ar.export(kb), "r", "t", path)
    s = ar.summarize(kb, ar.load(path))
    assert s["a.rule"].state == "ready" and s["b.count"].state == "objection" and s["b.count"].split
    # a later run replaces the same role's verdict
    ar.ingest(_results({"source": {"b.count": "pass"}}), ar.export(kb), "r2", "t2", path)
    s = ar.summarize(kb, ar.load(path))
    assert s["b.count"].state == "partial" and not s["b.count"].split
    # the fact changes: earlier verdicts no longer count
    f = tmp_path / "f.yaml"
    f.write_text(f.read_text(encoding="utf-8").replace("value: plurality", "value: majority"), encoding="utf-8")
    kb2 = KnowledgeBase.load(tmp_path)
    s = ar.summarize(kb2, ar.load(path))
    assert s["a.rule"].state == "none" and s["a.rule"].stale == 3
    assert "預審" in ar.render(ar.summarize(kb, ar.load(path)), kb, "now")


def test_agents_never_approve_and_objections_lead_the_queue(tmp_path):
    (tmp_path / "f.yaml").write_text(YAML.replace("status: reviewed", "status: proposed"), encoding="utf-8")
    kb = KnowledgeBase.load(tmp_path)
    path = tmp_path / "agent_reviews.yaml"
    ar.ingest(_results({"source": {"a.rule": "pass", "b.count": "fail"}}), ar.export(kb), "r", "t", path)
    st = review.state(kb, [], {"a.rule": "Ana", "b.count": "Ana"}, Counter({"a.rule": 50}))
    assert [it.fact.id for it in st.queue()] == ["a.rule", "b.count"]  # by citations
    st.agents = ar.summarize(kb, ar.load(path))
    assert st.counts()["reviewed"] == 0  # machine verdicts are never approvals
    assert [it.fact.id for it in st.queue()] == ["b.count", "a.rule"]  # an objection comes first
    assert "有異議" in review.render(st, {}, "now")
