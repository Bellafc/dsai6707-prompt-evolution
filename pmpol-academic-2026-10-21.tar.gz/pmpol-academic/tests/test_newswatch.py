from datetime import datetime, timezone

from pmpol import newswatch, requirements

RSS = """<rss><channel>
<item><title>Tanker attacked near Hormuz - Wire</title><link>https://example.org/a</link>
<pubDate>Mon, 05 Oct 2026 10:00:00 GMT</pubDate><source url="https://example.org">Wire</source></item>
<item><title>Old story - Wire</title><link>https://example.org/b</link>
<pubDate>Mon, 21 Sep 2026 10:00:00 GMT</pubDate><source url="https://example.org">Wire</source></item>
</channel></rss>"""


def test_questions_with_a_news_query_get_a_news_line(tmp_path):
    def refuse(params):  # GDELT refusing (429) falls back to Google News; no retry
        raise RuntimeError("429 Too Many Requests")

    reqs = [r for r in requirements.load() if r.id in ("hormuz", "us_house_2026")]
    rows = newswatch.watch(reqs, now=datetime(2026, 10, 6, tzinfo=timezone.utc), fetch=refuse,
                           rss_fetch=lambda params: RSS, cache=tmp_path / "cache")
    assert [r.id for r, _ in rows] == ["hormuz", "hormuz"]  # only questions with a news query: English and Persian
    req, res = rows[0]
    assert res.count == 1 and res.source == "google_news"  # the old story is outside the 72-hour window
    out = tmp_path / "news.json"
    assert newswatch.export(rows, out) == 2
    p = newswatch.proof(req, res)
    assert p.grounded and p.check() == [] and p.steps[0].layer == "L1" and "Hormuz" in p.title
    ev = requirements.gather(_data_with(tmp_path, out))
    assert any(line == "news" for line, *_ in ev.items)


def _data_with(tmp_path, news_json):
    d = tmp_path / "data"
    d.mkdir()
    (d / "news.json").write_text(news_json.read_text(encoding="utf-8"), encoding="utf-8")
    return d


def test_relevance_and_local_editions(tmp_path):
    from pmpol.movers.news import local_search, relevance

    assert relevance("Fresh attacks on tankers in Strait of Hormuz", "Strait of Hormuz shipping") == 2 / 3
    assert relevance("Home heating costs soar", "Strait of Hormuz shipping") == 0.0
    assert relevance("中共間諜監控 作為台海衝突談判籌碼", "台海 共軍") == 0.5  # substring test for CJK
    seen = {}

    def rss(params):
        seen.update(params)
        return RSS.replace("Tanker attacked near Hormuz", "台海 共軍 動態")

    res = local_search("台海 共軍", "zh-TW", "TW", "2026-10-03T00:00:00+00:00", "2026-10-06T00:00:00+00:00",
                       cache=tmp_path, rss_fetch=rss, edition="zh-Hant")
    assert seen["hl"] == "zh-TW" and seen["ceid"] == "TW:zh-Hant" and res.articles[0]["language"] == "zh-TW"
    req = next(r for r in requirements.load() if r.id == "taiwan_strait")
    p = newswatch.proof(req, res)
    assert p.result["on_topic"] == 1 and p.result["language"] == "zh-TW" and "相關性 100%" in p.steps[0].text
