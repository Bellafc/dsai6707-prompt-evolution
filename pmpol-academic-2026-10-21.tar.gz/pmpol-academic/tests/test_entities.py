import json


from pmpol.entities import sources
from pmpol.entities.graph import EntityIndex, build_entity_graph, to_ftm
from pmpol.entities.sources import Entity, name_variants
from pmpol.models import Event, Market
from pmpol.universe.index import Universe


def person(eid, name, prominent=True, **kw):
    return Entity(id=eid, kind="person", name=name, aliases=name_variants(name), prominent=prominent, **kw)


def index(*ents, batch="test"):
    return EntityIndex.build([(batch, list(ents))])


US = dict(us_context=True)


def ids(mentions):
    return {m.entity for m in mentions}


# --- names --------------------------------------------------------------------------

def test_name_variants():
    assert name_variants("Daniel J. Sullivan Jr.") >= {"daniel j sullivan", "daniel sullivan"}
    assert "jd vance" in name_variants("J.D. Vance")
    assert name_variants("Christian Menefee (D)") == {"christian menefee"}


# --- merging ------------------------------------------------------------------------

def test_merge_by_wikidata_and_by_name_variant():
    idx = EntityIndex.build([
        ("plum", [person("os:1", "Peter Hegseth", country="us", positions=["Secretary of War"])]),
        ("markets", [person("cand:pete", "Pete Hegseth", prominent=False, country="us")]),
        ("congress", [person("Q1", "Maria Cantwell", country="us", state="WA", wikidata="Q1")]),
        ("other", [person("os:2", "Maria Cantwell", country="us", wikidata="Q1")]),
    ])
    assert len(idx.entities) == 2
    heg = idx.entities["os:1"]
    assert "pete hegseth" in heg.aliases and heg.positions == ["Secretary of War"]


def test_no_merge_across_states():
    idx = index(person("a", "John Smith", state="TX", country="us"), person("b", "John Smith", state="OH", country="us"))
    assert len(idx.entities) == 2


# --- linking ------------------------------------------------------------------------

def test_full_name_and_prominent_surname():
    idx = index(person("heg", "Pete Hegseth", country="us"), person("talarico", "James Talarico", prominent=False,
                                                                    country="us", state="TX"))
    assert ids(idx.link_text("Hegseth out as Secretary of Defense by...?", "title", **US)) == {"heg"}
    assert ids(idx.link_text("James Talarico", "outcome", **US)) == {"talarico"}


def test_surname_rules_block_common_false_positives():
    idx = index(person("jj", "John James", country="us", state="MI"),
                person("kor", "Sultan Korean", country="xx"),
                person("rocha", "Paulo Rocha", country="br"))
    # "James" is a first name here, "Korean" a demonym, "Ruben Rocha" someone else.
    assert idx.link_text("Will James Talarico win?", "title", **US) == []
    assert idx.link_text("Xi meets with Korean leader by...?", "title", us_context=False) == []
    assert idx.link_text("Sinaloa Gov. Ruben Rocha extradited?", "title", us_context=False) == []


def test_foreign_people_need_foreign_context_for_surname_links():
    idx = index(person("greene", "Chet Greene", country="ag"))
    assert idx.link_text("Greene", "outcome", **US) == []
    assert ids(idx.link_text("Greene resigns?", "title", us_context=False)) == {"greene"}


def test_race_and_state_disambiguate_namesakes():
    troy = person("troy", "Troy Nehls", country="us", state="TX", district="TX-22")
    trever = person("trever", "Trever Nehls", prominent=False, country="us", state="TX")
    trever.races.add("race:tx22")
    idx = index(troy, trever)
    assert ids(idx.link_text("Nehls, 3+ pts", "outcome", us_context=True, state="TX", race="race:tx22")) == {"trever"}
    assert idx.link_text("Nehls, 3+ pts", "outcome", us_context=True, state="TX") == []


# --- sources ------------------------------------------------------------------------

def test_congress_loader(monkeypatch):
    raw = [{"id": {"bioguide": "B1", "wikidata": "Q9"}, "name": {"first": "Frank", "last": "Mrvan",
                                                               "official_full": "Frank J. Mrvan"},
            "terms": [{"type": "rep", "state": "IN", "district": 1, "party": "Democrat"}]}]
    monkeypatch.setattr(sources, "_cached", lambda name, url, max_age_h=24: json.dumps(raw).encode())
    (e,) = sources.congress()
    assert (e.id, e.district, e.party, e.prominent) == ("Q9", "IN-01", "D", True)
    assert "frank mrvan" in e.aliases


def test_opensanctions_loader_keeps_current_positions(monkeypatch):
    rec = {"id": "x1", "schema": "Person", "caption": "Salim Salih BIN BURAYK",
           "properties": {"name": ["Salim Salih BIN BURAYK"], "citizenship": ["ye"], "positionOccupancies": [
               {"properties": {"status": ["current"], "post": [{"caption": "Prime Minister", "properties": {}}]}},
               {"properties": {"status": ["ended"], "post": [{"caption": "Minister of Finance", "properties": {}}]}},
           ]}}
    monkeypatch.setattr(sources, "_cached", lambda name, url, max_age_h=24: json.dumps(rec).encode())
    (e,) = sources.opensanctions("us_cia_world_leaders")
    assert e.name == "Salim Salih Bin Burayk" and e.positions == ["Prime Minister"] and e.country == "ye"


def _event(venue, eid, title, outcomes):
    ms = [Market(venue=venue, market_id=f"{eid}-{i}", event_id=eid, question=f"Will {o} win?", outcome=o,
                 bid=0.4, ask=0.5, close_time="2026-11-04T00:00:00Z") for i, o in enumerate(outcomes)]
    return Event(venue, eid, title, mutually_exclusive=True, markets=ms)


def test_market_candidates_skip_offices_and_places():
    u = Universe.build([
        _event("polymarket", "tx-18-house-election-winner", "TX-18 House Election Winner",
               ["Christian Menefee (D)", "Ronald Whitfield (R)"]),
        _event("kalshi", "KXGAOUTRIGHT-26", "Georgia: Which elections will be won outright?",
               ["Attorney General", "Secretary of State", "New Hampshire"]),
    ])
    names = {e.name for e in sources.market_candidates(u)}
    assert names == {"Christian Menefee", "Ronald Whitfield"}


# --- graph and FtM export -------------------------------------------------------------

def test_graph_and_ftm_export():
    u = Universe.build([_event("polymarket", "hegseth-out", "Hegseth out as Secretary of Defense by...?", ["Yes"])])
    heg = person("heg", "Pete Hegseth", country="us", party="R", positions=["Secretary of War"])
    eg = build_entity_graph(u, index(heg))
    assert ids(eg.mentions["polymarket:hegseth-out"]) == {"heg"}
    recs = list(to_ftm(eg))
    schemas = {r["schema"] for r in recs}
    assert schemas == {"Person", "Position", "Occupancy", "Organization", "Membership"}
    occ = next(r for r in recs if r["schema"] == "Occupancy")
    assert occ["properties"]["holder"] == ["heg"]
