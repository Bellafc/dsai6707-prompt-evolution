from datetime import date

from pmpol import gdp_realtime as gr


def _levels(qs, growth):
    """Levels whose annualised growth rounds to the given rates."""
    lv, x = {}, 1000.0
    for q, g in zip(qs, growth):
        x *= (1 + g / 100) ** 0.25
        lv[q] = round(x, 4)
    return lv


def test_first_print_is_the_earliest_vintage_holding_the_quarter():
    qs = gr.quarters("2021Q4", "2022Q3")
    assert qs == ["2021Q4", "2022Q1", "2022Q2", "2022Q3"]
    # first prints: 2022Q1 -1.4, 2022Q2 -0.9; revised later to -1.0 and +0.6
    first = _levels(qs, [7.0, -1.4, -0.9, 2.6])
    later = _levels(qs, [7.0, -1.0, 0.6, 2.7])
    calls = []

    def get(url):
        calls.append(url)
        dates = url.split("vintage_date=")[1].split(",")
        head = ["observation_date"] + [f"GDPC1_{d.replace('-', '')}" for d in dates]
        rows = []
        for q in qs:
            d_obs = f"{q[:4]}-{(int(q[-1]) - 1) * 3 + 1:02d}-01"
            row = [d_obs]
            for d in dates:
                published = gr.quarter_end(q) + __import__("datetime").timedelta(days=28) <= date.fromisoformat(d)
                src = later if d >= "2023-01-01" else first
                row.append(str(src[q]) if published else "")
            rows.append(row)
        return "\n".join(",".join(r) for r in [head] + rows)

    import tempfile
    from pathlib import Path

    fp = gr.first_prints(qs[1:], date(2026, 10, 7), cache=Path(tempfile.mkdtemp()), get=get, pause=0)
    assert fp["2022Q1"][0] == -1.4 and fp["2022Q2"][0] == -0.9 and fp["2022Q1"][1] == "2022-05-05"
    rec = gr.record(fp, [("2022Q1", -1.0), ("2022Q2", 0.6), ("2022Q3", 2.7)])
    assert rec.pairs_first == ["2022Q2"] and rec.pairs_latest == []
    assert [f["quarter"] for f in rec.sign_flips] == ["2022Q2"]
    assert "2022Q2" in gr.render(rec) and "us.gdp.first_print_record" in gr.kb_yaml(rec, date(2026, 10, 7))


def test_quarter_helpers():
    assert gr.previous("2022Q1") == "2021Q4" and gr.quarter_end("2022Q1") == date(2022, 3, 31)
    assert gr.quarter_end("2022Q4") == date(2022, 12, 31)
