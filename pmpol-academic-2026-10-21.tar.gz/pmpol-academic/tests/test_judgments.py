from pmpol import store
from pmpol.judgments import changes, record


def _proof(p, venue_quote, conf="moderate"):
    return {"conclusion": f"共識機率 {100 * p:.0f}%", "analytic_confidence": conf, "result": {"pooled": p},
            "steps": [{"layer": "L4", "id": "q:kalshi", "text": f"K Yes {venue_quote}"},
                      {"layer": "L2", "id": "cal", "text": "slope 1.13"},
                      {"layer": "L5", "id": "pool", "text": "pooled"}]}


def test_changes_name_the_inputs_that_moved(tmp_path):
    conn = store.connect(tmp_path / "db.sqlite")
    assert record(conn, [("consensus:a", "consensus", "TX Senate", _proof(0.40, "40%"))], "2026-10-03T13:29") == 1
    # a small move is logged without inputs; it is not a change
    assert record(conn, [("consensus:a", "consensus", "TX Senate", _proof(0.41, "41%"))], "2026-10-04T06:00") == 0
    assert changes(conn) == []
    assert record(conn, [("consensus:a", "consensus", "TX Senate", _proof(0.47, "47%"))], "2026-10-04T12:15") == 1
    (c,) = changes(conn)
    assert (c.old_ts, round(c.delta, 2)) == ("2026-10-03T13:29", 0.07)
    assert c.changed == [("q:kalshi", "K Yes 40%", "K Yes 47%")]  # L5 steps are not inputs
    record(conn, [("consensus:a", "consensus", "TX Senate", _proof(0.47, "47%", "low"))], "2026-10-04T18:00")
    assert changes(conn)[0].new_confidence == "low"  # a confidence change is a change too
