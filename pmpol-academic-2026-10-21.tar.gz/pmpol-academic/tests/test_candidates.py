from pmpol.entities import candidates as cand
from pmpol.models import Event, Market

WIKI = """== District 34 ==
=== General election ===
{{Election box begin no change | title = 2026 Texas's 34th congressional district election results }}
{{Election box candidate with party link no change
| candidate = [[Vicente Gonzalez]] (incumbent)
| party = Democratic Party (United States)
}}
{{Election box candidate with party link no change
| candidate = [[Mayra Flores]]
| party = Republican Party (United States)
}}
{{Election box end}}
== District 35 ==
=== Republican primary ===
==== Results ====
{{Election box winning candidate with party link no change
| party = Republican Party (United States)
| candidate = [[John Lujan]]
}}
=== General election ===
==== Results ====
{{Election box candidate with party link no change
|candidate = Johnny Garcia
|party = Democratic Party (United States)
}}
{{Election box candidate with party link no change
| candidate = Carlos De La Cruz
| party = Republican Party (United States)
}}
== District 36 ==
"""

GOVERNOR = """== General election ==
=== Results ===
{{Election box candidate with party link
|party = Democratic Party (United States)
|candidate = {{ubl|[[Katie Hobbs]] (incumbent)|[[John Giles (American politician)|John Giles]]}}
}}
{{Election box candidate with party link
|party = Republican Party (United States)
|candidate = {{ubl|[[Andy Biggs]]|[[Sine Kerr]]}}
}}
{{Election box candidate with party link
|party = Arizona Green Party
|candidate = {{ubl|Risa Lombardo|Lisa Castillo}}
}}
"""


def test_general_election_candidates_are_read_per_district_and_not_from_the_primary():
    race = "United States|TX-35|house|2026|general"
    assert cand.page_for(race) == ("2026_United_States_House_of_Representatives_elections_in_Texas", "District 35")
    got = cand.parse(WIKI, race, "p", "District 35")
    assert [(c.name, c.party) for c in got] == [("Johnny Garcia", "D"), ("Carlos De La Cruz", "R")]  # not Lujan
    assert [(c.name, c.party) for c in cand.parse(WIKI, "x", "p", "District 34")] == [
        ("Vicente Gonzalez", "D"), ("Mayra Flores", "R")]
    gov = cand.parse(GOVERNOR, "x", "p")  # a ticket: the first name is the governor candidate
    assert [(c.name, c.party) for c in gov] == [("Katie Hobbs", "D"), ("Andy Biggs", "R"),
                                                ("Risa Lombardo", "Arizona Green Party")]
    assert cand.page_for("United States|AK-AL|house|2026|general")[0].endswith("_election_in_Alaska")
    assert cand.page_for("United States|GA|senate|2026|general") == ("2026_United_States_Senate_election_in_Georgia", "")


def test_fetch_stops_at_a_rate_limit_and_keeps_what_it_has(tmp_path, monkeypatch):
    monkeypatch.setattr(cand, "DATA", tmp_path)

    class R:
        def __init__(self, code, text=""):
            self.status_code, self.text = code, text
    calls = []

    def get(url):
        calls.append(url)
        return R(200, WIKI) if len(calls) == 1 else R(403)
    got = cand.fetch(["A", "B", "C"], pause=0, get=get)
    assert list(got) == ["A"] and len(calls) == 2  # a refusal stops the run: no requests for B and C


def _race(venue, eid, rows):
    title = "TX-35 House Election Winner 2026"
    return Event(venue, eid, title, mutually_exclusive=True, markets=[
        Market(venue, f"{eid}-{i}", eid, title, label, bid=b, ask=a, close_time="2026-11-04T00:00:00Z", fee_rate=0.02)
        for i, (label, b, a) in enumerate(rows)])


def _run(listed):
    from pmpol.kb import KnowledgeBase
    from pmpol.propositions import relations as onto_rel
    from pmpol.universe.index import Universe

    u = Universe.build([_race("gemini", "G", [("Carlos De La Cruz Jr.", 0.39, 0.42), ("Johnny Garcia", 0.5, 0.55)]),
                        _race("kalshi", "K", [("Carlos De La Cruz (R)", 0.50, 0.52), ("Johnny Garcia (D)", 0.4, 0.45)]),
                        _race("polymarket", "P", [("Republican Party", 0.58, 0.60), ("Democratic Party", 0.38, 0.4)])])
    race = "United States|TX-35|house|2026|general"
    cands = {race: [cand.Candidate(race, n, p, "p", "District 35", "2026-10-04T11:00") for n, p in listed]}
    rels = onto_rel.build(u, kb=KnowledgeBase.load(), candidates=cands if listed else {}).relations
    return [r for r in rels if r.template.endswith(":bridge_person_party")]


def test_the_person_party_bridge_cites_the_l1_list_or_falls_back_to_the_assumption():
    from pmpol.propositions.derive import person_party_conflicts  # noqa: F401  (public for the reports)

    listed = _run([("Johnny Garcia", "D"), ("Carlos De La Cruz", "R")])
    assert listed and all(r.grounds == ("data:candidates:United States|TX-35|house|2026|general",) for r in listed)
    assumed = _run([])
    assert assumed and all(r.grounds == ("assumption:labels_identify_party_candidate",) for r in assumed)
    # the list contradicts the labels: no bridge
    assert not [r for r in _run([("Johnny Garcia", "D"), ("Carlos De La Cruz", "D")])
                if "gemini:G-0" in r.lhs + r.rhs]
    assert not [r for r in _run([("Johnny Garcia", "D"), ("Mayra Flores", "R")]) if "gemini:G-0" in r.lhs + r.rhs]
    two = _run([("Johnny Garcia", "D"), ("Carlos De La Cruz", "R"), ("Someone Else", "R")])  # top-two style
    assert not [r for r in two if "gemini:G-0" in r.lhs + r.rhs]


def test_same_person_within_a_race():
    assert cand.same_person("Carlos De La Cruz Jr.", "Carlos De La Cruz")
    assert not cand.same_person("Donald Trump Jr.", "Donald Trump Sr.")
    assert not cand.same_person("Daniel J. Sullivan", "Daniel S. Sullivan")
    assert not cand.same_person("Johnny Garcia", "Johnny Gonzalez")
