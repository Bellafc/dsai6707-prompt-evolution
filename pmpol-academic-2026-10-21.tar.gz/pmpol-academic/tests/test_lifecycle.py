from pmpol import store
from pmpol.models import Signal
from pmpol.track.lifecycle import lifecycle


def test_open_closed_and_reopened_signals_from_the_stored_snapshots(tmp_path):
    conn = store.connect(tmp_path / "db.sqlite")
    snaps = {"a": ["x", "y", "z"], "b": ["x", "z"], "c": ["x", "y"]}  # y: gone in b, back in c (reopened); z closes
    times = {"a": "2026-10-03T00:00+00:00", "b": "2026-10-03T06:00+00:00", "c": "2026-10-03T12:00+00:00"}
    for snap, ids in snaps.items():
        store.save_signals(conn, [Signal("relations", "k", i, 0.05, {"id": i}) for i in ids], observed_at=times[snap])
    lc = lifecycle(conn)
    assert (lc.open, lc.closed, lc.reopened) == (2, 1, 1)
    assert lc.median_open_hours == 12.0 and lc.median_closed_hours == 6.0
