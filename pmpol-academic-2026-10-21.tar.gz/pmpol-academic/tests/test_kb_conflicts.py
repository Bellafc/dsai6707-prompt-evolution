from pmpol.kb import KnowledgeBase
from pmpol.proof import Proof
from pmpol.universe.explain import _fact_step

FACT = """  - id: {id}
    layer: L1
    subject: United Kingdom CPI
    predicate: inflation_rate_2026_08
    value: {value}
    source: {{title: {src}, url: https://example.org/{id}}}
    admiralty: B2
    status: {status}
    recorded_at: 2026-10-04
{extra}"""


def _kb(tmp_path, *facts):
    (tmp_path / "f.yaml").write_text("facts:\n" + "".join(FACT.format(extra="", **f) for f in facts))
    return KnowledgeBase.load(tmp_path)


def test_conflicting_sources_must_both_be_marked_disputed(tmp_path):
    kb = _kb(tmp_path, dict(id="uk.cpi.ons", value=3.1, src="ONS", status="reviewed"),
             dict(id="uk.cpi.oecd", value=3.3, src="OECD", status="proposed"))
    assert [f.id for f in kb.conflicts()[0]] == ["uk.cpi.oecd", "uk.cpi.ons"]
    assert any("must all be marked disputed" in e for e in kb.errors)


def test_disputed_conflicts_are_shown_side_by_side_in_proofs(tmp_path):
    kb = _kb(tmp_path, dict(id="uk.cpi.ons", value=3.1, src="ONS", status="disputed"),
             dict(id="uk.cpi.oecd", value=3.3, src="OECD", status="disputed"))
    assert kb.errors == [] and [f.id for f in kb.rivals("uk.cpi.ons")] == ["uk.cpi.oecd"]
    p = Proof("t", "c")
    _fact_step(p, kb.facts["uk.cpi.ons"], kb)
    assert p.result["conflicting_facts"] == ["uk.cpi.oecd"] and any("3.3" in c and "OECD" in c for c in p.caveats)


def test_same_value_or_different_periods_is_no_conflict(tmp_path):
    kb = _kb(tmp_path, dict(id="a", value=3.1, src="ONS", status="reviewed"),
             dict(id="b", value=3.1, src="OECD", status="reviewed"))
    assert kb.conflicts() == []
    (tmp_path / "f.yaml").write_text("facts:\n" + FACT.format(
        id="a", value=1, src="s", status="reviewed", extra="    valid_to: 2025-01-19\n") + FACT.format(
        id="b", value=2, src="s", status="reviewed", extra="    valid_from: 2025-01-20\n"))
    assert KnowledgeBase.load(tmp_path).conflicts() == []  # one office holder after another
