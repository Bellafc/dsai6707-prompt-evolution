export const meta = {
  name: 'kb-review',
  description: 'Multi-agent pre-review of knowledge-base facts: source, consistency and adversary roles, blind to each other',
  whenToUse: 'After `pmpol review agents-export`; record the result with `pmpol review agents-ingest`',
  phases: [
    { title: 'Review', detail: 'three independent roles over batches of facts' },
    { title: 'Fill gaps', detail: 'one follow-up per batch for facts an agent skipped' },
  ],
}

// args: { ids: [fact ids], batch: 40, facts: "data/agent_review/facts.json", today: "YYYY-MM-DD" }
const IDS = args.ids
const BATCH = args.batch || 40
const FACTS = args.facts || 'data/agent_review/facts.json'
const TODAY = args.today

const SCHEMA = {
  type: 'object',
  properties: {
    reviews: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          fact: { type: 'string' },
          verdict: { type: 'string', enum: ['pass', 'fail', 'uncertain'] },
          reasons: { type: 'string' },
          evidence: { type: 'array', items: { type: 'string' } },
          fix: { type: 'string' },
        },
        required: ['fact', 'verdict', 'reasons'],
      },
    },
  },
  required: ['reviews'],
}

const COMMON = `You are one of three independent reviewers of facts in this repository's knowledge base (kb/). The
other reviewers check the same facts from other angles; you will not see their work and they will not see yours.
Your verdicts do NOT approve anything: a person signs off later (two-person rule). Today is ${TODAY}.

The facts are in ${FACTS} (JSON list). Each has id, layer (L0 institutional rule, L1 current fact, L2 base rate,
L3 expert consensus), subject, predicate, value, source {title, url, quote, license}, admiralty grade, status,
recorded_at, valid_from/valid_to, derived_from, note, file, and cached_source: a local copy of the source page when
one exists (read it first; it is what an earlier verification fetched).

Rules:
- Read-only: do not edit, create or delete any file inside the repository (use /tmp for scratch work).
- Network: use curl or WebFetch with the User-Agent "pmpol/0.1 (https://github.com/bellafc/polymarket_politics; research, read-only)".
  If a site refuses (403, 429, robot policy), do not retry in a loop and do not disguise the client: mark what you
  could not check as uncertain. Wikipedia and some government sites refuse cloud hosts.
- Never put any personal email address or other personal data in a request.
- Precision first: "fail" needs specific evidence that the fact is wrong, unsupported, misquoted, out of date or
  misclassified; if you could not check, say "uncertain", never guess "pass".
- Write "reasons" and "fix" in Traditional Chinese, short and concrete (what you checked, what you found). Put the
  URLs or file paths you relied on in "evidence". "fix" is an optional suggested correction.
- Return exactly one review per fact id you were given.`

const ROLES = {
  source: `ROLE: source checker. For each fact: does the source exist; does the quote appear in it (whitespace and
case aside); and does the source actually support the VALUE, the subject and the validity dates (a quote that is
present but does not establish the value is a fail)? Is the licence stated where needed, and is the Admiralty grade
plausible (A = official/primary, B = reliable secondary, ...)? For facts computed by this system (derived_from, or
a source pointing at pmpol code: calibration, consensus correlation, House history), check the value against the
inputs and reports in the repository (reports/*_calibration.md, reports/*_family_correlation.md, data/reference/*.html,
kb/L1/us_house_history.yaml) instead of the web.`,
  consistency: `ROLE: consistency checker. Read ALL the facts in the file (you are given the ids to judge, but compare
against everything). For each fact you judge: is the layer right (an institutional rule is L0, a holder or a date is
L1, a historical frequency is L2, a judgment or framework is L3)? Are valid_from/valid_to coherent and is the fact
still true as of ${TODAY} (an L1 fact past its valid_to, or describing an office holder or date that has since changed,
fails)? Do its derived_from inputs exist and actually imply it? Does it conflict with another fact on the same subject
and predicate, and if so are both marked disputed? Is the predicate/value shape sensible? You may use the network to
check whether an L1 fact is still current.`,
  adversary: `ROLE: adversary. Assume each fact is wrong and try to prove it: look for a newer law or amendment, a
changed office holder or schedule, a later data release, a better (more primary) source that says something
different, or a misreading of the cited source. Use independent sources, not only the cited one. Only a concrete
counter-source makes a "fail"; if your attempt to refute it found nothing, "pass" with what you tried; if you could
not search, "uncertain".`,
}

function chunks(xs, n) {
  const out = []
  for (let i = 0; i < xs.length; i += n) out.push(xs.slice(i, i + n))
  return out
}

const tasks = []
for (const role of ['source', 'adversary']) {
  chunks(IDS, BATCH).forEach((ids, i) => tasks.push({ role, ids, label: `${role}:${i + 1}` }))
}
tasks.push({ role: 'consistency', ids: IDS, label: 'consistency' })
log(`${IDS.length} facts, ${tasks.length} reviewer agents (source and adversary in batches of ${BATCH}, one consistency agent)`)

const prompt = (t, ids) => `${COMMON}\n\n${ROLES[t.role]}\n\nJudge these ${ids.length} fact ids:\n${ids.join('\n')}`

const results = await pipeline(
  tasks,
  t => agent(prompt(t, t.ids), { label: t.label, phase: 'Review', schema: SCHEMA }),
  async (res, t) => {
    const got = new Set((res ? res.reviews : []).map(r => r.fact))
    const missing = t.ids.filter(id => !got.has(id))
    let reviews = (res ? res.reviews : []).filter(r => t.ids.includes(r.fact))
    if (missing.length) {
      log(`${t.label}: ${missing.length} facts without a verdict, one follow-up`)
      const more = await agent(prompt(t, missing), { label: `${t.label}:gaps`, phase: 'Fill gaps', schema: SCHEMA })
      reviews = reviews.concat((more ? more.reviews : []).filter(r => missing.includes(r.fact)))
      const still = missing.filter(id => !reviews.some(r => r.fact === id))
      if (still.length) log(`${t.label}: still no verdict for ${still.join(', ')}`)
    }
    return { role: t.role, label: t.label, reviews }
  },
)

const out = results.filter(Boolean)
const tally = {}
for (const r of out) for (const v of r.reviews) tally[`${r.role}:${v.verdict}`] = (tally[`${r.role}:${v.verdict}`] || 0) + 1
log(JSON.stringify(tally))
return out
