# 分類器研究的人工標註：每行 {id, label, annotator, task, note, at}；只存市場代號和標籤，不存平台文字（Kalshi 條款不允許重新散布）。
