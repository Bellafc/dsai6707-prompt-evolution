# 學術用途的匯出（2026-10-21，來源 commit a9b0fef）

這份樹是 `polymarket_politics` 的共用地基加上分類器研究（Alex 的 MPhil），由 `scripts/export_academic.py` 產生。
**不包含**團隊交易的部分：組合與稅後篩選（`pmpol.arb`、`config/tax_us.toml`、`kb/L0/us_tax.yaml`、
`docs/CERTAINTY_STRATEGY.md`）、各期報告（只留分類器的）、自家主機的部署、以及所有平台文字的快取（`data/`）。

## 資料怎麼重建

平台文字不能跟著程式散布（Kalshi 的資料條款不允許重新散布彙編資料），所以資料集要從快照重建：

```bash
pip install -e ".[dev]" && pytest                      # 離線測試
pmpol universe                                         # 抓一個快照到 data/snapshots/（或從團隊拿 universe_20261014T0042Z.json.gz）
pmpol classify export --snapshot-in data/snapshots/<快照>
pmpol classify sample --n 300                          # 固定種子：同一個快照會抽出同一批 id
```

金標準樣本的 id 在 `annotations/classify/*.sample_ids.txt`（annotations/classify/candidate.sample_ids.txt (308 ids); annotations/classify/decided_by.sample_ids.txt (359 ids); annotations/classify/office.sample_ids.txt (502 ids); annotations/classify/runoff.sample_ids.txt (314 ids)），用來核對抽樣結果一致。
標註檔（`annotations/classify/<task>.<annotator>.jsonl`）只存 id 和標籤，可以進版控。

## 授權

程式的授權由團隊決定後再加 `LICENSE`（建議 Apache-2.0，和 ollajev、Vega 一致）。各資料來源的授權見 README「資料來源與授權」。

## 規則

`CLAUDE.md` 的原則照舊：只做研究、不下單；分類器的輸出是 L5 提議，不能核准事實；每個預測記模型和 commit；測試離線。
