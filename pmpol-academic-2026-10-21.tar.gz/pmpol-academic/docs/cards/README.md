# 模型卡與資料說明書

每個引擎一張**模型卡**（格式參考 Mitchell 等 2019，arXiv:1810.03993），每個資料集一份**資料說明書**（參考 Gebru 等，arXiv:1803.09010）。目的：讓讀者不看程式碼也知道每個輸出「是什麼、怎麼來、能用在哪、不能用在哪、目前準不準」。

| 檔案 | 對象 |
|---|---|
| [`consistency.md`](consistency.md) | 一致性引擎（關係模板、違反、跨平台價差） |
| [`consensus.md`](consensus.md) | 跨平台共識 |
| [`movers.md`](movers.md) | 價格異動與沉默異動線索 |
| [`settlement.md`](settlement.md) | 結算資料檢查（市場的結算來源是公開資料時） |
| [`macro_regimes.md`](macro_regimes.md) | 總經結構化判斷 |
| [`datasets.md`](datasets.md) | 資料說明書：快照、已結算市場、知識庫、總經觀測 |

每張卡最上面的 YAML 區塊給程式讀（之後查看器會顯示）；「目前成績」一節的數字來自 `pmpol track` 和 `pmpol truth calibrate`，更新時一起改。
