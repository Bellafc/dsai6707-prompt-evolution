# 知識庫（`kb/`）：大樓的地基

這裡放 L0–L3 的事實，每一筆都人工整理、透過 Git 審核。L4（市場觀測）和 L5（系統推論）不放這裡。分層的定義見專案首頁 README 的「團隊基本共識：知識分層」。

```
kb/
  L0/<國家>.yaml       制度規則：憲法、法律（us, cn, tw, il, uk, ru, ir, br）
  L1/current_2026.yaml 現況事實：誰在任、選舉日期、席次組成
  L2/macro_base_rates.yaml   歷史基準率：美林時鐘 1973–2004、NBER 衰退日期
  L3/macro_frameworks.yaml   框架與慣例：薩姆規則、紐約聯儲 probit、OECD 景氣階段、美林時鐘、康波各家分期（並列，標為有爭議）
```

## 一筆事實長什麼樣子

```yaml
  - id: us.senate.vp_tiebreak          # 國家.主題.項目，全域唯一
    layer: L0
    subject: United States Senate
    predicate: tie_broken_by
    value: Vice President               # 可以是數字、字串、日期、字典
    valid_from:                         # 在真實世界從何時開始為真（可省略）
    valid_to:                           # 何時失效（省略代表仍有效）
    source:
      title: U.S. Constitution, Art. I, Sec. 3
      url: https://www.constituteproject.org/constitution/United_States_of_America_1992?lang=en
      quote: "shall have no Vote, unless they be equally divided"  # 必須能在網址上逐字找到
      license: public law text, via Constitute Project
    admiralty: A1                       # 來源可靠度 A–F + 資訊可信度 1–6
    status: reviewed                    # proposed（提議）/ reviewed（已審核）/ disputed（有爭議）
    recorded_at: 2026-10-02             # 我們什麼時候記錄的（回測時避免偷看未來）
    derived_from: []                    # 由其他事實推導時，列出它們的 id
    note: ""
```

## 規則

- **已審核的 L0 必須附逐字引文**，或者用 `derived_from` 指出它是由哪些已審核事實推導出來的。
- 引文要能在網址的頁面上**逐字找到**（不分大小寫和空白）。`pmpol kb verify` 會實際抓頁面比對。
- 找不到可抓取的來源，或來源被擋（例如 parliament.uk 回傳 403），就維持 `proposed`，在 `note` 寫明原因。
- 各方說法互相矛盾、或無法查證的，標成 `disputed`，並給較低的 Admiralty 等級。不要選邊站。
- 規則改過的（例如俄羅斯 2020 年修憲），用 `valid_from` / `valid_to` 分成兩筆，不要直接覆蓋。
- Constitute Project 的英譯本可能落後於最新修憲。遇到這種情況改引官方網站（例如 kremlin.ru）。

## 怎麼新增或審核

```bash
pmpol kb validate          # 格式檢查（離線；pytest 也會跑）
pmpol kb verify            # 上網逐字比對引文，頁面快取在 data/kb_sources/
pmpol kb show senate       # 查詢：id、主詞或謂詞含有關鍵字的事實
```

1. 在對應的檔案加一筆，狀態先填 `proposed`。
2. 跑 `pmpol kb validate` 和 `pmpol kb verify`。
3. **兩人規則**（2026-10-04 起）：由**另一個人**審核。`pmpol review` 產生待審佇列（`reports/<日期>_review_queue.md`，依被多少推理證明引用排序）；審核者確認來源和引文後執行 `pmpol review approve <事實> --reviewer <名字> --note <理由>`（或 `reject`、`dispute`），指令會改狀態並在 `kb/reviews.yaml` 加一筆紀錄（審核者、日期、當時內容的雜湊），然後提交。
   - 機器（本系統的指令、AI 助手、bot）可以提出事實，不能審核；提出者不能審核自己的事實。
   - 審核後主詞、謂詞、值、有效期間或來源改了，審核就過期，要重審（`pmpol audit` 會列出）。
   - **多 Agent 預審**（2026-10-05 起）：人工審核前，三個互相看不到彼此結果的 AI 角色（來源、一致性、反方）先各自看過每筆事實，結果記在 `kb/agent_reviews.yaml`（綁定內容雜湊）。這只是準備：機器不能核准，狀態不會改變；佇列把 AI 有異議的事實排在前面、全數通過的標成「等人簽核」。執行方式：`pmpol review agents-export` → Claude Code 執行 `.claude/workflows/kb-review.js` → `pmpol review agents-ingest` → `pmpol review agents`（報告）。
   - 這套流程之前標成 `reviewed` 的事實沒有審核紀錄，算「舊制已審核」，也在佇列裡等人確認；它們都是 AI 助手整理並標記的。

## 誰在用這些事實

- 參議院模型的控制門檻（副總統 Vance 屬共和黨，所以 R 需要 50 席、D 需要 51 席）由 `us.senate.seats`、`us.senate.vp_tiebreak`、`us.vice_president` 算出來；`config/senate_2026.toml` 和知識庫不一致時會直接報錯。報告會列出用到的事實 id。
- 之後的推理證明物件，每一步都會引用這裡的事實 id。
